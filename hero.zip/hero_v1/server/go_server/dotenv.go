package main

import (
	"bufio"
	"log"
	"os"
	"strings"
)

// LoadDotEnv reads a .env file and sets environment variables.
//
// Does NOT override variables that already exist in the environment.
// This lets operators override .env values via shell:  C2_PASSWORD=xxx ./c2-server
//
// File format (same as Docker / Node dotenv):
//   KEY=value
//   KEY="quoted value with spaces"
//   KEY='single quoted'
//   # comment lines
//   empty lines are skipped
//
// Zero external dependencies — pure stdlib.
func LoadDotEnv(paths ...string) {
	for _, p := range paths {
		f, err := os.Open(p)
		if err != nil {
			continue // not found — try next path
		}
		scanner := bufio.NewScanner(f)
		count := 0
		for scanner.Scan() {
			line := strings.TrimSpace(scanner.Text())

			// Skip empty lines and comments
			if line == "" || strings.HasPrefix(line, "#") {
				continue
			}

			// Split on first = only
			eqIdx := strings.Index(line, "=")
			if eqIdx < 1 {
				continue // no KEY= found
			}

			key := strings.TrimSpace(line[:eqIdx])
			val := strings.TrimSpace(line[eqIdx+1:])

			// Strip surrounding quotes
			val = strings.TrimPrefix(val, "\"")
			val = strings.TrimSuffix(val, "\"")
			val = strings.TrimPrefix(val, "'")
			val = strings.TrimSuffix(val, "'")

			// Only set if NOT already in environment (shell takes priority)
			if os.Getenv(key) == "" {
				os.Setenv(key, val)
				count++
			}
		}
		f.Close()
		if count > 0 {
			log.Printf("[CONFIG] Loaded %d variables from %s", count, p)
		}
		return // use first file found
	}
}
