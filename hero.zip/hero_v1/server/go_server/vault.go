package main

// ============================================================
// ENCRYPTED DISK VAULT — hero/server/go_server/vault.go
//
// Problem: PSKHex sirf RAM vault mein hai (XOR encrypted).
// Server restart → RAM flush → PSKHex lost → agent reconnect REJECTED.
//
// Solution: AES-256-GCM encrypted vault.db on disk.
//
// BUGFIX (Bug #6 — Weak KDF): the original KDF was a single SHA256
//   hash over (master_key || context_string). A single SHA256 pass is
//   NOT a password-based key derivation function — GPUs do billions of
//   SHA256 per second, so if C2_ENC_KEY leaks (env var dump, log file,
//   process inspection) the vault falls in seconds.
//
// FIX: PBKDF2-HMAC-SHA256 with 600,000 iterations (OWASP 2023 minimum
//   for SHA-256). On the same hardware that did billions of SHA256/s,
//   PBKDF2 with 600k iterations slows brute-force to ~1.5k attempts/s
//   per GPU — a 7-orders-of-magnitude improvement.
//
//   We use golang.org/x/crypto/pbkdf2 — already a transitive dep via
//   gorilla/websocket (and the JWT lib), so zero new external deps.
//
// File format:
//   ┌──────────────────────────────────┐
//   │  4 bytes  — "HRV2" magic        │  version bump (was HRV1)
//   │  16 bytes — PBKDF2 salt          │  random per file, NEW
//   │  12 bytes — GCM nonce            │  random per write
//   │  N bytes  — AES-256-GCM ciphertext│  JSON: {pskHash: pskHex, ...}
//   │  16 bytes — GCM auth tag (inside) │  tamper detection
//   └──────────────────────────────────┘
//
// Magic version bump from "HRV1" → "HRV2" because the new KDF produces
// a different vault key for the same master key. Old vaults (HRV1)
// fail the magic check on load — operator must re-build agents once
// after upgrading. The log message makes this explicit.
//
// Init order (main.go):
//   LoadConfig() → serverConfig.EncryptionKey available
//   InitAgentStore() → initPSKVault() → initVaultDisk() → vaultDiskLoad()
//   SaveBuild() → vaultPut() → vaultDiskSave()
//   GetByPSKHash() → vaultGet() (now populated from disk on startup)
// ============================================================

import (
        "crypto/aes"
        "crypto/cipher"
        "crypto/rand"
        "crypto/sha256"
        "encoding/hex"
        "encoding/json"
        "fmt"
        "io"
        "log"
        "os"
        "sync"

        "golang.org/x/crypto/pbkdf2"
)

const (
        vaultMagic        = "HRV2"               // bumped from HRV1 — new KDF format
        vaultMagicSize    = 4
        vaultSaltSize     = 16                    // PBKDF2 salt — NEW in v2
        vaultNonceSize    = 12                    // GCM standard nonce size
        vaultKeyInfo      = "hero-vault-psk-v2"   // KDF context string (bumped)
        vaultFileName     = "vault.db"
        vaultPBKDF2Iters  = 600_000               // OWASP 2023 minimum for SHA-256
)

var (
        vaultDiskPath string
        vaultDiskMu   sync.Mutex
        vaultAESKey   [32]byte
        vaultSalt     [vaultSaltSize]byte   // current salt — written to file on save
        vaultReady    bool
)

// initVaultDisk — derive encryption key from C2_ENC_KEY via PBKDF2.
// Must be called AFTER LoadConfig() (needs serverConfig.EncryptionKey).
//
// The salt is generated ONCE per installation and stored in the vault
// file header (the first 16 bytes after the magic). initVaultDisk only
// generates a fresh salt if no vault file exists yet — on subsequent
// loads the salt is read from the existing file.
func initVaultDisk() {
        vaultDiskMu.Lock()
        defer vaultDiskMu.Unlock()

        if vaultReady {
                return
        }

        encKeyHex := serverConfig.EncryptionKey
        if len(encKeyHex) != 64 {
                log.Printf("[VAULT] ERROR: C2_ENC_KEY not 64 hex chars (%d chars) — disk vault disabled", len(encKeyHex))
                return
        }

        master, err := hex.DecodeString(encKeyHex)
        if err != nil {
                log.Printf("[VAULT] ERROR: C2_ENC_KEY hex decode failed: %v — disk vault disabled", err)
                return
        }

        // Determine vault path: <hero_root>/agent_db/vault.db
        heroRoot := os.Getenv("HERO_ROOT")
        if heroRoot == "" {
                heroRoot, _ = os.Getwd()
        }
        vaultDiskPath = fmt.Sprintf("%s/%s/%s", heroRoot, storeDir, vaultFileName)

        // Ensure agent_db/ directory exists
        vaultDir := fmt.Sprintf("%s/%s", heroRoot, storeDir)
        if err := os.MkdirAll(vaultDir, 0700); err != nil {
                log.Printf("[VAULT] ERROR: cannot create vault directory %s: %v", vaultDir, err)
                return
        }

        // ── Bug #6 fix: PBKDF2 with 600k iterations ────────────────────────
        // The salt is generated fresh here and PERSISTED in the vault file
        // (vaultDiskSave writes it after the magic). On subsequent loads,
        // vaultDiskLoad reads the salt from the existing file and calls
        // vaultDeriveKeyFromSalt() to get the matching key.
        //
        // For the FIRST run (no vault file yet) we generate a random salt
        // now and use it for any vault write that happens before a load.
        if _, err := io.ReadFull(rand.Reader, vaultSalt[:]); err != nil {
                log.Printf("[VAULT] ERROR: salt generation failed: %v — disk vault disabled", err)
                return
        }

        // Derive the key from (master, vaultSalt). vaultDeriveKeyFromSalt
        // also re-stores the salt (no-op here since we just set it above)
        // and updates vaultAESKey atomically.
        vaultDeriveKeyFromSalt(master, vaultSalt[:])

        // Zero the master immediately — don't leave it on the stack longer
        // than necessary.
        for i := range master {
                master[i] = 0
        }

        vaultReady = true
        log.Printf("[VAULT] Disk vault ready — %s (PBKDF2-HMAC-SHA256, %d iters)",
                vaultDiskPath, vaultPBKDF2Iters)
}

// vaultDeriveKeyFromSalt — recompute the vault key for the given salt.
// Called by initVaultDisk (with a freshly-generated salt) and by
// vaultDiskLoad (with the salt read from the existing vault file).
//
// Updates TWO pieces of package-level state:
//   1. vaultAESKey — the derived AES-256 key
//   2. vaultSalt   — the salt used (so vaultDiskSave can write it back)
//
// Must be called from inside the vaultDiskMu critical section.
func vaultDeriveKeyFromSalt(master []byte, salt []byte) {
        if len(salt) != vaultSaltSize {
                return
        }
        derived := pbkdf2.Key(master, salt, vaultPBKDF2Iters, 32, sha256.New)
        // Wipe the old key bytes before overwriting (best effort).
        for i := range vaultAESKey {
                vaultAESKey[i] = 0
        }
        copy(vaultAESKey[:], derived)
        // Track the salt that produced this key — vaultDiskSave writes it
        // into the file so the next load can re-derive the same key.
        copy(vaultSalt[:], salt)
}

// vaultDiskLoad — read + verify vault.db, return count of PSK entries.
// Called once at startup in InitAgentStore().
// Returns number of PSK entries in the vault (for the log message).
//
// ════════════════════════════════════════════════════════════════════════
// SECURITY HARDENING (Task A — memory dump defense)
// ════════════════════════════════════════════════════════════════════════
//
// PREVIOUS: vaultDiskLoad read vault.db, decrypted, and POPULATED the
//           in-memory pskVault XOR cache with all PSK entries. This meant
//           ALL plaintext PSKs were persistently in RAM (XOR-encrypted
//           with a per-process random key in same heap = vulnerable).
//
// NEW: vaultDiskLoad just verifies the file + counts entries for the log
//      message. It does NOT populate any RAM cache. PSKs are decrypted
//      on-demand by vaultDiskGetEntry (one at a time, wiped after use).
//
// ════════════════════════════════════════════════════════════════════════
func vaultDiskLoad() int {
        vaultDiskMu.Lock()
        defer vaultDiskMu.Unlock()

        if !vaultReady {
                return 0
        }

        data, err := os.ReadFile(vaultDiskPath)
        if err != nil {
                if !os.IsNotExist(err) {
                        log.Printf("[VAULT] WARN: read error: %v", err)
                }
                return 0 // fresh start — no vault yet, that's fine
        }

        // Minimum size: magic(4) + salt(16) + nonce(12) + GCM tag(16) = 48 bytes
        minSize := vaultMagicSize + vaultSaltSize + vaultNonceSize + 16
        if len(data) < minSize {
                log.Printf("[VAULT] WARN: vault file too small (%d bytes, min %d) — corrupted?",
                        len(data), minSize)
                return 0
        }

        // Verify magic bytes
        if string(data[:vaultMagicSize]) != vaultMagic {
                if string(data[:vaultMagicSize]) == "HRV1" {
                        log.Printf("[VAULT] WARN: legacy HRV1 vault detected (single-SHA256 KDF, removed in Bug #6 fix). "+
                                "The new KDF (PBKDF2 600k iters) is incompatible. Old vault is IGNORED. "+
                                "Re-build agents to repopulate the vault in the new format.")
                } else {
                        log.Printf("[VAULT] WARN: invalid magic (got %q) — corrupted or wrong version", data[:vaultMagicSize])
                }
                return 0
        }

        // ── Read salt + recompute vault key ──────────────────────────────────
        // The salt is baked into the file. We need to re-derive the in-memory
        // vaultAESKey from THIS salt + master key, otherwise decryption fails.
        salt := data[vaultMagicSize : vaultMagicSize+vaultSaltSize]
        masterHex := serverConfig.EncryptionKey
        master, err := hex.DecodeString(masterHex)
        if err != nil {
                log.Printf("[VAULT] ERROR: cannot re-derive key (C2_ENC_KEY hex decode failed): %v", err)
                return 0
        }
        vaultDeriveKeyFromSalt(master, salt)
        // Zero master immediately
        for i := range master {
                master[i] = 0
        }

        nonce := data[vaultMagicSize+vaultSaltSize : vaultMagicSize+vaultSaltSize+vaultNonceSize]
        ciphertext := data[vaultMagicSize+vaultSaltSize+vaultNonceSize:]

        // Decrypt with AES-256-GCM (using the salt-derived key)
        block, err := aes.NewCipher(vaultAESKey[:])
        if err != nil {
                log.Printf("[VAULT] ERROR: AES cipher init: %v", err)
                return 0
        }
        gcm, err := cipher.NewGCM(block)
        if err != nil {
                log.Printf("[VAULT] ERROR: GCM init: %v", err)
                return 0
        }

        plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
        if err != nil {
                log.Printf("[VAULT] ERROR: decrypt failed (wrong key or corrupted vault): %v", err)
                return 0
        }

        // Parse JSON payload just to COUNT entries (no RAM cache populated).
        var entries map[string]string
        if err := json.Unmarshal(plaintext, &entries); err != nil {
                log.Printf("[VAULT] ERROR: JSON parse failed: %v", err)
                // Wipe plaintext before returning
                for i := range plaintext {
                        plaintext[i] = 0
                }
                return 0
        }
        count := len(entries)

        // Wipe the plaintext JSON buffer immediately — defence in depth.
        // The buffer contained ALL PSKs in plaintext; we only needed the count.
        for i := range plaintext {
                plaintext[i] = 0
        }

        if count > 0 {
                log.Printf("[VAULT] Verified %d PSK entry(ies) in encrypted disk vault (PBKDF2) — decrypted on-demand per checkin",
                        count)
        }
        return count
}

// ════════════════════════════════════════════════════════════════════════
// ON-DEMAND ENTRY GET/PUT (Task A — replaces the in-memory cache)
// ════════════════════════════════════════════════════════════════════════
//
// These functions read/write vault.db on every call. The file format is:
//   [4B magic "HRV2"][16B salt][12B nonce][AES-GCM ciphertext of JSON map]
//
// The JSON map is {psk_hash_hex: psk_hex_value, ...}.
//
// For each call:
//   1. Read vault.db
//   2. AES-GCM decrypt the JSON map (briefly in RAM — wiped after use)
//   3. Find/insert the requested entry
//   4. For Put: re-encrypt + atomic write back
//   5. Wipe all plaintext buffers
//
// This is sub-millisecond per call (file read ~1ms + AES-GCM ~10µs).
// Acceptable because Layer 3 (this vault) is only hit on server restart
// before listeners are running — at most a handful of checkins per restart.

// vaultDiskGetEntry — read vault.db, decrypt, find specific PSK entry by hash.
// Returns (pskHex, true) if found, ("", false) otherwise.
// CALLER MUST zero the returned pskHex string after use (see agent.go).
func vaultDiskGetEntry(pskHash string) (string, bool) {
        vaultDiskMu.Lock()
        defer vaultDiskMu.Unlock()

        if !vaultReady {
                return "", false
        }

        data, err := os.ReadFile(vaultDiskPath)
        if err != nil {
                return "", false
        }

        // Verify magic
        if len(data) < vaultMagicSize+vaultSaltSize+vaultNonceSize+16 {
                return "", false
        }
        if string(data[:vaultMagicSize]) != vaultMagic {
                return "", false
        }

        // Salt is in header — we already have vaultAESKey derived from it
        // at startup (or via vaultDiskLoad). Just use it.
        nonce := data[vaultMagicSize+vaultSaltSize : vaultMagicSize+vaultSaltSize+vaultNonceSize]
        ciphertext := data[vaultMagicSize+vaultSaltSize+vaultNonceSize:]

        block, err := aes.NewCipher(vaultAESKey[:])
        if err != nil {
                return "", false
        }
        gcm, err := cipher.NewGCM(block)
        if err != nil {
                return "", false
        }

        plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
        if err != nil {
                log.Printf("[VAULT] on-demand decrypt failed for hash=%s...: %v",
                        safeHashPrefixPub(pskHash), err)
                return "", false
        }
        defer func() {
                // Wipe plaintext buffer after we're done — defence in depth.
                // The buffer contains ALL PSKs; we want to expose only the one
                // we're returning.
                for i := range plaintext {
                        plaintext[i] = 0
                }
        }()

        var entries map[string]string
        if err := json.Unmarshal(plaintext, &entries); err != nil {
                return "", false
        }

        pskHex, ok := entries[pskHash]
        return pskHex, ok
}

// vaultDiskPutEntry — read vault.db, add/update one PSK entry, write back.
// Atomic: tmp file + rename. Wipes plaintext buffers after use.
func vaultDiskPutEntry(pskHash, pskHex string) error {
        vaultDiskMu.Lock()
        defer vaultDiskMu.Unlock()

        if !vaultReady {
                return fmt.Errorf("vault not initialized")
        }

        // ── 1. Load existing entries (if vault file exists) ─────────────────
        entries := make(map[string]string)
        if data, err := os.ReadFile(vaultDiskPath); err == nil {
                if len(data) >= vaultMagicSize+vaultSaltSize+vaultNonceSize+16 &&
                        string(data[:vaultMagicSize]) == vaultMagic {
                        nonce := data[vaultMagicSize+vaultSaltSize : vaultMagicSize+vaultSaltSize+vaultNonceSize]
                        ciphertext := data[vaultMagicSize+vaultSaltSize+vaultNonceSize:]

                        // ── S-M1 FIX: aes.NewCipher / cipher.NewGCM errors used to be
                        // silently discarded with `block, _ := aes.NewCipher(...)`.
                        // If NewCipher fails (e.g., key wiped to all-zero by a
                        // concurrent vaultDeriveKeyFromSalt race, or key length wrong)
                        // `block` is nil → cipher.NewGCM(block) returns nil+err → the
                        // following gcm.Open(nil, ...) would nil-deref PANIC, taking
                        // down the whole server on a single bad vault read. Now we
                        // surface the failure as a FATAL log, disable the disk vault
                        // (vaultReady=false → all subsequent put/get calls become no-ops),
                        // and return a proper error so the caller knows the put failed.
                        block, err := aes.NewCipher(vaultAESKey[:])
                        if err != nil {
                                log.Printf("[VAULT] FATAL: aes.NewCipher failed during put-entry load: %v — disabling disk vault", err)
                                vaultReady = false
                                return fmt.Errorf("AES cipher init: %w", err)
                        }
                        gcm, err := cipher.NewGCM(block)
                        if err != nil {
                                log.Printf("[VAULT] FATAL: cipher.NewGCM failed during put-entry load: %v — disabling disk vault", err)
                                vaultReady = false
                                return fmt.Errorf("GCM init: %w", err)
                        }
                        if plaintext, derr := gcm.Open(nil, nonce, ciphertext, nil); derr == nil {
                                _ = json.Unmarshal(plaintext, &entries)
                                // Wipe plaintext buffer immediately — we've parsed it into
                                // the entries map, the buffer is no longer needed.
                                for i := range plaintext {
                                        plaintext[i] = 0
                                }
                        }
                }
        }

        // ── 2. Add/update the requested entry ───────────────────────────────
        entries[pskHash] = pskHex

        // ── 3. Serialize to JSON ───────────────────────────────────────────
        plaintext, err := json.Marshal(entries)
        if err != nil {
                return fmt.Errorf("JSON marshal: %w", err)
        }
        defer func() {
                // Wipe the plaintext JSON buffer after we're done encrypting.
                for i := range plaintext {
                        plaintext[i] = 0
                }
        }()

        // ── 4. AES-256-GCM encrypt ─────────────────────────────────────────
        block, err := aes.NewCipher(vaultAESKey[:])
        if err != nil {
                return fmt.Errorf("AES cipher: %w", err)
        }
        gcm, err := cipher.NewGCM(block)
        if err != nil {
                return fmt.Errorf("GCM init: %w", err)
        }

        nonce := make([]byte, vaultNonceSize)
        if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
                return fmt.Errorf("nonce generation: %w", err)
        }

        // Seal appends GCM tag to ciphertext automatically
        ciphertext := gcm.Seal(nil, nonce, plaintext, nil)

        // ── 5. Build file: magic(4) + salt(16) + nonce(12) + ciphertext(+tag) ──
        buf := make([]byte, 0, vaultMagicSize+vaultSaltSize+vaultNonceSize+len(ciphertext))
        buf = append(buf, vaultMagic...)
        buf = append(buf, vaultSalt[:]...)
        buf = append(buf, nonce...)
        buf = append(buf, ciphertext...)

        // ── 6. Atomic write: tmp + rename (prevents corruption on crash) ────
        tmpPath := vaultDiskPath + ".tmp"
        if err := os.WriteFile(tmpPath, buf, 0600); err != nil {
                return fmt.Errorf("write tmp: %w", err)
        }
        if err := os.Rename(tmpPath, vaultDiskPath); err != nil {
                os.Remove(tmpPath) // cleanup
                return fmt.Errorf("atomic rename: %w", err)
        }

        return nil
}

// safeHashPrefixPub — for log messages, only show first 12 chars of PSK hash.
// (Same logic as db.go::safeHashPrefix, but accessible from vault.go's
// package-level scope — they're in the same package so this is a duplicate
// name; Go allows it only if signatures match, so we use a different name.)
func safeHashPrefixPub(h string) string {
        if len(h) > 12 {
                return h[:12]
        }
        return h
}

// vaultDiskSave — DEPRECATED. Kept for backwards compat (any code that still
// calls it gets a no-op — the new vaultDiskPutEntry writes to disk immediately
// on every Put, so there's no RAM cache to flush).
//
// This is here so existing call sites (e.g., db.go's old SaveBuild) don't
// break compile if they still reference it. New code should use vaultDiskPutEntry.
func vaultDiskSave() error {
        // No-op — vaultDiskPutEntry persists immediately on every Put.
        // The RAM cache that this function used to flush no longer exists.
        return nil
}