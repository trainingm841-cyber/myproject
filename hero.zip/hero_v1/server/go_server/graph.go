// graph.go — Attack Graph + AD Map data plane (v8, Phase D/E)
//
// ARCHITECTURE (mirrors bof.go's "server is the honest broker" pattern):
//
//      agent  ──(admap / agraph JSON result)──▶ CompleteTask hook
//                                                └─ OnTaskResult() stores raw
//                                                   JSON per session (memory)
//      GUI    ──GET /api/graph/attack──────────▶ assemble graph from sessions
//                                                + stored agraph/admap evidence
//      GUI    ──GET /api/admap/{sessionID}─────▶ latest stored admap scan
//
// ATTACK GRAPH (Phase D) — compromised machines ONLY, no fantasy edges:
//   nodes : C2 root, every agent session (live + stale), the domains the
//           agents report membership in, and network neighbors (ARP cache /
//           established TCP) each agent actually observed.
//   edges : control (C2→agent), member (agent→domain), arp/tcp (agent→host).
//   Every neighbor node is backed by an observation the agent sent back —
//   nothing is inferred or invented.
//
// AD MAP (Phase E) — per-session domain view, kept SEPARATE from the attack
// graph: the agent's `admap` scan (DC + browse list) is stored verbatim and
// served to ui/graph/AdMapWindow.java which renders the domain topology.
//
// THREAD SAFETY: the store is mutex-guarded; sessions come from
// sessionMgr.GetAllSessions() (already RLock'd upstream).

package main

import (
        "encoding/json"
        "fmt"
        "log"
        "net"
        "net/http"
        "strings"
        "sync"
        "time"
)

// ============================================================
// Per-session recon store (admap + agraph results)
// ============================================================

type graphEntry struct {
        Updated time.Time `json:"updated"`
        Raw     string    `json:"raw"` // verbatim agent JSON
}

var graphStore = struct {
        sync.Mutex
        admaps  map[string]graphEntry // sessionID → latest admap result
        agraphs map[string]graphEntry // sessionID → latest agraph result
}{
        admaps:  make(map[string]graphEntry),
        agraphs: make(map[string]graphEntry),
}

// ── Bug #10 fix: graph cache with dirty flag ─────────────────────────────
//
// Problem: handleAttackGraph rebuilt the full GraphPayload on every poll.
// The UI polls /api/graph/attack every 5s. With 50 sessions + large
// agraph data, each rebuild is 50ms+ of CPU under the session RLock —
// a constant tax that adds up at scale.
//
// Fix: cache the serialized GraphPayload. Invalidate on:
//   - any new agraph result stored (OnTaskResult)
//   - any new admap result stored (OnTaskResult)
//   - any session_new / session_lost / session_update event
//     (handled via InvalidateGraphCache() called from those paths)
//
// Serve from cache when:
//   - cache is not dirty AND
//   - cache age < 10s (bounded staleness — even if no event fires,
//     the operator sees fresh data at most 10s late)
//
// Worst case (constant activity): rebuild every 10s, down from every 5s.
// Best case (idle dashboard): 1 rebuild per 10s, was 12/min, now 6/min.
var (
        graphCacheMu     sync.Mutex
        graphCacheBytes  []byte    // pre-serialized JSON, ready to write
        graphCacheTime   time.Time
        graphCacheDirty  = true    // start dirty → first request rebuilds
        graphCacheMaxAge = 10 * time.Second
)

// InvalidateGraphCache — marks the cached attack-graph payload as stale.
// Called from OnTaskResult (admap/agraph updates) and from session
// new/lost/update events. Next /api/graph/attack request will rebuild.
func InvalidateGraphCache() {
        graphCacheMu.Lock()
        graphCacheDirty = true
        graphCacheMu.Unlock()
}

// OnTaskResult — called by SessionManager.CompleteTask for EVERY completed
// task. Cheap string compare for 99.9% of traffic; only admap/agraph
// results are parsed and stored.
func OnTaskResult(sessionID, command, result string) {
        switch strings.ToLower(command) {
        case "admap":
                if !isKindJSON(result, "ad_map") {
                        return
                }
                graphStore.Lock()
                graphStore.admaps[sessionID] = graphEntry{Updated: time.Now().UTC(), Raw: result}
                graphStore.Unlock()
                InvalidateGraphCache()  // Bug #10: invalidate cache on store
                log.Printf("[GRAPH] AD map stored for session %s (%d bytes)", sessionID[:8], len(result))
        case "agraph":
                if !isKindJSON(result, "attack_node") {
                        return
                }
                graphStore.Lock()
                graphStore.agraphs[sessionID] = graphEntry{Updated: time.Now().UTC(), Raw: result}
                graphStore.Unlock()
                InvalidateGraphCache()  // Bug #10: invalidate cache on store
                log.Printf("[GRAPH] Attack-node enrichment stored for session %s (%d bytes)", sessionID[:8], len(result))
        case "trueip":
                // v9: agent's public/NAT IP for the dashboard chain
                // (source private → TRUE public → redirector). Result is a
                // bare IP string from the implant; validate strictly.
                ip := strings.TrimSpace(result)
                if ip != "" && net.ParseIP(ip) != nil {
                        sessionMgr.SetPublicIP(sessionID, ip)
                        InvalidateGraphCache()  // Bug #10: trueip changes session info → invalidate
                } else if ip != "" {
                        log.Printf("[GRAPH] trueip: ignoring non-IP result %q", shortID(sessionID))
                }
        }
}

// isKindJSON — reject error/echo text early: a valid result must parse as a
// JSON object carrying the expected "kind" tag.
func isKindJSON(result, kind string) bool {
        result = strings.TrimSpace(result)
        if len(result) == 0 || result[0] != '{' || strings.HasPrefix(result, "[ERR]") {
                return false
        }
        var probe struct {
                Kind string `json:"kind"`
        }
        if err := json.Unmarshal([]byte(result), &probe); err != nil {
                return false
        }
        return probe.Kind == kind
}

func GetAdMapEntry(sessionID string) (graphEntry, bool) {
        graphStore.Lock()
        defer graphStore.Unlock()
        e, ok := graphStore.admaps[sessionID]
        return e, ok
}

func GetAgraphEntry(sessionID string) (graphEntry, bool) {
        graphStore.Lock()
        defer graphStore.Unlock()
        e, ok := graphStore.agraphs[sessionID]
        return e, ok
}

// ============================================================
// Graph wire model (consumed by ui/graph/GraphData.java)
// ============================================================

type GNode struct {
        ID    string                 `json:"id"`
        Label string                 `json:"label"`
        Type  string                 `json:"type"` // c2 | agent | domain | dc | host
        Info  map[string]interface{} `json:"info"`
}

type GEdge struct {
        Src  string `json:"src"`
        Dst  string `json:"dst"`
        Kind string `json:"kind"` // control | member | dc | arp | tcp
}

type GraphPayload struct {
        Generated string  `json:"generated"`
        Mode      string  `json:"mode"`
        Nodes     []GNode `json:"nodes"`
        Edges     []GEdge `json:"edges"`
}

// ============================================================
// GET /api/graph/attack — assemble the compromised-machine graph
// ============================================================

// Per-session neighbor cap — keeps the JSON (and the canvas) sane even if
// an agent reports a noisy ARP cache. Real observations, bounded drawing.
const maxNeighborsPerSession = 48

func handleAttackGraph(w http.ResponseWriter, r *http.Request) {
        if r.Method != http.MethodGet {
                writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "GET only"})
                return
        }

        // ── Bug #10 fix: serve from cache when fresh ─────────────────────────
        // The UI polls /api/graph/attack every 5s. The rebuild is O(sessions
        // × neighbors) with multiple JSON unmarshals per session — 50ms+ at
        // 50 sessions. Cache the serialized payload and serve from cache
        // unless:
        //   (a) cache is marked dirty (admap/agraph/trueip just landed, or
        //       a session was added/removed/updated via InvalidateGraphCache)
        //   (b) cache is older than graphCacheMaxAge (10s) — bounded staleness
        //       so even if an event was missed, the operator still gets fresh
        //       data within 10s.
        graphCacheMu.Lock()
        cached := graphCacheBytes
        cacheTime := graphCacheTime
        dirty := graphCacheDirty
        graphCacheMu.Unlock()

        if !dirty && len(cached) > 0 && time.Since(cacheTime) < graphCacheMaxAge {
                w.Header().Set("Content-Type", "application/json")
                w.WriteHeader(http.StatusOK)
                w.Write(cached)
                return
        }

        // Cache miss — rebuild.
        payload := buildAttackGraph()

        // Serialize once, serve + cache the bytes so the next request is
        // a single w.Write(cached) call.
        payloadBytes, err := json.Marshal(payload)
        if err != nil {
                log.Printf("[GRAPH] cache marshal failed: %v — serving uncached", err)
                writeJSON(w, http.StatusOK, payload)
                return
        }

        graphCacheMu.Lock()
        graphCacheBytes = payloadBytes
        graphCacheTime = time.Now()
        graphCacheDirty = false
        graphCacheMu.Unlock()

        w.Header().Set("Content-Type", "application/json")
        w.WriteHeader(http.StatusOK)
        w.Write(payloadBytes)
}

// buildAttackGraph — pure function that walks the session list + graph store
// and assembles the GraphPayload. Called by handleAttackGraph on cache miss.
// Separated out so the cache layer is testable in isolation.
func buildAttackGraph() GraphPayload {
        nodes := map[string]*GNode{}
        edges := []GEdge{}
        addNode := func(n GNode) string {
                if _, dup := nodes[n.ID]; !dup {
                        nodes[n.ID] = &n
                }
                return n.ID
        }
        addEdge := func(src, dst, kind string) {
                // dedupe identical edges
                for _, e := range edges {
                        if e.Src == src && e.Dst == dst && e.Kind == kind {
                                return
                        }
                }
                edges = append(edges, GEdge{Src: src, Dst: dst, Kind: kind})
        }

        addNode(GNode{ID: "c2", Label: "C2 Server", Type: "c2",
                Info: map[string]interface{}{"note": "teamserver"}})

        for _, s := range sessionMgr.GetAllSessions() {
                // ── Agent node (the compromised machine) ─────────────────────────
                agentID := "sess:" + s.ID
                info := map[string]interface{}{
                        "hostname":    s.Hostname,
                        "username":    s.Username,
                        "ip":          s.IP,
                        "internal_ip": s.InternalIP,
                        "public_ip":   s.PublicIP,
                        "process":     s.Process,
                        "parent":      s.Parent,
                        "privs":       s.Privs,
                        "transport":   s.Transport,
                        "os":          s.OS,
                        "arch":        s.Arch,
                        "pid":         s.PID,
                        "first_seen":  s.FirstSeen,
                        "last_seen":   s.LastSeen,
                        "active":      s.Active,
                        "stale":       s.Stale,
                }
                domain := ""

                // ── Enrichment: agraph evidence (admin flag, domain, neighbors) ──
                var arpHosts, tcpHosts []string
                if ag, ok := GetAgraphEntry(s.ID); ok {
                        var node struct {
                                Domain  string `json:"domain"`
                                IsAdmin bool   `json:"is_admin"`
                                ARP     []struct {
                                        IP  string `json:"ip"`
                                        MAC string `json:"mac"`
                                } `json:"arp"`
                                TCP []struct {
                                        Local  string `json:"local"`
                                        Remote string `json:"remote"`
                                } `json:"tcp_established"`
                        }
                        if json.Unmarshal([]byte(ag.Raw), &node) == nil {
                                info["admin"] = node.IsAdmin
                                info["domain"] = node.Domain
                                info["enriched_at"] = ag.Updated
                                if node.Domain != "" {
                                        domain = node.Domain
                                }
                                for _, a := range node.ARP {
                                        if a.IP != "" {
                                                arpHosts = append(arpHosts, a.IP)
                                        }
                                }
                                for _, t := range node.TCP {
                                        if i := strings.LastIndex(t.Remote, ":"); i > 0 {
                                                tcpHosts = append(tcpHosts, t.Remote[:i])
                                        }
                                }
                        }
                }

                // Domain fallback from the admap scan (if agraph hasn't run yet)
                if domain == "" {
                        if am, ok := GetAdMapEntry(s.ID); ok {
                                var scan struct {
                                        Domain    string `json:"domain"`
                                        Workgroup bool   `json:"workgroup"`
                                }
                                if json.Unmarshal([]byte(am.Raw), &scan) == nil && !scan.Workgroup {
                                        domain = scan.Domain
                                }
                        }
                }
                // v9 FIX (phantom-domain bug): never draw a domain node when the
                // "domain" is actually the agent's own hostname/userdomain — that
                // duplicated the agent node on non-domain machines.
                if domain != "" && strings.EqualFold(domain, s.Hostname) {
                        domain = ""
                }

                addNode(GNode{ID: agentID, Label: s.Username + "@" + s.Hostname, Type: "agent", Info: info})

                // ── v9 FIX (honest path): draw the REAL beacon route ──────────
                relayed := s.InternalIP != "" && s.IP != "" && s.IP != s.InternalIP
                if relayed {
                        relayID := "relay:" + s.IP
                        addNode(GNode{ID: relayID, Label: s.IP, Type: "relay",
                                Info: map[string]interface{}{
                                        "role":        "redirector / pivot hop",
                                        "seen_by":     s.Hostname,
                                        "forwards_to": "teamserver",
                                }})
                        addEdge("c2", relayID, "uplink")
                        addEdge(relayID, agentID, "control")
                } else {
                        addEdge("c2", agentID, "control")
                }

                // ── Domain membership ────────────────────────────────────────────
                if domain != "" && !strings.EqualFold(domain, "WORKGROUP") {
                        domID := "dom:" + strings.ToLower(domain)
                        addNode(GNode{ID: domID, Label: domain, Type: "domain",
                                Info: map[string]interface{}{"kind": "reported domain"}})
                        addEdge(agentID, domID, "member")
                }

                // ── Observed neighbors (ARP first — stronger evidence) ───────────
                seen := map[string]bool{}
                added := 0
                neighbor := func(ip, kind string) {
                        if added >= maxNeighborsPerSession || ip == "" || seen[ip] || isLocalIP(ip, s.IP) {
                                return
                        }
                        seen[ip] = true
                        nid := "net:" + ip
                        addNode(GNode{ID: nid, Label: ip, Type: "host",
                                Info: map[string]interface{}{"source": kind, "seen_by": s.Hostname}})
                        addEdge(agentID, nid, kind)
                        added++
                }
                for _, ip := range arpHosts {
                        neighbor(ip, "arp")
                }
                for _, ip := range tcpHosts {
                        neighbor(ip, "tcp")
                }
        }

        payload := GraphPayload{
                Generated: time.Now().UTC().Format(time.RFC3339),
                Mode:      "attack",
                Nodes:     make([]GNode, 0, len(nodes)),
                Edges:     edges,
        }
        for _, n := range nodes {
                payload.Nodes = append(payload.Nodes, *n)
        }
        return payload
}

// isLocalIP — don't draw the agent's own address / loopback as neighbors.
func isLocalIP(ip, sessionIP string) bool {
        if ip == "127.0.0.1" || ip == "0.0.0.0" {
                return true
        }
        if sessionIP != "" && ip == sessionIP {
                return true
        }
        // multicast / broadcast
        if strings.HasSuffix(ip, ".255") || strings.HasPrefix(ip, "224.") || strings.HasPrefix(ip, "239.") {
                return true
        }
        return false
}

// ============================================================
// GET /api/admap/{sessionID} — latest stored AD map scan
// ============================================================

func handleGetAdMap(w http.ResponseWriter, r *http.Request) {
        if r.Method != http.MethodGet {
                writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "GET only"})
                return
        }
        sessionID := strings.TrimPrefix(r.URL.Path, "/api/admap/")
        if sessionID == "" {
                writeJSON(w, http.StatusBadRequest, map[string]string{"error": "session id required"})
                return
        }
        entry, ok := GetAdMapEntry(sessionID)
        if !ok {
                writeJSON(w, http.StatusNotFound, map[string]string{
                        "error": fmt.Sprintf("no AD map scan stored for session %s — run 'admap' first (right-click → Graphs → AD Map, or the console)", shortID(sessionID))})
                return
        }
        var raw json.RawMessage
        if json.Valid([]byte(entry.Raw)) {
                raw = json.RawMessage(entry.Raw)
        } else {
                raw = json.RawMessage("{}")
        }
        writeJSON(w, http.StatusOK, map[string]interface{}{
                "session_id": sessionID,
                "updated":    entry.Updated,
                "data":       raw,
        })
}

func shortID(id string) string {
        if len(id) > 8 {
                return id[:8]
        }
        return id
}

// ============================================================
// GET /api/graph/network (v10) — UNIFIED graph: attack + admap combined
// ============================================================
//
// Operator wanted ONE view instead of separate Attack Graph + AD Map
// windows. This endpoint returns the same node/edge model as
// /api/graph/attack, but for every live session it ALSO splices in the
// admap scan (domain + DC + every computer in the browse list) and the
// agraph enrichment (ARP/TCP neighbours). The result is a single picture
// showing:
//
//   C2 ──uplink──▶ relay ──control──▶ agent
//                                       │
//                                       ├── member ── domain ──── dc
//                                       │            │
//                                       │            ├── inventory ── computer1..N
//                                       │            └── trust     ── adjacent domain
//                                       ├── arp ── host (observed neighbour)
//                                       └── tcp ── host (observed neighbour)
//
// Every node is backed by real evidence the agent sent — nothing is
// inferred. The GUI renders it with the same GraphView engine; the
// domain/computer cluster sits around the agent that reported it.

type NetworkNode struct {
        ID    string                 `json:"id"`
        Label string                 `json:"label"`
        Type  string                 `json:"type"` // c2|relay|agent|domain|workgroup|dc|computer|host
        Info  map[string]interface{} `json:"info"`
}

type NetworkEdge struct {
        Src  string `json:"src"`
        Dst  string `json:"dst"`
        Kind string `json:"kind"` // control|uplink|member|dc|inventory|trust|arp|tcp
}

type NetworkPayload struct {
        Generated string         `json:"generated"`
        Mode      string         `json:"mode"` // "network"
        Nodes     []NetworkNode  `json:"nodes"`
        Edges     []NetworkEdge  `json:"edges"`
        Stats     NetworkStats   `json:"stats"`
}

type NetworkStats struct {
        Agents           int `json:"agents"`
        Relays           int `json:"relays"`
        Domains          int `json:"domains"`
        DCs              int `json:"dcs"`
        Computers        int `json:"computers"`
        ObservedHosts    int `json:"observed_hosts"`
        AdjacentDomains  int `json:"adjacent_domains"`
}

func handleNetworkGraph(w http.ResponseWriter, r *http.Request) {
        if r.Method != http.MethodGet {
                writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "GET only"})
                return
        }

        nodes := map[string]*NetworkNode{}
        edges := []NetworkEdge{}
        edgeSeen := map[string]bool{}

        addNode := func(n NetworkNode) string {
                if _, dup := nodes[n.ID]; !dup {
                        nodes[n.ID] = &n
                }
                return n.ID
        }
        addEdge := func(src, dst, kind string) {
                key := src + "|" + dst + "|" + kind
                if edgeSeen[key] {
                        return
                }
                edgeSeen[key] = true
                edges = append(edges, NetworkEdge{Src: src, Dst: dst, Kind: kind})
        }

        addNode(NetworkNode{ID: "c2", Label: "C2 Server", Type: "c2",
                Info: map[string]interface{}{"note": "teamserver"}})

        stats := NetworkStats{}

        for _, s := range sessionMgr.GetAllSessions() {
                // ── Agent node (the compromised machine) ─────────────────────
                agentID := "sess:" + s.ID
                info := map[string]interface{}{
                        "hostname":    s.Hostname,
                        "username":    s.Username,
                        "ip":          s.IP,
                        "internal_ip": s.InternalIP,
                        "public_ip":   s.PublicIP,
                        "process":     s.Process,
                        "parent":      s.Parent,
                        "privs":       s.Privs,
                        "transport":   s.Transport,
                        "os":          s.OS,
                        "arch":        s.Arch,
                        "pid":         s.PID,
                        "first_seen":  s.FirstSeen,
                        "last_seen":   s.LastSeen,
                        "active":      s.Active,
                        "stale":       s.Stale,
                }
                domain := ""

                // ── Enrichment: agraph evidence (admin flag, domain, neighbors) ──
                var arpHosts, tcpHosts []string
                if ag, ok := GetAgraphEntry(s.ID); ok {
                        var node struct {
                                Domain  string `json:"domain"`
                                IsAdmin bool   `json:"is_admin"`
                                ARP     []struct {
                                        IP  string `json:"ip"`
                                        MAC string `json:"mac"`
                                } `json:"arp"`
                                TCP []struct {
                                        Local  string `json:"local"`
                                        Remote string `json:"remote"`
                                } `json:"tcp_established"`
                        }
                        if json.Unmarshal([]byte(ag.Raw), &node) == nil {
                                info["admin"] = node.IsAdmin
                                info["enriched_at"] = ag.Updated
                                if node.Domain != "" {
                                        domain = node.Domain
                                        info["domain"] = node.Domain
                                }
                                for _, a := range node.ARP {
                                        if a.IP != "" {
                                                arpHosts = append(arpHosts, a.IP)
                                        }
                                }
                                for _, t := range node.TCP {
                                        if i := strings.LastIndex(t.Remote, ":"); i > 0 {
                                                tcpHosts = append(tcpHosts, t.Remote[:i])
                                        }
                                }
                        }
                }

                // ── Domain fallback from admap scan ──
                var admapData *struct {
                        Domain    string `json:"domain"`
                        Workgroup bool   `json:"workgroup"`
                        DC        *struct {
                                Name    string `json:"name"`
                                Address string `json:"address"`
                                Site    string `json:"site"`
                                Forest  string `json:"forest"`
                        } `json:"dc"`
                        Computers []struct {
                                Name    string `json:"name"`
                                Type    string `json:"type"`
                                Comment string `json:"comment"`
                                Version string `json:"version"`
                        } `json:"computers"`
                        Domains []string `json:"domains"`
                        Agent   string  `json:"agent"`
                        IsAdmin bool    `json:"is_admin"`
                        Total   int     `json:"total"`
                }

                if am, ok := GetAdMapEntry(s.ID); ok {
                        var scan struct {
                                Domain    string `json:"domain"`
                                Workgroup bool   `json:"workgroup"`
                                DC        *struct {
                                        Name    string `json:"name"`
                                        Address string `json:"address"`
                                        Site    string `json:"site"`
                                        Forest  string `json:"forest"`
                                } `json:"dc"`
                                Computers []struct {
                                        Name    string `json:"name"`
                                        Type    string `json:"type"`
                                        Comment string `json:"comment"`
                                        Version string `json:"version"`
                                } `json:"computers"`
                                Domains []string `json:"domains"`
                                Agent   string  `json:"agent"`
                                IsAdmin bool    `json:"is_admin"`
                                Total   int     `json:"total"`
                        }
                        if json.Unmarshal([]byte(am.Raw), &scan) == nil {
                                info["admap_at"] = am.Updated
                                info["computer_count"] = len(scan.Computers)
                                info["workgroup"] = scan.Workgroup
                                if domain == "" && !scan.Workgroup {
                                        domain = scan.Domain
                                        info["domain"] = domain
                                }
                                admapData = &scan
                        }
                }

                // v9 phantom-domain fix
                if domain != "" && strings.EqualFold(domain, s.Hostname) {
                        domain = ""
                        delete(info, "domain")
                }

                addNode(NetworkNode{ID: agentID, Label: s.Username + "@" + s.Hostname, Type: "agent", Info: info})
                stats.Agents++

                // ── Honest beacon path: C2 → relay → agent ──
                relayed := s.InternalIP != "" && s.IP != "" && s.IP != s.InternalIP
                if relayed {
                        relayID := "relay:" + s.IP
                        addNode(NetworkNode{ID: relayID, Label: s.IP, Type: "relay",
                                Info: map[string]interface{}{
                                        "role":        "redirector / pivot hop",
                                        "seen_by":     s.Hostname,
                                        "forwards_to": "teamserver",
                                }})
                        addEdge("c2", relayID, "uplink")
                        addEdge(relayID, agentID, "control")
                        stats.Relays++
                } else {
                        addEdge("c2", agentID, "control")
                }

                // ── Domain + DC + Computers (from admap scan) ──
                if admapData != nil {
                        var domID string
                        if domain != "" && !strings.EqualFold(domain, "WORKGROUP") {
                                domID = "dom:" + strings.ToLower(domain)
                                addNode(NetworkNode{ID: domID, Label: domain, Type: "domain",
                                        Info: map[string]interface{}{
                                                "kind":            "reported domain",
                                                "computer_count":  len(admapData.Computers),
                                                "total":           admapData.Total,
                                                "workgroup":       admapData.Workgroup,
                                        }})
                                addEdge(agentID, domID, "member")
                                stats.Domains++
                        } else if admapData.Workgroup {
                                domID = "wg:" + strings.ToLower(admapData.Domain)
                                addNode(NetworkNode{ID: domID, Label: admapData.Domain, Type: "workgroup",
                                        Info: map[string]interface{}{
                                                "computer_count": len(admapData.Computers),
                                                "total":          admapData.Total,
                                        }})
                                addEdge(agentID, domID, "member")
                        }

                        // DC node
                        if admapData.DC != nil && admapData.DC.Name != "" {
                                dcName := strings.TrimPrefix(admapData.DC.Name, "\\")
                                dcID := "dc:" + dcName
                                addNode(NetworkNode{ID: dcID, Label: dcName, Type: "dc",
                                        Info: map[string]interface{}{
                                                "address": admapData.DC.Address,
                                                "site":    admapData.DC.Site,
                                                "forest":  admapData.DC.Forest,
                                                "role":    "domain controller",
                                        }})
                                if domID != "" {
                                        addEdge(domID, dcID, "dc")
                                }
                                stats.DCs++
                        }

                        // Computers — every machine in the browse list
                        for _, c := range admapData.Computers {
                                if c.Name == "" {
                                        continue
                                }
                                pcID := "pc:" + c.Name
                                nodeType := "computer"
                                role := c.Type
                                if role == "dc" || role == "bdc" {
                                        nodeType = "dc"
                                }
                                _ = addNode(NetworkNode{ID: pcID, Label: c.Name, Type: nodeType,
                                        Info: map[string]interface{}{
                                                "role":    role,
                                                "comment": c.Comment,
                                                "version": c.Version,
                                        }})
                                if domID != "" {
                                        addEdge(domID, pcID, "inventory")
                                }
                                if nodeType == "computer" {
                                        stats.Computers++
                                }
                        }

                        // Adjacent/trusted domains
                        for i, d := range admapData.Domains {
                                if d == "" || (domain != "" && strings.EqualFold(d, domain)) {
                                        continue
                                }
                                adjID := fmt.Sprintf("adj:%d:%s", i, strings.ToLower(d))
                                addNode(NetworkNode{ID: adjID, Label: d, Type: "domain",
                                        Info: map[string]interface{}{"role": "adjacent/trusted domain"}})
                                if domID != "" {
                                        addEdge(domID, adjID, "trust")
                                }
                                stats.AdjacentDomains++
                        }
                } else if domain != "" && !strings.EqualFold(domain, "WORKGROUP") {
                        // agraph-only domain (no admap scan) — show membership edge
                        domID := "dom:" + strings.ToLower(domain)
                        addNode(NetworkNode{ID: domID, Label: domain, Type: "domain",
                                Info: map[string]interface{}{"kind": "reported domain"}})
                        addEdge(agentID, domID, "member")
                        stats.Domains++
                }

                // ── Observed network neighbours (ARP + TCP) ──
                seen := map[string]bool{}
                added := 0
                neighbor := func(ip, kind string) {
                        if added >= maxNeighborsPerSession || ip == "" || seen[ip] || isLocalIP(ip, s.IP) {
                                return
                        }
                        seen[ip] = true
                        nid := "net:" + ip
                        addNode(NetworkNode{ID: nid, Label: ip, Type: "host",
                                Info: map[string]interface{}{"source": kind, "seen_by": s.Hostname}})
                        addEdge(agentID, nid, kind)
                        added++
                        stats.ObservedHosts++
                }
                for _, ip := range arpHosts {
                        neighbor(ip, "arp")
                }
                for _, ip := range tcpHosts {
                        neighbor(ip, "tcp")
                }
        }

        payload := NetworkPayload{
                Generated: time.Now().UTC().Format(time.RFC3339),
                Mode:      "network",
                Nodes:      make([]NetworkNode, 0, len(nodes)),
                Edges:      edges,
                Stats:      stats,
        }
        for _, n := range nodes {
                payload.Nodes = append(payload.Nodes, *n)
        }
        writeJSON(w, http.StatusOK, payload)
}
