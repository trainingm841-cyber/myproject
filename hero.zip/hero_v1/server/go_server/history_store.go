package main

// history_store.go — Per-session text history files for operator reference
//
// ════════════════════════════════════════════════════════════════════════
// DESIGN RATIONALE (operator-driven redesign)
// ════════════════════════════════════════════════════════════════════════
//
// The previous SQLite-backed session persistence (sessions.db) auto-restored
// old sessions on server restart. This was WRONG for the operator workflow:
//
//   1. Operator restarts the server (after shutting it down last night)
//   2. Operator logs in
//   3. Operator expects to manually start the listener they want to use
//      (because the agent's baked config has the listener name + PSK)
//   4. Operator waits for agent to reconnect via that listener
//   5. Once reconnected, operator wants to see what tasks they ran last
//      night so they can pick up where they left off
//
// With auto-restore, step 3 was broken — old sessions appeared on the
// dashboard BEFORE the listener was even started, confusing the operator.
// The session was a ghost (no active checkin, no listener) — operator
// couldn't tell if the agent was actually back or not.
//
// NEW design:
//   - Server startup does NOT auto-restore sessions
//   - Agent reconnection creates a FRESH session (new UUID) in memory
//   - Per-session HISTORY FILES (text, human-readable) are written to
//     agent_db/history_<session_short>.log — one file per session, ever
//   - Operator can `cat agent_db/history_*.log` to see:
//       * Session metadata (hostname, username, OS, listener, IPs, etc.)
//       * Every task queued (command, args, priority, timestamp)
//       * Every task result (output, error, success, timestamp)
//   - Vault.db (PSK) STILL exists for agent reconnection verification
//   - psk_store.json STILL exists for build records (which agent built
//     for which listener — operator's pointer into agent_db/ files)
//
// File format (operator-friendly, grep-able, plain text):
//   ─────────────────────────────────────────────────────────────────
//   ═══ HERO C2 — Session History ═══
//   Session ID    : <uuid>
//   Hostname      : <hostname>
//   Username      : <username>
//   OS            : <os>
//   Listener      : <listener_id>
//   Internal IP   : <ip>
//   Public IP     : <ip>
//   Process       : <process> (parent: <parent>)
//   Privs         : <system|admin|user>
//   Sleep         : <Ns>, Jitter: <X>%
//   First Seen    : <timestamp>
//   Last Seen     : <timestamp>
//   Checkins      : <N>
//
//   ─── Task History ───
//
//   [<timestamp>] TASK #<id>  PRIORITY: <level>
//     Command: <cmd>
//     Args:    <args>
//     Status:  <queued|completed|cancelled>
//     Output:
//       <output text, indented>
//   ─────────────────────────────────────────────────────────────────
//
// The file is APPEND-ONLY for task entries. The header is rewritten when
// session metadata changes (e.g., new checkin updates Last Seen + Checkin
// count). Operator sees the latest state at the top + chronological task
// log below.
//
// WHY NOT ONE BIG FILE?
//   One-file-per-session means operator can `cat agent_db/history_<id>.log`
//   to see ONE agent's history without grepping through a giant log. The
//   8-char session prefix in filename makes tab-completion easy.
//
// CONCURRENCY:
//   Each history file has its own sync.Mutex (keyed by session ID). Two
//   concurrent task completions on the same session serialize properly.
//   Two DIFFERENT sessions write to different files in parallel — no
//   contention.
//
// ════════════════════════════════════════════════════════════════════════

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const historyDir = "agent_db"

// Per-session mutex — prevents interleaved writes when multiple goroutines
// complete tasks for the same session concurrently. Map keyed by full
// session ID (UUID), so different sessions never contend.
var (
	historyMuMu sync.Mutex
	historyMus  = make(map[string]*sync.Mutex)
)

func historyMuFor(sessionID string) *sync.Mutex {
	historyMuMu.Lock()
	defer historyMuMu.Unlock()
	mu, ok := historyMus[sessionID]
	if !ok {
		mu = &sync.Mutex{}
		historyMus[sessionID] = mu
	}
	return mu
}

func historyFilePath(sessionID string) string {
	short := sessionID
	if len(short) > 8 {
		short = short[:8]
	}
	return filepath.Join(historyDir, "history_"+short+".log")
}

// ensureHistoryDir — create agent_db/ on first call. Idempotent.
func ensureHistoryDir() {
	_ = os.MkdirAll(historyDir, 0700)
}

// writeSessionHeader — writes the session metadata block at the top of
// the history file. The header is REWRITTEN on every call (so updated
// Last Seen / Checkins / Public IP show through), but task entries
// (appended below) are preserved.
//
// Implementation:
//   1. Read existing file (if any) — separate header from task log
//   2. Write new header
//   3. Append old task log (everything below the "--- Task History ---" line)
//   4. If file doesn't exist, write header + empty task log section
//
// All operations are under the per-session mutex.
func writeSessionHeader(s *Session) {
	ensureHistoryDir()
	mu := historyMuFor(s.ID)
	mu.Lock()
	defer mu.Unlock()

	path := historyFilePath(s.ID)

	// Read existing task log (if file exists)
	var taskLog string
	if data, err := os.ReadFile(path); err == nil {
		content := string(data)
		// Find the task history separator
		idx := strings.Index(content, "─── Task History ───")
		if idx >= 0 {
			taskLog = content[idx:]
		}
	}

	// Build new header
	header := buildSessionHeaderBlock(s)

	// Combine: new header + (existing task log OR fresh task log section)
	var final string
	if taskLog != "" {
		final = header + "\n" + taskLog
	} else {
		final = header + "\n─── Task History ───\n\n"
	}

	// Atomic write: write to temp file then rename (no partial writes visible)
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, []byte(final), 0600); err != nil {
		// Best-effort — don't crash the server if disk is full / readonly
		return
	}
	_ = os.Rename(tmp, path)
}

func buildSessionHeaderBlock(s *Session) string {
	firstSeen := s.FirstSeen.Format("2006-01-02 15:04:05")
	lastSeen := s.LastSeen.Format("2006-01-02 15:04:05")
	jitterPct := 0.0
	if s.SleepTime > 0 {
		jitterPct = s.Jitter * 100
	}
	privs := s.Privs
	if privs == "" {
		privs = "unknown"
	}
	internalIP := s.InternalIP
	if internalIP == "" {
		internalIP = "(unknown)"
	}
	publicIP := s.PublicIP
	if publicIP == "" {
		publicIP = "(unknown)"
	}
	process := s.Process
	if process == "" {
		process = "(standalone)"
	}
	parent := s.Parent
	if parent == "" {
		parent = "(none)"
	}
	listener := s.ListenerID
	if listener == "" {
		listener = "(none)"
	}

	return strings.Join([]string{
		"═══════════════════════════════════════════════════════════",
		"  HERO C2 — Session History",
		"═══════════════════════════════════════════════════════════",
		fmt.Sprintf("Session ID    : %s", s.ID),
		fmt.Sprintf("Hostname      : %s", s.Hostname),
		fmt.Sprintf("Username      : %s", s.Username),
		fmt.Sprintf("OS            : %s", s.OS),
		fmt.Sprintf("Arch          : %s", s.Arch),
		fmt.Sprintf("Listener      : %s", listener),
		fmt.Sprintf("Internal IP   : %s", internalIP),
		fmt.Sprintf("Public IP     : %s", publicIP),
		fmt.Sprintf("Process       : %s (parent: %s)", process, parent),
		fmt.Sprintf("Privs         : %s", privs),
		fmt.Sprintf("Sleep         : %ds, Jitter: %.1f%%", s.SleepTime, jitterPct),
		fmt.Sprintf("First Seen    : %s", firstSeen),
		fmt.Sprintf("Last Seen     : %s", lastSeen),
		fmt.Sprintf("Checkins      : %d", s.CheckinNum),
		"═══════════════════════════════════════════════════════════",
	}, "\n")
}

// appendTaskQueued — append a "task queued" entry to the session's history file.
// Called from AddTask/AddTaskWithPriority after the task is added to the
// in-memory Tasks slice.
func appendTaskQueued(s *Session, t *Task) {
	mu := historyMuFor(s.ID)
	mu.Lock()
	defer mu.Unlock()

	path := historyFilePath(s.ID)
	entry := buildTaskEntry(t, false)
	appendToFile(path, entry)
}

// appendTaskResult — append a "task completed" entry showing the result.
// Called from CompleteTask after the task is marked completed in memory.
// Session ID is passed because the caller (CompleteTask) only has the ID,
// not the full Session pointer.
func appendTaskResult(sessionID string, t *Task) {
	mu := historyMuFor(sessionID)
	mu.Lock()
	defer mu.Unlock()

	path := historyFilePath(sessionID)
	entry := buildTaskEntry(t, true)
	appendToFile(path, entry)
}

// markSessionKilled — append a "session killed" entry to the history file
// when the operator manually kills the session. Does NOT delete the file
// — operator may still want to review what they did with this agent.
func markSessionKilled(sessionID string) {
	mu := historyMuFor(sessionID)
	mu.Lock()
	defer mu.Unlock()

	path := historyFilePath(sessionID)
	stamp := time.Now().UTC().Format("2006-01-02 15:04:05")
	entry := fmt.Sprintf("\n[%s] SESSION KILLED by operator\n", stamp)
	appendToFile(path, entry)
}

func buildTaskEntry(t *Task, withResult bool) string {
	stamp := t.Created.Format("2006-01-02 15:04:05")
	priName := "normal"
	switch t.Priority {
	case PriorityUrgent:
		priName = "urgent"
	case PriorityHigh:
		priName = "high"
	case PriorityLow:
		priName = "low"
	}
	var b strings.Builder
	b.WriteString(fmt.Sprintf("\n[%s] TASK #%s  PRIORITY: %s\n", stamp, t.ID, priName))
	b.WriteString(fmt.Sprintf("  Command: %s\n", t.Command))
	if t.Args != "" {
		// Truncate very long args in the log (full args are in the in-memory Task)
		args := t.Args
		if len(args) > 500 {
			args = args[:500] + "... (truncated)"
		}
		b.WriteString(fmt.Sprintf("  Args:    %s\n", args))
	} else {
		b.WriteString("  Args:    \n")
	}
	if withResult {
		b.WriteString(fmt.Sprintf("  Status:  %s\n", t.Status))
		if t.Completed.IsZero() {
			// Defensive — should always be set on result path
			b.WriteString("  Completed: (missing)\n")
		} else {
			b.WriteString(fmt.Sprintf("  Completed: %s\n", t.Completed.Format("2006-01-02 15:04:05")))
		}
		if t.Result != "" {
			b.WriteString("  Output:\n")
			// Indent output lines so they're visually grouped under the task
			for _, line := range strings.Split(t.Result, "\n") {
				b.WriteString("    " + line + "\n")
			}
		} else {
			b.WriteString("  Output: (empty)\n")
		}
	} else {
		b.WriteString("  Status:  queued (waiting for next beacon)\n")
	}
	return b.String()
}

// appendToFile — open the file in append mode, write the entry, close.
// File is created (0600) if it doesn't exist. Errors are best-effort
// logged — we NEVER want history writes to crash the server.
func appendToFile(path, entry string) {
	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0600)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = f.WriteString(entry)
}
