package main

import (
        "encoding/json"
        "log"
        "net/http"
        "strings"
        "sync"
        "time"

        "github.com/gorilla/websocket"
)

var upgrader = websocket.Upgrader{
        CheckOrigin: func(r *http.Request) bool {
                // Only allow connections from:
                // 1. Non-browser clients (JavaFX HTTP client) don't send Origin header
                // 2. Localhost for development
                // 3. Same-origin (production domain matching Host header)
                origin := r.Header.Get("Origin")
                if origin == "" {
                        return true // Non-browser client (JavaFX, curl, etc.)
                }
                if strings.HasPrefix(origin, "http://localhost") ||
                        strings.HasPrefix(origin, "http://127.0.0.1") ||
                        strings.HasPrefix(origin, "https://localhost") ||
                        strings.HasPrefix(origin, "https://127.0.0.1") {
                        return true
                }
                return strings.HasPrefix(origin, r.Host)
        },
}

func SetupWSRoute(mux *http.ServeMux) {
        mux.HandleFunc("GET /api/ws", handleWS)
}

func handleWS(w http.ResponseWriter, r *http.Request) {
        // Auth via query param or header
        token := r.URL.Query().Get("token")
        if token == "" {
                authHeader := r.Header.Get("Authorization")
                token = strings.TrimPrefix(authHeader, "Bearer ")
        }
        if ok, _, _ := ValidateJWT(token); !ok {
                http.Error(w, "unauthorized", http.StatusUnauthorized)
                return
        }

        conn, err := upgrader.Upgrade(w, r, nil)
        if err != nil {
                log.Printf("[WS] Upgrade failed: %v", err)
                return
        }
        defer conn.Close()

        // Event channel for this client. 256 buffer — build_progress streams
        // ~100 events per build; a client briefly falling behind must not lose
        // events via the broadcast drop path (select/default in BroadcastEvent).
        eventCh := make(chan WsEvent, 256)
        RegisterWSClient(eventCh)
        defer UnregisterWSClient(eventCh)

        log.Println("[WS] Client connected")

        // BUGFIX: the ping-pong goroutine wrote frames directly while the
        // event loop wrote frames from another goroutine — gorilla/websocket
        // panics on concurrent writes ("concurrent write to websocket
        // connection") and the reader-goroutine panic is not recovered,
        // taking down the whole server. All writes now go through one mutex.
        var wsWriteMu sync.Mutex
        writeMsg := func(msgType int, data []byte) error {
                wsWriteMu.Lock()
                defer wsWriteMu.Unlock()
                // Bounded writes: a stalled/dead client must never block the
                // event loop forever (gorilla blocks indefinitely without a
                // deadline — the per-conn eventCh then fills and the broadcast
                // path silently drops events for everyone's benefit).
                _ = conn.SetWriteDeadline(time.Now().Add(15 * time.Second))
                return conn.WriteMessage(msgType, data)
        }

        // Keepalive (FAST DISCONNECT HARDENING):
        //
        // OLD: server pinged every 30s, dead-man deadline was 90s. If the
        //      server died, the client could not detect the disconnect for
        //      up to 90 seconds — operator UI sat in "still connected"
        //      limbo, no live session updates, no error.
        //
        // NEW: ping every 10s, deadline 25s. Healthy clients still never
        //      notice (auto-pong per RFC 6455 happens on every ping). Dead
        //      TCP peers are now reaped in ≤25s instead of ≤90s — a 3.6×
        //      improvement in disconnect-detection latency, with zero impact
        //      on the steady-state traffic load (ping frames are 2 bytes).
        //
        // The 25s deadline is 2.5× the ping interval — survives one lost
        // ping (jittery network / GC pause on client) without a false
        // disconnect, but reaps genuinely dead peers within a reasonable
        // window. Tightening further (e.g. 15s deadline with 5s ping) would
        // cause false-disconnect storms on busy networks.
        //
        // No behavior change on the happy path — this is purely a liveness
        // tuning adjustment. Pong handler still extends the deadline on every
        // pong, and any client-initiated traffic (subscribe command, ping)
        // also refreshes the deadline via the read-goroutine's
        // SetReadDeadline call below.
        const (
                pingInterval = 10 * time.Second
                pongWait     = 25 * time.Second
        )
        _ = conn.SetReadDeadline(time.Now().Add(pongWait))
        conn.SetPongHandler(func(string) error {
                return conn.SetReadDeadline(time.Now().Add(pongWait))
        })

        // Read goroutine - handle pings and client commands
        go func() {
                defer conn.Close()
                for {
                        _, msg, err := conn.ReadMessage()
                        if err != nil {
                                return
                        }
                        _ = conn.SetReadDeadline(time.Now().Add(pongWait)) // any traffic counts
                        // Client can send ping or subscribe commands
                        if string(msg) == "ping" {
                                _ = writeMsg(websocket.TextMessage, []byte("pong"))
                                continue
                        }
                        // Typed event subscription:
                        // Client sends: {"action":"subscribe","events":["task_result","session_new"]}
                        // Client sends: {"action":"subscribe","events":[]}  ← clears filter (receive all)
                        var cmd struct {
                                Action string   `json:"action"`
                                Events []string `json:"events"`
                        }
                        if json.Unmarshal(msg, &cmd) == nil && cmd.Action == "subscribe" {
                                SetWSClientSubscriptions(eventCh, cmd.Events)
                                if len(cmd.Events) == 0 {
                                        _ = writeMsg(websocket.TextMessage, []byte(`{"type":"subscribed","events":"all"}`))
                                } else {
                                        evJSON, _ := json.Marshal(cmd.Events)
                                        ack := append([]byte(`{"type":"subscribed","events":`), append(evJSON, '}')...)
                                        _ = writeMsg(websocket.TextMessage, ack)
                                }
                        }
                }
        }()

        // Server-side ping ticker (dead-man detector for dead TCP peers)
        go func() {
                ticker := time.NewTicker(pingInterval)
                defer ticker.Stop()
                for range ticker.C {
                        if err := writeMsg(websocket.PingMessage, nil); err != nil {
                                return // write failed → conn dead; read deadline reaps the rest
                        }
                }
        }()

        // Write goroutine - send events to client
        for event := range eventCh {
                data, err := json.Marshal(event)
                if err != nil {
                        continue
                }
                err = writeMsg(websocket.TextMessage, data)
                if err != nil {
                        log.Printf("[WS] Write error: %v", err)
                        break
                }
        }

        log.Println("[WS] Client disconnected")
}