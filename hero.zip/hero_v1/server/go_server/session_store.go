package main

// session_store.go — SQLite-backed session + task persistence
//
// Problem solved:
//   Server restart → in-memory SessionManager wiped → all sessions lost.
//   Agents that re-checkin get a BRAND NEW session — no task history,
//   no graph data, operator dashboard shows everything as new.
//
// Design:
//   Two tables in agent_db/sessions.db (separate from psk_store.json):
//     sessions — one row per session, all dashboard columns
//     tasks    — one row per task, foreign key session_id
//
//   On startup:  LoadPersistedSessions() → rebuild sessionMgr from disk.
//   On change:   PersistSession() / PersistTask() / MarkTaskDone() called
//                from AddSession, FindOrCreateSession, AddTask, CompleteTask.
//   On kill:     DeletePersistedSession() removes rows (operator killed it).
//
// OPSEC notes:
//   - sessions.db is created with 0600 permissions (owner-only).
//   - Crypto field (HKDF session keys) is NEVER written to disk —
//     it is session-scoped RAM-only state. Agents re-derive on next checkin.
//   - Task Result column is stored — needed for post-engagement reporting.
//     Operators who want zero-on-disk results should use the wipe command
//     after engagement (future: add /api/admin/wipe-task-results endpoint).
//   - No WAL mode — journal_mode=DELETE keeps a single .db file, no
//     .db-wal / .db-shm side-files that a scanner might notice.
//
// Dependencies:
//   modernc.org/sqlite — pure-Go SQLite, no CGO required.
//   Add to go.mod: require modernc.org/sqlite v1.35.0

import (
        "database/sql"
        "log"
        "os"
        "sync"
        "time"

        _ "modernc.org/sqlite"
)

const sessionDBPath = "agent_db/sessions.db"

var (
        sdb     *sql.DB
        sdbOnce sync.Once
        sdbMu   sync.Mutex
)

// initSessionDB — open (or create) sessions.db and run schema migrations.
// Called once from main() after InitSessions().
func initSessionDB() {
        sdbOnce.Do(func() {
                if err := os.MkdirAll("agent_db", 0700); err != nil {
                        log.Fatalf("[SESSDB] cannot create agent_db: %v", err)
                }
                db, err := sql.Open("sqlite", sessionDBPath)
                if err != nil {
                        log.Fatalf("[SESSDB] open failed: %v", err)
                }
                // Conservative settings: one writer at a time, no WAL side-files.
                db.SetMaxOpenConns(1)
                if _, err := db.Exec(`PRAGMA journal_mode=DELETE`); err != nil {
                        log.Printf("[SESSDB] WARN: pragma failed: %v", err)
                }
                if err := migrateSessionDB(db); err != nil {
                        log.Fatalf("[SESSDB] migration failed: %v", err)
                }
                sdb = db
                log.Printf("[SESSDB] sessions.db ready at %s", sessionDBPath)
        })
}

func migrateSessionDB(db *sql.DB) error {
        _, err := db.Exec(`
        CREATE TABLE IF NOT EXISTS sessions (
                id            TEXT PRIMARY KEY,
                hostname      TEXT,
                os            TEXT,
                username      TEXT,
                arch          TEXT,
                ip            TEXT,
                pid           INTEGER,
                first_seen    DATETIME,
                last_seen     DATETIME,
                active        INTEGER,
                listener_id   TEXT,
                sleep_time    INTEGER,
                jitter        REAL,
                checkin_num   INTEGER,
                internal_ip   TEXT,
                public_ip     TEXT,
                process       TEXT,
                parent        TEXT,
                privs         TEXT,
                transport     TEXT
        );
        CREATE TABLE IF NOT EXISTS tasks (
                id            TEXT PRIMARY KEY,
                session_id    TEXT NOT NULL,
                command       TEXT,
                args          TEXT,
                status        TEXT,
                result        TEXT,
                priority      INTEGER DEFAULT 1,
                created       DATETIME,
                completed     DATETIME,
                FOREIGN KEY(session_id) REFERENCES sessions(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_tasks_session ON tasks(session_id);
        CREATE INDEX IF NOT EXISTS idx_tasks_status  ON tasks(status);
        `)
        return err
}

// ── Write helpers ─────────────────────────────────────────────────────────

// PersistSession — upsert a session row (INSERT OR REPLACE).
// Called under sessionMgr.mu — sdb writes use their own sdbMu so no deadlock.
func PersistSession(s *Session) {
        if sdb == nil { return }
        sdbMu.Lock()
        defer sdbMu.Unlock()
        _, err := sdb.Exec(`
        INSERT OR REPLACE INTO sessions
                (id,hostname,os,username,arch,ip,pid,
                 first_seen,last_seen,active,listener_id,
                 sleep_time,jitter,checkin_num,
                 internal_ip,public_ip,process,parent,privs,transport)
        VALUES  (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
                s.ID, s.Hostname, s.OS, s.Username, s.Arch, s.IP, s.PID,
                s.FirstSeen, s.LastSeen, boolInt(s.Active), s.ListenerID,
                s.SleepTime, s.Jitter, s.CheckinNum,
                s.InternalIP, s.PublicIP, s.Process, s.Parent, s.Privs, s.Transport,
        )
        if err != nil {
                log.Printf("[SESSDB] PersistSession error: %v", err)
        }
}

// PersistTask — insert a new task row.
func PersistTask(t *Task) {
        if sdb == nil { return }
        sdbMu.Lock()
        defer sdbMu.Unlock()
        _, err := sdb.Exec(`
        INSERT OR IGNORE INTO tasks (id,session_id,command,args,status,result,priority,created,completed)
        VALUES (?,?,?,?,?,?,?,?,?)`,
                t.ID, t.SessionID, t.Command, t.Args, t.Status, t.Result,
                t.Priority, t.Created, t.Completed,
        )
        if err != nil {
                log.Printf("[SESSDB] PersistTask error: %v", err)
        }
}

// MarkTaskDone — update status, result, completed for a finished task.
func MarkTaskDone(taskID, result string) {
        if sdb == nil { return }
        sdbMu.Lock()
        defer sdbMu.Unlock()
        _, err := sdb.Exec(`
        UPDATE tasks SET status='completed', result=?, completed=? WHERE id=?`,
                result, time.Now().UTC(), taskID,
        )
        if err != nil {
                log.Printf("[SESSDB] MarkTaskDone error: %v", err)
        }
}

// DeletePersistedSession — operator killed the session, remove from disk.
func DeletePersistedSession(sessionID string) {
        if sdb == nil { return }
        sdbMu.Lock()
        defer sdbMu.Unlock()
        // CASCADE deletes tasks too (FK defined above)
        if _, err := sdb.Exec(`DELETE FROM sessions WHERE id=?`, sessionID); err != nil {
                log.Printf("[SESSDB] DeletePersistedSession error: %v", err)
        }
}

// UpdatePersistedSessionCheckin — lightweight update on every checkin
// (last_seen, checkin_num, and refreshable recon fields).
func UpdatePersistedSessionCheckin(s *Session) {
        if sdb == nil { return }
        sdbMu.Lock()
        defer sdbMu.Unlock()
        _, err := sdb.Exec(`
        UPDATE sessions SET
                last_seen=?, checkin_num=?,
                internal_ip=?, process=?, parent=?, privs=?, transport=?,
                sleep_time=?, jitter=?
        WHERE id=?`,
                s.LastSeen, s.CheckinNum,
                s.InternalIP, s.Process, s.Parent, s.Privs, s.Transport,
                s.SleepTime, s.Jitter,
                s.ID,
        )
        if err != nil {
                log.Printf("[SESSDB] UpdateCheckin error: %v", err)
        }
}

// SetPersistedPublicIP — store discovered public IP.
func SetPersistedPublicIP(sessionID, ip string) {
        if sdb == nil { return }
        sdbMu.Lock()
        defer sdbMu.Unlock()
        if _, err := sdb.Exec(`UPDATE sessions SET public_ip=? WHERE id=?`, ip, sessionID); err != nil {
                log.Printf("[SESSDB] SetPublicIP error: %v", err)
        }
}

// ── Startup restore ───────────────────────────────────────────────────────

// LoadPersistedSessions — called once at startup AFTER initSessionDB().
// Rebuilds sessionMgr from sessions.db so operators see their sessions
// after a server restart. Crypto field is left nil — agents re-derive
// on their next checkin (FindOrCreateSession path).
//
// ════════════════════════════════════════════════════════════════════════
// CRITICAL BUG FIX — SetMaxOpenConns(1) + nested query = DEADLOCK
// ════════════════════════════════════════════════════════════════════════
//
// SYMPTOM (as reported by operator):
//   After server restart with ≥1 persisted session in sessions.db,
//   the server would HANG after printing:
//     [SESSDB] sessions.db ready at agent_db/sessions.db
//   and never reach:
//     [SESSDB] Restored N active session(s) from disk
//   nor bind port 5000 → client gets "Connection refused" on login.
//
// ROOT CAUSE:
//   initSessionDB() sets db.SetMaxOpenConns(1) — only ONE database
//   connection can be active at any time (this is the conventional
//   SQLite write-serialisation pattern, recommended by modernc.org/sqlite
//   to avoid the "database is locked" errors that pure-Go SQLite is
//   prone to).
//
//   The OLD LoadPersistedSessions() iterated `rows.Next()` for each
//   session AND called `loadTasksForSession(s.ID)` INSIDE the loop —
//   which calls `sdb.Query()` to fetch that session's tasks.
//
//   *sql.Rows holds its connection until rows.Close() is called.
//   With pool size 1, the inner `sdb.Query()` blocks FOREVER waiting
//   for the pool to return a connection that the outer rows is
//   still holding. Classic nested-query deadlock.
//
//   On a FRESH server install (empty sessions.db) the outer rows.Next()
//   loop body never executes, so no inner query is attempted, so no
//   deadlock — that's why first run worked but restart-after-sessions
//   hung.
//
// FIX:
//   Two-pass approach. Pass 1: iterate the sessions rows, build a list
//   of session IDs (still under the rows iteration, but no inner query).
//   rows.Close() releases the connection back to the pool. Pass 2:
//   iterate the session-ID list, call loadTasksForSession(id) for each
//   — now the inner query has the full pool (well, the 1 connection)
//   to itself.
//
//   This is a minimal, surgical fix — no schema migration, no behavior
//   change, no API change. The output is byte-identical to what the
//   old (broken) code would have produced on a system that DIDN'T
//   deadlock.
//
// ALTERNATIVE CONSIDERED + REJECTED:
//   Bumping SetMaxOpenConns to >1 would fix the deadlock but RE-INTRODUCE
//   the "database is locked" errors that the original author was avoiding.
//   Two-pass is strictly better — it preserves the single-writer invariant
//   AND fixes the deadlock.
//
// ════════════════════════════════════════════════════════════════════════
func LoadPersistedSessions() int {
        if sdb == nil { return 0 }

        // ── Pass 1: collect sessions into a slice (no inner query here) ───
        rows, err := sdb.Query(`
        SELECT id,hostname,os,username,arch,ip,pid,
               first_seen,last_seen,active,listener_id,
               sleep_time,jitter,checkin_num,
               internal_ip,public_ip,process,parent,privs,transport
        FROM sessions WHERE active=1`)
        if err != nil {
                log.Printf("[SESSDB] LoadPersistedSessions query error: %v", err)
                return 0
        }

        // Collect sessions into a slice. We CAN'T call loadTasksForSession
        // here — that would re-acquire the only pooled connection while
        // rows is still holding it. See the bug-fix comment above.
        type sessRow struct {
                s          Session
                firstSeen  string
                lastSeen   string
                activeInt  int
        }
        var collected []sessRow
        for rows.Next() {
                var r sessRow
                err := rows.Scan(
                        &r.s.ID, &r.s.Hostname, &r.s.OS, &r.s.Username, &r.s.Arch, &r.s.IP, &r.s.PID,
                        &r.firstSeen, &r.lastSeen, &r.activeInt, &r.s.ListenerID,
                        &r.s.SleepTime, &r.s.Jitter, &r.s.CheckinNum,
                        &r.s.InternalIP, &r.s.PublicIP, &r.s.Process, &r.s.Parent, &r.s.Privs, &r.s.Transport,
                )
                if err != nil {
                        log.Printf("[SESSDB] row scan error: %v", err)
                        continue
                }
                collected = append(collected, r)
        }
        rows.Close()  // ← CRITICAL: releases the connection back to the pool
                     //   BEFORE we try to acquire it again for task loading.

        // ── Pass 2: now safe to call loadTasksForSession for each session ──
        // The connection is back in the pool; inner queries will get it
        // without blocking.
        count := 0
        for _, r := range collected {
                s := r.s
                s.Active = r.activeInt == 1
                s.FirstSeen, _ = time.Parse(time.RFC3339Nano, r.firstSeen)
                s.LastSeen, _  = time.Parse(time.RFC3339Nano, r.lastSeen)
                s.Tasks = loadTasksForSession(s.ID)  // ← safe now, no nested query

                // Recompute stale deadline from persisted sleep/jitter
                computeStaleDeadline(&s)

                sessionMgr.mu.Lock()
                sessionMgr.sessions[s.ID] = &s
                sessionMgr.mu.Unlock()
                count++
        }
        log.Printf("[SESSDB] Restored %d active session(s) from disk", count)
        return count
}

func loadTasksForSession(sessionID string) []Task {
        rows, err := sdb.Query(`
        SELECT id,session_id,command,args,status,result,priority,created,completed
        FROM tasks WHERE session_id=? ORDER BY priority DESC, created ASC`, sessionID)
        if err != nil {
                return nil
        }
        defer rows.Close()
        var tasks []Task
        for rows.Next() {
                var t Task
                var createdStr, completedStr string
                if err := rows.Scan(
                        &t.ID, &t.SessionID, &t.Command, &t.Args,
                        &t.Status, &t.Result, &t.Priority,
                        &createdStr, &completedStr,
                ); err != nil {
                        continue
                }
                t.Created,   _ = time.Parse(time.RFC3339Nano, createdStr)
                t.Completed, _ = time.Parse(time.RFC3339Nano, completedStr)
                // Pending/sent tasks on restart: mark as cancelled so they
                // don't silently re-execute. Agent has moved on.
                if t.Status == "pending" || t.Status == "sent" {
                        t.Status = "cancelled"
                }
                tasks = append(tasks, t)
        }
        return tasks
}

// ── Utility ───────────────────────────────────────────────────────────────

func boolInt(b bool) int {
        if b { return 1 }
        return 0
}
