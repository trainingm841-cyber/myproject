package main

// ============================================================
// AGENT PSK STORE — hero/server/go_server/db.go
//
// Problem solved:
//   Server restart → RAM flush → listener PSKHex = ""
//   → Agent checkin → PSK hash match fails → "crypto mismatch"
//
// Fix:
//   Every agent build writes PSK + metadata to agent_db/psk_store.json
//   On checkin, if in-memory listener lookup fails → fall back to this store
//   Zero external dependencies — pure Go encoding/json
// ============================================================

import (
        "encoding/json"
        "log"
        "os"
        "sort"
        "sync"
        "time"
)

// AgentBuildRecord — har agent build ki poori kundli
//
// SECURITY NOTE: PSKHex is NEVER written to disk in plaintext.
// On disk (psk_store.json) only PSKHash is stored — the SHA256 of the PSK.
// PSKHex is only kept in RAM (in the builds map) after being loaded from
// the encrypted bbolt cert store. This prevents plaintext PSK exposure
// if an attacker gets read access to agent_db/.
type AgentBuildRecord struct {
        BuildID      string    `json:"build_id"`
        ListenerID   string    `json:"listener_id"`
        ListenerName string    `json:"listener_name"`
        PSKHex       string    `json:"-"`             // NEVER serialised to disk — RAM only
        PSKHash      string    `json:"psk_hash"`      // SHA256(PSK) hex — safe to store on disk
        AgentName    string    `json:"agent_name"`
        OS           string    `json:"os"`
        Arch         string    `json:"arch"`
        Format       string    `json:"format"`
        C2Host       string    `json:"c2_host"`
        C2Port       int       `json:"c2_port"`
        C2Protocol   string    `json:"c2_protocol"`
        BuiltAt      time.Time `json:"built_at"`
}

// AgentStore — thread-safe, disk-backed PSK registry
type AgentStore struct {
        mu     sync.RWMutex
        builds map[string]AgentBuildRecord // PSKHash → record
        path   string
}

// agentStore — package-level singleton, init karo InitAgentStore() se
var agentStore *AgentStore

const storeDir  = "agent_db"
const storePath = "agent_db/psk_store.json"

// InitAgentStore — server start pe ek baar call karo
// agent_db/ directory create karta hai agar nahi hai
// Existing store disk se load karta hai
//
// ════════════════════════════════════════════════════════════════════════
// SECURITY HARDENING (Task A — memory dump defense)
// ════════════════════════════════════════════════════════════════════════
//
// PREVIOUS DESIGN (vulnerable):
//   pskVault was an in-memory map[string][]byte holding XOR-encrypted PSKs.
//   The XOR key was a per-process random 32-byte value stored in pskVault.key.
//   PROBLEM: both the XOR key AND the encrypted PSK blobs lived in the SAME
//   process heap. An attacker who could dump process memory (e.g., via
//   /proc/<pid>/maps + /proc/<pid>/mem, gcore, gdb attach, OOM dump)
//   could XOR them back together to recover all plaintext PSKs.
//
// NEW DESIGN (defense in depth):
//   - The in-memory XOR cache is REMOVED ENTIRELY.
//   - PSKs are NEVER persistently in RAM. They exist only on disk
//     (vault.db, AES-256-GCM encrypted with a PBKDF2-derived key).
//   - On SaveBuild: vaultDiskPutEntry(hash, psk) writes a single PSK
//     to vault.db (decrypt-existing → add → encrypt-all → atomic write).
//   - On GetByPSKHash: vaultDiskGetEntry(hash) reads vault.db, decrypts
//     the entire JSON map (necessary because vault format is one blob),
//     finds the entry, returns it. The decrypted buffer is wiped after
//     the lookup.
//   - PSKHex is briefly in RAM only during:
//       1. SaveBuild → vaultDiskPutEntry → wipe after write
//       2. GetByPSKHash → vaultDiskGetEntry → return → caller wipes
//          after NewSessionCrypto derivation (handled in agent.go)
//   - Lifetime of decrypted PSK in RAM: sub-millisecond.
//
// WHAT REMAINS IN RAM:
//   - vaultAESKey [32]byte (the PBKDF2-derived AES-256 key)
//   - vaultSalt [16]byte (the PBKDF2 salt — public, in file header anyway)
//   - These are NECESSARY to decrypt vault.db on-demand. Without them,
//     every checkin would need to re-run PBKDF2 (150ms each).
//
// ATTACK SURFACE REMAINING:
//   If attacker dumps process memory, they get vaultAESKey + vaultSalt.
//   To recover any PSK they STILL need vault.db on disk (which contains
//   the AES-GCM encrypted PSK blobs). Without disk access, the AES key
//   alone is useless — there's nothing to decrypt.
//
//   Combined with the existing disk-side defenses (PBKDF2 600k iters,
//   per-install salt, 0600 permissions), this is significantly harder
//   than the previous "XOR cache in same RAM" design.
//
// ════════════════════════════════════════════════════════════════════════
func InitAgentStore() {
        initVaultDisk()   // derive AES key from C2_ENC_KEY, set vault path

        if err := os.MkdirAll(storeDir, 0700); err != nil {
                log.Fatalf("[DB] Cannot create agent_db directory: %v", err)
        }

        // Verify vault.db is loadable + count entries (no in-memory cache anymore).
        // vaultDiskLoad now just verifies the file + returns the count for the
        // log message. It does NOT populate any RAM cache.
        vaultCount := vaultDiskLoad()

        s := &AgentStore{
                builds: make(map[string]AgentBuildRecord),
                path:   storePath,
        }
        s.load()
        agentStore = s

        log.Printf("[DB] Agent store initialized — %d build record(s) in %s, %d PSK(s) in vault",
                len(s.builds), storePath, vaultCount)

        if vaultCount > 0 {
                log.Printf("[DB] PSKs are encrypted on disk (vault.db) — decrypted on-demand per checkin (no RAM cache)")
        }

        // Agar koi builds hain to summary print karo
        if len(s.builds) > 0 {
                for _, r := range s.builds {
                        log.Printf("[DB]   └── %s | %s/%s | listener=%s | built=%s",
                                r.AgentName, r.OS, r.Arch,
                                r.ListenerName,
                                r.BuiltAt.Format("2006-01-02 15:04:05"),
                        )
                }
        }
}

// load — disk se JSON load karo (internal, lock nahi chahiye — init mein call hota hai)
// Note: PSKHex is never on disk. After load, vault will be empty until
// agents are rebuilt. This is by design — PSKHex is session-scoped.
func (s *AgentStore) load() {
        data, err := os.ReadFile(s.path)
        if err != nil {
                if !os.IsNotExist(err) {
                        log.Printf("[DB] WARN: Could not read %s: %v", s.path, err)
                }
                // Fresh start — empty store, that's fine
                return
        }
        if err := json.Unmarshal(data, &s.builds); err != nil {
                log.Printf("[DB] WARN: Could not parse store (corrupted?): %v", err)
                // Backup corrupt file before overwriting
                _ = os.Rename(s.path, s.path+".bak")
                s.builds = make(map[string]AgentBuildRecord)
        }
}

// flush — builds map ko disk pe atomic write karo
// tmp file write → rename (prevents corruption on crash)
func (s *AgentStore) flush() error {
        data, err := json.MarshalIndent(s.builds, "", "  ")
        if err != nil {
                return err
        }
        tmp := s.path + ".tmp"
        if err := os.WriteFile(tmp, data, 0600); err != nil {
                return err
        }
        return os.Rename(tmp, s.path)
}

// ════════════════════════════════════════════════════════════════════════
// PSK VAULT — on-disk only (RAM cache REMOVED for security)
// ════════════════════════════════════════════════════════════════════════
//
// The previous pskVault (in-memory XOR-encrypted map) was REMOVED because
// it was vulnerable to process memory dumps — both the XOR key and the
// encrypted PSK blobs lived in the same heap, so an attacker with memory
// access could trivially recover all plaintext PSKs.
//
// NEW DESIGN: PSKs are NEVER persistently in RAM. They live only in
// vault.db (AES-256-GCM encrypted). vaultPut/vaultGet below are thin
// wrappers around vaultDiskPutEntry/vaultDiskGetEntry (defined in vault.go).
//
// Trade-off: every GetByPSKHash call now does a disk read + AES-GCM decrypt
// (sub-millisecond). This is acceptable because:
//   - Layer 1 (listener RAM PSK) handles the hot path during normal operation
//   - Layer 2 (global server key) handles the legacy fallback
//   - Layer 3 (this vault) is only hit on server restart before listener is
//     running — at most a handful of checkins per restart
//
// The decrypted PSKHex returned by vaultGet is in RAM only briefly — caller
// MUST zero it after NewSessionCrypto derivation (handled in agent.go).
//
// ════════════════════════════════════════════════════════════════════════

// vaultPut — encrypt + persist a single PSK to vault.db on disk.
// No RAM cache — disk is the single source of truth.
func vaultPut(pskHash, pskHex string) {
        if err := vaultDiskPutEntry(pskHash, pskHex); err != nil {
                log.Printf("[DB] ERROR: vaultPut failed for hash=%s...: %v",
                        safeHashPrefix(pskHash), err)
        }
}

// vaultGet — read + decrypt a single PSK from vault.db on disk.
// Returns ("", false) if not found or vault not ready.
// CALLER MUST zero the returned string after use (see agent.go::handleC2Checkin).
func vaultGet(pskHash string) (string, bool) {
        return vaultDiskGetEntry(pskHash)
}

// safeHashPrefix — for log messages, only show first 12 chars of PSK hash.
// Never log the full hash either — defence in depth.
func safeHashPrefix(h string) string {
        if len(h) > 12 {
                return h[:12]
        }
        return h
}

// SaveBuild — agent build hone ke baad call karo.
// PSKHash disk pe store hota hai (psk_store.json), PSKHex disk pe vault.db
// mein AES-256-GCM encrypted form mein store hota hai. RAM cache HATAYA gaya
// hai (Task A — memory dump defense). PSKHex RAM mein sirf microseconds ke
// liye rehta hai jab tak vaultDiskPutEntry encrypt karke disk pe likhta hai.
func (s *AgentStore) SaveBuild(r AgentBuildRecord) error {
        if r.PSKHash == "" || r.PSKHex == "" {
                return nil // sanity check
        }

        // PSKHex ko encrypted disk vault mein persist karo (no RAM cache).
        // vaultPut internally calls vaultDiskPutEntry which:
        //   1. Reads existing vault.db (if any), decrypts the JSON map
        //   2. Adds/updates this PSK entry
        //   3. Re-encrypts the entire JSON map with AES-256-GCM
        //   4. Atomic write (tmp + rename) back to vault.db
        // The decrypted JSON buffer is wiped inside vaultDiskPutEntry after use.
        vaultPut(r.PSKHash, r.PSKHex)

        // Disk pe bhejne se pehle PSKHex clear karo (json:"-" tag bhi hai,
        // lekin defence in depth: explicitly blank karo before flush)
        diskRecord := r
        diskRecord.PSKHex = "" // confirm: never on disk

        s.mu.Lock()
        s.builds[r.PSKHash] = diskRecord
        err := s.flush()
        s.mu.Unlock()
        if err != nil {
                log.Printf("[DB] ERROR: Could not save build record: %v", err)
        } else {
                log.Printf("[DB] Saved build: %s (%s/%s) listener=%s psk_hash=%s... [PSK in encrypted vault.db]",
                        r.AgentName, r.OS, r.Arch, r.ListenerName, r.PSKHash[:12])
                // vaultPut already wrote to disk above — no separate vaultDiskSave needed.
                // The old `vaultDiskSave()` call (which serialized the entire RAM cache)
                // is no longer applicable because there's no RAM cache to save.
        }
        return err
}

// GetByPSKHash — agent checkin pe PSKHash bhejta hai → PSK lo.
// Server restart ke baad bhi kaam karta hai — vault.db se PSKHex on-demand
// decrypt hota hai (no RAM cache). Caller MUST zero the returned PSKHex after
// NewSessionCrypto derivation (handled in agent.go::handleC2Checkin).
func (s *AgentStore) GetByPSKHash(pskHash string) (*AgentBuildRecord, bool) {
        s.mu.RLock()
        r, ok := s.builds[pskHash]
        s.mu.RUnlock()
        if !ok {
                return nil, false
        }
        record := r // copy
        // Inject PSKHex from encrypted vault (not from disk)
        if pskHex, found := vaultGet(pskHash); found {
                record.PSKHex = pskHex
        } else {
                // Vault miss — server was restarted without this PSK being re-built.
                // PSKHex cannot be recovered (never stored on disk).
                // Agent must be rebuilt to get a new PSK.
                log.Printf("[DB] WARN: PSK vault miss for hash=%s... — agent must be rebuilt", pskHash[:12])
                return nil, false
        }
        return &record, true
}

// GetAllBuilds — API endpoint ke liye sab builds, latest first
func (s *AgentStore) GetAllBuilds() []AgentBuildRecord {
        s.mu.RLock()
        defer s.mu.RUnlock()
        out := make([]AgentBuildRecord, 0, len(s.builds))
        for _, r := range s.builds {
                out = append(out, r)
        }
        // Sort by BuiltAt descending (latest first)
        sort.Slice(out, func(i, j int) bool {
                return out[i].BuiltAt.After(out[j].BuiltAt)
        })
        return out
}

// Count — kitne builds hain
func (s *AgentStore) Count() int {
        s.mu.RLock()
        defer s.mu.RUnlock()
        return len(s.builds)
}
