package models;

import java.util.Map;

public class ListenerInfo {
    public String id;
    public String name;
    public String protocol;
    public String host;
    public int port;
    public String domain;
    public String sni;
    public boolean active;
    public int domain_port;
    public int session_count;
    public String started_at;
    public Map<String, String> custom_headers;

    // Getters (backward compat)
    public String getId() { return id; }
    public String getName() { return name; }
    public String getProtocol() { return protocol; }
    public String getHost() { return host; }
    public int getPort() { return port; }
    public String getDomain() { return domain; }
    public String getSni() { return sni; }
    public boolean isActive() { return active; }
    public int getSession_count() { return session_count; }
    public String getStarted_at() { return started_at; }
    public Map<String, String> getCustom_headers() { return custom_headers; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setProtocol(String protocol) { this.protocol = protocol; }
    public void setHost(String host) { this.host = host; }
    public void setPort(int port) { this.port = port; }
    public void setDomain(String domain) { this.domain = domain; }
    public int getDomain_port() { return domain_port; }
    public void setDomain_port(int domain_port) { this.domain_port = domain_port; }
    public void setSni(String sni) { this.sni = sni; }
    public void setActive(boolean active) { this.active = active; }
    public void setSession_count(int session_count) { this.session_count = session_count; }
    public void setStarted_at(String started_at) { this.started_at = started_at; }
    public void setCustom_headers(Map<String, String> custom_headers) { this.custom_headers = custom_headers; }

    public String getAddress() {
        return protocol + "://" + host + ":" + port;
    }

    public String getCallback() {
        String h = (domain != null && !domain.isEmpty()) ? domain : host;
        int p = (domain != null && !domain.isEmpty() && domain_port > 0) ? domain_port : port;
        boolean isStd = ("https".equals(protocol) && p == 443) || ("http".equals(protocol) && p == 80);
        if (isStd) return protocol + "://" + h;
        return protocol + "://" + h + ":" + p;
    }
}