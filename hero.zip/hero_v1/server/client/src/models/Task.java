package models;

public class Task {
    private String id;
    private String session_id;
    private String command;
    private String args;
    private String status; // pending, sent, completed, failed
    private String result;
    private String created;
    private String completed;

    public String getId() { return id; }
    public String getSession_id() { return session_id; }
    public String getCommand() { return command; }
    public String getArgs() { return args; }
    public String getStatus() { return status; }
    public String getResult() { return result; }
    public String getCreated() { return created; }
    public String getCompleted() { return completed; }

    public void setId(String id) { this.id = id; }
    public void setSession_id(String session_id) { this.session_id = session_id; }
    public void setCommand(String command) { this.command = command; }
    public void setArgs(String args) { this.args = args; }
    public void setStatus(String status) { this.status = status; }
    public void setResult(String result) { this.result = result; }
    public void setCreated(String created) { this.created = created; }
    public void setCompleted(String completed) { this.completed = completed; }

    @Override
    public String toString() {
        return String.format("[%s] %s %s", status, command, args != null && !args.isEmpty() ? args : "");
    }
}
