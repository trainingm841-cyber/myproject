package models;

import java.util.List;

public class DashboardStats {
    private int total_sessions;
    private int active_sessions;
    private int total_listeners;
    private int active_listeners;
    private int pending_tasks;
    private String uptime;
    private String version;
    private List<ActivityEvent> recent_events;

    public static class ActivityEvent {
        public String time;
        public String type;
        public String message;
    }

    public int getTotal_sessions() { return total_sessions; }
    public int getActive_sessions() { return active_sessions; }
    public int getTotal_listeners() { return total_listeners; }
    public int getActive_listeners() { return active_listeners; }
    public int getPending_tasks() { return pending_tasks; }
    public String getUptime() { return uptime; }
    public String getVersion() { return version; }
    public List<ActivityEvent> getRecent_events() { return recent_events; }
}