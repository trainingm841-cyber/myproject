package models;

import java.time.Instant;
import java.util.List;

public class Session {
    private String id;
    private String hostname;
    private String os;
    private String username;
    private String arch;
    private String ip;
    private int pid;
    private String first_seen;
    private String last_seen;
    private boolean active;
    private boolean stale;    // true = missed checkins but reaper hasn't killed it (SLEEPING state)
    private String listener_id;
    private int sleep_time;
    private double jitter;
    private List<Task> tasks;
    private int checkin_num;
    // v9 dashboard chain columns (agent-reported truth + task-discovered)
    private String internal_ip;
    private String public_ip;
    private String process;
    private String parent_process;
    private String privs;
    private String transport;

    // No-arg constructor — used when NetworkGraphWindow opens with no active session
    public Session() {
        this.id = "none";
        this.hostname = "no-session";
        this.username = "—";
        this.os = "—";
        this.arch = "—";
    }

    // Getters
    public String getId() { return id; }
    public String getHostname() { return hostname; }
    public String getOs() { return os; }
    public String getUsername() { return username; }
    public String getArch() { return arch; }
    public String getIp() { return ip; }
    public int getPid() { return pid; }
    public String getFirst_seen() { return first_seen; }
    public String getLast_seen() { return last_seen; }
    public boolean isActive() { return active; }
    public boolean isStale() { return stale; }
    public String getListener_id() { return listener_id; }
    public int getSleep_time() { return sleep_time; }
    public double getJitter() { return jitter; }
    public List<Task> getTasks() { return tasks; }
    public int getCheckin_num() { return checkin_num; }
    public String getInternal_ip() { return internal_ip; }
    public String getPublic_ip() { return public_ip; }
    public String getProcess() { return process; }
    public String getParent_process() { return parent_process; }
    public String getPrivs() { return privs; }
    public String getTransport() { return transport; }
    /** The IP the teamserver actually sees = redirector hop when a pivot is in path. */
    public String getRedirectorIp() { return ip; }
    /** Hosting process for the Process column: "none" when the beacon runs standalone. */
    public String getProcessDisplay() {
        if (process == null || process.isBlank()) return "none";
        String lower = process.toLowerCase();
        if (lower.contains("hero_agent") || lower.contains("hero-agent")) return "none";
        return process;
    }
    public String getInternalIpDisplay() {
        return (internal_ip == null || internal_ip.isBlank()) ? ip : internal_ip;
    }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setHostname(String hostname) { this.hostname = hostname; }
    public void setOs(String os) { this.os = os; }
    public void setUsername(String username) { this.username = username; }
    public void setArch(String arch) { this.arch = arch; }
    public void setIp(String ip) { this.ip = ip; }
    public void setPid(int pid) { this.pid = pid; }
    public void setFirst_seen(String first_seen) { this.first_seen = first_seen; }
    public void setLast_seen(String last_seen) { this.last_seen = last_seen; }
    public void setActive(boolean active) { this.active = active; }
    public void setStale(boolean stale) { this.stale = stale; }
    public void setListener_id(String listener_id) { this.listener_id = listener_id; }
    public void setSleep_time(int sleep_time) { this.sleep_time = sleep_time; }
    public void setJitter(double jitter) { this.jitter = jitter; }
    public void setTasks(List<Task> tasks) { this.tasks = tasks; }
    public void setCheckin_num(int checkin_num) { this.checkin_num = checkin_num; }
    public void setInternal_ip(String v) { this.internal_ip = v; }
    public void setPublic_ip(String v) { this.public_ip = v; }
    public void setProcess(String v) { this.process = v; }
    public void setParent_process(String v) { this.parent_process = v; }
    public void setPrivs(String v) { this.privs = v; }
    public void setTransport(String v) { this.transport = v; }

    @Override
    public String toString() {
        return String.format("%s@%s (%s) [%s]", username, hostname, os, id.substring(0, 8));
    }
}
