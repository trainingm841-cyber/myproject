package models;

public class ImplantConfig {
    // ── TARGET ──
    public String name = "hero_implant";
    public String os = "windows";
    public String arch = "x64";
    public String outputFormat = "exe";
    public String output_name = "hero_implant";
    // ── COMMUNICATION ──
    public String listenerID = "";
    public String listener_id = "";
    public int sleepTime = 3600;
    public int sleep_time = 3600;
    public double jitter = 0.2;
    public String killDate = "";
    public String kill_date = "";
    public String user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
    public String fallback_domain = "";
    public boolean domain_front = false;
    public String cdn_provider = "";
    public int max_errors = 100;       // consecutive task errors before agent self-exits (MANDATORY)
    public int max_retries = 1000;     // consecutive connect failures before fallback (0 = unlimited, MANDATORY)
    public int backoff_base_ms = 60000;    // first reconnect wait (MANDATORY, >= 1000)
    public int backoff_max_ms = 14400000;  // backoff cap (MANDATORY, >= base)
    public String backoff_strategy = "exponential"; // exponential | fixed | random (MANDATORY)
    public String jitter_distribution = "uniform";  // uniform | gaussian | exponential (OPTIONAL)
    public String working_hours = "";               // "HH:MM-HH:MM" window (OPTIONAL)
    public int timeout = 30;
    // ── EVASION ──
    public String amsiBypass = "hwbp";
    public String amsi_bypass = "hwbp";
    public String etwPatch = "hwbp";
    public String etw_patch = "hwbp";
    public String sleepObfusc = "none";  // "none" or "shadow7"
    public String sleep_obfusc = "none";
    public String antiVM = "none";
    public String anti_vm = "none";
    public String syscall_method = "none";
    public boolean import_obfusc = false;
    public String string_encrypt = "none";
    public String binary_obfusc = "none";

    // ── Getters & Setters (backward compat) ──
    public String getListener_id() { return listener_id; } public void setListener_id(String v) { listener_id = v; listenerID = v; }
    public String getListenerID() { return listenerID; } public void setListenerID(String v) { listenerID = v; listener_id = v; }
    public String getOs() { return os; } public void setOs(String v) { os = v; }
    public String getArch() { return arch; } public void setArch(String v) { arch = v; }
    public String getOutput_format() { return outputFormat; } public void setOutput_format(String v) { outputFormat = v; output_name = v; }
    public String getOutput_name() { return output_name; } public void setOutput_name(String v) { output_name = v; name = v; }
    public String getName() { return name; } public void setName(String v) { name = v; output_name = v; }
    public int getSleep_time() { return sleepTime; } public void setSleep_time(int v) { sleepTime = v; sleep_time = v; }
    public int getSleepTime() { return sleepTime; } public void setSleepTime(int v) { sleepTime = v; sleep_time = v; }
    public double getJitter() { return jitter; } public void setJitter(double v) { jitter = v; }
    public String getKill_date() { return killDate; } public void setKill_date(String v) { killDate = v; kill_date = v; }
    public String getKillDate() { return killDate; } public void setKillDate(String v) { killDate = v; kill_date = v; }
    public String getUser_agent() { return user_agent; } public void setUser_agent(String v) { user_agent = v; }
    public String getFallback_domain() { return fallback_domain; } public void setFallback_domain(String v) { fallback_domain = v; }
    public boolean isDomain_front() { return domain_front; } public void setDomain_front(boolean v) { domain_front = v; }
    public String getCdn_provider() { return cdn_provider; } public void setCdn_provider(String v) { cdn_provider = v; }
    public int getMax_retries() { return max_retries; } public void setMax_retries(int v) { max_retries = v; }
    public int getTimeout() { return timeout; } public void setTimeout(int v) { timeout = v; }
    public String getAmsi_bypass() { return amsiBypass; } public void setAmsi_bypass(String v) { amsiBypass = v; amsi_bypass = v; }
    public String getAmsiBypass() { return amsiBypass; } public void setAmsiBypass(String v) { amsiBypass = v; amsi_bypass = v; }
    public String getEtw_patch() { return etwPatch; } public void setEtw_patch(String v) { etwPatch = v; etw_patch = v; }
    public String getEtwPatch() { return etwPatch; } public void setEtwPatch(String v) { etwPatch = v; etw_patch = v; }
    public String getSleep_obfusc() { return sleepObfusc; } public void setSleep_obfusc(String v) { sleepObfusc = v; sleep_obfusc = v; }
    public String getSleepObfusc() { return sleepObfusc; } public void setSleepObfusc(String v) { sleepObfusc = v; sleep_obfusc = v; }
    public String getAnti_vm() { return antiVM; } public void setAnti_vm(String v) { antiVM = v; anti_vm = v; }
    public String getAntiVM() { return antiVM; } public void setAntiVM(String v) { antiVM = v; anti_vm = v; }
    public String getSyscall_method() { return syscall_method; } public void setSyscall_method(String v) { syscall_method = v; }
    public boolean isImport_obfusc() { return import_obfusc; } public void setImport_obfusc(boolean v) { import_obfusc = v; }
    public String getString_encrypt() { return string_encrypt; } public void setString_encrypt(String v) { string_encrypt = v; }
    public String getBinary_obfusc() { return binary_obfusc; } public void setBinary_obfusc(String v) { binary_obfusc = v; }
}