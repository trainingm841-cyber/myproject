package ui;

import service.ApiService;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class ConnectDialog {

    private final Stage stage;
    private final ApiService api;
    private TextField urlField;
    private PasswordField passField;
    private Label statusLabel;
    private Button connectBtn;

    public ConnectDialog(Stage stage) {
        this.stage = stage;
        this.api = new ApiService();
    }

    public ApiService getApi() {
        return api;
    }

    public void show(Runnable onSuccess) {
        VBox root = new VBox(15);
        root.setPadding(new Insets(30));
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-color: #0f0f23;");

        // Title
        Label title = new Label("C2 FRAMEWORK");
        title.setStyle("-fx-text-fill: #00ff41; -fx-font-size: 28px; -fx-font-weight: bold; -fx-font-family: 'Consolas', monospace;");

        Label subtitle = new Label("v2.0 — JavaFX Client");
        subtitle.setStyle("-fx-text-fill: #666; -fx-font-size: 12px; -fx-font-family: 'Consolas', monospace;");

        // Server URL
        Label urlLabel = new Label("Server URL:");
        urlLabel.setStyle("-fx-text-fill: #cccccc; -fx-font-size: 13px;");

        urlField = new TextField("https://127.0.0.1:5000");
        urlField.setStyle("-fx-background-color: #1a1a2e; -fx-text-fill: #ffffff; -fx-font-size: 14px; -fx-padding: 8px; -fx-border-color: #333; -fx-border-radius: 4px;");
        urlField.setPrefWidth(350);

        // Password
        Label passLabel = new Label("Password:");
        passLabel.setStyle("-fx-text-fill: #cccccc; -fx-font-size: 13px;");

        passField = new PasswordField();
        passField.setPromptText("Enter operator password");
        passField.setStyle("-fx-background-color: #1a1a2e; -fx-text-fill: #ffffff; -fx-font-size: 14px; -fx-padding: 8px; -fx-border-color: #333; -fx-border-radius: 4px;");
        passField.setPrefWidth(350);

        // Connect button
        connectBtn = new Button("CONNECT");
        connectBtn.setStyle("-fx-background-color: #00ff41; -fx-text-fill: #000000; -fx-font-size: 14px; -fx-font-weight: bold; -fx-padding: 10px 30px; -fx-border-radius: 4px; -fx-cursor: hand;");
        connectBtn.setPrefWidth(350);
        connectBtn.setDefaultButton(true);

        // Status
        statusLabel = new Label("");
        statusLabel.setStyle("-fx-text-fill: #ff4444; -fx-font-size: 12px;");

        root.getChildren().addAll(title, subtitle, new Separator(), urlLabel, urlField, passLabel, passField, connectBtn, statusLabel);

        // Actions
        connectBtn.setOnAction(e -> handleConnect(onSuccess));
        passField.setOnAction(e -> handleConnect(onSuccess)); // Enter key

        Scene scene = new Scene(root, 450, 380);
        scene.getStylesheets().add(getClass().getResource("/dark-theme.css").toExternalForm());

        stage.setTitle("C2 Connect");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

        passField.requestFocus();
    }

    private void handleConnect(Runnable onSuccess) {
        String url = urlField.getText().trim();
        String pass = passField.getText().trim();

        if (url.isEmpty() || pass.isEmpty()) {
            statusLabel.setText("URL and password are required");
            return;
        }

        connectBtn.setDisable(true);  // Fix: This should be a final or effectively final reference
        statusLabel.setText("Connecting...");
        statusLabel.setStyle("-fx-text-fill: #ffaa00; -fx-font-size: 12px;");

        Thread t = new Thread(() -> {
            try {
                api.setBaseUrl(url);
                boolean ok = api.login(pass);

                Platform.runLater(() -> {
                    if (ok) {
                        statusLabel.setText("Connected!");
                        statusLabel.setStyle("-fx-text-fill: #00ff41; -fx-font-size: 12px;");
                        onSuccess.run();
                    } else {
                        statusLabel.setText("Authentication failed");
                        statusLabel.setStyle("-fx-text-fill: #ff4444; -fx-font-size: 12px;");
                        connectBtn.setDisable(false);
                    }
                });
            } catch (Exception ex) {
                // DIAGNOSTIC FIX: many IOException subtypes (SSLHandshakeException,
                // certain wrapped ConnectException instances, HttpTimeoutException
                // when the cause chain is shallow) return null from getMessage(),
                // producing the unhelpful "Connection failed: null" label.
                //
                // Build a useful message that always shows:
                //   1. The simple class name  (tells operator WHAT failed)
                //   2. The message if any     (tells WHY)
                //   3. The root cause class + message (often the real reason
                //      lives 1-2 levels down the cause chain on JDK 21+)
                //
                // Also dumps the full stack trace to stderr so the operator
                // can see the complete failure in the terminal that launched
                // ./bin/c2-client (very useful for post-restart diagnosis
                // when the server has come back but something is off — TLS
                // cert mismatch, port change, server still binding, etc).
                StringBuilder diag = new StringBuilder();
                diag.append(ex.getClass().getSimpleName());
                if (ex.getMessage() != null && !ex.getMessage().isBlank()) {
                    diag.append(": ").append(ex.getMessage());
                }
                Throwable root = ex;
                while (root.getCause() != null && root.getCause() != root) {
                    root = root.getCause();
                }
                if (root != ex) {
                    diag.append(" (root: ").append(root.getClass().getSimpleName());
                    if (root.getMessage() != null && !root.getMessage().isBlank()) {
                        diag.append(": ").append(root.getMessage());
                    }
                    diag.append(")");
                }
                String diagStr = diag.toString();
                System.err.println("[CONNECT] login failed — " + diagStr);
                ex.printStackTrace(System.err);
                final String finalDiag = diagStr;
                Platform.runLater(() -> {
                    statusLabel.setText("Connection failed: " + finalDiag);
                    statusLabel.setStyle("-fx-text-fill: #ff4444; -fx-font-size: 12px;");
                    connectBtn.setDisable(false);
                });
            }
        });
        t.setDaemon(true);
        t.start();
    }
}