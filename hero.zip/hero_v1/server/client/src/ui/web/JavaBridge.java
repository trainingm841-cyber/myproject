package ui.web;

import models.Session;
import models.Task;
import service.ApiService;
import javafx.application.Platform;
import netscape.javascript.JSObject;

/**
 * JavaBridge — bidirectional bridge between JavaFX backend and HTML/JS frontend.
 *
 * HTML/JS calls these methods via:
 *   window.javaBridge.methodName(args)
 *
 * Java calls JS via:
 *   webEngine.executeScript("window.appendLine(...)");
 *   webEngine.executeScript("window.loadGraph(...)");
 *
 * Registered in WebView by:
 *   JSObject win = (JSObject) engine.executeScript("window");
 *   win.setMember("javaBridge", new JavaBridge(session, api, engine, onCommand));
 *
 * IMPORTANT: All methods called FROM JS run on the JavaFX Application Thread.
 * Methods calling back INTO JS must also be on FX thread — wrap in Platform.runLater().
 */
public class JavaBridge {

    // ── Functional interfaces for callbacks ──────────────────────────────

    /** id = dedupe id from the JS outbox entry; input = raw command text. */
    public interface CommandCallback  { void onCommand(String id, String input); }
    public interface CancelCallback   { void onCancel(); }
    public interface CloseCallback    { void onClose(); }
    public interface NodeCallback     { void onNodeSelected(String nodeJson); }

    // ── State ─────────────────────────────────────────────────────────────

    private final Session          session;
    private final ApiService       api;
    private final javafx.scene.web.WebEngine engine;

    // Callbacks wired by SessionTab / NetworkGraphWindow
    private CommandCallback onCommand;
    private CancelCallback  onCancel;
    private CloseCallback   onClose;
    private NodeCallback    onNodeSelected;

    // ── Constructor ───────────────────────────────────────────────────────

    public JavaBridge(Session session, ApiService api,
                      javafx.scene.web.WebEngine engine) {
        this.session = session;
        this.api     = api;
        this.engine  = engine;
    }

    // ── Setters (called by SessionTab / GraphWindow) ──────────────────────

    public void setOnCommand(CommandCallback cb)       { this.onCommand      = cb; }
    public void setOnCancel(CancelCallback cb)         { this.onCancel       = cb; }
    public void setOnClose(CloseCallback cb)           { this.onClose        = cb; }
    public void setOnNodeSelected(NodeCallback cb)     { this.onNodeSelected = cb; }

    // Build-specific callbacks (set by BuildAgentDialog wrapper)
    public interface BuildStartCallback { void onStart(); }
    public interface BuildEndCallback   { void onEnd(); }
    private BuildStartCallback onBuildStart;
    private BuildEndCallback   onBuildEnd;
    public void setOnBuildStart(BuildStartCallback cb) { this.onBuildStart = cb; }
    public void setOnBuildEnd(BuildEndCallback cb)     { this.onBuildEnd   = cb; }

    // ═════════════════════════════════════════════════════════════════════
    //  JS → Java  (called from HTML via window.javaBridge.xxx())
    //  MUST be public, non-static — JavaFX JSObject reflection requires it
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Called when user hits Enter (or presses Send) in BeaconConsole.html.
     * id is the outbox entry id — SessionTab dedupes with it so the direct
     * path and the poller-driven outbox drain can never run a command twice.
     */
    public void onCommand(String id, String input) {
        if (onCommand != null) onCommand.onCommand(id, input);
    }

    /**
     * Called by SessionTab's outbox drain: JS could not reach the bridge
     * directly (JSObject member dead on some Linux WebViews), so Java pulled
     * the queued entries out of window.__cmdOutbox via executeScript and
     * delivers them here. Same dedupe rules apply.
     */
    public void deliverQueued(String id, String text) {
        if (onCommand != null) onCommand.onCommand(id, text);
    }

    /**
     * Called on Ctrl+C in BeaconConsole.html.
     * Mirrors: BeaconConsole.setOnCancelTask()
     */
    public void cancelTask() {
        if (onCancel != null) onCancel.onCancel();
    }

    /**
     * Called when user types 'exit' in BeaconConsole.html.
     * Mirrors: SessionTab C10 fix — onTabClose callback.
     */
    public void closeTab() {
        if (onClose != null) onClose.onClose();
    }

    /**
     * Called when operator clicks a node in Graph.html.
     * nodeJson = JSON string of the GraphData.Node.
     */
    public void onNodeSelected(String nodeJson) {
        if (onNodeSelected != null) onNodeSelected.onNodeSelected(nodeJson);
    }

    /**
     * Called by Graph.html to fetch graph data for a mode.
     * mode = "attack" | "network" | "admap"
     * Returns JSON string, or empty JSON on failure.
     */
    public String getGraphData(String mode) {
        try {
            return switch (mode) {
                case "network" -> api.getNetworkGraph();
                case "admap"   -> api.getAdMap(session.getId());
                default        -> api.getAttackGraph();
            };
        } catch (Exception e) {
            return "{\"nodes\":[],\"edges\":[],\"error\":\"" + escJson(e.getMessage()) + "\"}";
        }
    }

    /**
     * Called by Graph.html — send agraph or admap task to the selected agent.
     * Mirrors: NetworkGraphWindow.runTaskOnAgent() / runAdmapPoll()
     */
    public String sendGraphTask(String targetSessionId, String taskType) {
        try {
            String taskId = api.sendTask(targetSessionId, taskType, "");
            return "{\"taskId\":\"" + taskId + "\",\"status\":\"queued\"}";
        } catch (Exception e) {
            return "{\"error\":\"" + escJson(e.getMessage()) + "\"}";
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Java → JS  (called from SessionTab / GraphWindow to update HTML UI)
    //  All must be called on FX thread (Platform.runLater wraps as needed)
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Append a styled task result — mirrors OutputFormatter segments.
     * command = command name (for per-command formatting in JS)
     * rawResult = agent's raw output string
     * args = original command arguments
     */
    public void jsAppendTaskResult(String command, String rawResult, String args) {
        String safe = escJson(rawResult);
        String safeCmd = escJson(command);
        String safeArgs = escJson(args);
        exec("window.appendTaskResult('" + safeCmd + "','" + safe + "','" + safeArgs + "')");
    }

    /** Append [*] info line. */
    public void jsAppendInfo(String msg) {
        exec("window.appendInfo('" + escJson(msg) + "')");
    }

    /** Append [+] success line. */
    public void jsAppendSuccess(String msg) {
        exec("window.appendSuccess('" + escJson(msg) + "')");
    }

    /** Append [!] warning line. */
    public void jsAppendWarning(String msg) {
        exec("window.appendWarning('" + escJson(msg) + "')");
    }

    /** Append [-] error line. */
    public void jsAppendError(String msg) {
        exec("window.appendError('" + escJson(msg) + "')");
    }

    /** Update the Hero> prompt text. */
    public void jsSetPrompt(String text) {
        exec("window.setPromptText('" + escJson(text) + "')");
    }

    /** Show banner on console open. */
    public void jsShowBanner(String sessionId, String user, String host, String os, String arch) {
        exec(String.format("window.showBanner('%s','%s','%s','%s','%s')",
            escJson(sessionId), escJson(user), escJson(host), escJson(os), escJson(arch)));
    }

    /** Load or refresh graph with new JSON data. */
    public void jsLoadGraph(String graphJson) {
        // graphJson can be large — use executeScript with injected variable
        // to avoid single-line limit issues
        exec("window._gdata = " + graphJson + "; window.loadGraph(window._gdata)");
    }

    /** Update graph incrementally (preserves node positions). */
    public void jsUpdateGraph(String graphJson) {
        exec("window._gdata = " + graphJson + "; window.updateGraph(window._gdata)");
    }

    // ═════════════════════════════════════════════════════════════════════
    //  DIALOG-SPECIFIC METHODS (Task B Phase 1 — CreateListenerDialog)
    //
    // These methods are called by the HTML dialogs (loaded in WebView)
    // when the user interacts with them. Each method:
    //   1. Receives a JSON payload (or simple arg) from the JS side
    //   2. Runs the ApiService call on a background thread (NOT the FX
    //      thread — HTTP calls block for hundreds of ms)
    //   3. Fires a JS callback via executeScript when done:
    //        window.onListenerStarted()   → success
    //        window.onListenerError(msg)  → failure
    //   4. Optionally calls onClose callback (JavaFX Stage close)
    //
    // All methods are public + non-static (JSObject reflection requires it).
    // They run on the FX thread when called from JS — that's why each one
    // spawns a worker thread for the actual HTTP work.
    // ═════════════════════════════════════════════════════════════════════

    /**
     * submitListenerForm — called by CreateListenerDialog.html when the
     * user clicks "Start Listener". Spawns a background thread that:
     *   1. Calls api.createListener(json)
     *   2. On success: fires window.onListenerStarted() + onSuccess Runnable
     *   3. On error:   fires window.onListenerError(msg)
     *
     * Mirrors the original CreateListenerDialog.java::onStart() method
     * exactly — same callback contract, same JSON payload format.
     *
     * @param json the listener config JSON built by Alpine.js app.js
     */
    public void submitListenerForm(String json) {
        // Capture the engine ref — it might be nulled if dialog closes mid-call
        final javafx.scene.web.WebEngine eng = this.engine;
        final ApiService apiRef = this.api;
        new Thread(() -> {
            if (apiRef == null) {
                execJs(eng, "window.onListenerError('No API — preview mode')");
                return;
            }
            try {
                apiRef.createListener(json);
                // Success — fire callback into the WebView
                execJs(eng, "window.onListenerStarted()");
                // Also fire the JavaFX onSuccessListener Runnable (e.g., refresh listener list)
                if (onSuccessListener != null) {
                    Platform.runLater(onSuccessListener);
                }
            } catch (Exception ex) {
                // Error — surface the message to the HTML status bar
                String safe = escJson(ex.getMessage() != null ? ex.getMessage() : ex.toString());
                execJs(eng, "window.onListenerError('" + safe + "')");
            }
        }, "listener-submit").start();
    }

    /**
     * closeListenerDialog — called by CreateListenerDialog.html when the
     * user clicks "Cancel" or presses Esc. Triggers the onClose callback
     * (which the dialog wrapper sets up to call stage.close()).
     */
    public void closeListenerDialog() {
        if (onClose != null) onClose.onClose();
    }

    /**
     * setOnSuccessListener — sets the JavaFX Runnable to invoke when the
     * listener was successfully started (e.g., to refresh the listener list
     * in SessionsTab). Called by CreateListenerDialog wrapper after the
     * JavaBridge is constructed.
     */
    public void setOnSuccessListener(Runnable r) {
        // Re-purpose onClose for the success path too — wrapper handles both
        // Actually let's add a separate field for clarity
        this.onSuccessListener = r;
    }
    private Runnable onSuccessListener;

    // Helper to execute JS on the (possibly null) engine
    private void execJs(javafx.scene.web.WebEngine eng, String js) {
        if (eng == null) return;
        if (Platform.isFxApplicationThread()) {
            try { eng.executeScript(js); }
            catch (Exception ignored) {}
        } else {
            Platform.runLater(() -> {
                try { eng.executeScript(js); }
                catch (Exception ignored) {}
            });
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    //  BUILD AGENT DIALOG METHODS (Task B Phase 2)
    //
    //  These methods are called by the BuildAgentDialog HTML frontend
    //  (Alpine.js app.js). They handle:
    //    - Initial data load (listeners + profiles for the dropdowns)
    //    - Build submission (POST /api/builder/build with 10-min timeout)
    //    - Live progress streaming via WS "build_progress" events
    //    - Build result/error callbacks
    //  ═══════════════════════════════════════════════════════════════════

    /**
     * fetchInitialData — synchronously returns a JSON string containing
     * the operator's listeners and the server's malleable profiles.
     * Called by Alpine.js init() so the dropdowns populate on dialog open.
     *
     * Returns: '{"listeners":[...], "profiles":[...]}' on success,
     *          '{"listeners":[], "profiles":[], "error":"..."}' on failure.
     *
     * NOTE: This runs on the FX thread (called from JS). The HTTP calls
     * are quick (~50ms each on localhost), so we don't need a background
     * thread. If the server is slow, the dialog will block briefly
     * during init — acceptable trade-off for synchronous dropdown fill.
     */
    public String fetchInitialData() {
        if (api == null) {
            return "{\"listeners\":[],\"profiles\":[],\"error\":\"no API\"}";
        }
        StringBuilder sb = new StringBuilder("{\"listeners\":[");
        try {
            var listeners = api.getListeners();
            for (int i = 0; i < listeners.size(); i++) {
                if (i > 0) sb.append(",");
                var l = listeners.get(i);
                sb.append("{\"id\":\"").append(escJson(l.id))
                  .append("\",\"name\":\"").append(escJson(l.name))
                  .append("\",\"protocol\":\"").append(escJson(l.protocol))
                  .append("\",\"port\":").append(l.port)
                  .append("}");
            }
        } catch (Exception e) {
            // Log but don't fail — empty listeners list is OK
            System.err.println("[BuildAgentDialog] fetchListeners failed: " + e);
        }
        sb.append("],\"profiles\":[");
        try {
            var profiles = api.getProfiles();
            for (int i = 0; i < profiles.size(); i++) {
                if (i > 0) sb.append(",");
                var p = profiles.get(i);
                sb.append("{\"name\":\"").append(escJson(p.name))
                  .append("\",\"file_name\":\"").append(escJson(p.file_name))
                  .append("\",\"description\":\"").append(escJson(p.description != null ? p.description : ""))
                  .append("\"}");
            }
        } catch (Exception e) {
            System.err.println("[BuildAgentDialog] fetchProfiles failed: " + e);
        }
        sb.append("]}");
        return sb.toString();
    }

    /**
     * submitBuildForm — called by BuildAgentDialog.html when operator clicks
     * "Build Agent". Spawns a background thread (10-min timeout) that:
     *   1. Marks this dialog as the active build-progress receiver
     *      (so MainView's WS routing forwards events here)
     *   2. Calls api.buildImplantJson(json) — blocks until cargo build finishes
     *   3. On success: fires window.onBuildDone(resultJson) + onSuccessListener
     *   4. On error:   fires window.onBuildError(msg)
     *
     * The 10-minute timeout is set inside ApiService.buildImplantJson itself
     * (HttpRequest.timeout(Duration.ofMinutes(10))). This method just spawns
     * the thread so the FX thread isn't blocked.
     *
     * @param json the agent config JSON built by Alpine.js app.js
     */
    public void submitBuildForm(String json) {
        final javafx.scene.web.WebEngine eng = this.engine;
        final ApiService apiRef = this.api;
        // ── Mark this dialog as the active build-progress receiver ──
        // This is CRITICAL for WS progress events to reach the right dialog.
        // MainView calls BuildAgentDialog.onBuildProgress(pct, stage, detail)
        // which checks the static activeInstance pointer. Without this,
        // progress events are dropped and the progress bar never updates.
        if (onBuildStart != null) onBuildStart.onStart();
        new Thread(() -> {
            if (apiRef == null) {
                execJs(eng, "window.onBuildError('No API — preview mode')");
                if (onBuildEnd != null) onBuildEnd.onEnd();
                return;
            }
            try {
                String result = apiRef.buildImplantJson(json);
                String safeResult = escJson(result);
                execJs(eng, "window.onBuildDone('" + safeResult + "')");
                if (onSuccessListener != null) {
                    Platform.runLater(onSuccessListener);
                }
            } catch (Exception ex) {
                String safe = escJson(ex.getMessage() != null ? ex.getMessage() : ex.toString());
                execJs(eng, "window.onBuildError('" + safe + "')");
            } finally {
                // Clear activeInstance so a subsequent build from another
                // dialog can claim the progress stream
                if (onBuildEnd != null) onBuildEnd.onEnd();
            }
        }, "build-submit").start();
    }

    /**
     * jsUpdateBuildProgress — called by BuildAgentDialog wrapper when a
     * WS "build_progress" event arrives (via MainView → static onBuildProgress).
     * Forwards the update to the HTML UI by calling window.updateBuildProgress().
     *
     * @param pct    0-100 progress percentage
     * @param stage  'compiling'|'linking'|'stealth'|'done'|etc
     * @param detail human-readable line from cargo output
     */
    public void jsUpdateBuildProgress(int pct, String stage, String detail) {
        String safeStage   = escJson(stage != null ? stage : "");
        String safeDetail  = escJson(detail != null ? detail : "");
        execJs(engine, "window.updateBuildProgress(" + pct + ",'" + safeStage + "','" + safeDetail + "')");
    }

    /**
     * closeBuildDialog — called by BuildAgentDialog.html on Close button/Esc.
     * Triggers the onClose callback (Stage.close).
     */
    public void closeBuildDialog() {
        if (onClose != null) onClose.onClose();
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Helpers
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Execute JS on the FX thread.
     * If already on FX thread (normal case from SessionTab callbacks),
     * executes immediately. If called from a background thread, wraps
     * in Platform.runLater().
     */
    private void exec(String js) {
        if (Platform.isFxApplicationThread()) {
            try { engine.executeScript(js); }
            catch (Exception e) { /* WebView not ready yet — silently skip */ }
        } else {
            Platform.runLater(() -> {
                try { engine.executeScript(js); }
                catch (Exception e) { /* silently skip */ }
            });
        }
    }

    /**
     * Escape a string for safe embedding in a JS single-quoted string.
     *
     * OPSEC FIX (audit J-CR1): The OLD implementation used sequential
     * replace() calls — backslash first, then single-quote. The order
     * caused a double-escape: input `O'Brien\\` → step1: `O'Brien\\\\`
     * → step2: `O\\'Brien\\\\` → JS parses as `O\` + `Brien\\` → syntax
     * error OR XSS (attacker-controlled agent output can inject JS).
     *
     * NEW: use Gson's JSON string encoder (toJson). A JSON string IS a
     * valid JS string literal (both use `"..."` with `\"` escaping).
     * Gson handles ALL edge cases: unicode, control chars, quotes,
     * backslashes, newlines — single-pass, no order-of-replacement bug.
     * We strip the surrounding double-quotes and convert to single-quote
     * delimiters for JS single-quoted context.
     *
     * Alternative: could also use a char-by-char switch, but Gson is
     * already a dependency (pom.xml) and is battle-tested.
     */
    private static String escJson(String s) {
        if (s == null) return "";
        // Gson encodes as: "escaped string" (with double quotes)
        // We need: 'escaped string' (for JS single-quoted context)
        // JSON string escaping == JS string escaping for all practical chars
        String jsonStr = gson.toJson(s);  // returns "..." (with quotes)
        // Strip leading/trailing double-quotes, switch to single-quote delimiters
        // The inner content is already properly escaped by Gson
        if (jsonStr.length() >= 2 && jsonStr.startsWith("\"") && jsonStr.endsWith("\"")) {
            return jsonStr.substring(1, jsonStr.length() - 1);
        }
        // Fallback (shouldn't happen — Gson always wraps in quotes)
        return jsonStr;
    }

    /** Gson instance for JSON string encoding (thread-safe, reusable). */
    private static final com.google.gson.Gson gson = new com.google.gson.Gson();
}
