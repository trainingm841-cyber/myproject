/* ============================================================
 * HERO C2 — CreateListenerDialog Alpine.js application
 *
 * This file defines the listenerForm() function that Alpine.js
 * uses as the x-data root for the dialog. All form state, protocol
 * switching, validation, and submission happens here.
 *
 * Wiring (untouched from the original Java version):
 *   - When operator clicks "Start Listener", we build the JSON
 *     payload using the same field names + validation rules as
 *     the original CreateListenerDialog.java::buildJson()
 *   - We hand the JSON to window.javaBridge.submitListenerForm(json)
 *   - Java side (JavaBridge.java) calls ApiService.createListener(json)
 *   - On success: JavaBridge fires window.closeListenerDialogSuccess()
 *   - On error: JavaBridge fires window.showListenerError(message)
 *
 * All protocol schemas mirror the original buildHTTPS/buildDNS/etc
 * methods in CreateListenerDialog.java exactly — same field ids,
 * same default values, same required-vs-optional flags.
 * ============================================================ */

/**
 * Protocol schemas — mirrors CreateListenerDialog.java's static
 * field maps. Each entry defines:
 *   name:    Display name (matches the original String[] PROTOCOLS)
 *   hint:    Short description shown above the form
 *   note:    Warning/info shown below the hint
 *   fields:  Array of {id, label, default, required, options?}
 *            - For text fields: just {id,label,default,required}
 *            - For combo fields: add options:[...]
 *   protoId: The wire protocol id sent in JSON ("https","dns", etc.)
 *
 * The original Java code had separate buildHTTPS/buildDNS/etc
 * methods + an inferProto() switch. Here it's all declarative —
 * changing the protocol dropdown just swaps the schema, and
 * Alpine re-renders the form fields automatically.
 */
function listenerForm() {
  return {
    // ── Currently selected protocol (display name) ───────────────
    proto: 'HTTPS',

    // ── Form field values, keyed by id ──────────────────────────
    // Populated by init() based on the current protocol's schema.
    fields: {},

    // ── Status display ───────────────────────────────────────────
    status: '',     // '', 'starting', 'success', 'error'
    statusText: '',
    submitting: false,

    // ── Protocol schemas (declarative form definitions) ─────────
    // Each schema's fields array is checked on render — only fields
    // present in the current schema's array are shown.
    protocols: [
      {
        name: 'HTTPS',
        hint: 'Standard HTTPS listener. Most common egress. Encrypted over TLS 1.3.',
        note: '⚠  Agent connects directly to this listener. Ensure domain / nginx reverse proxy is set up.',
        protoId: 'https',
        fields: [
          {id: 'name',        label: 'Listener Name', default: 'https-main',          required: true},
          {id: 'host',        label: 'Bind Address',  default: '0.0.0.0',            required: false},
          {id: 'port',        label: 'Port',          default: '8443',               required: true},
          {id: 'domain',      label: 'Callback Domain', default: 'c2.example.com',   required: true},
          {id: 'domain_port', label: 'External Port', default: '443',                required: false},
          {id: 'sni',         label: 'SNI (TLS Host)', default: 'ajax.googleapis.com', required: false},
        ],
      },
      {
        name: 'DNS',
        hint: 'DNS beacon channel. Used when HTTPS/HTTP egress is blocked. Slow but resilient.',
        note: '⚠  Configure NS records for the DNS zone to point to this server\'s IP.',
        protoId: 'dns',
        fields: [
          {id: 'name',        label: 'Listener Name',  default: 'dns-longhaul',       required: true},
          {id: 'host',        label: 'DNS Zone Host',  default: '0.0.0.0',            required: true},
          {id: 'port',        label: 'DNS Port',       default: '53',                required: true},
          {id: 'record_type', label: 'Record Type',    default: 'TXT',    options: ['TXT','A','AAAA','MX'], required: false},
          {id: 'ttl',         label: 'TTL (seconds)',  default: '1',                 required: false},
          {id: 'domain',      label: 'Zone Domain',     default: 'dns.c2.example.com', required: true},
        ],
      },
      {
        name: 'SMB',
        hint: 'Peer-to-peer named pipe. C2 does NOT contact agent directly — parent beacon relays.',
        note: '⚠  Peer-to-peer only. A parent beacon with egress must relay traffic. No direct internet.',
        protoId: 'smb',
        fields: [
          {id: 'name',       label: 'Listener Name',  default: 'smb-pipe-01',         required: true},
          {id: 'host',       label: 'Pipe Name',      default: '\\\\.\\pipe\\mojo_5f3a9c', required: true},
          {id: 'direction',  label: 'Direction',      default: 'Server (bind)',
            options: ['Server (bind)', 'Client (connect to parent)'], required: false},
          {id: 'port',       label: 'Max Instances',   default: '5',                  required: false},
        ],
      },
      {
        name: 'TCP',
        hint: 'Peer-to-peer raw TCP. For internal pivots. C2 does NOT contact agent directly.',
        note: '⚠  Peer-to-peer only. Use for internal lateral movement pivots — not internet egress.',
        protoId: 'tcp',
        fields: [
          {id: 'name',       label: 'Listener Name',  default: 'tcp-pivot-01',       required: true},
          {id: 'host',       label: 'Bind Host',      default: '127.0.0.1',          required: true},
          {id: 'port',       label: 'Bind Port',      default: '4444',               required: true},
          {id: 'direction',  label: 'Direction',      default: 'Bind (local pivot)',
            options: ['Bind (local pivot)', 'Reverse (connect out)'], required: false},
        ],
      },
      {
        name: 'gRPC',
        hint: 'gRPC over HTTP/2 TLS. Traffic looks like microservice communication.',
        note: '⚠  Agent uses gRPC stub. Listener exposes the C2 service over HTTP/2 TLS.',
        protoId: 'grpc',
        fields: [
          {id: 'name',  label: 'Listener Name',    default: 'grpc-cloud',     required: true},
          {id: 'host',  label: 'Bind Address',     default: '0.0.0.0',        required: false},
          {id: 'port',  label: 'Port',             default: '443',            required: true},
          {id: 'sni',   label: 'SNI / Server Name', default: 'c2.example.com', required: false},
          {id: 'tls',   label: 'TLS Mode',         default: 'mTLS (mutual)',
            options: ['mTLS (mutual)', 'TLS (server only)', 'Plaintext (lab only)'], required: false},
        ],
      },
      {
        name: 'Graph API / O365',
        hint: 'Microsoft Graph API channel. Traffic routes via Microsoft servers — almost never blocked.',
        note: '⚠  Requires a registered Azure AD application with Mail.ReadWrite permission.',
        protoId: 'graph',
        fields: [
          {id: 'name',    label: 'Listener Name',  default: 'graph-o365',              required: true},
          {id: 'host',    label: 'Relay Host',     default: '0.0.0.0',                 required: true},
          {id: 'port',    label: 'Relay Port',    default: '5985',                    required: false},
          {id: 'domain',  label: 'Tenant Domain', default: 'target.onmicrosoft.com',  required: true},
          {id: 'channel', label: 'Graph Channel', default: 'Outlook (mail)',
            options: ['Outlook (mail)', 'OneDrive (files)', 'Teams (chat)', 'SharePoint'], required: false},
          {id: 'poll',    label: 'Poll Interval (s)', default: '60',                  required: false},
        ],
      },
      {
        name: 'DoH (DNS over HTTPS)',
        hint: 'DNS over HTTPS. Bypasses DNS monitoring — uses port 443, not 53.',
        note: '⚠  Configure your domain\'s DNS to point TXT queries at this server.',
        protoId: 'doh',
        fields: [
          {id: 'name',         label: 'Listener Name',  default: 'doh-cf',              required: true},
          {id: 'host',         label: 'Bind Address',   default: '0.0.0.0',             required: false},
          {id: 'port',         label: 'Port',           default: '443',                required: false},
          {id: 'domain',       label: 'C2 Domain',      default: 'sub.c2.example.com', required: true},
          {id: 'sni',          label: 'DoH Endpoint SNI', default: 'cloudflare-dns.com', required: false},
          {id: 'record_type',  label: 'Record Type',    default: 'TXT',
            options: ['TXT','A','AAAA'], required: false},
          {id: 'poll',         label: 'Poll Interval (s)', default: '30',              required: false},
        ],
      },
    ],

    // ── Lifecycle ────────────────────────────────────────────────
    init() {
      // Set up keyboard shortcut: Escape closes the dialog
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !this.submitting) {
          this.closeDialog();
        }
      });
      // Apply HTTPS schema by default
      this.onProtocolChange();
    },

    // ── Get current schema based on selected proto name ─────────
    currentSchema() {
      return this.protocols.find(p => p.name === this.proto) || this.protocols[0];
    },

    // ── Called when protocol dropdown changes ───────────────────
    // Resets form fields to the new schema's defaults.
    onProtocolChange() {
      const schema = this.currentSchema();
      this.fields = {};
      // Populate defaults for each field in the new schema
      schema.fields.forEach(f => {
        this.fields[f.id] = f.default || '';
      });
      this.status = '';
      this.statusText = '';
    },

    // ── Field lookup helpers (used by x-show in template) ───────
    hasField(id) {
      const schema = this.currentSchema();
      return schema.fields.some(f => f.id === id);
    },
    isRequired(id) {
      const schema = this.currentSchema();
      const f = schema.fields.find(x => x.id === id);
      return f ? f.required : false;
    },
    label(id) {
      const schema = this.currentSchema();
      const f = schema.fields.find(x => x.id === id);
      return f ? f.label : id;
    },
    placeholder(id) {
      const schema = this.currentSchema();
      const f = schema.fields.find(x => x.id === id);
      return f ? (f.required ? '' : 'optional') : '';
    },
    options(id) {
      const schema = this.currentSchema();
      const f = schema.fields.find(x => x.id === id);
      return f && f.options ? f.options : [];
    },

    // ── Hint + Note text for the current protocol ───────────────
    hint() { return this.currentSchema().hint; },
    note() { return this.currentSchema().note; },

    // ── Status bar helpers ──────────────────────────────────────
    statusMsg()   { return this.statusText; },
    statusClass() {
      switch (this.status) {
        case 'starting': return 'info';
        case 'success':  return 'success';
        case 'error':    return 'error';
        default:        return 'warning';
      }
    },

    // ─────────────────────────────────────────────────────────────
    // VALIDATION + JSON BUILDER
    // Mirrors CreateListenerDialog.java::buildJson() exactly:
    //   - name required for all
    //   - host required unless SMB (uses host as pipe name — required anyway)
    //   - port required unless SMB (port_optional)
    //   - domain required for HTTP-based protocols (HTTPS, DNS, gRPC, Graph, DoH)
    // ─────────────────────────────────────────────────────────────
    buildJson() {
      const schema = this.currentSchema();
      const isSMB = (this.proto === 'SMB');
      const needsDomain = ['HTTPS', 'DNS', 'gRPC', 'Graph API / O365', 'DoH (DNS over HTTPS)'].includes(this.proto);

      const name = (this.fields.name || '').trim();
      if (!name) {
        this.showError('Listener Name is required');
        return null;
      }

      const host = (this.fields.host || '').trim();
      if (!isSMB && !host) {
        this.showError('Bind Address is required');
        return null;
      }

      const port = (this.fields.port || '').trim();
      // SMB doesn't require port
      if (!isSMB && port) {
        const p = parseInt(port, 10);
        if (isNaN(p) || p < 1 || p > 65535) {
          this.showError('Port must be a number between 1 and 65535');
          return null;
        }
      } else if (!isSMB && !port) {
        this.showError('Port is required for ' + this.proto + ' listener');
        return null;
      } else if (isSMB && port) {
        // For SMB, port is "Max Instances" — just needs to be positive
        const p = parseInt(port, 10);
        if (isNaN(p) || p < 1) {
          this.showError('Max Instances must be a positive number');
          return null;
        }
      }

      let domain = '';
      if (this.hasField('domain')) {
        domain = (this.fields.domain || '').trim();
      }
      if (needsDomain && !domain) {
        this.showError('Callback Domain is required for ' + this.proto + ' listener');
        return null;
      }

      // ── Build JSON object ────────────────────────────────────
      // Match the original appendStr/appendInt logic: optional fields
      // are only included if they have a non-empty value.
      const obj = {
        name: name,
        protocol: schema.protoId,
      };

      if (host) obj.host = host;
      if (port) obj.port = parseInt(port, 10);
      if (domain) obj.domain = domain;

      // domain_port (optional)
      const domainPort = (this.fields.domain_port || '').trim();
      if (domainPort) {
        const dp = parseInt(domainPort, 10);
        if (!isNaN(dp)) obj.domain_port = dp;
      }

      // sni (optional)
      const sni = (this.fields.sni || '').trim();
      if (sni) obj.sni = sni;

      // record_type, direction, channel, tls (combos — only if present in schema)
      ['record_type', 'direction', 'channel', 'tls'].forEach(k => {
        if (this.hasField(k) && this.fields[k]) {
          obj[k] = this.fields[k];
        }
      });

      // ttl, poll (integer fields, only if present)
      ['ttl', 'poll'].forEach(k => {
        if (this.hasField(k)) {
          const v = (this.fields[k] || '').trim();
          if (v) {
            const n = parseInt(v, 10);
            if (!isNaN(n)) obj[k] = n;
          }
        }
      });

      return JSON.stringify(obj);
    },

    showError(msg) {
      this.status = 'error';
      this.statusText = '● ' + msg;
    },

    // ─────────────────────────────────────────────────────────────
    // START LISTENER ACTION
    // Hands the JSON to JavaBridge. Java side handles the actual
    // POST /api/listeners + success/error callbacks.
    // ─────────────────────────────────────────────────────────────
    onStart() {
      const json = this.buildJson();
      if (!json) return;  // validation already showed error

      this.submitting = true;
      this.status = 'starting';
      this.statusText = '● Starting...';

      // Hand off to Java side. JavaBridge.submitListenerForm will:
      //   1. Call api.createListener(json) on a background thread
      //   2. On success: call window.onListenerStarted() (defined below)
      //   3. On error:   call window.onListenerError(msg) (defined below)
      try {
        if (window.javaBridge && typeof window.javaBridge.submitListenerForm === 'function') {
          window.javaBridge.submitListenerForm(json);
        } else {
          // Fallback: no bridge (running in plain browser preview)
          this.submitting = false;
          this.showError('No JavaBridge available (preview mode)');
        }
      } catch (e) {
        this.submitting = false;
        this.showError('Bridge error: ' + (e.message || e));
      }
    },

    // ── Java → JS callbacks (JavaBridge calls these after the API call) ──
    // These are called by JavaBridge.java after the background HTTP
    // request to /api/listeners completes.
    onListenerStarted() {
      this.submitting = false;
      this.status = 'success';
      this.statusText = '● Listener started ✓';
      // Auto-close after short delay so user sees the success indicator
      setTimeout(() => this.closeDialog(), 600);
    },

    onListenerError(msg) {
      this.submitting = false;
      this.status = 'error';
      this.statusText = '● FAIL: ' + (msg || 'unknown error');
    },

    // ── Close dialog (Cancel button + Esc key) ───────────────────
    closeDialog() {
      if (window.javaBridge && typeof window.javaBridge.closeListenerDialog === 'function') {
        window.javaBridge.closeListenerDialog();
      } else {
        // Fallback for plain browser preview — print a log
        console.log('[preview] closeDialog() called');
      }
    },
  };
}

// Expose globally so Alpine's x-data="listenerForm()" can find it
window.listenerForm = listenerForm;
