/* ============================================================
 * HERO C2 — BuildAgentDialog Alpine.js application
 *
 * Same pattern as CreateListenerDialog/app.js — Alpine.js x-data
 * root with all form state + reactive UI logic.
 *
 * WIRING (untouched from the original Java BuildAgentDialog):
 *   - On "Build Agent" click: buildJson() produces the JSON payload
 *     (same fields as the original Java buildJson() method)
 *   - Hand off to window.javaBridge.submitBuildForm(json)
 *   - Java side calls api.buildImplantJson(json) on a background thread
 *     (10-minute timeout — heavy cargo compile on server)
 *   - Server streams "build_progress" events via WebSocket:
 *       MainView receives → calls BuildAgentDialog.onBuildProgress(pct, stage, detail)
 *       (static method on the Java wrapper)
 *       → calls bridge.jsUpdateBuildProgress(pct, stage, detail)
 *       → calls window.updateBuildProgress(pct, stage, detail) here
 *   - On success: Java side fires window.onBuildDone(resultJson)
 *   - On error:   Java side fires window.onBuildError(msg)
 *
 * Only fields the agent/server actually consume are exposed in the UI.
 * v3 design: request > profile > default (server-side resolution),
 * so timing/evasion values are OPTIONAL here — empty fields let the
 * server fall back to the profile + built-in defaults.
 * ============================================================ */

function agentForm() {
  return {
    // ── Tab navigation ───────────────────────────────────────────
    activeTab: 'build',

    // ── Form fields (only those sent in buildJson) ──────────────
    form: {
      listener_id:      '',
      name:             'hero_agent',
      output_name:      'hero_agent',
      os:               'Windows',
      arch:             'x64 (AMD64)',
      output_format:    'exe (Windows PE)',
      malleable_profile: 'None',
      sleep_time:       null,   // null = empty = server uses profile/default
      jitter:           null,
      string_encrypt:   false,
      binary_obfusc:    false,
    },

    // ── Caches loaded from server (listeners + profiles) ─────────
    listeners: [],
    profiles:  [],

    // ── Static option lists ──────────────────────────────────────
    osOpts:     ['Windows', 'Linux', 'macOS'],
    archOpts:   ['x64 (AMD64)', 'x86 (i386)', 'ARM64 (AArch64)'],
    formatMap: {
      'Windows': ['exe (Windows PE)', 'staged (stager + stage-2 zip)'],
      'Linux':   ['elf', 'raw'],
      'macOS':   ['macho', 'raw'],
    },

    // ── Build state machine ─────────────────────────────────────
    building:   false,   // true while build in progress
    done:       false,   // true after successful build
    failed:     false,   // true after failed build

    // ── Progress bar state (updated by Java→JS callback) ────────
    progressPct:     0,
    progressStage:   '',
    progressDetail:  '',

    // ── Status bar ───────────────────────────────────────────────
    status:     '',     // '', 'building', 'success', 'error'
    statusText: '',

    // ════════════════════════════════════════════════════════════
    // LIFECYCLE
    // ════════════════════════════════════════════════════════════
    init() {
      // Escape key closes dialog (unless build is running)
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !this.building) this.closeDialog();
      });
      // NOTE: Data loading (listeners + profiles) is handled by
      // window.loadData() — called from Java side AFTER the bridge
      // is wired. This avoids the race condition where Alpine's init()
      // runs before window.javaBridge is available.
    },

    // Called from Java side via engine.executeScript("window.loadData()")
    // AFTER JavaBridge is wired. This guarantees window.javaBridge is live.
    loadData() {
      this.loadListeners();
      this.loadProfiles();
    },

    loadListeners() {
      try {
        if (window.javaBridge && typeof window.javaBridge.fetchInitialData === 'function') {
          const raw = window.javaBridge.fetchInitialData();
          if (raw) {
            const data = JSON.parse(raw);
            this.listeners = data.listeners || [];
            // Auto-select first listener if exactly one exists
            if (this.listeners.length === 1 && !this.form.listener_id) {
              this.form.listener_id = this.listeners[0].id;
            }
          }
        }
      } catch (e) {
        console.warn('[BuildAgentDialog] loadListeners failed:', e);
      }
    },

    loadProfiles() {
      try {
        if (window.javaBridge && typeof window.javaBridge.fetchInitialData === 'function') {
          const raw = window.javaBridge.fetchInitialData();
          if (raw) {
            const data = JSON.parse(raw);
            this.profiles = data.profiles || [];
          }
        }
      } catch (e) {
        console.warn('[BuildAgentDialog] loadProfiles failed:', e);
      }
    },

    // ════════════════════════════════════════════════════════════
    // FORMAT OPTIONS — depends on selected OS
    // ════════════════════════════════════════════════════════════
    formatOptsForOS() {
      const opts = this.formatMap[this.form.os] || ['exe (Windows PE)'];
      // If current output_format isn't in the new OS's list, reset to first option
      if (!opts.includes(this.form.output_format)) {
        this.form.output_format = opts[0];
      }
      return opts;
    },

    onOSChange() {
      // Reset output_format to first option of the new OS
      const opts = this.formatMap[this.form.os] || [];
      if (opts.length > 0) this.form.output_format = opts[0];
    },

    // ════════════════════════════════════════════════════════════
    // VALIDATION + JSON BUILDER
    // Mirrors BuildAgentDialog.java::buildJson() exactly — same fields,
    // same optional-vs-required rules.
    // ════════════════════════════════════════════════════════════
    buildJson() {
      // Required: listener_id
      if (!this.form.listener_id) {
        this.showError('Select a listener first');
        return null;
      }
      // Required: output_name (or fallback to name)
      let outputName = (this.form.output_name || '').trim();
      if (!outputName) outputName = (this.form.name || '').trim();
      if (!outputName) {
        this.showError('Output Name is required');
        return null;
      }
      // Sanitize output_name — strip .exe suffix if user added it
      // (server appends .exe automatically based on OS)
      if (outputName.toLowerCase().endsWith('.exe')) {
        outputName = outputName.substring(0, outputName.length - 4);
      }

      // Build the JSON — only fields server actually consumes in v3
      const obj = {
        listener_id:    this.form.listener_id,
        name:            outputName,
        output_name:    outputName,
        os:              this.form.os.toLowerCase(),
        arch:            this.archToCanonical(this.form.arch),
        output_format:   this.formatToCanonical(this.form.output_format),
        // Obfuscation flags (build-time binary transforms)
        string_encrypt:  this.form.string_encrypt ? 'aes-128' : '',
        binary_obfusc:    this.form.binary_obfusc ? 'strip' : '',
      };

      // Optional: sleep_time (only include if user provided)
      if (this.form.sleep_time && this.form.sleep_time > 0) {
        obj.sleep_time = this.form.sleep_time;
      }
      // Optional: jitter (only include if user provided)
      if (this.form.jitter && this.form.jitter > 0) {
        // Convert percent to fraction (server expects 0.0-1.0)
        obj.jitter = this.form.jitter / 100.0;
      }
      // Optional: malleable profile (strip .toml extension, server resolves)
      if (this.form.malleable_profile && this.form.malleable_profile !== 'None') {
        let profile = this.form.malleable_profile;
        if (profile.endsWith('.toml')) {
          profile = profile.substring(0, profile.length - 5);
        }
        obj.malleable_profile = profile;
      }

      return JSON.stringify(obj);
    },

    // Canonical conversions — match what the original Java code does
    archToCanonical(archDisplay) {
      // Display: "x64 (AMD64)" → Canonical: "x86_64" (server expects "x64" for build target)
      if (archDisplay.startsWith('x64'))   return 'x64';
      if (archDisplay.startsWith('x86'))   return 'x86';
      if (archDisplay.startsWith('ARM64')) return 'arm64';
      return archDisplay.toLowerCase();
    },
    formatToCanonical(formatDisplay) {
      // Display: "exe (Windows PE)" → server expects "exe" or "staged"
      if (formatDisplay.startsWith('staged')) return 'staged';
      if (formatDisplay.startsWith('exe'))    return 'exe';
      if (formatDisplay.startsWith('elf'))    return 'elf';
      if (formatDisplay.startsWith('macho'))  return 'macho';
      if (formatDisplay.startsWith('raw'))    return 'raw';
      return formatDisplay.toLowerCase();
    },

    // ════════════════════════════════════════════════════════════
    // BUILD ACTION — hand off to JavaBridge
    // ════════════════════════════════════════════════════════════
    onBuild() {
      const json = this.buildJson();
      if (!json) return;  // validation already showed error

      // Reset state machine
      this.building = true;
      this.done = false;
      this.failed = false;
      this.progressPct = 0;
      this.progressStage = 'starting';
      this.progressDetail = '';
      this.status = 'building';
      this.statusText = '● Building...';

      try {
        if (window.javaBridge && typeof window.javaBridge.submitBuildForm === 'function') {
          window.javaBridge.submitBuildForm(json);
        } else {
          this.showError('No JavaBridge available (preview mode)');
        }
      } catch (e) {
        this.showError('Bridge error: ' + (e.message || e));
      }
    },

    // ════════════════════════════════════════════════════════════
    // JAVA → JS CALLBACKS
    // JavaBridge calls these after API responses / WS events
    // ════════════════════════════════════════════════════════════

    // Called by JavaBridge when a WS "build_progress" event arrives.
    // pct: 0-100, stage: 'compiling'|'linking'|'stealth'|'done'|etc,
    // detail: human-readable line from cargo output
    updateBuildProgress(pct, stage, detail) {
      this.progressPct = Math.max(0, Math.min(100, parseInt(pct, 10) || 0));
      this.progressStage = stage || '';
      this.progressDetail = detail || '';
      // Auto-detect "done" state from stage name (server sends stage='done')
      if (stage === 'done' || pct >= 100) {
        this.building = false;
        this.done = true;
        this.status = 'success';
        this.statusText = '● Build complete ✓';
      }
    },

    // Called by JavaBridge when api.buildImplantJson() returns successfully
    // resultJson is the server's BuildResponse JSON string
    onBuildDone(resultJson) {
      this.building = false;
      this.done = true;
      this.failed = false;
      this.progressPct = 100;
      this.progressStage = 'done';
      this.status = 'success';
      this.statusText = '● Build complete ✓';

      // Parse result to show file_name + sha256 in status
      try {
        const r = JSON.parse(resultJson);
        if (r.file_name && r.sha256) {
          this.statusText = '● ' + r.file_name + ' (sha256:' + r.sha256.substring(0, 12) + '...) ✓';
        }
      } catch (e) { /* result wasn't JSON — keep generic success */ }

      // Auto-close after 1.2s so user sees the ✓
      setTimeout(() => this.closeDialog(), 1200);
    },

    // Called by JavaBridge when api.buildImplantJson() throws
    onBuildError(msg) {
      this.building = false;
      this.done = false;
      this.failed = true;
      this.status = 'error';
      // Truncate very long error messages
      let m = msg || 'unknown error';
      if (m.length > 160) m = m.substring(0, 160) + '…';
      this.statusText = '● FAIL: ' + m;
    },

    showError(msg) {
      this.status = 'error';
      this.statusText = '● ' + msg;
    },

    statusMsg()   { return this.statusText; },
    statusClass() {
      switch (this.status) {
        case 'building': return 'info';
        case 'success':  return 'success';
        case 'error':    return 'error';
        default:         return 'warning';
      }
    },

    // ── Close dialog (Close button + Esc key) ───────────────────
    closeDialog() {
      if (window.javaBridge && typeof window.javaBridge.closeBuildDialog === 'function') {
        window.javaBridge.closeBuildDialog();
      }
    },
  };
}

// Expose globally so Alpine's x-data="agentForm()" can find it
window.agentForm = agentForm;
