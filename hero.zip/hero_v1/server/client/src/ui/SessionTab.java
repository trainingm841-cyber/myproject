package ui;

import models.Session;
import models.Task;
import service.ApiService;
import ui.console.OutputFormatter;
import ui.console.PromptBar;
import ui.console.StatusBar;
import ui.console.TerminalStyle;
import ui.web.JavaBridge;
import javafx.application.Platform;
import java.net.URL;
import javafx.geometry.Insets;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import netscape.javascript.JSObject;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * SessionTab v2 — BeaconConsole.java (RichTextFX) replaced with
 * BeaconConsole.html (WebView + JS).
 *
 * Composition:
 *   ┌─────────────────────────────────────────────────┐
 *   │  PromptBar  [id | user@host | arch | sleep]    │  ← JavaFX (unchanged)
 *   ├─────────────────────────────────────────────────┤
 *   │  WebView → BeaconConsole.html                   │  ← HTML/CSS/JS (NEW)
 *   │   (same output colors, same keyboard shortcuts) │
 *   ├─────────────────────────────────────────────────┤
 *   │  StatusBar  ● alive | task: idle | rtt: --      │  ← JavaFX (unchanged)
 *   └─────────────────────────────────────────────────┘
 *
 * All existing logic (ApiService calls, WS task delivery, dedup, poller,
 * watchdog, C6/C7/C10 fixes) is UNCHANGED. Only BeaconConsole is replaced.
 *
 * JavaBridge wires JS→Java (onCommand, cancelTask, closeTab) and
 * Java→JS (appendTaskResult, appendInfo, etc.).
 */
public class SessionTab {

    private final Session session;
    private final ApiService api;
    private final ExecutorService executor = Executors.newCachedThreadPool();
    private java.util.concurrent.ScheduledExecutorService taskPoller;

    // ── UI components ──
    private final WebView    consoleView;
    private final WebEngine  consoleEngine;
    private       JavaBridge bridge;
    private final PromptBar  promptBar;
    private final StatusBar  statusBar;

    // ── Pending tasks (C6 fix: ConcurrentHashMap, single atomic put) ──
    private static final class PendingTask {
        final long   start;
        final String commandText;
        final String args;
        PendingTask(long s, String c, String a) { start=s; commandText=c; args=a; }
    }
    private final Map<String, PendingTask> pendingTasks     = new ConcurrentHashMap<>();
    private final java.util.Set<String>    processedTaskIds =
        java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<>());

    // Command dedupe: a command can arrive twice — once via the direct
    // JSObject bridge call and once via the outbox drain — same id means the
    // same user action, run it exactly once. Bounded via clear when large.
    private final java.util.Set<String> processedCmdIds =
        java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<>());

    // C7 fix: fire "killed by operator" line only once per death
    private volatile boolean beaconDeadShown = false;

    // Cloud-fix (#3 remainder): bridge stays null until the console page
    // finishes loading (wirebridge runs on LoadWorker SUCCEEDED). A task
    // result or beacon-death notice can arrive BEFORE that — queue those
    // Java→JS calls and flush them in wirebridge() so early output is
    // SHOWN instead of being lost to a NullPointerException.
    // FX-thread-only: every caller here already runs via Platform.runLater.
    private final java.util.List<Runnable> pendingJs = new java.util.ArrayList<>();

    /** Run a Java→JS call now if the bridge is ready, else queue it for wirebridge(). */
    private void js(Runnable call) {
        if (bridge != null) call.run();
        else pendingJs.add(call);
    }

    // C10 fix: callback to close the owning tab
    private Runnable onTabClose;

    private static final String PROMPT = "Hero>";

    // ─────────────────────────────────────────────────────────────────────

    // Fallback HTML — shown if BeaconConsole.html cannot be found on classpath or disk
    private static final String FALLBACK_HTML =
        "<!DOCTYPE html><html><head><meta charset=\"UTF-8\">" +
        "<style>*{margin:0;padding:0;box-sizing:border-box}" +
        "body{background:#0a0e14;color:#c9d1d9;font-family:monospace;font-size:13px;height:100vh;display:flex;flex-direction:column}" +
        "#out{flex:1;overflow-y:auto;padding:8px 12px;white-space:pre-wrap}" +
        "#row{display:flex;padding:4px 8px;background:#0d1117;border-top:1px solid #6e7681}" +
        "#p{color:#58a6ff;font-weight:bold;padding-left:4px;white-space:nowrap}" +
        "#i{flex:1;background:transparent;border:none;outline:none;color:#c9d1d9;font-family:monospace;font-size:13px;padding:0 4px}" +
        ".info{color:#58a6ff}.ok{color:#3fb950}.warn{color:#d29922}.err{color:#f85149}" +
        "</style></head><body>" +
        "<div id=\"out\"><span class=\"info\">[*] Hero C2 — Beacon Console ready\n</span></div>" +
        "<div id=\"row\"><span id=\"p\">Hero&gt;&nbsp;</span><input id=\"i\" autocomplete=\"off\" spellcheck=\"false\"></div>" +
        "<script>" +
        "var h=document.getElementById('out'),inp=document.getElementById('i'),hist=[],hi=-1;" +
        "function app(t,c){var s=document.createElement('span');s.className=c||'';s.textContent=t;h.appendChild(s);h.scrollTop=h.scrollHeight;}" +
        "window.appendInfo=function(m){app('[*] '+m+'\n','info');};" +
        "window.appendSuccess=function(m){app('[+] '+m+'\n','ok');};" +
        "window.appendWarning=function(m){app('[!] '+m+'\n','warn');};" +
        "window.appendError=function(m){app('[-] '+m+'\n','err');};" +
        "window.appendTaskResult=function(cmd,raw,args){app((raw||'(no output)')+'\n','');};" +
        "window.appendCommandEcho=function(p,c){app('\n','');app(p+' ','info');app(c+'\n','');};" +
        "window.clearConsole=function(){h.innerHTML='';};" +
        "window.setPromptText=function(t){document.getElementById('p').textContent=t+'\u00a0';};" +
        "window.showBanner=function(id,u,host,os,arch){app('Hero C2 — Beacon Console\n-------------------------\nSession: '+id.substring(0,8)+'\nTarget:  '+u+'@'+host+'\nSystem:  '+os+' ('+arch+')\n\n','info');};" +
        "window.showHelp=function(){app('Type commands and press Enter. Tab=complete, Up/Down=history, Ctrl+L=clear\n','info');};" +
        "window.showCommandHelp=function(c){app('Command: '+c+'\n','info');};" +
        "window.__drainCmdOutbox=function(){var o=window.__cmdOutbox||[];window.__cmdOutbox=[];return JSON.stringify(o);};" +
        "function isEnter(e){return e.key==='Enter'||e.keyCode===13||e.which===13||(e.ctrlKey&&(e.key==='m'||e.key==='M'));}" +
        "var lastEnter=0;function handleEnter(){var now=Date.now();if(now-lastEnter<150)return;lastEnter=now;" +
        "var t=inp.value.trim();if(!t)return;hist.push(t);hi=hist.length;" +
        "window.appendCommandEcho('Hero>',t);inp.value='';" +
        "if(t==='clear'){window.clearConsole();return;}if(t==='help'){window.showHelp();return;}" +
        "if(t==='exit'){if(window.javaBridge)window.javaBridge.closeTab();return;}" +
        "var eid='c'+now.toString(36);(window.__cmdOutbox=window.__cmdOutbox||[]).push({id:eid,text:t});" +
        "try{if(window.javaBridge&&typeof window.javaBridge.onCommand==='function'){window.javaBridge.onCommand(eid,t);window.__cmdOutbox=window.__cmdOutbox.filter(function(x){return x.id!==eid;});}}catch(e){}}" +
        "inp.addEventListener('keydown',function(e){if(isEnter(e)){e.preventDefault();handleEnter();}" +
        "else if(e.key==='ArrowUp'){if(hi>0){hi--;inp.value=hist[hi]||'';}e.preventDefault();}" +
        "else if(e.key==='ArrowDown'){if(hi<hist.length-1){hi++;inp.value=hist[hi]||'';}else{hi=hist.length;inp.value='';}e.preventDefault();}" +
        "else if(e.ctrlKey&&e.key==='l'){window.clearConsole();e.preventDefault();}" +
        "else if(e.ctrlKey&&e.key==='c'){if(window.javaBridge)window.javaBridge.cancelTask();inp.value='';e.preventDefault();}});" +
        "inp.addEventListener('keyup',function(e){if(isEnter(e)){e.preventDefault();handleEnter();}});" +
        "inp.focus();" +
        "</script></body></html>";

    public SessionTab(Session session, ApiService api) {
        this.session = session;
        this.api     = api;

        // ── WebView (replaces BeaconConsole) ──
        consoleView   = new WebView();
        consoleEngine = consoleView.getEngine();
        consoleView.setStyle("-fx-background-color: #0a0e14;");
        VBox.setVgrow(consoleView, Priority.ALWAYS);

        // Disable context menu (right-click) on WebView
        consoleView.setContextMenuEnabled(false);

        // ── JavaFX components (unchanged) ──
        promptBar = new PromptBar(session);
        statusBar = new StatusBar();

        // ── Load HTML console ──
        // Try classpath resource first (JAR mode), fall back to file path (dev mode)
        java.net.URL htmlRes = getClass().getResource("/ui/web/BeaconConsole.html");
        if (htmlRes == null) {
            // Dev mode: load directly from source tree
            try {
                java.io.File hf = new java.io.File("src/ui/web/BeaconConsole.html");
                if (!hf.exists()) hf = new java.io.File("server/client/src/ui/web/BeaconConsole.html");
                if (hf.exists()) htmlRes = hf.toURI().toURL();
            } catch (java.net.MalformedURLException ignore) { /* use fallback */ }
        }
        if (htmlRes != null) {
            consoleEngine.load(htmlRes.toExternalForm());
        } else {
            // Absolute last resort: inline minimal HTML so tab is never blank
            consoleEngine.loadContent(FALLBACK_HTML);
        }

        // ── Wire JavaBridge AFTER page load ──
        consoleEngine.getLoadWorker().stateProperty().addListener((obs, old, newState) -> {
            if (newState == javafx.concurrent.Worker.State.SUCCEEDED) {
                wirebridge();
            }
        });

        // ── Start fallback task poller ──
        startTaskPoller();
    }

    /** Wire JavaBridge to JS window object. Called once on page load. */
    private void wirebridge() {
        bridge = new JavaBridge(session, api, consoleEngine);

        // Register bridge as window.javaBridge in JS
        JSObject win = (JSObject) consoleEngine.executeScript("window");
        win.setMember("javaBridge", bridge);

        // Wire callbacks: JS→Java
        bridge.setOnCommand(this::onCommand);
        bridge.setOnCancel(this::onCancelTask);
        bridge.setOnClose(() -> {
            bridge.jsAppendInfo("Session tab closed.");
            cleanup();
            if (onTabClose != null) Platform.runLater(onTabClose);
        });

        // Show banner (same as old BeaconConsole.showBanner)
        bridge.jsShowBanner(
            session.getId(),
            session.getUsername(),
            session.getHostname(),
            session.getOs(),
            session.getArch()
        );

        // Flush anything that arrived while the page was still loading
        for (Runnable r : pendingJs) r.run();
        pendingJs.clear();
    }

    public VBox getRoot() {
        VBox root = new VBox(0, promptBar.getBox(), consoleView, statusBar.getBox());
        root.setPadding(new Insets(0));
        root.setStyle("-fx-background-color: " + TerminalStyle.BG + ";");
        VBox.setVgrow(consoleView, Priority.ALWAYS);
        return root;
    }

    // ── Command dispatch (same logic as before) ───────────────────────────

    /**
     * @param cmdId dedupe id from the JS outbox entry (may be empty) —
     *              the same id arriving twice is the SAME user action.
     */
    private void onCommand(String cmdId, String input) {
        input = (input == null) ? "" : input.trim();
        if (input.isEmpty()) return;

        if (cmdId != null && !cmdId.isEmpty() && !processedCmdIds.add(cmdId)) {
            return; // duplicate delivery (direct bridge + outbox drain)
        }
        if (processedCmdIds.size() > 500) {
            processedCmdIds.clear(); // bounded — old ids are long gone
        }

        if (executor.isShutdown()) {
            js(() -> bridge.jsAppendError("Session tab closed — open a new tab from the Sessions list."));
            return;
        }

        String[] parts   = input.split("\\s+", 2);
        String   cmd     = parts[0].toLowerCase();
        String   args    = parts.length > 1 ? parts[1] : "";

        // Local-only commands — JS handles help/clear/exit directly.
        // 'sessions' still needs a Java-side message.
        if (cmd.equals("sessions")) {
            bridge.jsAppendInfo("Use the Sessions tab in the sidebar to switch sessions.");
            return;
        }

        // Agent commands — submit to executor
        final String commandText = input;
        final String commandName = cmd;
        final String commandArgs = args;

        statusBar.onTaskQueued(commandName);

        executor.submit(() -> {
            try {
                long start  = System.currentTimeMillis();
                String taskId = api.sendTask(session.getId(), commandName, commandArgs);

                // C6 fix: single atomic put
                pendingTasks.put(taskId, new PendingTask(start, commandText, commandArgs));

                int bytesSent = 25 + commandName.length() + commandArgs.length();
                statusBar.onTaskSent(commandName, bytesSent);

                if (!isSilentCommand(commandName)) {
                    bridge.jsAppendInfo("Tasked beacon to run: " + commandText);
                }

                // 60s watchdog
                final String wdTaskId = taskId;
                final String wdCmd    = commandText;
                new Thread(() -> {
                    try { Thread.sleep(60_000); } catch (InterruptedException e) { return; }
                    if (pendingTasks.containsKey(wdTaskId)) {
                        bridge.jsAppendWarning(
                            "Task '" + wdCmd + "' still pending after 60s — beacon may be slow or dead");
                    }
                }, "wd-" + taskId.substring(0,8)).start();

            } catch (ApiService.ServerInfoException sie) {
                // Server-side INFO response (boflist, bof with no args) —
                // display as normal console output, NOT as an error.
                bridge.jsAppendInfo(sie.output);
                statusBar.onTaskDone("info", 0, 0);
            } catch (Exception e) {
                bridge.jsAppendError("Task dispatch failed: " + e.getMessage());
                statusBar.onTaskFailed(e.getMessage());
            }
        });
    }

    private void onCancelTask() {
        if (pendingTasks.isEmpty()) return;
        bridge.jsAppendWarning("Cancel requested — task already in flight. Result will still arrive.");
    }

    // ── Task result delivery ──────────────────────────────────────────────

    /** Called by SessionsTab when WS delivers a task result. */
    public void onTaskResult(String taskId, String result) {
        if (processedTaskIds.contains(taskId)) return; // dedup
        processedTaskIds.add(taskId);
        displayTaskResult(taskId, result);
    }

    private void displayTaskResult(String taskId, String result) {
        PendingTask p = pendingTasks.remove(taskId);
        if (p == null) return;

        long   rtt      = System.currentTimeMillis() - p.start;
        String[] parts  = p.commandText.trim().split("\\s+", 2);
        String cmdName  = parts[0];
        String cmdArgs  = parts.length > 1 ? parts[1] : "";

        // Send raw result to JS — JS formatter handles coloring
        // (mirrors OutputFormatter.format() logic which is now duplicated in JS)
        // Queued if the page is still loading (bridge not wired yet).
        js(() -> bridge.jsAppendTaskResult(cmdName, result, cmdArgs));

        int bytesRecv = result == null ? 0 : result.length();
        statusBar.onTaskDone(cmdName, rtt, bytesRecv);
    }

    // ── Session lifecycle callbacks ───────────────────────────────────────

    public void onSessionUpdated(Session updated) {
        Platform.runLater(() -> {
            promptBar.refresh(updated);
            if (!updated.isActive()) {
                statusBar.onBeaconDead();
            } else if (updated.isStale()) {
                statusBar.onBeaconSleeping();
                beaconDeadShown = false;
            } else {
                statusBar.onBeaconAlive();
                beaconDeadShown = false;
            }
        });
    }

    public void onBeaconDead() {
        if (beaconDeadShown) return;
        beaconDeadShown = true;
        statusBar.onBeaconDead();
        // Queued if the page is still loading (bridge not wired yet).
        js(() -> bridge.jsAppendError("Session killed by operator."));
    }

    public void setOnTabClose(Runnable r) { this.onTabClose = r; }

    public void cleanup() {
        if (taskPoller != null) taskPoller.shutdownNow();
        executor.shutdownNow();
    }

    // ── Task poller (fallback for WS drops) ──────────────────────────────

    private void startTaskPoller() {
        taskPoller = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "task-poller-" + session.getId().substring(0,8));
            t.setDaemon(true);
            return t;
        });
        taskPoller.scheduleAtFixedRate(() -> {
            // JS→Java insurance: drain commands the console could not deliver
            // through the JSObject bridge (dead on some Linux WebViews).
            drainConsoleOutbox();
            if (pendingTasks.isEmpty()) return;
            try {
                Session updated = api.getSession(session.getId());
                if (updated.getTasks() == null) return;
                for (Task t : updated.getTasks()) {
                    String tid = t.getId();
                    if ("completed".equals(t.getStatus())
                            && pendingTasks.containsKey(tid)
                            && !processedTaskIds.contains(tid)) {
                        processedTaskIds.add(tid);
                        final String res = t.getResult();
                        Platform.runLater(() -> displayTaskResult(tid, res));
                    }
                }
            } catch (Exception ignore) { /* silent retry */ }
        }, 1, 2, java.util.concurrent.TimeUnit.SECONDS);
    }

    /**
     * Pull commands queued by BeaconConsole.html out of the page and run
     * them. Uses ONLY the Java→JS direction (executeScript) which always
     * works, unlike window.javaBridge member calls which are unreliable on
     * some Linux WebView setups. Dedupe happens by entry id in onCommand.
     */
    private void drainConsoleOutbox() {
        if (bridge == null) return;
        final WebEngine eng   = consoleEngine;
        final JavaBridge bref = bridge;
        Platform.runLater(() -> {
            try {
                Object r = eng.executeScript("window.__drainCmdOutbox ? window.__drainCmdOutbox() : '[]'");
                if (r == null) return;
                String json = r.toString();
                if (json.isEmpty() || "[]".equals(json)) return;
                com.google.gson.JsonArray arr =
                    com.google.gson.JsonParser.parseString(json).getAsJsonArray();
                for (com.google.gson.JsonElement el : arr) {
                    com.google.gson.JsonObject ob = el.getAsJsonObject();
                    String id = ob.has("id")   && !ob.get("id").isJsonNull()   ? ob.get("id").getAsString()   : "";
                    String tx = ob.has("text") && !ob.get("text").isJsonNull() ? ob.get("text").getAsString() : "";
                    if (!tx.isEmpty()) bref.deliverQueued(id, tx);
                }
            } catch (Exception ignore) { /* page busy or reloading — next tick */ }
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private static boolean isSilentCommand(String cmd) {
        return switch (cmd) {
            case "sleep","jitter","working_hours","workhours","config","beaconinfo",
                 "wipe","clear","cls","help","exit","sessions" -> true;
            default -> false;
        };
    }
}
