package ui;

import models.DashboardStats;
import service.ApiService;
import service.WsService;
import ui.dialogs.CreateListenerDialog;
import ui.dialogs.BuildAgentDialog;
import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * MainView — top-level window layout for HERO C2 client.
 *
 * Layout (simplified per user request — only Sessions tab remains):
 *
 *   ┌─────────────────────────────────────────────────────────────┐
 *   │  File                                                        │  ← menu bar
 *   ├─────────────────────────────────────────────────────────────┤
 *   │  HERO    [ Sessions ]        [+ Listener]  [▶ Build Agent]   │  ← top bar with action buttons
 *   ├─────────────────────────────────────────────────────────────┤
 *   │                                                             │
 *   │   Sessions tab content (sessions table + terminal +         │
 *   │   listeners table at bottom)                                │
 *   │                                                             │
 *   ├─────────────────────────────────────────────────────────────┤
 *   │  ● Connected | Sessions: 1 | Listeners: 1 | Uptime: 6m 11s  │  ← status bar
 *   └─────────────────────────────────────────────────────────────┘
 *
 * Home, Listeners, Builder tabs removed.
 * Listener creation and Agent building are done via right-click or top bar buttons.
 */
public class MainView {
    private final ApiService api;
    private final WsService  ws;
    private final Stage      stage;
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(3);

    private SessionsTab  sessionsTab;

    private Label statusLabel, sessionCountLabel, listenerCountLabel, uptimeLabel;

    // Style constants
    private static final String BG     = "#0a0e14";
    private static final String PANEL  = "#161b22";
    private static final String BORDER = "#30363d";
    private static final String FG     = "#c9d1d9";
    private static final String DIM    = "#8b949e";
    private static final String ACCENT = "#58a6ff";

    public MainView(Stage stage, ApiService api) {
        this.stage = stage;
        this.api   = api;
        this.ws    = new WsService();
        sessionsTab  = new SessionsTab(api, stage);
    }

    public void show() {
        // ── Menu bar ──────────────────────────────────────────────────
        MenuBar menuBar = new MenuBar();
        Menu fileMenu = new Menu("File");
        MenuItem exitItem = new MenuItem("Exit");
        exitItem.setOnAction(e -> { scheduler.shutdown(); ws.disconnect(); stage.close(); });
        fileMenu.getItems().add(exitItem);
        menuBar.getMenus().add(fileMenu);
        menuBar.setStyle("-fx-background-color: " + BG + "; -fx-border-color: " + BORDER + "; -fx-border-width: 0 0 1 0;");

        // ── Top bar: logo + Sessions label + action buttons ──────────
        HBox topBar = new HBox(0);
        topBar.setStyle("-fx-background-color: " + BG + "; -fx-border-color: " + BORDER + "; -fx-border-width: 0 0 1 0;");
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setPadding(new Insets(0, 16, 0, 16));
        topBar.setPrefHeight(40);

        Label logo = new Label("HERO");
        logo.setStyle("-fx-text-fill: " + FG + "; -fx-font-size: 14px; -fx-font-weight: bold;"
                + " -fx-font-family: 'JetBrains Mono', 'Consolas', monospace;"
                + " -fx-padding: 0 24px 0 0;"
                + " -fx-letter-spacing: 2;");

        Label sessionsLabel = new Label("Sessions");
        // v9: blue underline removed — operator asked for a clean session
        // header (the old 2px accent bottom-border is gone).
        sessionsLabel.setStyle("-fx-text-fill: " + FG + "; -fx-font-size: 13px; -fx-font-weight: bold;"
                + " -fx-padding: 0 24px 0 0;");

        // Spacer to push buttons to the right
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Action buttons
        Button createListenerBtn = actionBtn("+ Listener", ACCENT, "#ffffff");
        createListenerBtn.setOnAction(e -> {
            new CreateListenerDialog(stage, api, () -> sessionsTab.refreshListeners()).show();
        });

        Button buildAgentBtn = actionBtn("▶ Build Agent", PANEL, FG);
        buildAgentBtn.setOnAction(e -> {
            new BuildAgentDialog(stage, api, null).show();
        });

        topBar.getChildren().addAll(logo, sessionsLabel, spacer, createListenerBtn, buildAgentBtn);

        // ── Content area ─────────────────────────────────────────────
        Node content = sessionsTab.getContent();

        // ── Status bar ───────────────────────────────────────────────
        statusLabel = new Label("● Connected");
        statusLabel.setStyle("-fx-text-fill: #3fb950; -fx-font-size: 11px;"
                + " -fx-font-family: 'JetBrains Mono', 'Consolas', monospace;");
        sessionCountLabel = new Label("Sessions: 0");
        sessionCountLabel.setStyle("-fx-text-fill: #c9d1d9; -fx-font-size: 11px;");
        listenerCountLabel = new Label("Listeners: 0");
        listenerCountLabel.setStyle("-fx-text-fill: #c9d1d9; -fx-font-size: 11px;");
        uptimeLabel = new Label("Uptime: 0s");
        uptimeLabel.setStyle("-fx-text-fill: #c9d1d9; -fx-font-size: 11px;"
                + " -fx-font-family: 'JetBrains Mono', 'Consolas', monospace;");

        HBox statusBar = new HBox(20, statusLabel, sep(), sessionCountLabel, listenerCountLabel,
                sep(), uptimeLabel);
        statusBar.setPadding(new Insets(4, 16, 4, 16));
        statusBar.setStyle("-fx-background-color: " + BG + "; -fx-border-color: " + BORDER + "; -fx-border-width: 1 0 0 0;");
        HBox.setHgrow(statusLabel, Priority.ALWAYS);

        // ── Assemble root layout ─────────────────────────────────────
        VBox topBox = new VBox(0, menuBar, topBar);
        BorderPane root = new BorderPane();
        root.setTop(topBox);
        root.setCenter(content);
        root.setBottom(statusBar);
        root.setStyle("-fx-background-color: " + BG + ";");

        Scene scene = new Scene(root, 1280, 800);
        scene.getStylesheets().add(getClass().getResource("/dark-theme.css").toExternalForm());
        stage.setTitle("HERO C2");
        stage.setScene(scene);
        stage.show();

        // ── WebSocket ────────────────────────────────────────────────
        ws.setOnEvent(this::handleWsEvent);
        ws.connect(api.getBaseUrl(), api.getToken());

        // ── Background refresh ───────────────────────────────────────
        // When WS is connected, events arrive in real-time so we only poll
        // for status bar health checks every 5s (lightweight /api/health or
        // /api/dashboard/stats). Session/listener refresh is driven by WS events.
        //
        // When WS drops, we fall back to full polling every 3s so the UI
        // doesn't go stale. The wsConnected flag toggles the mode.
        // ────────────────────────────────────────────────────────────────
        scheduler.scheduleAtFixedRate(() -> {
            try {
                // Always refresh status bar (health check + counters)
                refreshStatusBarAsync();
                // Only poll sessions/listeners if WS is NOT connected
                // (WS events handle real-time updates when connected)
                if (!ws.isConnected()) {
                    Platform.runLater(() -> {
                        sessionsTab.refresh();
                        sessionsTab.refreshListeners();
                    });
                }
            } catch (Exception e) { /* silent */ }
        }, 0, 3, TimeUnit.SECONDS);

        stage.setOnCloseRequest(e -> { scheduler.shutdown(); ws.disconnect(); });
    }

    private Label sep() {
        Label s = new Label("|");
        s.setStyle("-fx-text-fill: #30363d; -fx-font-size: 11px;");
        return s;
    }

    private Button actionBtn(String text, String bg, String fg) {
        Button b = new Button(text);
        b.setStyle("-fx-background-color: " + bg + ";"
            + " -fx-text-fill: " + fg + ";"
            + " -fx-font-size: 12px;"
            + " -fx-font-weight: bold;"
            + " -fx-padding: 7px 16px;"
            + " -fx-border-color: " + (bg.equals(ACCENT) ? ACCENT : BORDER) + ";"
            + " -fx-border-radius: 4px;"
            + " -fx-cursor: hand;");
        b.setOnMouseEntered(e -> b.setStyle("-fx-background-color: " + lighten(bg) + ";"
            + " -fx-text-fill: " + fg + ";"
            + " -fx-font-size: 12px;"
            + " -fx-font-weight: bold;"
            + " -fx-padding: 7px 16px;"
            + " -fx-border-color: " + (bg.equals(ACCENT) ? ACCENT : BORDER) + ";"
            + " -fx-border-radius: 4px;"
            + " -fx-cursor: hand;"));
        b.setOnMouseExited(e -> b.setStyle("-fx-background-color: " + bg + ";"
            + " -fx-text-fill: " + fg + ";"
            + " -fx-font-size: 12px;"
            + " -fx-font-weight: bold;"
            + " -fx-padding: 7px 16px;"
            + " -fx-border-color: " + (bg.equals(ACCENT) ? ACCENT : BORDER) + ";"
            + " -fx-border-radius: 4px;"
            + " -fx-cursor: hand;"));
        return b;
    }

    private static String lighten(String hex) {
        return switch (hex) {
            case "#161b22" -> "#21262d";
            case "#58a6ff" -> "#79b8ff";
            default -> hex;
        };
    }

    // ── WS event handler with debounce ──────────────────────────────
    // Multiple WS events can arrive in rapid succession (e.g. session_new
    // + session_new + task_result within 100ms). Without debounce, each
    // triggers a separate API call to /api/sessions. Debounce coalesces
    // rapid events into a single refresh.
    private volatile long lastWsRefreshTime = 0;
    private volatile boolean wsRefreshDropped = false;          // C5 fix: events suppressed during the window
    private final java.util.concurrent.atomic.AtomicBoolean wsTrailingScheduled =
            new java.util.concurrent.atomic.AtomicBoolean(false);
    private static final long WS_REFRESH_DEBOUNCE_MS = 500;

    private void handleWsEvent(String json) {
        String type = WsService.parseEventType(json);
        // v9: session_update (e.g. True IP discovered) refreshes the table too
        if ("session_new".equals(type) || "session_lost".equals(type) || "session_update".equals(type)) {
            // C5 FIX: the old debounce DISCARDED suppressed events — a second
            // beacon checking in within 500ms never refreshed the table (and
            // with WS up, polling is deliberately off, so it stayed missing).
            // Now: leading-edge refresh + ONE trailing refresh that fires if
            // anything was suppressed during the window (true coalescing).
            long now = System.currentTimeMillis();
            if (now - lastWsRefreshTime < WS_REFRESH_DEBOUNCE_MS) {
                wsRefreshDropped = true;
                scheduleTrailingRefresh();
                return;
            }
            lastWsRefreshTime = now;
            Platform.runLater(() -> sessionsTab.refresh());
            scheduleTrailingRefresh();
        } else if ("task_result".equals(type)) {
            Platform.runLater(() -> sessionsTab.onWsEvent(type, WsService.parseEventData(json)));
        } else if ("build_progress".equals(type)) {
            // Live payload-build progress → BuildAgentDialog footer progress bar
            com.google.gson.JsonObject d = WsService.parseEventData(json);
            int    pct    = d.has("percent") ? d.get("percent").getAsInt()   : 0;
            String stage  = d.has("stage")   ? d.get("stage").getAsString()  : "";
            String detail = d.has("detail")  ? d.get("detail").getAsString() : "";
            Platform.runLater(() -> BuildAgentDialog.onBuildProgress(pct, stage, detail));
        }
    }

    /** C5 fix: one coalesced trailing refresh after the debounce window. */
    private void scheduleTrailingRefresh() {
        if (!wsTrailingScheduled.compareAndSet(false, true)) return;
        scheduler.schedule(() -> {
            wsTrailingScheduled.set(false);
            if (wsRefreshDropped) {
                wsRefreshDropped = false;
                lastWsRefreshTime = System.currentTimeMillis();
                Platform.runLater(() -> sessionsTab.refresh());
            }
        }, WS_REFRESH_DEBOUNCE_MS, TimeUnit.MILLISECONDS);
    }

    private void refreshStatusBarAsync() {
        try {
            DashboardStats s = api.getDashboardStats();
            Platform.runLater(() -> {
                // Server is alive — update to green "Connected"
                statusLabel.setText("● Connected");
                statusLabel.setStyle("-fx-text-fill: #3fb950; -fx-font-size: 11px;"
                    + " -fx-font-family: 'JetBrains Mono', 'Consolas', monospace;");
                sessionCountLabel .setText("Sessions: "  + s.getActive_sessions());
                listenerCountLabel.setText("Listeners: " + s.getActive_listeners());
                uptimeLabel       .setText("Uptime: "    + formatUptime(s.getUptime()));
            });
        } catch (Exception e) {
            // Server is down or unreachable — update to red "Disconnected"
            Platform.runLater(() -> {
                statusLabel.setText("● Disconnected");
                statusLabel.setStyle("-fx-text-fill: #f85149; -fx-font-size: 11px;"
                    + " -fx-font-family: 'JetBrains Mono', 'Consolas', monospace;");
                sessionCountLabel.setText("Sessions: —");
                listenerCountLabel.setText("Listeners: —");
                uptimeLabel.setText("Uptime: —");
            });
        }
    }

    /** Format Go duration string like "5m58.663720571s" to "5m 58s" */
    private static String formatUptime(String raw) {
        if (raw == null || raw.isEmpty()) return "0s";
        try {
            long totalMs = parseGoDuration(raw);
            long hours = totalMs / 3600000;
            long mins  = (totalMs % 3600000) / 60000;
            long secs  = (totalMs % 60000) / 1000;
            if (hours > 0) return String.format("%dh %dm %ds", hours, mins, secs);
            if (mins  > 0) return String.format("%dm %ds", mins, secs);
            return String.format("%ds", secs);
        } catch (Exception e) {
            return raw.replaceAll("\\.\\d+s$", "s").replace("m", "m ");
        }
    }

    private static long parseGoDuration(String s) {
        long ms = 0;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+)h").matcher(s);
        while (m.find()) ms += Long.parseLong(m.group(1)) * 3600000L;
        m = java.util.regex.Pattern.compile("(\\d+)m").matcher(s);
        while (m.find()) ms += Long.parseLong(m.group(1)) * 60000L;
        m = java.util.regex.Pattern.compile("(\\d+(?:\\.\\d+)?)s").matcher(s);
        while (m.find()) ms += (long)(Double.parseDouble(m.group(1)) * 1000);
        return ms;
    }

    public ApiService getApi() { return api; }
}
