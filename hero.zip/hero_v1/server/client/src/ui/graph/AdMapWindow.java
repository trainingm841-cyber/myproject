package ui.graph;

import ui.web.JavaBridge;
import service.ApiService;
import models.Session;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import netscape.javascript.JSObject;

/**
 * AdMapWindow v2 — GraphView (Canvas) replaced with Graph.html (WebView + D3.js).
 * Same behavior: load stored scan on open, AD Scan button, poll until result arrives.
 * Modality.NONE — does NOT block dashboard.
 */
public class AdMapWindow extends Stage {

    private static final String BG     = "#0a0e14";
    private static final String PANEL  = "#161b22";
    private static final String BORDER = "#30363d";
    private static final String FG     = "#c9d1d9";
    private static final String DIM    = "#8b949e";
    private static final String ACCENT = "#58a6ff";
    private static final String OK     = "#3fb950";
    private static final String WARN   = "#d29922";
    private static final String ERR    = "#f85149";

    private final ApiService api;
    private final Session    session;

    private WebEngine  engine;
    private JavaBridge bridge;

    // Cloud-fix (#4 remainder): last resort when Graph.html cannot be found
    // on the classpath or the dev-mode file paths — mirrors SessionTab's
    // FALLBACK_HTML so this window is NEVER a blank white page.
    private static final String GRAPH_FALLBACK_HTML =
        "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><style>"
      + "body{background:#0a0e14;color:#c9d1d9;font-family:monospace;display:flex;"
      + "align-items:center;justify-content:center;height:100vh;margin:0}"
      + "div{max-width:680px;text-align:center;line-height:1.7}"
      + "h2{color:#f85149}code{color:#58a6ff}"
      + "</style></head><body><div>"
      + "<h2>Graph.html could not be loaded</h2>"
      + "<p>Looked for <code>/ui/web/Graph.html</code> on the classpath, then"
      + " <code>src/ui/web/Graph.html</code> and"
      + " <code>server/client/src/ui/web/Graph.html</code> on disk.</p>"
      + "<p>Launch the client from the project root (hero/), or rebuild with"
      + " Maven so ui/web/* is packaged as a resource.</p>"
      + "</div></body></html>";

    private final Label  statusLbl = new Label("ready");
    private final Label  nodeBar   = new Label("click a node for a quick summary");
    private final Button scanBtn   = new Button("\u25b6 AD Scan (admap)");
    private String lastUpdated = "";
    private Thread pollThread;
    private Timeline evtDrain;

    public AdMapWindow(Stage owner, ApiService api, Session session) {
        this.api     = api;
        this.session = session;

        setTitle("HERO \u2014 AD Map : " + session.getUsername() + "@" + session.getHostname());
        // NOTE: initOwner(owner) deliberately REMOVED — owned windows render as
        // attached dialogs on GNOME (no min/max, no reliable dragging). A plain
        // top-level window keeps the dashboard usable (Modality.NONE already set).
        initModality(Modality.NONE);
        initStyle(StageStyle.DECORATED);
        setResizable(true);
        var vb = Screen.getPrimary().getVisualBounds();
        setWidth (Math.min(1280, vb.getWidth()  * 0.88));
        setHeight(Math.min( 860, vb.getHeight() * 0.88));
        centerOnScreen();

        // ── WebView ──
        WebView webView = new WebView();
        engine = webView.getEngine();
        webView.setContextMenuEnabled(false);
        VBox.setVgrow(webView, Priority.ALWAYS);

        // ── Toolbar ──
        Label title = new Label("AD MAP");
        title.setStyle("-fx-text-fill:" + ACCENT + ";-fx-font-size:12px;-fx-font-weight:bold;");

        Label scope = new Label("agent: " + session.getUsername() + "@" + session.getHostname());
        scope.setStyle("-fx-text-fill:" + DIM + ";-fx-font-size:11px;");

        scanBtn.setStyle(btnStyle(true));
        scanBtn.setOnAction(e -> runScan());

        Button refreshBtn = new Button("\u21b3 Reload stored");
        refreshBtn.setStyle(btnStyle(false));
        refreshBtn.setOnAction(e -> loadStored());

        Button fitBtn = new Button("\u26f6 Fit");
        fitBtn.setStyle(btnStyle(false));
        fitBtn.setOnAction(e -> { if (engine != null) engine.executeScript("fitView()"); });

        statusLbl.setStyle("-fx-text-fill:" + DIM + ";-fx-font-size:11px;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox toolbar = new HBox(10, title, scope, scanBtn, refreshBtn, fitBtn, spacer, statusLbl);
        toolbar.setPadding(new Insets(10, 12, 10, 12));
        toolbar.setAlignment(Pos.CENTER_LEFT);
        toolbar.setStyle("-fx-background-color:" + PANEL + ";");

        // ── Bottom node info bar ──
        nodeBar.setStyle("-fx-text-fill:" + DIM + ";-fx-font-size:11px;-fx-font-family:Consolas;");
        HBox bottomBar = new HBox(nodeBar);
        bottomBar.setAlignment(Pos.CENTER_LEFT);
        bottomBar.setPadding(new Insets(5, 12, 5, 12));
        bottomBar.setStyle("-fx-background-color:" + PANEL + ";-fx-border-color:" + BORDER + " transparent transparent transparent;");

        // ── Layout ──
        VBox root = new VBox(0, toolbar, webView, bottomBar);
        root.setStyle("-fx-background-color:" + BG + ";");
        setScene(new Scene(root, 1280, 860));

        // ── Load HTML — classpath first, then dev-mode file fallback ──
        java.net.URL graphRes = getClass().getResource("/ui/web/Graph.html");
        if (graphRes == null) {
            try {
                java.io.File gf = new java.io.File("src/ui/web/Graph.html");
                if (!gf.exists()) gf = new java.io.File("server/client/src/ui/web/Graph.html");
                if (gf.exists()) graphRes = gf.toURI().toURL();
            } catch (java.net.MalformedURLException ignore) {}
        }
        if (graphRes != null) {
            engine.load(graphRes.toExternalForm());
        } else {
            // Absolute last resort — never leave the window blank-white
            engine.loadContent(GRAPH_FALLBACK_HTML);
        }

        // ── Wire bridge after load ──
        engine.getLoadWorker().stateProperty().addListener((obs, old, state) -> {
            if (state == javafx.concurrent.Worker.State.SUCCEEDED) {
                wireBridge();
                // Switch to admap mode in HTML toolbar — the mode event goes
                // through the JS mailbox and loadDataForMode fetches the
                // stored scan on a background thread (no loadStored() needed
                // here — that would duplicate the GET).
                engine.executeScript("setMode('admap')");
            }
        });

        setOnHidden(e -> {
            if (pollThread != null) pollThread.interrupt();
            if (evtDrain  != null) evtDrain.stop();
        });
    }

    private void wireBridge() {
        bridge = new JavaBridge(session, api, engine);
        JSObject win = (JSObject) engine.executeScript("window");
        win.setMember("javaBridge", bridge);

        bridge.setOnNodeSelected(nodeJson -> {
            Platform.runLater(() -> showNodeInfo(nodeJson));
        });

        startEventDrain();
    }

    // ── JS event mailbox drain (same pattern as NetworkGraphWindow) ──
    // Graph.html pushes {mode|refresh|node} events when the JSObject bridge
    // cannot deliver — Java pulls them with executeScript, which always works.
    private void startEventDrain() {
        evtDrain = new Timeline(new KeyFrame(Duration.millis(800), ev -> drainJsEvents()));
        evtDrain.setCycleCount(Timeline.INDEFINITE);
        evtDrain.play();
    }

    private void drainJsEvents() {
        try {
            Object r = engine.executeScript("window.__drainEvents ? window.__drainEvents() : '[]'");
            if (r == null) return;
            String json = r.toString();
            if (json.isEmpty() || "[]".equals(json)) return;
            com.google.gson.JsonArray arr =
                com.google.gson.JsonParser.parseString(json).getAsJsonArray();
            for (com.google.gson.JsonElement el : arr) {
                com.google.gson.JsonObject ob = el.getAsJsonObject();
                String type    = ob.has("type")    && !ob.get("type").isJsonNull()    ? ob.get("type").getAsString()    : "";
                String payload = ob.has("payload") && !ob.get("payload").isJsonNull() && ob.get("payload").isJsonPrimitive() ? ob.get("payload").getAsString() : "";
                switch (type) {
                    case "mode", "refresh" -> { if (!payload.isEmpty()) loadDataForMode(payload); }
                    case "node"            -> { if (!payload.isEmpty()) showNodeInfo(payload); }
                    default -> { }
                }
            }
        } catch (Exception ignore) { /* page busy or reloading — next tick */ }
    }

    // ── Mode-aware data load (background thread) ──

    private void loadDataForMode(String mode) {
        statusSet("loading " + mode + "\u2026", DIM);
        final String m = (mode == null || mode.isEmpty()) ? "admap" : mode;
        new Thread(() -> {
            try {
                String json = switch (m) {
                    case "network" -> api.getNetworkGraph();
                    case "attack"  -> api.getAttackGraph();
                    default        -> api.getAdMap(session.getId());
                };
                Platform.runLater(() -> {
                    if (bridge != null) bridge.jsLoadGraph(json);
                    statusSet("loaded", OK);
                });
            } catch (Exception ex) {
                Platform.runLater(() -> statusSet("load failed: " + ex.getMessage(), WARN));
            }
        }, "admap-load-" + m).start();
    }

    // ── Load stored scan ──────────────────────────────────────────────────

    private void loadStored() {
        statusSet("loading stored scan\u2026", DIM);
        new Thread(() -> {
            try {
                String json = api.getAdMap(session.getId());
                Platform.runLater(() -> {
                    if (json == null || json.contains("\"nodes\":[]")) {
                        statusSet("no scan stored yet \u2014 press 'AD Scan (admap)'", WARN);
                        return;
                    }
                    if (bridge != null) bridge.jsLoadGraph(json);
                    statusSet("stored scan loaded", OK);
                });
            } catch (Exception ex) {
                Platform.runLater(() -> statusSet("load failed: " + ex.getMessage(), WARN));
            }
        }, "admap-load").start();
    }

    // ── Run admap scan ────────────────────────────────────────────────────

    private void runScan() {
        final String taskId;
        try {
            taskId = api.sendTask(session.getId(), "admap", "");
        } catch (Exception ex) {
            statusSet("task failed: " + ex.getMessage(), ERR);
            return;
        }
        statusSet("admap tasked (" + taskId.substring(0, 8) + ") \u2014 waiting for beacon check-in\u2026", WARN);
        scanBtn.setDisable(true);

        if (pollThread != null) pollThread.interrupt();
        pollThread = new Thread(() -> {
            for (int i = 0; i < 60; i++) {
                try {
                    Thread.sleep(4000);
                    if (Thread.currentThread().isInterrupted()) return;
                    String json = api.getAdMap(session.getId());
                    if (json == null || json.contains("\"nodes\":[]")) continue;
                    // Check timestamp changed (simple string check)
                    if (json.contains(lastUpdated) && !lastUpdated.isEmpty()) continue;
                    Platform.runLater(() -> {
                        if (bridge != null) bridge.jsLoadGraph(json);
                        statusSet("scan complete \u2014 graph updated", OK);
                        scanBtn.setDisable(false);
                    });
                    return;
                } catch (InterruptedException ie) {
                    return;
                } catch (Exception ignore) { /* transient */ }
            }
            Platform.runLater(() -> {
                statusSet("no response yet \u2014 beacon sleep long; retry after check-in", WARN);
                scanBtn.setDisable(false);
            });
        }, "admap-poll");
        pollThread.setDaemon(true);
        pollThread.start();
    }

    // ── Node info bar ─────────────────────────────────────────────────────

    private void showNodeInfo(String nodeJson) {
        String label = jsonField(nodeJson, "label");
        String type  = jsonField(nodeJson, "type");
        String ip    = jsonField(nodeJson, "ip");
        if (ip.isEmpty()) ip = jsonField(nodeJson, "internal_ip");

        String info = label + "   \u00b7   " + type;
        if (!ip.isEmpty()) info += "   \u00b7   " + ip;
        if (type.equals("dc"))       info += "   \u00b7   Domain Controller \u2014 high value target";
        if (type.equals("computer")) info += "   \u00b7   from the AD browse list (NetServerEnum)";

        final String finalInfo = info;
        nodeBar.setText(finalInfo);
        nodeBar.setStyle("-fx-text-fill:" + FG + ";-fx-font-size:11px;-fx-font-family:Consolas;");
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private void statusSet(String s, String color) {
        statusLbl.setText(s);
        statusLbl.setStyle("-fx-text-fill:" + color + ";-fx-font-size:11px;");
    }

    private static String jsonField(String json, String key) {
        String search = "\"" + key + "\":\"";
        int i = json.indexOf(search);
        if (i < 0) return "";
        i += search.length();
        int j = json.indexOf('"', i);
        return j < 0 ? "" : json.substring(i, j);
    }

    private static String btnStyle(boolean accent) {
        return "-fx-background-color:" + PANEL + ";-fx-text-fill:" + (accent ? OK : FG)
             + ";-fx-border-color:" + BORDER + ";-fx-border-radius:4;-fx-background-radius:4;"
             + "-fx-padding:4 12 4 12;-fx-cursor:hand;";
    }
}
