package ui.graph;

import ui.web.JavaBridge;
import service.ApiService;
import models.Session;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import netscape.javascript.JSObject;

/**
 * NetworkGraphWindow v11 — GraphView.java (Canvas) replaced with
 * Graph.html (WebView + D3.js).
 *
 * Same behavior:
 *  - Modality.NONE — does NOT block dashboard
 *  - StageStyle.DECORATED — native min/max/close, resizable
 *  - Refresh, Enrich, AD Scan buttons still work (wired via JavaBridge)
 *  - Node click → node info bar at bottom
 *  - Auto-refresh every 30s (handled in JS side)
 *  - Attack / Network / AD Map mode tabs (in HTML toolbar)
 */
public class NetworkGraphWindow extends Stage {

    private static final String BG     = "#0a0e14";
    private static final String PANEL  = "#161b22";
    private static final String BORDER = "#30363d";
    private static final String FG     = "#c9d1d9";
    private static final String DIM    = "#8b949e";
    private static final String ACCENT = "#58a6ff";
    private static final String OK     = "#3fb950";
    private static final String ERR    = "#f85149";

    private final ApiService api;
    private final Session    session;    // current selected session (for Enrich/ADScan)

    private WebEngine  engine;
    private JavaBridge bridge;

    // Cloud-fix (#4 remainder): last resort when Graph.html cannot be found
    // on the classpath or the dev-mode file paths — mirrors SessionTab's
    // FALLBACK_HTML so this window is NEVER a blank white page.
    private static final String GRAPH_FALLBACK_HTML =
        "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><style>"
      + "body{background:#0a0e14;color:#c9d1d9;font-family:monospace;display:flex;"
      + "align-items:center;justify-content:center;height:100vh;margin:0}"
      + "div{max-width:680px;text-align:center;line-height:1.7}"
      + "h2{color:#f85149}code{color:#58a6ff}"
      + "</style></head><body><div>"
      + "<h2>Graph.html could not be loaded</h2>"
      + "<p>Looked for <code>/ui/web/Graph.html</code> on the classpath, then"
      + " <code>src/ui/web/Graph.html</code> and"
      + " <code>server/client/src/ui/web/Graph.html</code> on disk.</p>"
      + "<p>Launch the client from the project root (hero/), or rebuild with"
      + " Maven so ui/web/* is packaged as a resource.</p>"
      + "</div></body></html>";

    private final Label statusBar = new Label("ready");
    private final Label nodeBar   = new Label("click a node for a quick summary");
    private Thread pollThread;
    private Timeline evtDrain;

    // ─────────────────────────────────────────────────────────────────────

    public NetworkGraphWindow(Stage owner, ApiService api, Session session) {
        this.api     = api;
        // session can be null if no active sessions — handle gracefully
        this.session = session != null ? session : new Session();

        setTitle("HERO — Network Graph (attack + AD + neighbours)");
        // NOTE: initOwner(owner) deliberately REMOVED. Owned windows render as
        // attached/always-related dialogs on GNOME (Kali): no minimize/maximize
        // buttons, sometimes no dragging, and the operator could not reach the
        // dashboard while the graph was open. A plain top-level window gets
        // full native decorations, its own taskbar entry and Alt-Tab, and
        // Modality.NONE keeps the dashboard fully usable.
        initModality(Modality.NONE);       // does NOT block dashboard
        initStyle(StageStyle.DECORATED);   // native min/max/close
        setResizable(true);
        // Fit inside the visible screen — 1400x900 on a 1366x768 laptop
        // covers the whole desktop and feels like an unclosable modal.
        var vb = Screen.getPrimary().getVisualBounds();
        setWidth (Math.min(1400, vb.getWidth()  * 0.88));
        setHeight(Math.min( 900, vb.getHeight() * 0.88));
        centerOnScreen();

        // ── WebView ──
        WebView webView = new WebView();
        engine = webView.getEngine();
        webView.setContextMenuEnabled(false);
        VBox.setVgrow(webView, Priority.ALWAYS);

        // ── Bottom status strip (same as before) ──
        statusBar.setStyle("-fx-text-fill: " + DIM + "; -fx-font-size: 11px; -fx-font-family: Consolas;");
        nodeBar.setStyle  ("-fx-text-fill: " + DIM + "; -fx-font-size: 11px; -fx-font-family: Consolas;");

        HBox bottomBar = new HBox(20, nodeBar, statusBar);
        bottomBar.setAlignment(Pos.CENTER_LEFT);
        bottomBar.setPadding(new Insets(4, 12, 4, 12));
        bottomBar.setStyle("-fx-background-color: " + PANEL + "; -fx-border-color: " + BORDER + "; -fx-border-width: 1 0 0 0;");
        HBox.setHgrow(nodeBar, Priority.ALWAYS);

        // ── Layout ──
        VBox root = new VBox(0, webView, bottomBar);
        root.setStyle("-fx-background-color: " + BG + ";");

        Scene scene = new Scene(root, 1400, 900);
        scene.getStylesheets().add(
            getClass().getResource("/ui/web/dark-theme.css") != null
            ? getClass().getResource("/ui/web/dark-theme.css").toExternalForm()
            : "");
        setScene(scene);

        // ── Load HTML — classpath first, then dev-mode file fallback ──
        java.net.URL graphRes = getClass().getResource("/ui/web/Graph.html");
        if (graphRes == null) {
            try {
                java.io.File gf = new java.io.File("src/ui/web/Graph.html");
                if (!gf.exists()) gf = new java.io.File("server/client/src/ui/web/Graph.html");
                if (gf.exists()) graphRes = gf.toURI().toURL();
            } catch (java.net.MalformedURLException ignore) {}
        }
        if (graphRes != null) {
            engine.load(graphRes.toExternalForm());
        } else {
            // Absolute last resort — never leave the window blank-white
            engine.loadContent(GRAPH_FALLBACK_HTML);
        }

        // ── Wire bridge after load ──
        engine.getLoadWorker().stateProperty().addListener((obs, old, state) -> {
            if (state == javafx.concurrent.Worker.State.SUCCEEDED) {
                wireBridge();
                // Mode switch tells Java what to fetch (via the JS event
                // mailbox) — keeps ALL data loading on background threads.
                try { engine.executeScript("setMode('network')"); }
                catch (Exception ignore) {}
            }
        });

        // ── Window closed → stop poll thread + event drain ──
        setOnHidden(e -> {
            if (pollThread != null) pollThread.interrupt();
            if (evtDrain  != null) evtDrain.stop();
        });
    }

    private void wireBridge() {
        bridge = new JavaBridge(session, api, engine);

        JSObject win = (JSObject) engine.executeScript("window");
        win.setMember("javaBridge", bridge);

        // When JS clicks a node → update nodeBar
        bridge.setOnNodeSelected(nodeJson -> {
            Platform.runLater(() -> showNodeInfo(nodeJson));
        });

        startEventDrain();
    }

    // ── JS event mailbox drain ──────────────────────────────
    // Graph.html pushes {mode|refresh|node} events into window.__events when
    // the direct JSObject bridge cannot deliver them. Draining via
    // executeScript (Java→JS) always works, so the toolbar buttons, node
    // clicks and Refresh keep functioning on every WebView.
    private void startEventDrain() {
        evtDrain = new Timeline(new KeyFrame(Duration.millis(800), ev -> drainJsEvents()));
        evtDrain.setCycleCount(Timeline.INDEFINITE);
        evtDrain.play();
    }

    private void drainJsEvents() {
        try {
            Object r = engine.executeScript("window.__drainEvents ? window.__drainEvents() : '[]'");
            if (r == null) return;
            String json = r.toString();
            if (json.isEmpty() || "[]".equals(json)) return;
            com.google.gson.JsonArray arr =
                com.google.gson.JsonParser.parseString(json).getAsJsonArray();
            for (com.google.gson.JsonElement el : arr) {
                com.google.gson.JsonObject ob = el.getAsJsonObject();
                String type    = ob.has("type")    && !ob.get("type").isJsonNull()    ? ob.get("type").getAsString()    : "";
                String payload = ob.has("payload") && !ob.get("payload").isJsonNull() && ob.get("payload").isJsonPrimitive() ? ob.get("payload").getAsString() : "";
                switch (type) {
                    case "mode", "refresh" -> { if (!payload.isEmpty()) loadDataForMode(payload); }
                    case "node"            -> { if (!payload.isEmpty()) showNodeInfo(payload); }
                    default -> { }
                }
            }
        } catch (Exception ignore) { /* page busy or reloading — next tick */ }
    }

    // ── Data refresh ─────────────────────────────────────────────────────

    private void loadDataForMode(String mode) {
        statusSet("loading " + mode + "...", DIM);
        final String m = (mode == null || mode.isEmpty()) ? "attack" : mode;
        new Thread(() -> {
            try {
                String json = switch (m) {
                    case "network" -> api.getNetworkGraph();
                    case "admap"   -> api.getAdMap(session.getId());
                    default        -> api.getAttackGraph();
                };
                Platform.runLater(() -> {
                    if (bridge != null) bridge.jsLoadGraph(json);
                    statusSet("loaded", OK);
                });
            } catch (Exception e) {
                Platform.runLater(() -> statusSet("load failed: " + e.getMessage(), ERR));
            }
        }, "graph-load-" + m).start();
    }

    // ── Enrich selected agent (agraph task) ──────────────────────────────

    public void enrichSelected(String targetSessionId) {
        statusSet("agraph tasked — waiting for beacon check-in...", "#d29922");
        runPollTask(targetSessionId, "agraph", "enriched_at", 20, 4000,
            "agraph complete — graph updated",
            "still waiting — beacon sleep long; press Refresh later");
    }

    // ── AD Scan selected (admap task) ────────────────────────────────────

    public void admapSelected(String targetSessionId) {
        statusSet("admap tasked — waiting for beacon check-in...", "#d29922");
        runPollTask(targetSessionId, "admap", "admap_at", 60, 4000,
            "admap complete — graph updated",
            "no admap response yet — beacon sleep long; press Refresh later");
    }

    // ── Poll loop (common for agraph + admap) ────────────────────────────

    private void runPollTask(String sid, String taskType, String completionKey,
                             int maxIter, int intervalMs,
                             String successMsg, String timeoutMsg) {
        try {
            String taskId = api.sendTask(sid, taskType, "");
            statusSet(taskType + " queued (" + taskId.substring(0,8) + ") — waiting...", "#d29922");
        } catch (Exception e) {
            statusSet("task failed: " + e.getMessage(), ERR);
            return;
        }

        if (pollThread != null) pollThread.interrupt();
        pollThread = new Thread(() -> {
            for (int i = 0; i < maxIter; i++) {
                try {
                    Thread.sleep(intervalMs);
                    if (Thread.currentThread().isInterrupted()) return;
                    String json = api.getNetworkGraph();
                    Platform.runLater(() -> {
                        if (bridge != null) bridge.jsUpdateGraph(json);
                    });
                    // Check completion key presence in JSON (simple string scan)
                    if (json.contains(completionKey)) {
                        Platform.runLater(() -> statusSet(successMsg, OK));
                        return;
                    }
                } catch (InterruptedException ie) {
                    return;
                } catch (Exception ignore) { /* transient — keep polling */ }
            }
            Platform.runLater(() -> statusSet(timeoutMsg, "#d29922"));
        }, "graph-poll-" + taskType);
        pollThread.setDaemon(true);
        pollThread.start();
    }

    // ── Node info bar ─────────────────────────────────────────────────────

    private void showNodeInfo(String nodeJson) {
        // Parse label + type from JSON (simple extraction, no full JSON lib needed)
        String label = jsonField(nodeJson, "label");
        String type  = jsonField(nodeJson, "type");
        String ip    = jsonField(nodeJson, "ip");
        if (ip.isEmpty()) ip = jsonField(nodeJson, "internal_ip");

        String info = label + "   ·   " + type;
        if (!ip.isEmpty()) info += "   ·   " + ip;

        if (type.equals("dc"))       info += "   ·   Domain Controller — high value target";
        if (type.equals("computer")) info += "   ·   from AD browse list (NetServerEnum)";
        if (type.equals("domain"))   info += "   ·   target domain membership";

        nodeBar.setText(info);
        nodeBar.setStyle("-fx-text-fill: " + FG + "; -fx-font-size: 11px; -fx-font-family: Consolas;");
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private void statusSet(String msg, String color) {
        statusBar.setText(msg);
        statusBar.setStyle("-fx-text-fill: " + color + "; -fx-font-size: 11px; -fx-font-family: Consolas;");
    }

    /** Extract a JSON string field value (simple, no full parse needed). */
    private static String jsonField(String json, String key) {
        String search = "\"" + key + "\":\"";
        int i = json.indexOf(search);
        if (i < 0) return "";
        i += search.length();
        int j = json.indexOf('"', i);
        return j < 0 ? "" : json.substring(i, j);
    }
}
