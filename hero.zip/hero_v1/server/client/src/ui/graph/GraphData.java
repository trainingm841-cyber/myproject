package ui.graph;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * GraphData (v8, Phase D/E) — JSON → graph-model plumbing for the HERO
 * graph views.
 *
 * Two wire shapes are understood:
 *
 * 1. ATTACK GRAPH (server /api/graph/attack — server-assembled):
 *    { generated, mode:"attack", nodes:[{id,label,type,info}], edges:[{src,dst,kind}] }
 *
 * 2. AD MAP (server /api/admap/{session} — verbatim agent scan):
 *    { session_id, updated, data:{ kind:"ad_map", domain, workgroup, dc:{name,address,site,forest},
 *      domains:[], computers:[{name,type,comment,version}], total, enumerated, agent, is_admin } }
 *    → adMapToGraph() converts it to the same node/edge model so ONE renderer
 *      (GraphView) draws both.
 *
 * Node types (color-coded in GraphView): c2, agent, domain, workgroup, dc,
 * computer, host.
 */
public final class GraphData {

    private GraphData() {} // statics only

    // ========================================================
    // Model
    // ========================================================

    public static final class Node {
        public final String id;
        public final String label;
        public final String type;
        public final JsonObject info;
        Node(String id, String label, String type, JsonObject info) {
            this.id = id; this.label = label; this.type = type; this.info = info;
        }
    }

    public static final class Edge {
        public final String src, dst, kind;
        Edge(String src, String dst, String kind) { this.src = src; this.dst = dst; this.kind = kind; }
    }

    public static final class Graph {
        public final List<Node> nodes = new ArrayList<>();
        public final List<Edge> edges = new ArrayList<>();
        public final Map<String, Node> byId = new LinkedHashMap<>();
        void add(Node n) { if (!byId.containsKey(n.id)) { byId.put(n.id, n); nodes.add(n); } }
        void add(Edge e) { edges.add(e); }
    }

    // ========================================================
    // Attack graph parsing (server shape — pass through)
    // ========================================================

    public static Graph parseAttack(String raw) {
        Graph g = new Graph();
        JsonObject root = JsonParser.parseString(raw).getAsJsonObject();
        JsonArray nodes = root.getAsJsonArray("nodes");
        if (nodes != null) {
            for (JsonElement el : nodes) {
                JsonObject n = el.getAsJsonObject();
                g.add(new Node(str(n, "id"), str(n, "label"), str(n, "type"),
                        n.has("info") && n.get("info").isJsonObject() ? n.getAsJsonObject("info") : new JsonObject()));
            }
        }
        JsonArray edges = root.getAsJsonArray("edges");
        if (edges != null) {
            for (JsonElement el : edges) {
                JsonObject e = el.getAsJsonObject();
                g.add(new Edge(str(e, "src"), str(e, "dst"), str(e, "kind")));
            }
        }
        return g;
    }

    // ========================================================
    // v10: Unified Network graph parsing
    // Same node/edge shape as parseAttack — stats carries aggregate counts
    // (agents, dcs, computers, observed_hosts) for the status bar.
    // ========================================================

    public static final class NetworkStats {
        public int agents, relays, domains, dcs, computers, observed_hosts, adjacent_domains;
    }

    public static NetworkStats parseNetworkStats(String raw) {
        NetworkStats s = new NetworkStats();
        try {
            JsonObject root = JsonParser.parseString(raw).getAsJsonObject();
            if (root.has("stats") && root.get("stats").isJsonObject()) {
                JsonObject st = root.getAsJsonObject("stats");
                s.agents          = st.has("agents")          ? st.get("agents").getAsInt()          : 0;
                s.relays          = st.has("relays")          ? st.get("relays").getAsInt()          : 0;
                s.domains         = st.has("domains")         ? st.get("domains").getAsInt()         : 0;
                s.dcs             = st.has("dcs")             ? st.get("dcs").getAsInt()             : 0;
                s.computers       = st.has("computers")      ? st.get("computers").getAsInt()       : 0;
                s.observed_hosts  = st.has("observed_hosts")  ? st.get("observed_hosts").getAsInt()  : 0;
                s.adjacent_domains= st.has("adjacent_domains")? st.get("adjacent_domains").getAsInt(): 0;
            }
        } catch (Exception ignore) {}
        return s;
    }

    // ========================================================
    // AD map envelope parsing + graph conversion
    // ========================================================

    /** Parse {session_id, updated, data:{...}} — returns null on malformed input. */
    public static JsonObject parseAdMapEnvelope(String raw) {
        try {
            JsonObject root = JsonParser.parseString(raw).getAsJsonObject();
            return root.has("data") && root.get("data").isJsonObject() ? root : null;
        } catch (Exception e) {
            return null;
        }
    }

    public static String envelopeUpdated(JsonObject envelope) {
        return envelope.has("updated") ? envelope.get("updated").getAsString() : "";
    }

    /** Convert an agent ad_map JSON into the shared Graph model. */
    public static Graph adMapToGraph(JsonObject data) {
        Graph g = new Graph();

        String domain = str(data, "domain");
        if (domain.isEmpty()) domain = "WORKGROUP";
        boolean workgroup = bool(data, "workgroup");

        g.add(new Node("dom", domain, workgroup ? "workgroup" : "domain",
                info("role", workgroup ? "workgroup" : "domain",
                     "total", data.has("total") ? data.get("total").getAsInt() : 0)));

        // DC (DsGetDcName result)
        if (data.has("dc") && data.get("dc").isJsonObject()) {
            JsonObject dc = data.getAsJsonObject("dc");
            String name = str(dc, "name");
            if (!name.isEmpty()) {
                g.add(new Node("dc", name, "dc", dc));
                g.add(new Edge("dom", "dc", "dc"));
            }
        }

        // The agent itself (map origin)
        String agent = str(data, "agent");
        if (!agent.isEmpty()) {
            JsonObject ai = info("elevated", bool(data, "is_admin"));
            g.add(new Node("agent", agent, "agent", ai));
            g.add(new Edge("agent", "dom", "member"));
        }

        // Adjacent / trusted domains reported by the browse list
        JsonArray doms = data.getAsJsonArray("domains");
        if (doms != null) {
            int i = 0;
            for (JsonElement el : doms) {
                String d = el.getAsString();
                if (d.isEmpty() || d.equalsIgnoreCase(domain)) continue;
                String id = "dom" + (i++);
                g.add(new Node(id, d, "domain", info("role", "adjacent domain")));
                g.add(new Edge("dom", id, "trust"));
            }
        }

        // Computers (the browse list) — ring-rendered by GraphView
        JsonArray comps = data.getAsJsonArray("computers");
        if (comps != null) {
            for (JsonElement el : comps) {
                JsonObject c = el.getAsJsonObject();
                String name = str(c, "name");
                if (name.isEmpty()) continue;
                String id = "pc:" + name;
                String role = str(c, "type");
                String type = role.equals("dc") || role.equals("bdc") ? "dc" : "computer";
                g.add(new Node(id, name, type, c));
                g.add(new Edge("dom", id, "inventory"));
            }
        }
        return g;
    }

    // ========================================================
    // Helpers
    // ========================================================

    static String str(JsonObject o, String key) {
        return o != null && o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : "";
    }

    static boolean bool(JsonObject o, String key) {
        return o != null && o.has(key) && !o.get(key).isJsonNull() && o.get(key).getAsBoolean();
    }

    private static JsonObject info(Object... kv) {
        JsonObject o = new JsonObject();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            Object v = kv[i + 1];
            if (v instanceof Boolean) o.addProperty((String) kv[i], (Boolean) v);
            else if (v instanceof Number) o.addProperty((String) kv[i], (Number) v);
            else o.addProperty((String) kv[i], String.valueOf(v));
        }
        return o;
    }
}
