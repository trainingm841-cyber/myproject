package ui.dialogs;

import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;
import netscape.javascript.JSObject;
import service.ApiService;
import service.WsService;
import ui.web.JavaBridge;

/**
 * BuildAgentDialog — WebView-based version.
 *
 * REWRITE (Task B Phase 2): the original 1043-line JavaFX form was
 * replaced with a slim Java wrapper that loads an HTML/CSS/JS frontend
 * (located in src/ui/web/dialogs/BuildAgentDialog/) inside a JavaFX
 * WebView. Light grey color theme (visually distinct from the dark
 * CreateListenerDialog) per operator request.
 *
 * WHY: same reasoning as CreateListenerDialog — JavaFX form code was
 * brittle + verbose. HTML/CSS gives us declarative forms with tabs
 * + reactive show/hide.
 *
 * WIRING UNCHANGED FROM ORIGINAL:
 *   - Same constructor signature: (Window owner, ApiService api, Runnable onSuccess)
 *   - Same show() method
 *   - Same Modality.NONE (non-blocking)
 *   - Same api.buildImplantJson(json) call on submit
 *   - Same WebSocket "build_progress" event flow:
 *       Server → WS → MainView → BuildAgentDialog.onBuildProgress(pct, stage, detail)
 *       (static method on this class — MainView's existing call site unchanged)
 *   - Same onSuccess Runnable callback on success
 *
 * The JavaBridge instance is per-dialog. It exposes:
 *   - submitBuildForm(json) → runs api.buildImplantJson(json) on a
 *     background thread (10-min timeout). On success: fires
 *     window.onBuildDone(resultJson). On error: window.onBuildError(msg).
 *   - fetchInitialData() → synchronously returns JSON string with
 *     {listeners: [...], profiles: [...]} from /api/listeners + /api/profiles
 *   - closeBuildDialog() → closes the JavaFX Stage.
 *
 * STATIC activeInstance + onBuildProgress:
 *   The original Java version used a static `activeInstance` pointer +
 *   static onBuildProgress method to route WS build_progress events
 *   to the currently-building dialog. MainView calls:
 *     Platform.runLater(() -> BuildAgentDialog.onBuildProgress(pct, stage, detail));
 *   This pattern is preserved — only the dialog's INTERNAL implementation
 *   changed (JavaFX form → WebView). The static method signature is
 *   identical so MainView doesn't need any change.
 */
public class BuildAgentDialog {

    private final Stage       stage;
    private final ApiService  api;
    private final Runnable    onSuccess;
    private WebView           webView;
    private WebEngine         engine;
    private JavaBridge        bridge;

    // ── STATIC: WS progress routing (preserved from original) ──────
    // C9 FIX: this pointer means "the dialog with an ACTIVE build" —
    // set only when a build actually starts, not in the constructor.
    // Modality.NONE allows two dialogs open simultaneously; the static
    // pointer ensures only the actively-building one receives progress.
    private static volatile BuildAgentDialog activeInstance;

    // ── Constructors (same signature as original) ──────────────────
    public BuildAgentDialog(Window owner, ApiService api, Runnable onSuccess) {
        this.api       = api;
        this.onSuccess = onSuccess;
        this.stage     = new Stage();
        // When the dialog hides, clear the activeInstance pointer if we own it
        stage.setOnHiding(e -> {
            if (activeInstance == this) activeInstance = null;
        });
        buildUI(owner);
    }

    public void show() { stage.show(); }

    // ============================================================
    //  STATIC WS HOOK (called by MainView on FX thread)
    //  Same signature as original — MainView's call site unchanged.
    // ============================================================
    public static void onBuildProgress(int percent, String stage, String detail) {
        BuildAgentDialog d = activeInstance;
        if (d != null) d.handleBuildProgress(percent, stage, detail);
    }

    private void handleBuildProgress(int pct, String stageName, String detail) {
        // Forward to the HTML UI via JavaBridge → window.updateBuildProgress()
        if (bridge != null) {
            bridge.jsUpdateBuildProgress(pct, stageName, detail);
        }
    }

    // ============================================================
    //  UI BUILDING — WebView + JavaBridge wiring
    // ============================================================
    private void buildUI(Window owner) {
        stage.initOwner(owner);
        stage.initModality(Modality.NONE);   // non-blocking — matches original
        // Default DECORATED style — native title bar with min/max/close + drag
        stage.setTitle("Build Agent — HERO C2");
        stage.setWidth(640);
        stage.setHeight(480);  // reduced from 620 — matches actual content
        stage.setMinWidth(560);
        stage.setMinHeight(420);
        stage.setResizable(true);

        // ── WebView (replaces 1043 lines of JavaFX form code) ────
        webView = new WebView();
        engine  = webView.getEngine();
        engine.setJavaScriptEnabled(true);
        webView.setContextMenuEnabled(false);

        // ── Load HTML using the same fallback chain as CreateListenerDialog ──
        java.net.URL htmlRes = getClass().getResource(
            "/ui/web/dialogs/BuildAgentDialog/index.html");
        if (htmlRes == null) {
            java.io.File hf = new java.io.File(
                "src/ui/web/dialogs/BuildAgentDialog/index.html");
            if (!hf.exists()) {
                hf = new java.io.File(
                    "server/client/src/ui/web/dialogs/BuildAgentDialog/index.html");
            }
            if (hf.exists()) {
                try {
                    htmlRes = hf.toURI().toURL();
                } catch (java.net.MalformedURLException ignored) {}
            }
        }
        if (htmlRes != null) {
            engine.load(htmlRes.toExternalForm());
        } else {
            engine.loadContent(FALLBACK_HTML);
        }

        // ── Wire JavaBridge after page loads ─────────────────────
        engine.getLoadWorker().stateProperty().addListener((obs, old, neu) -> {
            if (neu == Worker.State.SUCCEEDED) {
                try {
                    JSObject win = (JSObject) engine.executeScript("window");
                    // Per-dialog JavaBridge — pass null session (this dialog has none),
                    // the api + engine, plus the onSuccess Runnable for builds.
                    bridge = new JavaBridge(null, api, engine);
                    bridge.setOnClose(() -> Platform.runLater(() -> stage.close()));
                    bridge.setOnSuccessListener(onSuccess);
                    // ── Wire build start/end callbacks for activeInstance management ──
                    // When a build starts, mark this dialog as the active progress
                    // receiver so MainView's WS events reach the right dialog.
                    // When build ends (success or error), clear the pointer.
                    bridge.setOnBuildStart(() -> BuildAgentDialog.markActive(BuildAgentDialog.this));
                    bridge.setOnBuildEnd(() -> BuildAgentDialog.clearActive(BuildAgentDialog.this));
                    // Register the bridge BEFORE installing the build-progress
                    // forwarder — Alpine's init() will call fetchInitialData()
                    // synchronously during x-init, so the bridge must be live.
                    win.setMember("javaBridge", bridge);

                    // ── Expose the build-specific Java→JS callbacks ──
                    engine.executeScript(
                        "window.updateBuildProgress = function(pct, stage, detail) { " +
                        "  if (window.Alpine) { " +
                        "    var d = document.querySelector('[x-data]'); " +
                        "    if (d && d._x_dataStack && d._x_dataStack[0]) { " +
                        "      d._x_dataStack[0].updateBuildProgress(pct, stage, detail); " +
                        "    } " +
                        "  } " +
                        "};");
                    engine.executeScript(
                        "window.onBuildDone = function(resultJson) { " +
                        "  if (window.Alpine) { " +
                        "    var d = document.querySelector('[x-data]'); " +
                        "    if (d && d._x_dataStack && d._x_dataStack[0]) { " +
                        "      d._x_dataStack[0].onBuildDone(resultJson); " +
                        "    } " +
                        "  } " +
                        "};");
                    engine.executeScript(
                        "window.onBuildError = function(msg) { " +
                        "  if (window.Alpine) { " +
                        "    var d = document.querySelector('[x-data]'); " +
                        "    if (d && d._x_dataStack && d._x_dataStack[0]) { " +
                        "      d._x_dataStack[0].onBuildError(msg); " +
                        "    } " +
                        "  } " +
                        "};");

                    // ── RACE CONDITION FIX ──────────────────────────────
                    // Alpine.js x-init runs BEFORE this SUCCEEDED callback fires
                    // (Alpine initializes during DOMContentLoaded, which happens
                    // before the WebView considers the page "done loading"). So
                    // window.javaBridge is undefined when Alpine's init() tries
                    // to call fetchInitialData() — dropdowns stay empty.
                    //
                    // FIX: After wiring the bridge, explicitly call the Alpine
                    // component's loadData() method from Java side. This
                    // guarantees the bridge is live when the data fetch happens.
                    // Uses the same _x_dataStack pattern as the other callbacks.
                    engine.executeScript(
                        "if (window.Alpine) { " +
                        "  var d = document.querySelector('[x-data]'); " +
                        "  if (d && d._x_dataStack && d._x_dataStack[0] && d._x_dataStack[0].loadData) { " +
                        "    d._x_dataStack[0].loadData(); " +
                        "  } " +
                        "}");
                } catch (Exception e) {
                    System.err.println("[BuildAgentDialog] bridge wiring failed: " + e);
                }
            }
        });

        StackPane root = new StackPane(webView);
        Scene scene = new Scene(root, 640, 480);
        try {
            java.net.URL css = getClass().getResource("/dark-theme.css");
            if (css != null) scene.getStylesheets().add(css.toExternalForm());
        } catch (Exception ignored) {}
        stage.setScene(scene);
    }

    // ============================================================
    //  FALLBACK HTML — shown only if index.html can't be loaded
    // ============================================================
    private static final String FALLBACK_HTML =
        "<!DOCTYPE html><html><head><meta charset='UTF-8'>" +
        "<style>" +
        "  body { background: #e4e7eb; color: #1f2328; font-family: 'Inter',sans-serif; padding: 30px; }" +
        "  h1 { color: #0969da; font-size: 20px; margin-bottom: 16px; }" +
        "  p { color: #57606a; line-height: 1.5; }" +
        "  code { background: #f5f6f8; color: #cf222e; padding: 2px 6px; border-radius: 3px; font-family: monospace; }" +
        "</style></head><body>" +
        "<h1>BuildAgentDialog: HTML file missing</h1>" +
        "<p>Looked for:</p>" +
        "<ul>" +
        "<li><code>/ui/web/dialogs/BuildAgentDialog/index.html</code> on classpath</li>" +
        "<li><code>src/ui/web/dialogs/BuildAgentDialog/index.html</code> on disk</li>" +
        "<li><code>server/client/src/ui/web/dialogs/BuildAgentDialog/index.html</code> on disk</li>" +
        "</ul>" +
        "<p>Run <code>./build.sh client</code> to re-build with the HTML resources bundled.</p>" +
        "</body></html>";

    // ════════════════════════════════════════════════════════════════════════
    //  STATIC MARKER for activeInstance — called by JavaBridge when
    //  operator clicks "Build Agent". Marks this dialog as the one
    //  that should receive WS build_progress events.
    // ════════════════════════════════════════════════════════════════════════
    public static void markActive(BuildAgentDialog d) {
        activeInstance = d;
    }
    public static void clearActive(BuildAgentDialog d) {
        if (activeInstance == d) activeInstance = null;
    }
}
