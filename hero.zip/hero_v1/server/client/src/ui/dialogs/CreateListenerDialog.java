package ui.dialogs;

import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;
import netscape.javascript.JSObject;
import service.ApiService;
import ui.web.JavaBridge;

/**
 * CreateListenerDialog — WebView-based version.
 *
 * REWRITE (Task B Phase 1): the original 843-line JavaFX form was
 * replaced with a slim Java wrapper that loads an HTML/CSS/JS frontend
 * (located in src/ui/web/dialogs/CreateListenerDialog/) inside a
 * JavaFX WebView. The actual form layout, protocol-switching logic,
 * validation, and JSON building all live in app.js (Alpine.js) now.
 *
 * WHY: JavaFX's form rendering was brittle and verbose (every field
 * needed addTextField/addComboField calls + style constants + layout
 * containers). HTML/CSS gives us declarative forms with reactive
 * show/hide on protocol change — a 50-line Alpine template replaces
 * ~400 lines of JavaFX boilerplate.
 *
 * WIRING UNCHANGED FROM ORIGINAL:
 *   - Same constructor signature: (Window owner, ApiService api, Runnable onSuccess)
 *   - Same show() method
 *   - Same Modality.NONE (non-blocking — matches original)
 *   - Same ApiService.createListener(json) call on submit
 *   - Same onSuccess Runnable callback on success
 *   - Same status update pattern (JavaBridge fires window callbacks)
 *
 * The JavaBridge instance is per-dialog (created here, passed to
 * WebView's window.javaBridge member). It exposes:
 *   - submitListenerForm(json) → calls api.createListener(json) on
 *     a background thread, then fires window.onListenerStarted() or
 *     window.onListenerError(msg) back into the WebView.
 *   - closeListenerDialog() → closes the JavaFX Stage.
 *
 * Resource loading follows the same fallback chain as BeaconConsole
 * and Graph.html:
 *   1. classpath:/ui/web/dialogs/CreateListenerDialog/index.html
 *   2. src/ui/web/dialogs/CreateListenerDialog/index.html
 *   3. server/client/src/ui/web/dialogs/CreateListenerDialog/index.html
 */
public class CreateListenerDialog {

    private final Stage      stage;
    private final ApiService api;
    private final Runnable   onSuccess;
    private WebView          webView;
    private WebEngine         engine;
    private JavaBridge        bridge;

    // ── Constructors — same signature as original ──────────────
    public CreateListenerDialog(Window owner, ApiService api, Runnable onSuccess) {
        this.api       = api;
        this.onSuccess = onSuccess;
        this.stage     = new Stage();
        buildUI(owner);
    }

    // Legacy constructor — no API wiring (standalone preview)
    public CreateListenerDialog(Window owner) {
        this(owner, null, null);
    }

    public void show() { stage.show(); }

    // ============================================================
    //  UI BUILDING — WebView + JavaBridge wiring
    // ============================================================
    private void buildUI(Window owner) {
        stage.initOwner(owner);
        stage.initModality(Modality.NONE);  // non-blocking — matches original
        // IMPORTANT: do NOT use StageStyle.UNDECORATED — that strips the
        // native title bar (no min/max/close buttons + can't drag the window).
        // The user explicitly asked for: (1) working min/max, (2) window
        // draggable, (3) smaller footer. Default DECORATED style gives all
        // of (1) + (2) for free — JavaFX renders the OS-native title bar
        // with minimize/maximize/close buttons + the title text + drag-to-move.
        // We set the title text via setTitle() below.
        stage.setTitle("Create Listener — HERO C2");
        stage.setWidth(560);
        stage.setHeight(420);  // reduced from 540 — matches actual content height
        stage.setMinWidth(520);
        stage.setMinHeight(360);
        stage.setResizable(true);

        // ── WebView (replaces 843 lines of JavaFX form code) ────
        webView = new WebView();
        engine  = webView.getEngine();
        engine.setJavaScriptEnabled(true);

        // Prevent the default context menu (right-click) — clean look
        webView.setContextMenuEnabled(false);

        // ── Load HTML using the same fallback chain as BeaconConsole ──
        // 1. classpath (production JAR — pom.xml bundles src/ui/web/**)
        // 2. dev mode: src/ui/web/... (relative to CWD when running from
        //    Maven without package phase)
        // 3. dev mode alt: server/client/src/ui/web/... (when running
        //    from project root)
        java.net.URL htmlRes = getClass().getResource(
            "/ui/web/dialogs/CreateListenerDialog/index.html");
        if (htmlRes == null) {
            // Dev fallback — try disk paths
            java.io.File hf = new java.io.File(
                "src/ui/web/dialogs/CreateListenerDialog/index.html");
            if (!hf.exists()) {
                hf = new java.io.File(
                    "server/client/src/ui/web/dialogs/CreateListenerDialog/index.html");
            }
            if (hf.exists()) {
                try {
                    htmlRes = hf.toURI().toURL();
                } catch (java.net.MalformedURLException ignored) {
                    // fall through to fallback HTML below
                }
            }
        }
        if (htmlRes != null) {
            //console.log("[CreateListenerDialog] loading " + htmlRes);
            engine.load(htmlRes.toExternalForm());
        } else {
            // Fallback inline HTML — only shows if the dialog file is missing
            engine.loadContent(FALLBACK_HTML);
        }

        // ── Wire JavaBridge after page loads ─────────────────────
        // The bridge's methods (submitListenerForm, closeListenerDialog)
        // are exposed to JS as window.javaBridge.* — Alpine.js app.js
        // calls them when the user clicks "Start Listener" or "Cancel".
        engine.getLoadWorker().stateProperty().addListener((obs, old, neu) -> {
            if (neu == Worker.State.SUCCEEDED) {
                try {
                    JSObject win = (JSObject) engine.executeScript("window");
                    // Create a per-dialog JavaBridge — pass null session
                    // (this dialog doesn't have one) and the api + engine.
                    // Callbacks are wired inline below.
                    bridge = new JavaBridge(null, api, engine);
                    bridge.setOnClose(() -> Platform.runLater(() -> stage.close()));
                    // When the listener is successfully started, fire the operator's
                    // onSuccess Runnable (e.g., refresh the SessionsTab listener list).
                    // This matches the original CreateListenerDialog behavior where
                    // onSuccess.run() was called inside onStart() on success.
                    bridge.setOnSuccessListener(onSuccess);
                    win.setMember("javaBridge", bridge);

                    // ── Expose the dialog-specific Java→JS callbacks ──
                    // These are called by JavaBridge after the HTTP call
                    // to /api/listeners completes (on background thread).
                    // The bridge's submitListenerForm method runs the API
                    // call and then calls back into these via executeScript.
                    engine.executeScript(
                        "window.onListenerStarted = function() { " +
                        "  if (window.Alpine) { " +
                        "    var d = document.querySelector('[x-data]'); " +
                        "    if (d && d._x_dataStack && d._x_dataStack[0]) { " +
                        "      d._x_dataStack[0].onListenerStarted(); " +
                        "    } " +
                        "  } " +
                        "};");
                    engine.executeScript(
                        "window.onListenerError = function(msg) { " +
                        "  if (window.Alpine) { " +
                        "    var d = document.querySelector('[x-data]'); " +
                        "    if (d && d._x_dataStack && d._x_dataStack[0]) { " +
                        "      d._x_dataStack[0].onListenerError(msg); " +
                        "    } " +
                        "  } " +
                        "};");
                } catch (Exception e) {
                    System.err.println("[CreateListenerDialog] bridge wiring failed: " + e);
                }
            }
        });

        // Layout: WebView fills the entire dialog
        StackPane root = new StackPane(webView);
        // Layout: WebView fills the entire dialog. Size matches stage's
        // initial size — when user resizes, the Scene grows/shrinks with
        // the stage (JavaFX default behaviour). WebView inside takes all
        // available space via StackPane.
        Scene scene = new Scene(root, 560, 420);
        // Apply the framework's dark theme so any JavaFX chrome around the WebView matches
        try {
            java.net.URL css = getClass().getResource("/dark-theme.css");
            if (css != null) scene.getStylesheets().add(css.toExternalForm());
        } catch (Exception ignored) {}
        stage.setScene(scene);
    }

    // ============================================================
    //  FALLBACK HTML — shown only if index.html can't be loaded
    // ============================================================
    private static final String FALLBACK_HTML =
        "<!DOCTYPE html><html><head><meta charset='UTF-8'>" +
        "<style>" +
        "  body { background: #0a0e14; color: #c9d1d9; font-family: 'Inter',sans-serif; padding: 30px; }" +
        "  h1 { color: #58a6ff; font-size: 20px; margin-bottom: 16px; }" +
        "  p { color: #8b949e; line-height: 1.5; }" +
        "  code { background: #161b22; color: #f85149; padding: 2px 6px; border-radius: 3px; font-family: monospace; }" +
        "</style></head><body>" +
        "<h1>CreateListenerDialog: HTML file missing</h1>" +
        "<p>Looked for:</p>" +
        "<ul>" +
        "<li><code>/ui/web/dialogs/CreateListenerDialog/index.html</code> on classpath</li>" +
        "<li><code>src/ui/web/dialogs/CreateListenerDialog/index.html</code> on disk</li>" +
        "<li><code>server/client/src/ui/web/dialogs/CreateListenerDialog/index.html</code> on disk</li>" +
        "</ul>" +
        "<p>Run <code>./build.sh client</code> to re-build with the HTML resources bundled.</p>" +
        "</body></html>";
}
