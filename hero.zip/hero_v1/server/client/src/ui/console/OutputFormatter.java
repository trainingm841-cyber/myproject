package ui.console;

import java.util.*;
import java.util.regex.*;

/**
 * OutputFormatter — converts raw agent output into styled segments for RichTextFX.
 *
 * Design (per user request — SIMPLE over DECORATIVE):
 *   - Only the Linux-style markers get colored: [*] blue, [+] green, [!] yellow, [-] red
 *   - All command output body is uniform default color (no per-token rainbow)
 *   - Table headers get accent color + bold
 *   - That's it — no fancy highlighting of IPs/paths/numbers/etc.
 *
 * Marker rules (applied to ALL commands uniformly):
 *   - Line starts with [*] → marker is blue, rest of line is default
 *   - Line starts with [+] → marker is green, rest of line is default
 *   - Line starts with [!] → marker is yellow, rest of line is default
 *   - Line starts with [-] or [ERR] → marker + line is red
 *   - Other lines → default color
 *
 * Special cases:
 *   - Empty output → "(no output)" in dim
 *   - Errors (raw starts with [ERR]) → entire output red
 *   - Banner/headers → accent color (used by showBanner)
 */
public final class OutputFormatter {

    private OutputFormatter() {}

    public static final class StyledSegment {
        public final String text;
        public final String cssClass;
        public StyledSegment(String text, String cssClass) {
            this.text = text;
            this.cssClass = cssClass;
        }
    }

    // ── Public entry point ────────────────────────────────────────────────
    public static List<StyledSegment> format(String command, String rawResult, String args) {
        String cmd = (command == null ? "" : command.toLowerCase()).trim();
        String raw = rawResult == null ? "" : rawResult;

        // Errors take precedence — agent prefixes with [ERR]
        if (raw.startsWith("[ERR]") || raw.startsWith("[-]") || raw.startsWith("Error:")) {
            return errorBlock(raw);
        }

        // Special-case commands that need confirmation lines.
        // FIX (I4 client half): sleep/kill/persist/wipe CONFIRMATIONS were
        // FABRICATED from the local args — the agent's real response (success
        // OR failure) was thrown away, so `sleep 999999` or a failed kill
        // still printed "updated ✓". These commands now render the agent's
        // actual reply via autoHighlight (the agent sends [+] / [ERR] markers).
        return switch (cmd) {
            case "amsi_check" -> amsiStatus(raw);
            case "screenshot" -> screenshotConfirm(raw);
            case "download"   -> downloadConfirm(raw, args);
            case "hash"       -> hashBlock(raw, args);
            case "pwd"        -> pwdBlock(raw);
            case "cd", "chdir"-> cdBlock(raw);
            default           -> autoHighlight(raw);
        };
    }

    // ── Core: marker-based highlighting ───────────────────────────────────

    /**
     * autoHighlight — applies the marker coloring rule to ANY output.
     * This is the default formatter for ~90% of commands.
     *
     * Marker rules:
     *   [*]    → blue marker, default body
     *   [+]    → green marker, default body
     *   [!]    → yellow marker, default body
     *   [-]    → red marker + red body
     *   [ERR]  → red marker + red body
     *   other  → default color
     *
     * Ensures output ends with a trailing newline so the next command echo
     * is visually separated (matches Linux/Windows terminal behavior).
     */
    private static List<StyledSegment> autoHighlight(String raw) {
        List<StyledSegment> out = new ArrayList<>();
        if (raw.isEmpty()) {
            out.add(new StyledSegment("(no output)\n", TerminalStyle.CL_DIM));
            return out;
        }

        String[] lines = raw.split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            // Re-add newline to every line EXCEPT the last empty one (split artifact)
            if (i < lines.length - 1) {
                line += "\n";
            } else if (line.isEmpty()) {
                // Last line is empty (raw ended with \n) — skip, we'll add trailing newline below
                continue;
            }

            String trimmed = line.stripLeading();
            String leadingWs = line.substring(0, line.length() - trimmed.length());

            if (trimmed.startsWith("[*]")) {
                out.add(new StyledSegment(leadingWs + "[*]", TerminalStyle.CL_INFO));
                out.add(new StyledSegment(trimmed.substring(3), TerminalStyle.CL_DEFAULT));
            } else if (trimmed.startsWith("[+]")) {
                out.add(new StyledSegment(leadingWs + "[+]", TerminalStyle.CL_SUCCESS));
                out.add(new StyledSegment(trimmed.substring(3), TerminalStyle.CL_DEFAULT));
            } else if (trimmed.startsWith("[!]")) {
                out.add(new StyledSegment(leadingWs + "[!]", TerminalStyle.CL_WARNING));
                out.add(new StyledSegment(trimmed.substring(3), TerminalStyle.CL_DEFAULT));
            } else if (trimmed.startsWith("[-]") || trimmed.startsWith("[ERR]")) {
                int prefixLen = trimmed.startsWith("[ERR]") ? 5 : 3;
                out.add(new StyledSegment(leadingWs + trimmed.substring(0, prefixLen),
                        TerminalStyle.CL_ERROR));
                out.add(new StyledSegment(trimmed.substring(prefixLen), TerminalStyle.CL_ERROR));
            } else {
                out.add(new StyledSegment(line, TerminalStyle.CL_DEFAULT));
            }
        }

        // Ensure output ends with exactly one newline
        if (!out.isEmpty()) {
            StyledSegment last = out.get(out.size() - 1);
            if (!last.text.endsWith("\n")) {
                out.set(out.size() - 1,
                    new StyledSegment(last.text + "\n", last.cssClass));
            }
        }
        return out;
    }

    // ── Special-case formatters ───────────────────────────────────────────

    /** Error block — entire output red. */
    private static List<StyledSegment> errorBlock(String raw) {
        List<StyledSegment> out = new ArrayList<>();
        String[] lines = raw.split("\n");
        String firstLine = lines[0]
            .replace("[ERR] ", "")
            .replace("Set-Location: ", "cd: ")
            .replace("Resolve-Path: ", "ls: ");
        out.add(new StyledSegment("[-] " + firstLine + "\n", TerminalStyle.CL_ERROR));
        return out;
    }




    /** amsi_check status. */
    private static List<StyledSegment> amsiStatus(String raw) {
        String status = raw == null ? "(unknown)" : raw.trim();
        String cls = status.toLowerCase().contains("patched") || status.toLowerCase().contains("disabled")
            ? TerminalStyle.CL_SUCCESS : TerminalStyle.CL_WARNING;
        return List.of(
            new StyledSegment("AMSI Status: ", TerminalStyle.CL_TABLE_HDR),
            new StyledSegment(status + "\n", cls)
        );
    }

    /** screenshot confirm. */
    private static List<StyledSegment> screenshotConfirm(String raw) {
        return List.of(
            new StyledSegment("[+] Screenshot captured", TerminalStyle.CL_SUCCESS),
            new StyledSegment(raw != null && !raw.isEmpty() ? " → " + raw + "\n" : "\n",
                TerminalStyle.CL_DEFAULT)
        );
    }

    /** download confirm — show file + size, NOT the base64 blob. */
    private static List<StyledSegment> downloadConfirm(String raw, String args) {
        int bytes = (raw == null ? 0 : raw.length() * 3 / 4);
        return List.of(
            new StyledSegment("[+] File: ", TerminalStyle.CL_SUCCESS),
            new StyledSegment((args == null ? "" : args) + "\n", TerminalStyle.CL_DEFAULT),
            new StyledSegment("[+] Size: ", TerminalStyle.CL_SUCCESS),
            new StyledSegment(humanSize(bytes) + " (" + bytes + " bytes)\n", TerminalStyle.CL_DEFAULT),
            new StyledSegment("[+] Data received and stored on server\n", TerminalStyle.CL_SUCCESS)
        );
    }

    /** hash block. */
    private static List<StyledSegment> hashBlock(String raw, String args) {
        String clean = raw == null ? "" : raw.replace("SHA256:", "").trim();
        return List.of(
            new StyledSegment("SHA256 (" + (args == null ? "" : args) + "):\n", TerminalStyle.CL_TABLE_HDR),
            new StyledSegment(clean + "\n", TerminalStyle.CL_DEFAULT)
        );
    }

    /** pwd — show path. */
    private static List<StyledSegment> pwdBlock(String raw) {
        String path = raw == null ? "" : raw.replace("Path\n----\n", "").trim();
        return List.of(
            new StyledSegment("Path\n----\n", TerminalStyle.CL_TABLE_HDR),
            new StyledSegment(path + "\n\n", TerminalStyle.CL_DEFAULT)
        );
    }

    /**
     * cd — show confirmation message on success, error on failure.
     * Agent returns the new CWD on success, or an error string on failure.
     */
    private static List<StyledSegment> cdBlock(String raw) {
        if (raw == null || raw.isEmpty()) {
            // Agent returned empty — treat as success with unknown path
            return List.of(
                new StyledSegment("[+] Directory changed\n", TerminalStyle.CL_SUCCESS)
            );
        }
        if (raw.startsWith("[ERR]") || raw.contains("Cannot find path")
                || raw.contains("ItemNotFoundException") || raw.contains("PathNotFound")) {
            return errorBlock(raw);
        }
        // Success — agent returned new CWD
        String newPath = raw.startsWith("cwd:") ? raw.substring(4).trim() : raw.trim();
        return List.of(
            new StyledSegment("[+] Changed to: ", TerminalStyle.CL_SUCCESS),
            new StyledSegment(newPath + "\n", TerminalStyle.CL_DEFAULT)
        );
    }

    // ── Utilities ─────────────────────────────────────────────────────────

    /** Human-readable byte size: 1234 → "1.2 KB". */
    public static String humanSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024));
        return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }
}
