package ui.console;

/**
 * TerminalStyle — single source of truth for terminal colors, fonts, and CSS classes.
 *
 * Design philosophy (per user request):
 *   - SIMPLE > DECORATIVE
 *   - Heavy coloring is annoying — only the marker prefixes ([*], [+], [-], [!]) get color
 *   - Output body is uniform default color
 *   - Prompt is "Hero>" in one accent color (blue)
 *   - No rainbow palette, no per-token highlighting
 *
 * Used by:
 *   - BeaconConsole   (output styling via StyleClassedTextArea)
 *   - PromptBar       (multi-info prompt segments)
 *   - StatusBar       (bottom activity bar)
 *   - dark-theme.css  (CSS class names referenced here MUST match stylesheet)
 */
public final class TerminalStyle {

    private TerminalStyle() {}

    // ── Color palette (minimal — keep it boring) ─────────────────────────
    public static final String BG         = "#0a0e14";  // deep dark (almost black)
    public static final String BG_INPUT   = "#0d1117";  // input row bg
    public static final String FG         = "#c9d1d9";  // default text (GitHub dark)
    public static final String FG_DIM     = "#6e7681";  // dim/borders
    public static final String ACCENT     = "#58a6ff";  // blue — prompt + headers
    public static final String OK         = "#3fb950";  // green — [+] success
    public static final String WARN       = "#d29922";  // yellow — [!] warning
    public static final String ERR        = "#f85149";  // red — [-] error
    public static final String INFO       = "#58a6ff";  // blue — [*] info

    // ── CSS class names (must match dark-theme.css) ───────────────────────
    public static final String CL_DEFAULT   = "term-default";
    public static final String CL_INFO      = "term-info";
    public static final String CL_SUCCESS   = "term-success";
    public static final String CL_WARNING   = "term-warning";
    public static final String CL_ERROR     = "term-error";
    public static final String CL_PROMPT    = "term-prompt";
    public static final String CL_COMMAND   = "term-command";
    public static final String CL_DIM       = "term-dim";
    public static final String CL_PATH      = "term-path";
    public static final String CL_IP        = "term-ip";
    public static final String CL_NUM       = "term-num";
    public static final String CL_USER      = "term-user";
    public static final String CL_HOST      = "term-host";
    public static final String CL_ARCH      = "term-arch";
    public static final String CL_SLEEP     = "term-sleep";
    public static final String CL_TABLE_HDR = "term-table-hdr";
    public static final String CL_TABLE_ROW = "term-table-row";
    public static final String CL_BANNER    = "term-banner";

    // ── Fonts ─────────────────────────────────────────────────────────────
    public static final String FONT_MONO    = "'JetBrains Mono', 'Consolas', 'Monaco', 'Cascadia Code', monospace";
    public static final String FONT_SIZE    = "13px";
    public static final String FONT_SIZE_SM = "11px";

    // ── Markers (Linux-style prefixes) ────────────────────────────────────
    public static final String INFO_MARK    = "[*]";
    public static final String SUCCESS_MARK = "[+]";
    public static final String WARN_MARK    = "[!]";
    public static final String ERR_MARK     = "[-]";
    public static final String PROMPT       = "Hero>";

    /** C11 fix: Labels ignore -fx-fill (that's a Text/Shape property) — they
     *  need -fx-text-fill. cssFor() was written for RichTextFX Text segments;
     *  every Label call site must use this variant instead or the color is
     *  silently dropped. Single source of truth: derived from cssFor(). */
    public static String cssForLabel(String className) {
        return cssFor(className).replace("-fx-fill:", "-fx-text-fill:");
    }

    /** Inline CSS for a class — used when stylesheet isn't loaded yet. */
    public static String cssFor(String className) {
        return switch (className) {
            case CL_INFO      -> "-fx-fill: " + INFO   + ";";
            case CL_SUCCESS   -> "-fx-fill: " + OK     + ";";
            case CL_WARNING   -> "-fx-fill: " + WARN   + ";";
            case CL_ERROR     -> "-fx-fill: " + ERR    + ";";
            case CL_PROMPT    -> "-fx-fill: " + ACCENT + "; -fx-font-weight: bold;";
            case CL_COMMAND   -> "-fx-fill: " + FG     + ";";
            case CL_DIM       -> "-fx-fill: " + FG_DIM + ";";
            case CL_PATH      -> "-fx-fill: " + FG     + ";";   // same as default — no rainbow
            case CL_IP        -> "-fx-fill: " + FG     + ";";
            case CL_NUM       -> "-fx-fill: " + FG     + ";";
            case CL_USER      -> "-fx-fill: " + FG     + ";";
            case CL_HOST      -> "-fx-fill: " + FG     + ";";
            case CL_ARCH      -> "-fx-fill: " + FG     + ";";
            case CL_SLEEP     -> "-fx-fill: " + FG     + ";";
            case CL_TABLE_HDR -> "-fx-fill: " + ACCENT + "; -fx-font-weight: bold;";
            case CL_TABLE_ROW -> "-fx-fill: " + FG     + ";";
            case CL_BANNER    -> "-fx-fill: " + ACCENT + "; -fx-font-weight: bold;";
            default           -> "-fx-fill: " + FG     + ";";
        };
    }
}
