package ui.console;

import java.util.*;
import java.util.stream.Collectors;

import models.Session;
import ui.console.CommandRegistry.CommandInfo;
import ui.console.CommandRegistry.CompletionType;

/**
 * CommandCompleter — TAB completion + Ctrl+R history search.
 *
 * Two responsibilities:
 *   1. completeInput(text, caret, session)  → suggestions popup
 *   2. searchHistory(query, history)        → Ctrl+R fuzzy match
 *
 * Smart logic:
 *   - First token: match against all command names from CommandRegistry
 *     Fuzzy match — prefix first, then substring, then anywhere
 *   - Second+ token: switch on command's CompletionType:
 *       REMOTE_PATH → suggest from session's known cwd + a static hint list
 *                     (we don't have ls cached, so we hint at common paths)
 *       PID         → suggest PIDs from session's last `ps` result (cached)
 *       CUSTOM      → command-specific (e.g., `help <cmd>`)
 *
 * No network calls — completion is purely client-side and instant.
 */
public final class CommandCompleter {

    private CommandCompleter() {}

    /** Result of a completion attempt. */
    public static final class CompletionResult {
        public final String prefix;            // text to replace (up to caret)
        public final List<String> suggestions; // ranked candidates
        public final boolean exactMatch;       // only one suggestion — auto-fill?

        public CompletionResult(String prefix, List<String> suggestions, boolean exactMatch) {
            this.prefix = prefix;
            this.suggestions = suggestions;
            this.exactMatch = exactMatch;
        }

        public boolean hasSuggestions() { return !suggestions.isEmpty(); }
    }

    // ── TAB completion ────────────────────────────────────────────────────

    /**
     * Compute completion suggestions for the current input.
     *
     * @param input   full text in input field
     * @param caret   caret position (we complete up to caret, not end)
     * @param session active session (for context-aware completion)
     * @return CompletionResult — never null
     */
    public static CompletionResult complete(String input, int caret, Session session) {
        if (input == null || input.isEmpty()) {
            return new CompletionResult("", Collections.emptyList(), false);
        }

        String upToCaret = input.substring(0, Math.min(caret, input.length()));
        String[] tokens = upToCaret.split("\\s+", -1);
        boolean inFirstToken = (tokens.length == 1);
        String lastToken = tokens[tokens.length - 1];

        if (inFirstToken) {
            // ── Complete command name ──
            return completeCommandName(lastToken);
        }

        // ── Complete arguments ──
        String cmdName = tokens[0].toLowerCase();
        CommandInfo info = CommandRegistry.get(cmdName);
        if (info == null) {
            return new CompletionResult(lastToken, Collections.emptyList(), false);
        }

        return switch (info.completion) {
            case REMOTE_PATH    -> completeRemotePath(lastToken, session);
            case PID            -> completePid(lastToken, session);
            case LOCAL_PATH     -> completeLocalPath(lastToken);
            case REGISTRY_KEY   -> completeRegistryKey(lastToken);
            case SERVICE_NAME   -> completeServiceName(lastToken);
            case USER_NAME      -> completeUserName(lastToken);
            case CUSTOM         -> completeCustom(cmdName, lastToken);
            default             -> new CompletionResult(lastToken, Collections.emptyList(), false);
        };
    }

    /** Fuzzy match command names. */
    private static CompletionResult completeCommandName(String prefix) {
        String p = prefix.toLowerCase();
        List<String> all = CommandRegistry.allNames();

        // Pass 1: prefix match (highest priority)
        List<String> prefixMatches = all.stream()
                .filter(n -> n.toLowerCase().startsWith(p))
                .collect(Collectors.toList());

        if (prefixMatches.size() == 1) {
            return new CompletionResult(prefix, prefixMatches, true);
        }
        if (!prefixMatches.isEmpty()) {
            return new CompletionResult(prefix, prefixMatches, false);
        }

        // Pass 2: substring match
        List<String> subMatches = all.stream()
                .filter(n -> n.toLowerCase().contains(p))
                .collect(Collectors.toList());

        return new CompletionResult(prefix, subMatches, false);
    }

    /** Common Windows paths — fast-path suggestions for cd/cat/ls. */
    private static final List<String> REMOTE_PATH_HINTS = List.of(
            "C:\\",
            "C:\\Users\\",
            "C:\\Users\\Public\\",
            "C:\\Windows\\",
            "C:\\Windows\\System32\\",
            "C:\\Program Files\\",
            "C:\\Program Files (x86)\\",
            "C:\\ProgramData\\",
            "C:\\temp\\",
            "C:\\temp\\"
    );

    private static CompletionResult completeRemotePath(String prefix, Session session) {
        if (prefix.isEmpty()) {
            // No prefix — suggest common Windows paths
            return new CompletionResult(prefix, REMOTE_PATH_HINTS, false);
        }

        // Suggest paths that start with the prefix (case-insensitive)
        String p = prefix.toLowerCase();
        List<String> matches = REMOTE_PATH_HINTS.stream()
                .filter(path -> path.toLowerCase().startsWith(p))
                .collect(Collectors.toList());

        // Also suggest relative paths if prefix doesn't start with drive letter
        if (!prefix.matches("^[A-Za-z]:.*") && !prefix.startsWith("\\\\")) {
            // Could append to session's CWD — for now just return matches
        }

        return new CompletionResult(prefix, matches, matches.size() == 1);
    }

    /** Local (operator-side) path completion — for future `upload` command. */
    private static CompletionResult completeLocalPath(String prefix) {
        // Not implemented yet — would scan java.io.File
        return new CompletionResult(prefix, Collections.emptyList(), false);
    }

    /** PID completion — would use cached ps output. */
    private static CompletionResult completePid(String prefix, Session session) {
        // No PID cache yet — return empty (could be extended later)
        return new CompletionResult(prefix, Collections.emptyList(), false);
    }

    /** Registry key hints. */
    private static CompletionResult completeRegistryKey(String prefix) {
        List<String> hints = List.of(
                "HKLM:\\Software\\",
                "HKLM:\\System\\CurrentControlSet\\Services\\",
                "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\\",
                "HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\\"
        );
        if (prefix.isEmpty()) return new CompletionResult(prefix, hints, false);
        String p = prefix.toLowerCase();
        List<String> matches = hints.stream()
                .filter(h -> h.toLowerCase().startsWith(p))
                .collect(Collectors.toList());
        return new CompletionResult(prefix, matches, matches.size() == 1);
    }

    /** Service name hints — common Windows services. */
    private static CompletionResult completeServiceName(String prefix) {
        List<String> hints = List.of("TermService", "wuauserv", "BITS", "Spooler",
                "WinDefend", "MpsSvc", "Schedule", "LanmanServer", "LanmanWorkstation");
        if (prefix.isEmpty()) return new CompletionResult(prefix, hints, false);
        String p = prefix.toLowerCase();
        List<String> matches = hints.stream()
                .filter(h -> h.toLowerCase().startsWith(p))
                .collect(Collectors.toList());
        return new CompletionResult(prefix, matches, matches.size() == 1);
    }

    private static CompletionResult completeUserName(String prefix) {
        // No cache yet
        return new CompletionResult(prefix, Collections.emptyList(), false);
    }

    /** Custom completion per command. */
    private static CompletionResult completeCustom(String cmd, String prefix) {
        if ("help".equals(cmd)) {
            // suggest command names
            return completeCommandName(prefix);
        }
        return new CompletionResult(prefix, Collections.emptyList(), false);
    }

    // ── Ctrl+R history search ─────────────────────────────────────────────

    /**
     * Fuzzy search through command history (newest first).
     * Returns the most recent entry containing the query (case-insensitive),
     * or null if no match.
     */
    public static String searchHistory(String query, List<String> history) {
        if (query == null || query.isBlank() || history == null || history.isEmpty()) {
            return null;
        }
        String q = query.toLowerCase();
        // Iterate from newest to oldest
        for (int i = history.size() - 1; i >= 0; i--) {
            String h = history.get(i);
            if (h != null && h.toLowerCase().contains(q)) {
                return h;
            }
        }
        return null;
    }

    /**
     * Cycle through all history matches for Ctrl+R (when user presses Ctrl+R again).
     * Returns the next match after `current`, or null.
     */
    public static String nextHistoryMatch(String query, List<String> history, String current) {
        if (query == null || history == null) return null;
        String q = query.toLowerCase();
        boolean foundCurrent = (current == null);
        for (int i = history.size() - 1; i >= 0; i--) {
            String h = history.get(i);
            if (h == null) continue;
            if (!foundCurrent) {
                if (h.equals(current)) foundCurrent = true;
                continue;
            }
            if (h.toLowerCase().contains(q)) return h;
        }
        return null;
    }
}
