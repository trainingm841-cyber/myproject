package ui.console;

import java.util.*;

/**
 * CommandRegistry — metadata for every agent command.
 *
 * Single source of truth for:
 *   - Command syntax (used by `help`)
 *   - Short description (used by tab-completion popup)
 *   - Completion type (what to suggest when user hits TAB after the command name)
 *   - Category (for `help` grouping)
 *
 * Smart design: instead of hard-coding switch cases everywhere, we centralize
 * command metadata here. Adding a new command = adding one entry.
 *
 * The actual command execution is still done by SessionTab/ApiService —
 * this registry is purely for UI affordances (help, tab completion, syntax hints).
 */
public final class CommandRegistry {

    private CommandRegistry() {}

    /** What kind of value completes the next argument? */
    public enum CompletionType {
        NONE,           // no completion offered
        LOCAL_PATH,     // operator's filesystem (e.g., for upload source)
        REMOTE_PATH,    // target's filesystem (e.g., for cat, ls, cd)
        PID,            // process IDs (for kill)
        REGISTRY_KEY,   // HKLM:\Software\... style
        SERVICE_NAME,   // for sc query/start/stop
        USER_NAME,      // for net user
        FILE_FORMAT,    // for download output format
        BOOL,           // on/off
        CUSTOM          // command-specific (handled by CommandCompleter)
    }

    public static final class CommandInfo {
        public final String name;
        public final String syntax;
        public final String description;
        public final String category;
        public final CompletionType completion;

        public CommandInfo(String name, String syntax, String description,
                           String category, CompletionType completion) {
            this.name = name;
            this.syntax = syntax;
            this.description = description;
            this.category = category;
            this.completion = completion;
        }
    }

    // ── Master command table ──────────────────────────────────────────────
    // Order = display order in `help`. Keep grouped by category for clarity.
    private static final List<CommandInfo> COMMANDS = List.of(
        // ── Shell ──
        new CommandInfo("shell",      "shell <cmd>",         "Run cmd.exe command",          "Shell",      CompletionType.NONE),
        new CommandInfo("powershell", "powershell <cmd>",    "Run PowerShell command",       "Shell",      CompletionType.NONE),
        new CommandInfo("exit",       "exit",                "Close this session tab",       "Shell",      CompletionType.NONE),
        new CommandInfo("clear",      "clear",               "Clear terminal screen",        "Shell",      CompletionType.NONE),
        new CommandInfo("help",       "help [cmd]",          "Show help for all/one command","Shell",      CompletionType.CUSTOM),

        // ── Filesystem ──
        new CommandInfo("ls",         "ls [path]",           "List directory contents",      "Filesystem", CompletionType.REMOTE_PATH),
        new CommandInfo("dir",        "dir [path]",          "List directory (Windows)",     "Filesystem", CompletionType.REMOTE_PATH),
        new CommandInfo("cd",         "cd <path>",           "Change directory",             "Filesystem", CompletionType.REMOTE_PATH),
        new CommandInfo("pwd",        "pwd",                 "Print working directory",      "Filesystem", CompletionType.NONE),
        new CommandInfo("cat",        "cat <file>",          "Print file contents",          "Filesystem", CompletionType.REMOTE_PATH),
        new CommandInfo("type",       "type <file>",         "Print file (Windows alias)",   "Filesystem", CompletionType.REMOTE_PATH),
        new CommandInfo("mkdir",      "mkdir <dir>",         "Create directory",             "Filesystem", CompletionType.REMOTE_PATH),
        new CommandInfo("rm",         "rm <path>",           "Remove file/dir",              "Filesystem", CompletionType.REMOTE_PATH),
        new CommandInfo("touch",      "touch <file>",        "Create empty file",            "Filesystem", CompletionType.REMOTE_PATH),
        new CommandInfo("cp",         "cp <src> <dst>",      "Copy file",                    "Filesystem", CompletionType.REMOTE_PATH),
        new CommandInfo("mv",         "mv <src> <dst>",      "Move/rename file",             "Filesystem", CompletionType.REMOTE_PATH),
        new CommandInfo("download",   "download <remote>",   "Download file from target",    "Filesystem", CompletionType.REMOTE_PATH),
        new CommandInfo("hash",       "hash <file>",         "SHA256 of remote file",        "Filesystem", CompletionType.REMOTE_PATH),
        new CommandInfo("drives",     "drives",              "List logical drives",          "Filesystem", CompletionType.NONE),
        new CommandInfo("find",       "find <name>",         "Search files by name",         "Filesystem", CompletionType.REMOTE_PATH),

        // ── Process ──
        new CommandInfo("tasklist",   "tasklist",            "List processes",               "Process",    CompletionType.NONE),
        new CommandInfo("kill",       "kill <pid>",          "Terminate process by PID",     "Process",    CompletionType.PID),
        new CommandInfo("listdlls",   "listdlls [pid]",      "List loaded DLLs",             "Process",    CompletionType.PID),

        // ── Network ──
        new CommandInfo("ipconfig",   "ipconfig",            "Show network config",          "Network",    CompletionType.NONE),
        new CommandInfo("netstat",    "netstat",             "Show network connections",     "Network",    CompletionType.NONE),
        new CommandInfo("arp",        "arp",                 "Show ARP table",               "Network",    CompletionType.NONE),
        new CommandInfo("dns",        "dns <name>",          "DNS lookup",                   "Network",    CompletionType.NONE),
        new CommandInfo("ping",       "ping <host>",         "Ping host (4 pkts)",           "Network",    CompletionType.NONE),

        // ── System ──
        new CommandInfo("whoami",     "whoami",              "Current user",                 "System",     CompletionType.NONE),
        new CommandInfo("whoamifull", "whoamifull",          "User + groups + privs",        "System",     CompletionType.NONE),
        new CommandInfo("sysinfo",    "sysinfo",             "Full system info",             "System",     CompletionType.NONE),
        new CommandInfo("hostname",   "hostname",            "Hostname only",                "System",     CompletionType.NONE),
        new CommandInfo("domain",     "domain",              "AD domain name",               "System",     CompletionType.NONE),
        new CommandInfo("admap",      "admap",               "AD map scan — DC + domain computers (Graphs → AD Map view)", "System", CompletionType.NONE),
        new CommandInfo("agraph",     "agraph",              "Node enrichment — ARP + TCP neighbors (Graphs → Attack Graph view)", "System", CompletionType.NONE),
        new CommandInfo("trueip",     "trueip [url]",        "Agent's public/NAT IP → dashboard True IP column (default: api.ipify.org)", "System", CompletionType.NONE),
        new CommandInfo("pid",        "pid",                 "Agent's PID",                  "System",     CompletionType.NONE),
        new CommandInfo("env",        "env",                 "Environment variables",        "System",     CompletionType.NONE),
        new CommandInfo("privs",      "privs",               "Current user's privileges",    "System",     CompletionType.NONE),
        new CommandInfo("uptime",     "uptime",              "System uptime",                "System",     CompletionType.NONE),

        // ── Registry / Services / Tasks ──
        new CommandInfo("reg",        "reg <query|add|del> <key> [val]", "Registry ops",     "Registry",   CompletionType.REGISTRY_KEY),
        new CommandInfo("sc",         "sc <query|start|stop|config> <svc>", "Service control","Registry",  CompletionType.SERVICE_NAME),
        new CommandInfo("schtasks",   "schtasks [/query|/create|/delete]", "Scheduled tasks","Registry",   CompletionType.NONE),
        new CommandInfo("eventlog",   "eventlog [n]",        "Recent event log entries",     "Registry",   CompletionType.NONE),

        // ── Net / AD ──
        new CommandInfo("netusers",   "netusers",            "List local users",             "AD/Net",     CompletionType.NONE),
        new CommandInfo("netgroups",  "netgroups",           "List local groups",            "AD/Net",     CompletionType.NONE),
        new CommandInfo("netshare",   "netshare",            "List network shares",          "AD/Net",     CompletionType.NONE),

        // ── BOF Arsenal (server packs coff+args, agent runs in-memory) ──
        // Server validates name + args BEFORE queueing — unknown BOFs and
        // bad args are rejected at the server, never crash the beacon.
        new CommandInfo("bof",        "bof <name> [type:arg ...]",  "Run BOF from arsenal (bof alone = list)", "BOF", CompletionType.CUSTOM),
        new CommandInfo("boflist",    "boflist",                    "List available BOFs (server-side)",       "BOF", CompletionType.NONE),
        new CommandInfo("hdesktop",   "hdesktop <start|stop|list|screenshot|exec cmd>", "Hidden desktop stealth GUI ops", "BOF", CompletionType.NONE),

        // ── Lateral / Persistence ──
        new CommandInfo("persist",    "persist <key>",       "Set persistence entry",        "Persistence",CompletionType.NONE),
        new CommandInfo("screenshot", "screenshot",          "Capture screen (saves to server)","Persistence",CompletionType.NONE),
        new CommandInfo("wipe",       "wipe",                "Agent self-destruct",          "Persistence",CompletionType.NONE),

        // ── Beacon control ──
        new CommandInfo("sleep",         "sleep <sec> [jitter%]",             "Set beacon interval (+optional jitter)", "Beacon", CompletionType.NONE),
        new CommandInfo("jitter",        "jitter <pct>",                      "Set jitter % live (0 = baked fraction)", "Beacon", CompletionType.NONE),
        new CommandInfo("working_hours", "working_hours HH:MM-HH:MM | off",   "Beacon window (UTC) — live gate",        "Beacon", CompletionType.NONE),
        new CommandInfo("profile",       "profile <name>",                    "Swap malleable profile at runtime",      "Beacon", CompletionType.NONE),
        new CommandInfo("config",        "config",                            "Show live runtime beacon config",        "Beacon", CompletionType.NONE),
        new CommandInfo("amsi_check",    "amsi_check",                        "Show AMSI patch status",                 "Beacon", CompletionType.NONE),
        new CommandInfo("sessions",      "sessions",                          "Switch session (use sidebar)",           "Beacon", CompletionType.NONE)
    );

    // ── Lookup indexes (built once) ───────────────────────────────────────
    private static final Map<String, CommandInfo> BY_NAME = new LinkedHashMap<>();
    private static final Map<String, List<CommandInfo>> BY_CATEGORY = new LinkedHashMap<>();
    static {
        for (CommandInfo ci : COMMANDS) {
            BY_NAME.put(ci.name.toLowerCase(), ci);
            BY_CATEGORY.computeIfAbsent(ci.category, k -> new ArrayList<>()).add(ci);
        }
    }

    /** Returns CommandInfo for a command name, or null if unknown. */
    public static CommandInfo get(String name) {
        if (name == null) return null;
        return BY_NAME.get(name.toLowerCase());
    }

    /** Returns all known command names, lowercased, in display order. */
    public static List<String> allNames() {
        return COMMANDS.stream().map(c -> c.name).toList();
    }

    /** Returns commands grouped by category, preserving order. */
    public static Map<String, List<CommandInfo>> byCategory() {
        return BY_CATEGORY;
    }

    /** Returns true if `name` is a known agent command. */
    public static boolean isKnown(String name) {
        return name != null && BY_NAME.containsKey(name.toLowerCase());
    }

    /** Returns the completion type for the FIRST argument of a command. */
    public static CompletionType completionFor(String commandName) {
        CommandInfo ci = get(commandName);
        return ci == null ? CompletionType.NONE : ci.completion;
    }
}
