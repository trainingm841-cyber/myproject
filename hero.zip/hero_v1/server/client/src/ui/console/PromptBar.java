package ui.console;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import models.Session;

/**
 * PromptBar — the top status line shown above the input row in each session tab.
 *
 * Layout (Cobalt Strike / Nighthawk inspired):
 *
 *   [<id8> | <user>@<host> | <arch> | <os> | sleep <sec>s | checkins <n>]
 *
 * Each segment is a separately-styled Label, so colors are crisp — not a single
 * gray string. Rebuilt when session info changes (refresh() called by SessionsTab).
 */
public final class PromptBar {

    private final HBox box;
    private final Label idLbl, userLbl, hostLbl, archLbl, osLbl, sleepLbl, checkinLbl;
    private final String sessionId;

    public PromptBar(Session session) {
        this.sessionId = session.getId();

        box = new HBox(0);
        box.setPadding(new Insets(4, 10, 4, 10));
        box.setStyle("-fx-background-color: " + TerminalStyle.BG + ";"
                + " -fx-border-color: " + TerminalStyle.FG_DIM + ";"
                + " -fx-border-width: 0 0 1 0;");

        // ── Build each segment as its own styled Label ──
        idLbl      = makeLabel(TerminalStyle.CL_NUM);
        userLbl    = makeLabel(TerminalStyle.CL_USER);
        hostLbl    = makeLabel(TerminalStyle.CL_HOST);
        archLbl    = makeLabel(TerminalStyle.CL_ARCH);
        osLbl      = makeLabel(TerminalStyle.CL_DEFAULT);
        sleepLbl   = makeLabel(TerminalStyle.CL_SLEEP);
        checkinLbl = makeLabel(TerminalStyle.CL_NUM);

        // ── Layout: [ seg | seg | seg ] ──
        box.getChildren().addAll(
            bracket("["), idLbl, sep("|"),
            userLbl, at(), hostLbl, sep("|"),
            archLbl, sep("|"),
            osLbl, sep("|"),
            sleepLbl, sep("|"),
            checkinLbl, bracket("]")
        );

        refresh(session);
    }

    /** Update all segments from fresh session data. */
    public void refresh(Session s) {
        idLbl      .setText(" " + shortId(s.getId()) + " ");
        userLbl    .setText(" " + stripDomain(s.getUsername()) + " ");
        hostLbl    .setText(" " + s.getHostname() + " ");
        archLbl    .setText(" " + (s.getArch() == null ? "?" : s.getArch()) + " ");
        osLbl      .setText(" " + (s.getOs() == null ? "?" : s.getOs()) + " ");
        sleepLbl   .setText(" sleep " + s.getSleep_time() + "s ");
        checkinLbl .setText(" chk " + s.getCheckin_num() + " ");
    }

    public HBox getBox() { return box; }
    public String getSessionId() { return sessionId; }

    // ── Helpers ───────────────────────────────────────────────────────────

    private static Label makeLabel(String cssClass) {
        Label l = new Label();
        l.setStyle(TerminalStyle.cssForLabel(cssClass)  // C11 fix: Label needs -fx-text-fill
                + " -fx-font-family: " + TerminalStyle.FONT_MONO + ";"
                + " -fx-font-size: " + TerminalStyle.FONT_SIZE_SM + ";");
        return l;
    }

    private static Label bracket(String s) {
        Label l = new Label(s);
        l.setStyle("-fx-text-fill: " + TerminalStyle.FG_DIM + ";"
                + " -fx-font-family: " + TerminalStyle.FONT_MONO + ";"
                + " -fx-font-size: " + TerminalStyle.FONT_SIZE_SM + ";");
        return l;
    }

    private static Label sep(String s) {
        Label l = new Label(s);
        l.setStyle("-fx-text-fill: " + TerminalStyle.FG_DIM + ";"
                + " -fx-font-family: " + TerminalStyle.FONT_MONO + ";"
                + " -fx-font-size: " + TerminalStyle.FONT_SIZE_SM + ";"
                + " -fx-padding: 0 4px;");
        return l;
    }

    private static Label at() {
        Label l = new Label("@");
        l.setStyle("-fx-text-fill: " + TerminalStyle.FG_DIM + ";"
                + " -fx-font-family: " + TerminalStyle.FONT_MONO + ";"
                + " -fx-font-size: " + TerminalStyle.FONT_SIZE_SM + ";");
        return l;
    }

    private static String shortId(String id) {
        return id == null ? "????" : (id.length() >= 8 ? id.substring(0, 8) : id);
    }

    private static String stripDomain(String user) {
        if (user == null) return "?";
        int bs = user.indexOf('\\');
        return bs >= 0 ? user.substring(bs + 1) : user;
    }
}
