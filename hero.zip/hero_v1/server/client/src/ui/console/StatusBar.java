package ui.console;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;

/**
 * StatusBar — bottom activity bar shown inside each session tab.
 *
 * Layout:
 *   ● beacon: alive | task: idle | rtt: 2.3s | sent: 0B | recv: 0B
 *
 * Updates:
 *   - On task dispatch:    "task: queued"
 *   - On task dispatched:  "task: sent (37B)"
 *   - On task complete:    "task: done (rtt 2.3s, recv 124B)"
 *   - On session timeout:  "beacon: dead"
 *
 * Compact HBox with spacers. All updates must run on JavaFX thread.
 */
public final class StatusBar {

    private final HBox box;
    private final Label beaconLbl, taskLbl, rttLbl, sentLbl, recvLbl;

    // Rolling counters for this session
    private long totalSent = 0;
    private long totalRecv = 0;

    public StatusBar() {
        box = new HBox(8);
        box.setPadding(new Insets(3, 10, 3, 10));
        box.setStyle("-fx-background-color: " + TerminalStyle.BG + ";"
                + " -fx-border-color: " + TerminalStyle.FG_DIM + ";"
                + " -fx-border-width: 1 0 0 0;");
        box.setAlignment(Pos.CENTER_LEFT);

        beaconLbl = makeLabel(TerminalStyle.CL_SUCCESS, "● alive");
        taskLbl   = makeLabel(TerminalStyle.CL_DEFAULT, "task: idle");
        rttLbl    = makeLabel(TerminalStyle.CL_DEFAULT, "rtt: --");
        sentLbl   = makeLabel(TerminalStyle.CL_DEFAULT, "sent: 0B");
        recvLbl   = makeLabel(TerminalStyle.CL_DEFAULT, "recv: 0B");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        box.getChildren().addAll(
            beaconLbl, sep(),
            taskLbl, sep(),
            rttLbl, sep(),
            spacer,
            sentLbl, sep(),
            recvLbl
        );
    }

    public HBox getBox() { return box; }

    /** Called when operator dispatches a task. */
    public void onTaskQueued(String command) {
        Platform.runLater(() -> {
            taskLbl.setText("task: queued (" + command + ")");
            taskLbl.setStyle(TerminalStyle.cssForLabel(TerminalStyle.CL_WARNING));
        });
    }

    /** Called when task is sent to agent. */
    public void onTaskSent(String command, int bytesSent) {
        totalSent += bytesSent;
        Platform.runLater(() -> {
            taskLbl.setText("task: sent (" + command + ")");
            taskLbl.setStyle(TerminalStyle.cssForLabel(TerminalStyle.CL_INFO));
            sentLbl.setText("sent: " + OutputFormatter.humanSize(totalSent));
        });
    }

    /** Called when task result is received. */
    public void onTaskDone(String command, long rttMs, int bytesRecv) {
        totalRecv += bytesRecv;
        Platform.runLater(() -> {
            taskLbl.setText("task: done (" + command + ")");
            taskLbl.setStyle(TerminalStyle.cssForLabel(TerminalStyle.CL_SUCCESS));
            rttLbl.setText("rtt: " + String.format("%.2fs", rttMs / 1000.0));
            recvLbl.setText("recv: " + OutputFormatter.humanSize(totalRecv));
        });
    }

    /** Called when task dispatch failed. */
    public void onTaskFailed(String reason) {
        Platform.runLater(() -> {
            taskLbl.setText("task: FAILED (" + reason + ")");
            taskLbl.setStyle(TerminalStyle.cssForLabel(TerminalStyle.CL_ERROR));
        });
    }

    /** Called when beacon is overdue but expected back (agent is sleeping). */
    public void onBeaconSleeping() {
        Platform.runLater(() -> {
            beaconLbl.setText("● sleeping");
            beaconLbl.setStyle(TerminalStyle.cssForLabel(TerminalStyle.CL_WARNING));
        });
    }

    /** Called when beacon checks in again after being sleeping/dead. */
    public void onBeaconAlive() {
        Platform.runLater(() -> {
            beaconLbl.setText("● alive");
            beaconLbl.setStyle(TerminalStyle.cssForLabel(TerminalStyle.CL_SUCCESS));
            taskLbl.setStyle(TerminalStyle.cssForLabel(TerminalStyle.CL_DEFAULT));
        });
    }

    /** Called when operator manually kills the session. */
    public void onBeaconDead() {
        Platform.runLater(() -> {
            beaconLbl.setText("● dead");
            beaconLbl.setStyle(TerminalStyle.cssForLabel(TerminalStyle.CL_ERROR));
            taskLbl.setText("task: --");
            taskLbl.setStyle(TerminalStyle.cssForLabel(TerminalStyle.CL_DIM));
        });
    }



    // ── Helpers ───────────────────────────────────────────────────────────
    private static Label makeLabel(String cssClass, String initialText) {
        Label l = new Label(initialText);
        l.setStyle(TerminalStyle.cssForLabel(cssClass)
                + " -fx-font-family: " + TerminalStyle.FONT_MONO + ";"
                + " -fx-font-size: " + TerminalStyle.FONT_SIZE_SM + ";");
        return l;
    }

    private static Label sep() {
        Label l = new Label("|");
        l.setStyle("-fx-text-fill: " + TerminalStyle.FG_DIM + ";"
                + " -fx-font-family: " + TerminalStyle.FONT_MONO + ";"
                + " -fx-font-size: " + TerminalStyle.FONT_SIZE_SM + ";");
        return l;
    }
}
