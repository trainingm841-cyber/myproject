import ui.ConnectDialog;
import ui.MainView;
import service.ApiService;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class C2Client extends Application {
    @Override
    public void start(Stage stage) {
        stage.setTitle("HERO C2");

        // ── Application icon (hero.jpg) ──────────────────────────────
        // Loaded from classpath resource /ui/hero.jpg. The icon shows in
        // the window title bar, taskbar, and OS window switcher.
        // JavaFX supports multiple icon sizes — add the image, the OS
        // picks the best fit automatically.
        try {
            var iconStream = getClass().getResourceAsStream("/ui/hero.jpg");
            if (iconStream != null) {
                Image icon = new Image(iconStream);
                stage.getIcons().add(icon);
            }
        } catch (Exception e) {
            System.err.println("[C2Client] icon load failed: " + e.getMessage());
        }

        ConnectDialog login = new ConnectDialog(stage);
        login.show(() -> {
            stage.close();
            Stage dashStage = new Stage();
            // Copy icon to dashboard stage too
            if (!stage.getIcons().isEmpty()) {
                dashStage.getIcons().add(stage.getIcons().get(0));
            }
            new MainView(dashStage, login.getApi()).show();
        });
    }

    public static void main(String[] args) { launch(args); }
}