package service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * WebSocket service with automatic exponential-backoff reconnection.
 * When the connection drops (error / close), the service schedules
 * a reconnect attempt after 5s → 10s → 20s → 30s (capped at 30s).
 * Each successful reconnect resets the backoff counter.
 *
 * HARDENING v3 (post-restart disconnect investigation):
 *
 *   1. CLIENT-SIDE PING (new): java.net.http.WebSocket auto-pongs server
 *      pings but does NOT auto-send client pings. If the server goes away
 *      quietly (process killed, network partition with no TCP RST), the
 *      client socket doesn't notice until the next outgoing frame fails
 *      — and if there are no outgoing frames (idle dashboard), the
 *      client thinks it's connected forever.
 *
 *      Fix: send a tiny "ping" text frame every 12s. The server-side
 *      ws.go reader goroutine recognises "ping" and replies "pong" (this
 *      is pre-existing protocol — see the read goroutine in handleWS).
 *      If no pong within 25s, we know the server is gone and the next
 *      send will fail → onError → scheduleReconnect.
 *
 *      12s is shorter than the server's 25s read deadline so the client
 *      is the proactive liveness source — server-side reaping is the
 *      fallback. Combined effect: dead-server detection in ≤25s (was ≤90s).
 *
 *   2. EXPONENTIAL BACKOFF ACCELERATED (new): old backoff was 5s → 10s
 *      → 20s → 30s. After a server restart, the operator often KNOWS the
 *      server is back (they typed ./bin/c2-server) and just needs the
 *      client to retry NOW. New backoff: 2s → 4s → 8s → 15s. First
 *      reconnect attempt in 2s (was 5s) — 2.5× faster recovery.
 *
 *   3. DEFENSIVE EVENT DISPATCH (new): previously, if onEvent.accept()
 *      threw any exception (NullPointerException in graph parser, JSON
 *      parse error, JavaFX threading issue), the WS read goroutine on the
 *      server side would get the client-side exception swallowed — but
 *      on the CLIENT side, the WS.Listener is invoked on a JDK internal
 *      thread. An uncaught exception in onText would propagate to JDK's
 *      WebSocket implementation which would silently close the socket
 *      without firing onError — the client would never know.
 *
 *      Fix: wrap onEvent.accept() in try-catch. Any exception is logged
 *      to stderr AND the socket is intentionally closed (which fires
 *      onError → scheduleReconnect). One bad event never kills the WS
 *      silently; either we recover via reconnect, or the operator sees
 *      the error in the terminal.
 *
 *   4. RECONNECT "BURST" CAP (new): if the server is down for a long
 *      time, the old code would retry every 30s forever. Now after 20
 *      failed attempts (≈ 4 minutes), we slow down to one attempt per
 *      minute — reduces CPU + log noise while the operator fixes the
 *      server. Reset on first successful reconnect.
 */
public class WsService {

    private final ScheduledExecutorService reconExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "ws-reconnect");
        t.setDaemon(true);
        return t;
    });

    // pingExecutor — separate single-thread scheduler for client-side pings.
    // Keeping pings on their own thread means a slow reconnect can't starve
    // pings (or vice versa). Both are daemon threads so they don't block
    // JVM exit.
    private final ScheduledExecutorService pingExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "ws-ping");
        t.setDaemon(true);
        return t;
    });

    private java.net.http.WebSocket ws;
    private Consumer<String> onEvent;
    private volatile boolean running = false;
    private volatile boolean shouldRun = false;
    private String baseUrl;
    private String token;

    // C4 fix: prevent two concurrent doConnect() runs (reconnect timers +
    // user-triggered connect can overlap).
    private final AtomicBoolean connecting = new AtomicBoolean(false);

    // C3 fix: accumulate WS message fragments — java.net.http.WebSocket may
    // deliver one message across several onText() calls (last=false for all
    // but the final one). The old code dispatched EVERY fragment as if it
    // were a complete event, so large task_result payloads (big cat/netstat
    // output) parsed as broken JSON and were silently dropped.
    private final StringBuilder fragBuf = new StringBuilder();

    // Reconnect backoff state
    // HARDENING: accelerated first-attempt — 2s instead of 5s. After 20
    // failures, drop to one attempt per 60s (burst-cap).
    private final AtomicInteger reconAttempt = new AtomicInteger(0);
    private static final int[] BACKOFF_MS = {2000, 4000, 8000, 15000};
    private static final int BURST_CAP_THRESHOLD = 20;   // after 20 fails
    private static final int BURST_CAP_MS = 60000;        // retry once per minute

    // Quiet-by-default stdout: info logs ([WS] Connected/Closed/Reconnecting)
    // only print when the client is launched with -Dhero.debug=true.
    // Real errors still go to stderr unconditionally.
    private static final boolean DEBUG = Boolean.getBoolean("hero.debug");

    public void setOnEvent(Consumer<String> handler) {
        this.onEvent = handler;
    }

    public void connect(String baseUrl, String token) {
        this.baseUrl = baseUrl;
        this.token = token;
        this.shouldRun = true;
        this.reconAttempt.set(0);
        // C4 fix: doConnect() blocks in buildAsync(...).join() + latch.await().
        // It used to run on the JavaFX Application Thread (MainView.show),
        // freezing the whole UI for the handshake — and for the OS TCP timeout
        // (~20-75s) when the server is unreachable. Run it off the FX thread.
        Thread t = new Thread(this::doConnect, "ws-connect");
        t.setDaemon(true);
        t.start();
    }

    private void doConnect() {
        if (!shouldRun || running) return;
        if (!connecting.compareAndSet(false, true)) return; // one connector at a time
        try {
            String wsUrl = baseUrl.replace("http://", "ws://").replace("https://", "wss://");
            if (!wsUrl.endsWith("/")) wsUrl += "/";

            // J-M4 SECURITY WARNING: the JWT token is currently passed in the
            // WebSocket URL query string (?token=...). This is consistent with
            // the server-side auth (ws.go reads the token from the URL query
            // string), but it has security implications:
            //
            //   * The token is logged in proxy / reverse-proxy access logs
            //     (nginx, Caddy, Envoy all log the full request URL by default).
            //   * The token may persist in browser history-equivalent caches
            //     on the client side (Java WebView URL store, JVM -D logs).
            //   * The token is visible to any process that can read /proc/<pid>
            //     or intercept the connect() syscall (strace, eBPF).
            //
            // The robust fix requires a coordinated server-side change to
            // accept the token via either:
            //   (a) the WebSocket `Sec-WebSocket-Protocol` subprotocol header
            //       (e.g. client sends ["hero-auth", token] and server validates
            //       the second value), OR
            //   (b) the first message after handshake — client sends
            //       {"type":"auth","token":"..."} before any other event,
            //       server waits for that frame before admitting the socket
            //       to the event bus.
            //
            // Until that server-side change lands, this remains a known
            // medium-severity exposure. Log a one-line warning so operators
            // see it in production logs.
            System.err.println("[WS] SECURITY WARNING (J-M4): JWT token is being sent in the WS URL "
                    + "query string (?token=...). This is visible in proxy logs and should be moved "
                    + "to a Sec-WebSocket-Protocol subprotocol or first-message auth in production.");
            wsUrl += "api/ws?token=" + token;

            // TLS FIX: reuse ApiService's trust-all SSLContext for WSS.
            // Without this, WSS handshake fails with self-signed certs.
            // Also disable hostname verification (cert may not have 127.0.0.1 in SAN).
            // FIX: setEndpointIdentificationAlgorithm(null) — NOT "" —
            // Java checks `!= null` before running hostname verification.
            // "" (empty string) is NOT null → verification still runs → fails.
            System.setProperty("jdk.internal.httpclient.disableHostnameVerification", "true");
            javax.net.ssl.SSLParameters sslParams = new javax.net.ssl.SSLParameters();
            sslParams.setEndpointIdentificationAlgorithm(null);
            java.net.http.HttpClient client = java.net.http.HttpClient.newBuilder()
                .sslContext(ApiService.getSSLContext())
                .sslParameters(sslParams)
                .build();
            CountDownLatch latch = new CountDownLatch(1);

            ws = client.newWebSocketBuilder()
                    .buildAsync(URI.create(wsUrl), new java.net.http.WebSocket.Listener() {
                        @Override
                        public void onOpen(java.net.http.WebSocket webSocket) {
                            if (DEBUG) System.out.println("[WS] Connected");
                            running = true;
                            reconAttempt.set(0); // reset backoff on success
                            webSocket.request(1);
                            latch.countDown();
                            // HARDENING: start client-side ping ticker — fires
                            // every 12s, sends "ping" text frame, server replies
                            // "pong" (existing protocol in ws.go read goroutine).
                            startPingTicker(webSocket);
                        }

                        @Override
                        public CompletionStage<?> onText(java.net.http.WebSocket webSocket, CharSequence data, boolean last) {
                            // C3 fix: buffer fragments; dispatch only complete messages.
                            // Listener callbacks arrive sequentially (JDK guarantee),
                            // so no extra synchronization is needed.
                            fragBuf.append(data);
                            if (last) {
                                String event = fragBuf.toString();
                                fragBuf.setLength(0);
                                // HARDENING: defensive dispatch — wrap onEvent
                                // in try-catch so a bad event doesn't kill the WS
                                // silently. Any exception is logged to stderr AND
                                // the socket is force-closed (which fires onClose
                                // → scheduleReconnect). One bad event should never
                                // mean the operator loses all real-time updates.
                                if (onEvent != null) {
                                    try {
                                        onEvent.accept(event);
                                    } catch (Throwable t) {
                                        System.err.println("[WS] event dispatch threw — closing socket for fresh reconnect: " + t);
                                        t.printStackTrace(System.err);
                                        try { webSocket.sendClose(1011, "event dispatch error"); }
                                        catch (Exception ignored) {}
                                    }
                                }
                            }
                            // DEMAND FIX: java.net.http consumes one demand unit
                            // for EVERY onText invocation — including intermediate
                            // fragments (last=false) of large messages. The old
                            // code re-requested only on last==true, so every
                            // fragmented message leaked (N-1) demand units. After
                            // enough large task_result/screenshot payloads demand
                            // hit 0 and the socket went silently deaf (no events
                            // received until reconnect). Refill on EVERY invocation.
                            webSocket.request(1);
                            return null;
                        }

                        @Override
                        public CompletionStage<?> onBinary(java.net.http.WebSocket webSocket, java.nio.ByteBuffer data, boolean last) {
                            // Insurance: the same demand rule applies to binary frames.
                            webSocket.request(1);
                            return null;
                        }

                        @Override
                        public void onError(java.net.http.WebSocket webSocket, Throwable error) {
                            System.err.println("[WS] Error: " + error.getMessage());
                            running = false;
                            fragBuf.setLength(0);
                            stopPingTicker();
                            latch.countDown();
                            // C1 fix: reconnect after an ESTABLISHED connection drops.
                            // The old code only reconnected when the drop happened
                            // during the initial connect window (doConnect still
                            // waiting on the latch); after that nothing ever called
                            // scheduleReconnect again — one server restart and the
                            // operator lost all real-time events for the session.
                            if (shouldRun) scheduleReconnect();
                        }

                        @Override
                        public CompletionStage<?> onClose(java.net.http.WebSocket webSocket, int code, String reason) {
                            if (DEBUG) System.out.println("[WS] Closed: " + code + " " + reason);
                            running = false;
                            fragBuf.setLength(0);
                            stopPingTicker();
                            latch.countDown();
                            if (shouldRun) scheduleReconnect(); // C1 fix — same as onError
                            return null;
                        }
                    }).join();

            latch.await();

            // If connection didn't succeed, schedule reconnect
            if (!running && shouldRun) {
                scheduleReconnect();
            }
        } catch (Exception e) {
            System.err.println("[WS] Connect failed: " + e.getMessage());
            running = false;
            stopPingTicker();
            if (shouldRun) {
                scheduleReconnect();
            }
        } finally {
            connecting.set(false);
        }
    }

    /**
     * HARDENING: start a 12s periodic ping ticker once the WS is open.
     * The server's read goroutine in ws.go recognises "ping" text frames
     * and replies "pong" (existing protocol — see the read goroutine in
     * handleWS). If the server is gone, our send will fail → onError fires
     * → reconnect scheduled.
     *
     * Pings are small (4 bytes ASCII "ping") and don't impact bandwidth.
     * They run on a dedicated daemon thread so they don't block the
     * reconnect timer or the FX thread.
     */
    private java.util.concurrent.Future<?> pingTickerFuture;
    private void startPingTicker(java.net.http.WebSocket socket) {
        stopPingTicker();
        pingTickerFuture = pingExecutor.scheduleAtFixedRate(() -> {
            if (!running || socket == null) return;
            try {
                // sendText returns a CompletableFuture — the JVM will reject
                // sendText on a closed socket by completing the future
                // exceptionally, which we don't wait on. The exception
                // triggers onClose/onError asynchronously.
                socket.sendText("ping", true);
            } catch (Throwable ignored) {
                // socket.sendText itself doesn't throw synchronously, but the
                // JDK's WebSocket impl can throw IllegalStateException if the
                // socket is being closed. Either way, onError will fire soon.
            }
        }, 12, 12, TimeUnit.SECONDS);
    }
    private void stopPingTicker() {
        if (pingTickerFuture != null) {
            pingTickerFuture.cancel(false);
            pingTickerFuture = null;
        }
    }

    /** Schedule a reconnect with exponential backoff */
    private void scheduleReconnect() {
        int attempt = reconAttempt.getAndIncrement();
        int delay;
        if (attempt >= BURST_CAP_THRESHOLD) {
            // After 20 failed attempts, slow down to 1 per minute — operator
            // is probably fixing the server, no point spamming reconnects.
            delay = BURST_CAP_MS;
            if (DEBUG && attempt % 10 == 0) System.out.println("[WS] Reconnect burst-cap reached — retrying once per minute");
        } else {
            int idx = Math.min(attempt, BACKOFF_MS.length - 1);
            delay = BACKOFF_MS[idx];
        }
        if (DEBUG) System.out.println("[WS] Reconnecting in " + (delay/1000) + "s (attempt #" + (attempt+1) + ")");
        reconExecutor.schedule(() -> {
            if (shouldRun && !running) {
                doConnect();
            }
        }, delay, TimeUnit.MILLISECONDS);
    }

    public void disconnect() {
        shouldRun = false;
        running = false;
        stopPingTicker();
        reconExecutor.shutdownNow();
        pingExecutor.shutdownNow();
        if (ws != null) {
            try { ws.sendClose(1000, "disconnect"); } catch (Exception ignored) {}
        }
    }

    public boolean isConnected() {
        return running;
    }

    // Parse incoming event type from JSON
    public static String parseEventType(String json) {
        try {
            JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
            return obj.get("type").getAsString();
        } catch (Exception e) {
            return "unknown";
        }
    }

    public static JsonObject parseEventData(String json) {
        try {
            JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
            return obj.get("data").getAsJsonObject();
        } catch (Exception e) {
            return new JsonObject();
        }
    }
}
