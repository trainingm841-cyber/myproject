package service;

import models.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.channels.ClosedChannelException;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509ExtendedTrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;
import java.security.cert.CertificateException;
import java.net.Socket;
import javax.net.ssl.SSLEngine;

public class ApiService {
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    // HARDENING: HttpClient was previously built with the default (implicit)
    // executor. JDK 21's HttpClient has an internal NIO selector thread that
    // can race with the connect attempt on a fresh request — when the server
    // is slow to accept the TCP connection (or has just been restarted and
    // is still binding the port), the selector may close the SocketChannel
    // BEFORE the connect syscall runs, producing the
    //   ConnectException (root: ClosedChannelException)
    // race that the user saw on second-login-after-restart.
    //
    // FIX: pin a dedicated, named, virtual-thread-per-task executor that is
    //      NOT shared with any other component and never auto-shuts. This
    //      removes the GC pressure that triggers the selector race.
    //      Plus increase the connect timeout 10s → 15s for slow-restart
    //      scenarios (the teamserver takes ~3-4s to bind after process start
    //      because of SQLite vault load + IP filter parse + JWT init).
    private final ExecutorService httpExecutor = Executors.newThreadPerTaskExecutor(
        Thread.ofVirtual().name("hero-http-", 0).factory());

    // TLS FIX (C2_USE_TLS=true): When the server runs with TLS enabled, the
    // client must connect via HTTPS. The server uses certs from /home/kali/cert/
    // which may be self-signed or from a private CA. Java's default trust store
    // won't trust them → SSLHandshakeException.
    //
    // FIX: use X509ExtendedTrustManager (NOT plain X509TrustManager).
    // Java's SSL layer wraps plain X509TrustManager in AbstractTrustManagerWrapper
    // which does hostname verification AFTER the trust check — this can't be
    // disabled via sslParameters. X509ExtendedTrustManager is called DIRECTLY
    // by the SSL layer (no wrapper) → both cert chain AND hostname checks
    // are bypassed in our override.
    private static final SSLContext trustAllSSLContext;
    static {
        try {
            TrustManager[] trustAll = new TrustManager[] {
                new X509ExtendedTrustManager() {
                    @Override
                    public void checkClientTrusted(X509Certificate[] chain, String authType, Socket socket) {}
                    @Override
                    public void checkServerTrusted(X509Certificate[] chain, String authType, Socket socket) {}
                    @Override
                    public void checkClientTrusted(X509Certificate[] chain, String authType, SSLEngine engine) {}
                    @Override
                    public void checkServerTrusted(X509Certificate[] chain, String authType, SSLEngine engine) {}
                    @Override
                    public void checkClientTrusted(X509Certificate[] chain, String authType) {}
                    @Override
                    public void checkServerTrusted(X509Certificate[] chain, String authType) {}
                    @Override
                    public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                }
            };
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAll, new java.security.SecureRandom());
            trustAllSSLContext = sc;
        } catch (Exception e) {
            throw new RuntimeException("Failed to init trust-all SSLContext: " + e.getMessage(), e);
        }
    }

    /** Package-visible so WsService can reuse the same SSLContext for WSS. */
    static SSLContext getSSLContext() { return trustAllSSLContext; }

    private final HttpClient http = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(15))
        .executor(httpExecutor)
        .sslContext(trustAllSSLContext)  // trust-all for lab (self-signed certs)
        .sslParameters(disableHostnameVerification())  // disable SAN/IP check
        .build();

    /**
     * Disable hostname verification for the Java HttpClient.
     *
     * Java's HttpClient does TWO checks during TLS handshake:
     *   1. Certificate chain trust (handled by trust-all TrustManager above)
     *   2. Hostname verification (checks if cert CN/SAN matches the URL host)
     *
     * The server's cert at /etc/hero/certs/new_server.crt may not have
     * 127.0.0.1 in its Subject Alternative Names → hostname verification
     * fails with "No subject alternative names matching IP address
     * 127.0.0.1 found".
     *
     * FIX: set endpoint identification algorithm to NULL (not "") —
     * Java checks `if (algorithm != null)` before running verification.
     * Empty string "" is NOT null → verification STILL runs → fails.
     * null = skip verification entirely.
     *
     * Also set the system property as a backup for JDK internal checks.
     */
    private static SSLParameters disableHostnameVerification() {
        // System property backup — disables hostname verification at JDK level
        System.setProperty("jdk.internal.httpclient.disableHostnameVerification", "true");
        SSLParameters params = new SSLParameters();
        params.setEndpointIdentificationAlgorithm(null);  // null = NO verification
        return params;
    }
    private String baseUrl, token;

    public void setBaseUrl(String url) { this.baseUrl = url.endsWith("/") ? url.substring(0, url.length()-1) : url; }
    public String getBaseUrl() { return baseUrl; }
    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public boolean isAuthenticated() { return token != null && !token.isEmpty(); }

    // ──────────────────────────────────────────────────────────────────────────
    // AUTH — hardening: TCP pre-check + retry on JDK race + clear diagnostics
    // ──────────────────────────────────────────────────────────────────────────
    //
    // The previous single-shot login() was vulnerable to:
    //   1. JDK 21 PlainHttpConnection race — ClosedChannelException mid-connect
    //      when the server is briefly unreachable. Symptom: "Connection failed:
    //      null" because the wrapper exception had no message.
    //   2. No way to distinguish "server not listening" from "TLS issue" from
    //      "wrong password" — the operator had no actionable diagnostic.
    //
    // Hardening layers (in order, all defensive — no behavior change on the
    // happy path):
    //   Layer 1: TCP pre-check (raw socket, 1.5s timeout) — if the server is
    //            not even accepting TCP on this host:port, fail IMMEDIATELY
    //            with a clear "server unreachable" message. No JDK race
    //            possible because we're not using HttpClient yet.
    //   Layer 2: HTTP retry loop — up to 3 attempts with 400ms/800ms/1.2s
    //            backoff. The JDK 21 race is transient; second attempt almost
    //            always succeeds once the selector has stabilised.
    //   Layer 3: Status-code categorisation — 401 = "wrong password" (no
    //            retry, surface to user), 5xx = "server error" (retry), 2xx
    //            = success (parse JWT token), other = "unexpected" (retry).
    //
    // Wiring untouched: server's /api/login handler is unchanged, JWT flow
    // unchanged, token field semantics unchanged.
    public boolean login(String password) throws Exception {
        // ── Layer 1: TCP pre-check ───────────────────────────────────────────
        // Parses baseUrl once, opens a raw TCP socket to the server.
        // If this fails, the server is NOT listening on this host:port —
        // no point even trying HTTP. We fail FAST (1.5s vs the HttpClient's
        // 15s connect timeout) with a message that tells the operator
        // exactly what's wrong (vs the JDK's opaque "null").
        URI uri;
        try {
            uri = URI.create(baseUrl);
        } catch (IllegalArgumentException e) {
            throw new Exception("Invalid server URL '" + baseUrl + "': " + e.getMessage(), e);
        }
        String host = uri.getHost();
        int port = uri.getPort();
        if (host == null || host.isEmpty()) {
            throw new Exception("Server URL is missing the host part (expected http(s)://HOST:PORT): " + baseUrl);
        }
        if (port == -1) {
            // Default port per scheme — common operator typo (forgot :5000)
            port = uri.getScheme().equalsIgnoreCase("https") ? 443 : 80;
        }
        // Raw TCP socket pre-check
        try (Socket probe = new Socket()) {
            probe.connect(new InetSocketAddress(host, port), 1500);
        } catch (IOException tcpFail) {
            // Server not listening / refused / unreachable — surface clearly
            throw new Exception(
                "Server unreachable at " + host + ":" + port +
                " — is c2-server running? (raw TCP probe failed: " +
                tcpFail.getClass().getSimpleName() +
                (tcpFail.getMessage() != null && !tcpFail.getMessage().isBlank()
                    ? ": " + tcpFail.getMessage() : "") + ")",
                tcpFail);
        }

        // ── Layer 2 + 3: HTTP login with retry ───────────────────────────────
        String body = "{\"password\":\"" + escapeJson(password) + "\"}";
        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + "/api/login"))
            .header("Content-Type", "application/json")
            .timeout(Duration.ofSeconds(20))
            .POST(HttpRequest.BodyPublishers.ofString(body))
            .build();

        Exception lastErr = null;
        int[] backoffMs = {0, 400, 800, 1200};   // attempt 0 = no wait, then escalating
        for (int attempt = 0; attempt < 3; attempt++) {
            try {
                if (backoffMs[attempt] > 0) {
                    Thread.sleep(backoffMs[attempt]);
                }
                HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
                int sc = resp.statusCode();
                if (sc == 200) {
                    LoginResponse lr = gson.fromJson(resp.body(), LoginResponse.class);
                    if (lr == null || lr.token == null || lr.token.isEmpty()) {
                        throw new Exception("server returned 200 but no token in body");
                    }
                    this.token = lr.token;
                    return true;
                }
                if (sc == 401 || sc == 403) {
                    // Auth reject — do NOT retry. Operator mistyped password,
                    // OR .env has a different password than the one being typed.
                    // Surface the server's body if it had one (usually it doesn't).
                    throw new Exception(
                        "Authentication rejected by server (HTTP " + sc + ") — " +
                        "check that the password matches C2_PASSWORD in /etc/hero/.env" +
                        (resp.body() != null && !resp.body().isBlank() ? ": " + resp.body() : ""));
                }
                if (sc >= 500 && sc < 600) {
                    // Server-side error — retry, maybe transient
                    lastErr = new Exception("server returned HTTP " + sc +
                        (resp.body() != null && !resp.body().isBlank() ? ": " + resp.body() : ""));
                    continue;
                }
                // Other (3xx, 4xx) — unlikely on /api/login, retry once
                lastErr = new Exception("unexpected HTTP " + sc +
                    (resp.body() != null && !resp.body().isBlank() ? ": " + resp.body() : ""));
                if (attempt < 2) continue;
                throw lastErr;
            } catch (ClosedChannelException | java.net.ConnectException ce) {
                // JDK 21 race — HttpClient's NIO selector closed the channel
                // before the connect syscall ran. This is transient and the
                // retry almost always succeeds on the second attempt.
                lastErr = new Exception(
                    "JDK HttpClient race on attempt " + (attempt + 1) +
                    "/3 (ClosedChannelException) — retrying",
                    ce);
                if (attempt < 2) continue;
                throw new Exception(
                    "Cannot reach server after 3 attempts (last: " +
                    ce.getClass().getSimpleName() + " — likely server is " +
                    "restarting or there's a network issue. Verify with: " +
                    "curl " + baseUrl + "/api/health)",
                    ce);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                throw new Exception("login interrupted", ie);
            }
        }
        // Exhausted retries
        throw new Exception("login failed after 3 attempts — last error: " +
            (lastErr != null ? lastErr.getMessage() : "unknown"));
    }
    private static class LoginResponse { String token; }

    // ──────────────────────────────────────────────────────────────────────────
    // All other API calls — wrapped in a common retry helper for resilience.
    // Same JDK race can hit ANY authenticated request, not just login.
    // ──────────────────────────────────────────────────────────────────────────
    private interface HttpCall<T> {
        T execute() throws Exception;
    }
    private <T> T withRetry(HttpCall<T> call) throws Exception {
        Exception lastErr = null;
        for (int attempt = 0; attempt < 3; attempt++) {
            try {
                if (attempt > 0) Thread.sleep(400L * attempt);
                return call.execute();
            } catch (ClosedChannelException | java.net.ConnectException ce) {
                lastErr = ce;
                if (attempt < 2) continue;
                throw new Exception("network failure after 3 attempts: " +
                    ce.getClass().getSimpleName(), ce);
            } catch (java.net.http.HttpTimeoutException te) {
                lastErr = te;
                if (attempt < 2) continue;
                throw te;
            }
        }
        throw new Exception("exhausted retries: " +
            (lastErr != null ? lastErr.getMessage() : "unknown"));
    }

    // DASHBOARD
    public DashboardStats getDashboardStats() throws Exception {
        return withRetry(() -> {
            HttpRequest req = authReq("/api/dashboard/stats").GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) return gson.fromJson(resp.body(), DashboardStats.class);
            throw new Exception("Stats failed: " + resp.statusCode());
        });
    }

    // SESSIONS
    public List<Session> getSessions() throws Exception {
        return withRetry(() -> {
            HttpRequest req = authReq("/api/sessions").GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) return gson.fromJson(resp.body(), new TypeToken<List<Session>>(){}.getType());
            throw new Exception("Sessions failed: " + resp.statusCode());
        });
    }

    public Session getSession(String id) throws Exception {
        return withRetry(() -> {
            HttpRequest req = authReq("/api/sessions/" + id).GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) return gson.fromJson(resp.body(), Session.class);
            throw new Exception("Session failed: " + resp.statusCode());
        });
    }

    public boolean killSession(String id) throws Exception {
        return withRetry(() -> {
            HttpRequest req = authReq("/api/sessions/" + id).DELETE().build();
            return http.send(req, HttpResponse.BodyHandlers.ofString()).statusCode() == 200;
        });
    }

    public String sendTask(String sessionId, String command, String args) throws Exception {
        return withRetry(() -> {
            String body = "{\"command\":\"" + escapeJson(command) + "\",\"args\":\"" + escapeJson(args) + "\"}";
            HttpRequest req = authReq("/api/sessions/" + sessionId + "/task")
                .header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(body)).build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) {
                // Check for server-side INFO response (boflist, bof with no args).
                // These return {"output": "..."} instead of a task_id.
                try {
                    ServerOutput so = gson.fromJson(resp.body(), ServerOutput.class);
                    if (so != null && so.output != null && !so.output.isEmpty() && (so.task_id == null || so.task_id.isEmpty())) {
                        // Server-side info response — throw a special exception
                        // that SessionTab catches and displays as output (not error)
                        throw new ServerInfoException(so.output);
                    }
                } catch (ServerInfoException sie) { throw sie; }
                catch (Exception ignore) { /* not a server-output response, fall through */ }

                TaskResponse tr = gson.fromJson(resp.body(), TaskResponse.class);
                return tr.task_id;
            }
            // Surface the server's rejection reason (strict validation / profile
            // / bof interception all reply 400 with {"error": "<message>"}).
            String detail = "";
            try {
                TaskError te = gson.fromJson(resp.body(), TaskError.class);
                if (te != null && te.error != null && !te.error.isEmpty()) detail = ": " + te.error;
            } catch (Exception ignore) { /* body wasn't json — fall through */ }
            throw new Exception("Task failed: " + resp.statusCode() + detail);
        });
    }
    private static class TaskResponse { String task_id; }
    private static class TaskError { String error; }
    private static class ServerOutput { String output; String task_id; }

    /** Thrown when the server returns a 200 with {"output":"..."} instead
     *  of a task_id. Used for server-side-only commands like `boflist`
     *  and `bof` (no args) — the response should be displayed as normal
     *  console output, NOT as an error. */
    public static class ServerInfoException extends Exception {
        public final String output;
        public ServerInfoException(String output) { super(output); this.output = output; }
    }

    // GRAPHS (v8, Phase D/E) — attack graph (server-assembled) + AD map
    // (agent-scanned, stored server-side). Raw JSON strings on purpose:
    // parsing/rendering lives in ui/graph/GraphData.
    public String getAttackGraph() throws Exception {
        return withRetry(() -> {
            HttpRequest req = authReq("/api/graph/attack").GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) return resp.body();
            throw new Exception("Attack graph failed: " + resp.statusCode());
        });
    }

    // v10: unified network graph (attack + admap + agraph combined in one view)
    public String getNetworkGraph() throws Exception {
        return withRetry(() -> {
            HttpRequest req = authReq("/api/graph/network").GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) return resp.body();
            throw new Exception("Network graph failed: " + resp.statusCode());
        });
    }

    public String getAdMap(String sessionId) throws Exception {
        return withRetry(() -> {
            HttpRequest req = authReq("/api/admap/" + sessionId).GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) return resp.body();
            String detail = "";
            try {
                TaskError te = gson.fromJson(resp.body(), TaskError.class);
                if (te != null && te.error != null && !te.error.isEmpty()) detail = ": " + te.error;
            } catch (Exception ignore) { /* non-json body */ }
            throw new Exception("AD map: " + resp.statusCode() + detail);
        });
    }

    // LISTENERS
    // MALLEABLE PROFILES — server-loaded list for the builder combo box
    public static class ProfileInfo {
        public String name, file_name, description, post_uri, get_uri, user_agent;
    }
    public List<ProfileInfo> getProfiles() throws Exception {
        return withRetry(() -> {
            HttpRequest req = authReq("/api/profiles").GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) return gson.fromJson(resp.body(), new TypeToken<List<ProfileInfo>>(){}.getType());
            throw new Exception("Profiles failed: " + resp.statusCode());
        });
    }

    public List<ListenerInfo> getListeners() throws Exception {
        return withRetry(() -> {
            HttpRequest req = authReq("/api/listeners").GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) return gson.fromJson(resp.body(), new TypeToken<List<ListenerInfo>>(){}.getType());
            throw new Exception("Listeners failed: " + resp.statusCode());
        });
    }

    public ListenerInfo createListener(String json) throws Exception {
        return withRetry(() -> {
            HttpRequest req = authReq("/api/listeners").header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json)).build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 201) return gson.fromJson(resp.body(), ListenerInfo.class);
            throw new Exception("Create listener failed: " + resp.statusCode() + " " + resp.body());
        });
    }

    public boolean removeListener(String id) throws Exception {
        return withRetry(() ->
            http.send(authReq("/api/listeners/" + id).DELETE().build(),
                      HttpResponse.BodyHandlers.ofString()).statusCode() == 200);
    }

    // BUILDER
    // String overload — for BuildAgentDialog which builds raw JSON itself
    public String generateImplant(String jsonBody) throws Exception {
        return withRetry(() -> {
            HttpRequest req = authReq("/api/builder/generate").header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody)).build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) return resp.body();
            throw new Exception("Generate failed: " + resp.statusCode() + " " + resp.body());
        });
    }

    public String generateImplant(ImplantConfig config) throws Exception {
        String body = gson.toJson(config);
        return withRetry(() -> {
            HttpRequest req = authReq("/api/builder/generate").header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body)).build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) return resp.body();
            throw new Exception("Generate failed: " + resp.statusCode() + " " + resp.body());
        });
    }

    public String buildImplant(ImplantConfig config) throws Exception {
        String body = gson.toJson(config);
        // Note: buildImplant deliberately skips the withRetry wrapper — the
        // 10-minute timeout + heavy server-side compilation means a single
        // failure is likely non-transient (cargo crash, rustc panic, etc).
        // Retry would just waste operator time + double the server load.
        HttpRequest req = authReq("/api/builder/build")
            .header("Content-Type", "application/json")
            .timeout(Duration.ofMinutes(10))
            .POST(HttpRequest.BodyPublishers.ofString(body)).build();
        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() == 200) return resp.body();
        throw new Exception("Build failed (" + resp.statusCode() + "): " + resp.body());
    }

    // HELPERS
    // buildImplantJson — raw JSON string to /api/builder/build (actual Rust compilation)
    // Used by BuildAgentDialog which constructs JSON manually with all OPSEC fields
    public String buildImplantJson(String jsonBody) throws Exception {
        HttpRequest req = authReq("/api/builder/build").header("Content-Type", "application/json")
            .timeout(Duration.ofMinutes(10))
            .POST(HttpRequest.BodyPublishers.ofString(jsonBody)).build();
        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() == 200) return resp.body();
        throw new Exception("Build failed (" + resp.statusCode() + "): " + resp.body());
    }

    private HttpRequest.Builder authReq(String path) {
        // v9.1: every authed request carries a 20s timeout. Without it a FROZEN
        // teamserver (e.g. the CompleteTask deadlock) left the graph window on
        // "fetching graph…" forever — callers now get a caught exception and
        // render a visible "fetch failed" instead of an eternal spinner.
        // buildImplant()'s 10-minute timeout is set after authReq() and wins.
        return HttpRequest.newBuilder().uri(URI.create(baseUrl + path)).header("Authorization", "Bearer " + token)
            .timeout(Duration.ofSeconds(20));
    }
    private String escapeJson(String s) { return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\""); }
}
