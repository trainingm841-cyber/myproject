//packer/packer.go
package packer

import (
        "archive/zip"
        "crypto/md5"
        "crypto/sha256"
        "fmt"
        "io"
        "os"
        "path/filepath"
        "strings"
        "time"
)

// PackResult — pack karne ka result
type PackResult struct {
        ZipPath   string    `json:"zip_path"`
        ZipSize   int64     `json:"zip_size"`
        MD5       string    `json:"md5"`
        SHA256    string    `json:"sha256"`
        CreatedAt time.Time `json:"created_at"`
}

// Pack — binary file ko zip mein pack karo (no metadata — OPSEC clean)
func Pack(binaryPath string, outputDir string) (*PackResult, error) {

        // Binary file exist karti hai?
        info, err := os.Stat(binaryPath)
        if err != nil {
                return nil, fmt.Errorf("binary not found: %w", err)
        }

        fmt.Printf("[*] Packing: %s (%.2f MB)\n", filepath.Base(binaryPath), float64(info.Size())/1024/1024)

        // Binary padhna
        binaryData, err := os.ReadFile(binaryPath)
        if err != nil {
                return nil, fmt.Errorf("failed to read binary: %w", err)
        }

        // Hashes calculate karo — integrity verification ke liye
        md5sum := fmt.Sprintf("%x", md5.Sum(binaryData))
        sha256sum := fmt.Sprintf("%x", sha256.Sum256(binaryData))

        fmt.Printf("[*] MD5:    %s\n", md5sum)
        fmt.Printf("[*] SHA256: %s\n", sha256sum)

        // Zip file ka path — strip .exe extension before adding .zip
        binaryName := filepath.Base(binaryPath)
        zipBaseName := binaryName
        if ext := filepath.Ext(zipBaseName); ext != "" {
                zipBaseName = zipBaseName[:len(zipBaseName)-len(ext)]
        }
        zipName := zipBaseName + ".zip"
        zipPath := filepath.Join(outputDir, zipName)

        // Zip banao
        if err := createZip(zipPath, binaryPath, binaryName, binaryData, info); err != nil {
                return nil, fmt.Errorf("failed to create zip: %w", err)
        }

        // Zip ka size
        zipInfo, err := os.Stat(zipPath)
        if err != nil {
                return nil, fmt.Errorf("zip file not found after creation: %w", err)
        }

        fmt.Printf("[+] Packed: %s (%.2f MB)\n", zipName, float64(zipInfo.Size())/1024/1024)

        // Original binary hatao — sirf zip rakhna (OPSEC: raw malware disk pe na bhatke)
        os.Remove(binaryPath)

        return &PackResult{
                ZipPath:   zipPath,
                ZipSize:   zipInfo.Size(),
                MD5:       md5sum,
                SHA256:    sha256sum,
                CreatedAt: time.Now(),
        }, nil
}

// createZip — actual zip file banana
func createZip(zipPath, binaryPath, binaryName string, binaryData []byte, info os.FileInfo) error {

        zipFile, err := os.Create(zipPath)
        if err != nil {
                return fmt.Errorf("failed to create zip file: %w", err)
        }
        defer zipFile.Close()

        zipWriter := zip.NewWriter(zipFile)
        defer zipWriter.Close()

        // Binary ko zip mein add karo
        header, err := zip.FileInfoHeader(info)
        if err != nil {
                return fmt.Errorf("failed to create zip header: %w", err)
        }
        
        header.Name = binaryName
        header.Method = zip.Deflate // compress karo
        
        // Permissions maintain karo (Windows exe ke liye 0644, Linux binaries ke liye 0755)
        // info.Mode() automatically original file ka mode le lega
        header.SetMode(info.Mode())

        writer, err := zipWriter.CreateHeader(header)
        if err != nil {
                return fmt.Errorf("failed to create zip entry: %w", err)
        }

        if _, err := writer.Write(binaryData); err != nil {
                return fmt.Errorf("failed to write binary to zip: %w", err)
        }



        return nil
}

// Unpack — zip se binary nikalo (testing/deployment ke liye)
// B-CR2: Zip-Slip protection — verify every extracted path stays inside outputDir.
// A malicious zip entry like `../../etc/cron.d/x` would otherwise escape outputDir.
func Unpack(zipPath, outputDir string) (string, error) {

        r, err := zip.OpenReader(zipPath)
        if err != nil {
                return "", fmt.Errorf("failed to open zip: %w", err)
        }
        defer r.Close()

        // Resolve outputDir to an absolute path ONCE so we can verify every entry.
        absOutputDir, err := filepath.Abs(filepath.Clean(outputDir))
        if err != nil {
                return "", fmt.Errorf("failed to resolve output dir: %w", err)
        }
        // Ensure trailing separator so HasPrefix cannot match a sibling directory
        // that merely shares a prefix name (e.g. /tmp/evil vs /tmp/evilx).
        absOutputDirPrefix := absOutputDir
        if !strings.HasSuffix(absOutputDirPrefix, string(filepath.Separator)) {
                absOutputDirPrefix += string(filepath.Separator)
        }

        var extractedPath string

        for _, f := range r.File {
                // metadata.json skip karo
                if f.Name == "metadata.json" {
                        continue
                }

                dstPath := filepath.Join(outputDir, f.Name)

                // B-CR2: Zip-Slip guard — reject entries that escape outputDir.
                absDst, err := filepath.Abs(filepath.Clean(dstPath))
                if err != nil {
                        return "", fmt.Errorf("failed to resolve extracted path for %q: %w", f.Name, err)
                }
                if absDst != absOutputDir &&
                        !strings.HasPrefix(absDst+string(filepath.Separator), absOutputDirPrefix) {
                        return "", fmt.Errorf("zip-slip detected: entry %q resolves to %q outside output dir %q",
                                f.Name, absDst, absOutputDir)
                }

                rc, err := f.Open()
                if err != nil {
                        return "", err
                }

                data, err := io.ReadAll(rc)
                rc.Close()
                if err != nil {
                        return "", err
                }

                // File write karte time original permissions maintain karo
                if err := os.WriteFile(dstPath, data, f.Mode()); err != nil {
                        return "", err
                }

                extractedPath = dstPath
                fmt.Printf("[+] Extracted: %s\n", dstPath)
        }

        return extractedPath, nil
}