# Hero C2 — Malleable Profile Catalog (v4)

17 production-grade wire-dialect profiles. The agent binary carries the
CODE; these TOMLs carry the SWITCHES. Every profile is runtime-swappable
on a live session (`profile <name>`) — URIs, User-Agent, headers, poll
mode, timing and postex spawn profile all change ATOMICALLY; session ID,
crypto keys and baked config are never touched.

## What is runtime vs build-time

| Runtime-applied on `profile <name>` | Build-time only (ignored on swap) |
|---|---|
| endpoint / get_endpoint (URIs) | evasion (amsi/etw/sleep_mask/anti_vm) |
| user_agent | resilience (backoff/max_errors/max_retries) |
| headers (POST) + get_headers (GET-poll, v4) | hosts (rotation list) |
| poll_mode (get <-> post live flip) | bootstrap (incl. deaddrop mode) |
| timing (sleep/jitter/working_hours) | kill_date |

## Catalog

| Profile | Persona | Poll | Base sleep | Notes |
|---|---|---|---|---|
| jquery-cdn | jQuery CDN fetch | get | dialog default | Generic CDN blend (default) |
| github-cdn | GitHub content fetch | get | dialog default | Dev endpoints |
| azure-edge | App Insights telemetry | get | dialog default | Azure-heavy orgs |
| cloudfront | CDN bundle fetch | post | dialog default | POST-poll CDN |
| aws-s3 | S3 static asset | post | dialog default | AWS-heavy orgs |
| microsoft-365 | Graph API client | get | 15m | office persona, Graph JSON dialect |
| teams-notif | Teams presence poller | get | 3m | LAN ambient noise |
| onedrive-sync | OneDrive sync engine | post | 10m | SkyDriveSync UA, 24/7 |
| chrome-update | Omaha updater | post | 1h | Google Update winhttp UA |
| defender-telemetry | AV/OneCollector telemetry | post | 20m | bond-encoded-gzip dialect |
| windows-update | WU/WSUS client | get | 4h | .msu download persona |
| docker-hub | Registry v2 client | get | 15m | manifest/blob dialect |
| npm-registry | npm CLI | get | 10m | npm-command headers |
| pip-pypi | pip client | get | 15m | simple-index dialect |
| github-raw | Raw fetch | get | 20m | DEAD-DROP READY (see below) |
| dormant-longhaul | Health probe | get | 3h | ~7 wakes/day, max survivability |
| burst-lowlatency | Realtime session | get | 2s | INTERACTIVE ONLY — swap out after ops |

## Operator pairings

- Sit down  -> `profile burst-lowlatency` (or `sleep 30`)
- Walk away -> `profile dormant-longhaul` (or `sleep 1800`)
- Never leave an idle agent on a loud profile — periodicity detection
  feeds on exactly that.

## Dead-drop (T1102.001) — github-raw.toml

The `[bootstrap]` section ships mode = "direct" by default. Flip it to
`mode = "deaddrop"` with YOUR raw URL before building and the binary
carries NO c2 host at all — first run fetches the config from between
the `<!--cfg:` / `cfg-->` markers in that file. Build-time only; runtime
swaps never touch bootstrap.

## Infrastructure requirement

Every profile family's URI prefixes must be routed by your edge
(nginx/redirector) BEFORE an agent swaps onto that profile. See the v4
addendum in the testing guide for the full prefix table. Unrouted
profile = green-but-deaf agent.

## Engine guarantees (validated by server tests)

- All URIs unique across the catalog (duplicate mux patterns would panic
  the listener) — guarded by TestProfileRouteUniqueness.
- GET header dialects survive the bake JSON — guarded by
  TestProfileGetHeadersBaked.
- URI charset `[A-Za-z0-9/_.-]`, max 8 headers per side, transport-owned
  headers (Host/Content-Length/Transfer-Encoding) always stripped.
