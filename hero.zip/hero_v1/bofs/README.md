# HERO BOF Workspace — Beacon Object Files

Standalone BOF (Beacon Object File) arsenal — **implant source tree se bilkul
alag**. Agent ke andar chalne wala loader yahan ka COFF load karke execute
karta hai.

## Directory Layout

```
hero/
└── bofs/
    ├── README.md          ← yeh file — structure + operator guide
    ├── include/           ← beacon.h — CS-compatible Beacon API header
    │   └── beacon.h          (arsenal BOFs + community BOFs isko include karte hain)
    ├── loader/            ← AGENT-INTERNAL machinery (BOF nahi hai!)
    │   └── bof_loader.c       COFF loader: build.rs ise agent binary me
    │                          link karta hai (VirtualAlloc, relocations,
    │                          BeaconAPI symbol resolution, `go` entry,
    │                          sacrificial-thread crash containment)
    ├── bofs_src/          ← BOF SOURCES (.c) — yahan naya BOF likho
    │   ├── hidden_desktop.c  Hidden Desktop BOF (agent build me embed hota hai)
    │   ├── pipe_list.c       named pipes enumeration
    │   ├── dcfinder.c        DC discovery via DNS SRV (blind AD map)
    │   ├── netsessions.c     SMB sessions (cred-hunt leads)
    │   ├── localadmins.c     local group members (admin map)
    │   ├── unquoted_svc.c    unquoted service paths (privesc)
    │   ├── aie_check.c       MSI AlwaysInstallElevated check
    │   └── clipboard.c       clipboard text grab
    ├── scripts/           ← build helpers
    │   ├── build_hidden_desktop.sh   standalone single-BOF compile
    │   └── (build.sh bofs repo root se sab kuch compile karta hai)
    └── bofs_out/          ← COMPILED BOF BINARIES (.x64.o) — jo agent
                               runtime pe execute hote hain
```

## Operator usage (server-side packed + validated)

```
bof                          → usage + available BOF list (server replies, agent ko kuch nahi jata)
bof <name> [type:arg ...]    → arsenal BOF run
boflist                      → same list

Arg types (CS-compatible):
  i:123      32-bit int          s:2      16-bit short
  z:text     ANSI string         Z:text   wide string
  h:AABBCC   raw hex bytes       123      bare numeric = int32
  bare text  = string            z:"C:\Program Files\x"   quotes = spaces
```

Examples:
```
bof pipe_list
bof dcfinder z:corp.local
bof netsessions z:filesrv01
bof localadmins z:sql01 z:"Remote Desktop Users"
```

**Validation chain (crash-proof by design):**
1. Server checks BOF name (regex) + arsenal presence + COFF magic (0x8664)
   BEFORE queueing — unknown BOF = HTTP 400 + message, agent ko kuch nahi milta
2. Args pack hoti hain server pe — agent ko kabhi raw text nahi jata
3. Agent loader har external symbol resolve karta hai — ek bhi unresolved
   ho to BOF safe-abort hota hai (crash nahi)
4. BOF ek **sacrificial thread** pe chalta hai + scoped VEH guard:
   BOF crash → sirf woh thread marta hai, agent zinda, memory wiped,
   C2 pe "BOF CRASHED — agent survived" message jata hai
5. Run ke baad: LoadLibrary'd DLLs FreeLibrary, BOF memory zero+free —
   zero residue

## Kaun kya hai — confusion table

| Cheez | Kya hai | Kahan banta hai | Agent me kaise jata hai |
|---|---|---|---|
| Cargo `.o` (target/) | implant ka internal build garbage | `cargo build` | Deploy NAHI hota |
| Agent C `.o` (evasion, inject, **loader**) | agent-internal native code | `build.rs` → OUT_DIR | static lib me link |
| **BOF `.o`** (`bofs_out/*.x64.o`) | **COFF object — asli BOF** | `build.sh bofs` (mingw) | server task se runtime pe load |
| `bof_bridge.rs` | Rust FFI bridge | — | `exec/bof_bridge.rs` (agent ka module) |

## Naya BOF kaise add karein

1. `bofs/bofs_src/` me `<naam>.c` likho — `#include "beacon.h"` karo
   (include path build.sh automatically deta hai), entry:
   `void go(char *args, int alen)`
2. Sirf BeaconAPI + Win32 use karo — no CRT, no persistent threads,
   har allocation free karo (BOF weak file hoti hai — hygiene zaroori)
3. Compile: `./build.sh bofs` → `bofs/bofs_out/<naam>.x64.o`
4. `bofs/bofs_src/` ke saath `server/go_server/bof.go` ke `bofRegistry`
   me ek entry + usage line add karo (GUI help me dikhta hai)
5. Task: `bof <naam> [type:arg ...]` — server pack + validate karta hai
6. Rules: **x64 COFF only** (Machine = 0x8664). Community BOFs (TrustedSec
   SA, nanodump style) seedha beacon.h ke saath compile hote hain —
   `#include "beacon.h"` aur baseline CS API same hai

## BeaconAPI (loader-provided — full CS surface)

Output:
- `void BeaconOutput(int type, const char *data, int len)`
- `void BeaconPrintf(int type, const char *fmt, ...)`

Packed-args parsing (B-CR5 ABI fix — `datap` passed BY POINTER so cursor
updates land in the caller's struct on MSVC x64; callers pass `&parser`):
- `void BeaconDataParse(datap *parser, char *buffer, int size)`
- `int BeaconDataInt(datap *parser)` / `short BeaconDataShort(datap *parser)`
- `int BeaconDataLength(datap *parser)` (length-prefix PEEK)
- `char *BeaconDataExtract(datap *parser, int *size)` (prefix consume)

Tokens / spawn / misc:
- `BOOL BeaconUseToken(HANDLE)` / `void BeaconRevertToken(void)` /
  `BOOL BeaconIsAdmin(void)`
- `BOOL BeaconGetSpawnTo(BOOL x86, char *buffer, int length)`
- `int toWideChar(char *multiByte, wchar_t *unicode, int maxUnicode)`
- `void BeaconGetCpuId(...)`, `DWORD BeaconGetCurrentThreadId(void)`,
  `DWORD BeaconGetProcessId(void)`
- `void *BeaconGetThreadContext(HANDLE, void*)`,
  `BOOL BeaconSetThreadContext(HANDLE, void*)`

Win32 resolution at runtime: kernel32, ntdll, user32, advapi32, ws2_32,
msvcrt, iphlpapi, netapi32, dnsapi, gdi32, shell32.

## Build wiring (kaun kahan se uthata hai)

- `implant/agent_core/build.rs` → loader: `../../bofs/loader/bof_loader.c`
  (agent me link), hidden_desktop: `../../bofs/bofs_src/hidden_desktop.c`
  (compile → `bofs/bofs_out/hidden_desktop.x64.o` → `include_bytes!` embed)
- `build.sh bofs` → `bofs_src/*.c` sab → `bofs_out/*.x64.o` (runtime arsenal)
- `server/go_server/bof.go` → arsenal load + args pack + validation gate
- Go payload builder (`build_handler.go`) → temp build tree me `<root>/bofs/`
  ko `implant/` ke bagal me copy karta hai, wahi relative paths hold hote hain
