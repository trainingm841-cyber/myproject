// beacon.h — Cobalt Strike-compatible Beacon API header for Hero BOFs
//
// ┌─────────────────────────────────────────────────────────────────────┐
// │ Use this header for ANY BOF written for the Hero C2 loader          │
// │ (bofs/loader/bof_loader.c). Community BOFs written against the      │
// │ classic CS beacon.h compile here unmodified — the loader provides   │
// │ every symbol listed below at runtime.                               │
// │                                                                     │
// │ Rules for a clean BOF (weak file — handle with care):               │
// │   • Output ONLY via BeaconPrintf / BeaconOutput (never printf)      │
// │   • Free every buffer you allocate (HeapFree / NetApiBufferFree /   │
// │     GlobalUnlock+GlobalFree / DnsRecordListFree ...)                │
// │   • No persistent threads — `go()` must return for the loader to    │
// │     wipe and free the BOF memory                                    │
// │   • Compile: see bofs/scripts/ + ./build.sh bofs                    │
// └─────────────────────────────────────────────────────────────────────┘

#ifndef HERO_BEACON_H
#define HERO_BEACON_H

#include <windows.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// ── Output channel types (passed as the `type` argument) ────────────────
#define CALLBACK_OUTPUT         0x0
#define CALLBACK_OUTPUT_OEM     0x1a
#define CALLBACK_OUTPUT_UTF8    0x20
#define CALLBACK_ERROR          0x0d

// ── Output ──────────────────────────────────────────────────────────────
void BeaconOutput(int type, const char *data, int len);
void BeaconPrintf(int type, const char *fmt, ...);

// ── Token control (thread impersonation) ────────────────────────────────
BOOL BeaconUseToken(HANDLE token);
void BeaconRevertToken(void);
BOOL BeaconIsAdmin(void);

// ── Post-exploitation job support ───────────────────────────────────────
BOOL BeaconGetSpawnTo(BOOL x86, char *buffer, int length);

// ── Helpers ─────────────────────────────────────────────────────────────
void  BeaconGetCpuId(uint32_t leaf, uint32_t subleaf,
                     uint32_t *eax, uint32_t *ebx,
                     uint32_t *ecx, uint32_t *edx);
DWORD BeaconGetCurrentThreadId(void);
DWORD BeaconGetProcessId(void);
void *BeaconGetThreadContext(HANDLE hThread, void *ctx);
BOOL  BeaconSetThreadContext(HANDLE hThread, void *ctx);
int   toWideChar(char *multiByte, wchar_t *unicode, int maxUnicode);

// ── Packed-argument parsing ─────────────────────────────────────────────
//
// Pack format (server side: server/go_server/bof.go packBofArgs):
//   [4B LE argc]
//   int   arg    : 4 bytes raw
//   short arg    : 2 bytes raw
//   z/Z/h/H arg  : [4B LE length][length bytes]  (strings include the NUL)
//
// datap is passed BY POINTER (B-CR5 ABI fix). The classic CS beacon.h
// passed `datap` BY VALUE, but on x64 Windows MSVC ABI structs > 8 bytes
// travel through a hidden pointer to a CALLER-ALLOCATED COPY — so the
// callee's cursor updates landed on that copy, NOT on the caller's
// original struct. Every BOF that called `BeaconDataParse(parser, ...)`
// saw `parser` UNMODIFIED after the call, then `BeaconDataExtract`
// read garbage. The fix: the loader's BeaconData* functions take
// `datap *parser` and callers pass `&parser`. DO NOT reorder fields.
typedef struct {
    char * original;   // the original of the buffer
    char * buffer;     // pointer to the current spot
    int    size;       // bytes remaining
    int    length;     // length of the extracted data
} datap;

void   BeaconDataParse(datap *parser, char *buffer, int size);
int    BeaconDataInt(datap *parser);
short  BeaconDataShort(datap *parser);
int    BeaconDataLength(datap *parser);    // peeks the 4B length prefix
char * BeaconDataExtract(datap *parser, int *size);  // consumes it

#ifdef __cplusplus
}
#endif

#endif // HERO_BEACON_H
