# bofs/loader/ — agent-internal COFF loader
# bof_loader.c = BOF execution machinery (BOF NAHI hai) — build.rs ise agent binary me link karta hai
