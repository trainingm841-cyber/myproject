#include <windows.h>
#include "beacon.h"
void go(char *args, int alen) {
    (void)args; (void)alen;
    WIN32_FIND_DATAA fd;
    int count = 0;
    BeaconPrintf(0, "=== Named Pipes ===\n");
    HANDLE h = FindFirstFileExA("\\\\.\\pipe\\*", FindExInfoStandard, &fd, FindExSearchNameMatch, NULL, 0);
    if (h == INVALID_HANDLE_VALUE) { BeaconPrintf(CALLBACK_ERROR, "[!] failed (gle=%lu)\n", (unsigned long)GetLastError()); return; }
    do { BeaconPrintf(0, "[%4d] %s\n", ++count, fd.cFileName); } while (FindNextFileA(h, &fd));
    FindClose(h);
    BeaconPrintf(0, "[+] %d pipe(s) found\n", count);
}
