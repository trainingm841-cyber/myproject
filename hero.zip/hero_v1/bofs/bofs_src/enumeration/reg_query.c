#include <windows.h>
#include <stdio.h>
#include "beacon.h"
static HKEY parse_root(const char *path, const char **outSubkey) {
    if (!path || !*path) return NULL;
    if (_strnicmp(path, "HKLM\\", 5) == 0) { *outSubkey = path + 5; return HKEY_LOCAL_MACHINE; }
    if (_strnicmp(path, "HKCU\\", 5) == 0) { *outSubkey = path + 5; return HKEY_CURRENT_USER; }
    if (_strnicmp(path, "HKCR\\", 5) == 0) { *outSubkey = path + 5; return HKEY_CLASSES_ROOT; }
    return NULL;
}
void go(char *args, int alen) {
    datap parser;
    BeaconDataParse(&parser, args, alen);
    char *regPath = BeaconDataExtract(&parser, NULL);
    char *valueName = BeaconDataExtract(&parser, NULL);
    if (!regPath || !valueName) { BeaconPrintf(CALLBACK_ERROR, "[!] Usage: bof reg_query z:<path> z:<value_name>\n"); return; }
    const char *subkey = NULL;
    HKEY hRoot = parse_root(regPath, &subkey);
    if (!hRoot || !subkey) { BeaconPrintf(CALLBACK_ERROR, "[!] Cannot parse root\n"); return; }
    HKEY hKey = NULL;
    if (RegOpenKeyExA(hRoot, subkey, 0, KEY_READ, &hKey) != ERROR_SUCCESS) { BeaconPrintf(CALLBACK_ERROR, "[!] RegOpenKeyEx failed\n"); return; }
    const char *actualName = (_stricmp(valueName, "@") == 0) ? "" : valueName;
    DWORD valueType=0, valueSize=0;
    if (RegQueryValueExA(hKey, actualName, NULL, &valueType, NULL, &valueSize) != ERROR_SUCCESS) { RegCloseKey(hKey); return; }
    if (valueSize > 1024*1024) { RegCloseKey(hKey); return; }
    BYTE *buf = (BYTE *)HeapAlloc(GetProcessHeap(), 0, valueSize+1);
    if (!buf) { RegCloseKey(hKey); return; }
    RegQueryValueExA(hKey, actualName, NULL, &valueType, buf, &valueSize);
    if (valueType == REG_SZ || valueType == REG_EXPAND_SZ)
        BeaconPrintf(CALLBACK_OUTPUT, "Value: %s\n", (char *)buf);
    else if (valueType == REG_DWORD)
        BeaconPrintf(CALLBACK_OUTPUT, "Value: %lu (0x%08lX)\n", (unsigned long)*(DWORD *)buf, (unsigned long)*(DWORD *)buf);
    else
        BeaconPrintf(CALLBACK_OUTPUT, "Value: (%lu bytes, type=%lu)\n", (unsigned long)valueSize, (unsigned long)valueType);
    HeapFree(GetProcessHeap(), 0, buf);
    RegCloseKey(hKey);
}
