#include <windows.h>
#include <stdio.h>
#include "beacon.h"
static void enum_subtasks(HKEY hParent, int depth) {
    DWORD index = 0; char subkeyName[256]={0}; DWORD subkeyNameLen=sizeof(subkeyName); FILETIME ftWrite;
    while (RegEnumKeyExA(hParent, index++, subkeyName, &subkeyNameLen, NULL, NULL, NULL, &ftWrite) == ERROR_SUCCESS) {
        HKEY hSub;
        if (RegOpenKeyExA(hParent, subkeyName, 0, KEY_READ, &hSub) == ERROR_SUCCESS) {
            char taskPath[512]={0}; DWORD pathLen=sizeof(taskPath); DWORD vt=0;
            if (RegQueryValueExA(hSub, "Path", NULL, &vt, (LPBYTE)taskPath, &pathLen) == ERROR_SUCCESS)
                BeaconPrintf(CALLBACK_OUTPUT, "  \\%s\n", taskPath);
            else if (depth < 10) enum_subtasks(hSub, depth+1);
            RegCloseKey(hSub);
        }
        subkeyNameLen = sizeof(subkeyName);
    }
}
void go(char *args, int alen) {
    (void)args; (void)alen;
    BeaconPrintf(CALLBACK_OUTPUT, "=== Scheduled Tasks ===\n");
    HKEY hTree = NULL;
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache\\Tree", 0, KEY_READ, &hTree) != ERROR_SUCCESS) {
        BeaconPrintf(CALLBACK_ERROR, "[!] Cannot open TaskCache\\Tree\n"); return;
    }
    enum_subtasks(hTree, 0);
    RegCloseKey(hTree);
    BeaconPrintf(CALLBACK_OUTPUT, "[+] done\n");
}
