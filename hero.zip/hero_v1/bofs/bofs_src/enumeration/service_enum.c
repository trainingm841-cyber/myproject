#include <windows.h>
#include "beacon.h"
void go(char *args, int alen) {
    (void)args; (void)alen;
    BeaconPrintf(CALLBACK_OUTPUT, "=== Services (RUNNING) ===\n");
    SC_HANDLE hScm = OpenSCManagerA(NULL, SERVICES_ACTIVE_DATABASE, SC_MANAGER_ENUMERATE_SERVICE);
    if (!hScm) { BeaconPrintf(CALLBACK_ERROR, "[!] OpenSCManager failed\n"); return; }
    DWORD bytesNeeded=0, servicesReturned=0, resumeHandle=0;
    EnumServicesStatusExA(hScm, SC_ENUM_PROCESS_INFO, SERVICE_WIN32, SERVICE_STATE_ALL, NULL, 0, &bytesNeeded, &servicesReturned, &resumeHandle, NULL);
    if (GetLastError() != ERROR_MORE_DATA) { CloseServiceHandle(hScm); return; }
    BYTE *buf = (BYTE *)HeapAlloc(GetProcessHeap(), 0, bytesNeeded);
    if (!buf) { CloseServiceHandle(hScm); return; }
    if (!EnumServicesStatusExA(hScm, SC_ENUM_PROCESS_INFO, SERVICE_WIN32, SERVICE_STATE_ALL, buf, bytesNeeded, &bytesNeeded, &servicesReturned, &resumeHandle, NULL)) {
        HeapFree(GetProcessHeap(), 0, buf); CloseServiceHandle(hScm); return;
    }
    ENUM_SERVICE_STATUS_PROCESSA *svcs = (ENUM_SERVICE_STATUS_PROCESSA *)buf;
    DWORD running = 0;
    for (DWORD i = 0; i < servicesReturned; i++) {
        if (svcs[i].ServiceStatusProcess.dwCurrentState != SERVICE_RUNNING) continue;
        running++;
        BeaconPrintf(CALLBACK_OUTPUT, "  [RUNNING] %s\n", svcs[i].lpServiceName);
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[+] %u/%u running\n", running, servicesReturned);
    HeapFree(GetProcessHeap(), 0, buf);
    CloseServiceHandle(hScm);
}
