# bofs/bofs_src/ — BOF sources (.c)
# Naya BOF yahan likho: entry void go(char* args, int alen), BeaconAPI output, no CRT
