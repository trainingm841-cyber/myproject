#include <windows.h>
#include "beacon.h"
void go(char *args, int alen) {
    (void)args; (void)alen;
    HANDLE hToken = NULL;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
        BeaconPrintf(CALLBACK_ERROR, "[!] OpenProcessToken failed (gle=%lu)\n", (unsigned long)GetLastError());
        return;
    }
    DWORD dwSize = 0;
    GetTokenInformation(hToken, TokenPrivileges, NULL, 0, &dwSize);
    if (dwSize == 0) { CloseHandle(hToken); return; }
    TOKEN_PRIVILEGES *privs = (TOKEN_PRIVILEGES *)HeapAlloc(GetProcessHeap(), 0, dwSize);
    if (!privs) { CloseHandle(hToken); return; }
    if (!GetTokenInformation(hToken, TokenPrivileges, privs, dwSize, &dwSize)) {
        HeapFree(GetProcessHeap(), 0, privs); CloseHandle(hToken); return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "=== Current Privileges (%u entries) ===\n", privs->PrivilegeCount);
    DWORD enabled_count = 0;
    for (DWORD i = 0; i < privs->PrivilegeCount; i++) {
        char privName[256] = {0};
        DWORD nameLen = sizeof(privName);
        if (LookupPrivilegeNameA(NULL, &privs->Privileges[i].Luid, privName, &nameLen)) {
            BOOL enabled = (privs->Privileges[i].Attributes & SE_PRIVILEGE_ENABLED);
            if (enabled) enabled_count++;
            const char *note = "";
            if (_stricmp(privName, "SeDebugPrivilege") == 0) note = "  <-- OpenProcess(any)";
            else if (_stricmp(privName, "SeImpersonatePrivilege") == 0) note = "  <-- ImpersonateNamedPipeClient";
            BeaconPrintf(CALLBACK_OUTPUT, "    [%s] %s%s\n", enabled ? "*" : " ", privName, note);
        }
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[+] %u/%u privileges enabled\n", enabled_count, privs->PrivilegeCount);
    HeapFree(GetProcessHeap(), 0, privs);
    CloseHandle(hToken);
}
