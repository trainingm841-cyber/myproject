#include <windows.h>
#include "beacon.h"
void go(char *args, int alen) {
    (void)args; (void)alen;
    BeaconRevertToken();
    char userName[256]={0}; DWORD nameLen=sizeof(userName);
    if (GetUserNameA(userName, &nameLen))
        BeaconPrintf(CALLBACK_OUTPUT, "[+] Reverted — now running as: %s\n", userName);
}
