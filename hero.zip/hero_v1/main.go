package main

import (
        "flag"
        "fmt"
        "log"
        "os"
        "os/signal"
        "syscall"

        "hero/server"
)

func main() {
        agentAddr := flag.String("agent", "", "Direct mTLS listen address")
        httpAgentAddr := flag.String("http-agent", "", "HTTP agent listener behind Nginx")
        guiAddr := flag.String("gui", "127.0.0.1:8443", "GUI web interface")
        certFile := flag.String("cert", "", "TLS cert (direct mTLS mode)")
        keyFile := flag.String("key", "", "TLS key (direct mTLS mode)")
        agentCertPath := flag.String("agent-cert", "", "Agent client cert path")
        agentKeyPath := flag.String("agent-key", "", "Agent client key path")
        c2Domain := flag.String("c2-domain", "", "C2 domain")
        c2Port := flag.Int("c2-port", 443, "C2 port")
        c2Endpoint := flag.String("c2-endpoint", "/api/v1/c2-endpoint", "C2 endpoint path")
        outputDir := flag.String("payloads", "./payloads", "Payloads directory")
        dataDir := flag.String("data", "./hero-data", "Data directory")
        flag.Parse()

        if *agentAddr == "" && *httpAgentAddr == "" {
                log.Fatal("[ERROR] Specify --agent or --http-agent")
        }
        if *certFile != "" || *keyFile != "" {
                for _, f := range []string{*certFile, *keyFile} {
                        if f == "" { log.Fatal("[ERROR] --cert and --key must both be provided") }
                        if _, err := os.Stat(f); os.IsNotExist(err) { log.Fatalf("[ERROR] not found: %s", f) }
                }
        }

        cfg := server.Config{
                AgentAddr: *agentAddr, HTTPAgentAddr: *httpAgentAddr,
                GUIAddr: *guiAddr, CertFile: *certFile, KeyFile: *keyFile,
                OutputDir: *outputDir, DataDir: *dataDir,
                AgentCertPath: *agentCertPath, AgentKeyPath: *agentKeyPath,
                C2Domain: *c2Domain, C2Port: *c2Port, C2Endpoint: *c2Endpoint,
        }

        // Print banner with auth token before server init
        tmpAuth, _ := server.NewAuth(cfg.DataDir)
        server.PrintBanner(cfg, tmpAuth.Token())

        go func() {
                sig := make(chan os.Signal, 1)
                signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
                <-sig
                fmt.Println("\n[HERO] Shutting down...")
                os.Exit(0)
        }()

        srv, err := server.New(cfg)
        if err != nil { log.Fatalf("[HERO] init failed: %v", err) }
        if err := srv.Start(); err != nil { log.Fatalf("[HERO] fatal: %v", err) }
}
