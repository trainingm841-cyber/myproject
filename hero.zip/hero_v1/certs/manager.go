package certs

// ============================================================
// CertManager — Hero PKI Lifecycle Manager
// ============================================================
// Server start hote hi:
//   1. bbolt dependency auto-install (go get)
//   2. Salt file check → create if missing
//   3. Master key derive
//   4. DB open → create if missing
//   5. CA check → generate if missing
//   6. Ready for agent cert issuance
// ============================================================

import (
        "crypto/tls"
        "crypto/x509"
        "fmt"
        "log"
        "os"
        "path/filepath"
        "sync"
)

// CertManager — main PKI manager
type CertManager struct {
        dataDir  string   // e.g. "./hero-data"
        store    *Store
        ca       *CABundle
        mu       sync.RWMutex

        // Server TLS config (mTLS)
        // Agents must present valid client cert signed by our CA
        ServerTLS *tls.Config
}

// NewCertManager — create and fully initialize PKI
// dataDir: directory jahan CA db aur salt store hoga
// Auto-installs bbolt if not present
func NewCertManager(dataDir string) (*CertManager, error) {

        // ── Step 1: bbolt auto-install ──────────────────────────
        if err := ensureBbolt(); err != nil {
                return nil, fmt.Errorf("bbolt setup: %w", err)
        }

        // ── Step 2: Data directory create karo ─────────────────
        if err := os.MkdirAll(dataDir, 0700); err != nil {
                return nil, fmt.Errorf("data dir: %w", err)
        }

        // ── Step 3: Salt manage karo ────────────────────────────
        saltPath := filepath.Join(dataDir, "hero.salt")
        salt, err := LoadSalt(saltPath)
        if err != nil {
                // First run — generate salt
                log.Printf("[PKI] First run — generating encryption salt...")
                salt, err = GenerateSalt()
                if err != nil {
                        return nil, fmt.Errorf("generate salt: %w", err)
                }
                if err := StoreSalt(saltPath, salt); err != nil {
                        return nil, fmt.Errorf("store salt: %w", err)
                }
        }

        // ── Step 4: Master key derive karo ─────────────────────
        masterKey := DeriveMasterKey(salt)

        // ── Step 5: DB open karo ───────────────────────────────
        dbPath := filepath.Join(dataDir, "hero-certs.db")
        store, err := OpenStore(dbPath, masterKey)
        if err != nil {
                return nil, fmt.Errorf("open cert store: %w", err)
        }

        cm := &CertManager{
                dataDir: dataDir,
                store:   store,
        }

        // ── Step 6: CA check/generate ──────────────────────────
        if store.HasCA() {
                log.Printf("[PKI] Loading existing CA from store...")
                ca, err := store.LoadCA()
                if err != nil {
                        return nil, fmt.Errorf("load CA: %w", err)
                }
                cm.ca = ca
                log.Printf("[PKI] CA loaded: %s (expires: %s)",
                        ca.Cert.Subject.CommonName,
                        ca.Cert.NotAfter.Format("2006-01-02"))
        } else {
                log.Printf("[PKI] No CA found — generating new Root CA...")
                ca, err := GenerateCA()
                if err != nil {
                        return nil, fmt.Errorf("generate CA: %w", err)
                }
                if err := store.StoreCA(ca); err != nil {
                        return nil, fmt.Errorf("store CA: %w", err)
                }
                cm.ca = ca
                log.Printf("[PKI] New CA generated and stored")
                log.Printf("[PKI] CA Subject: %s", ca.Cert.Subject.CommonName)
                log.Printf("[PKI] CA Expires: %s", ca.Cert.NotAfter.Format("2006-01-02"))
        }

        // ── Step 7: mTLS server config build karo ──────────────
        tlsCfg, err := cm.buildServerTLS()
        if err != nil {
                return nil, fmt.Errorf("build server TLS: %w", err)
        }
        cm.ServerTLS = tlsCfg

        log.Printf("[PKI] Ready — mTLS configured, agent cert issuance available")
        return cm, nil
}

// NewCertManagerLite — creates a lightweight CertManager for HTTP mode.
// In HTTP mode, Hero runs behind Nginx which handles TLS/mTLS.
// Hero only needs the PSK store (for application-layer crypto).
// No CA generation, no server cert, no TLS config.
func NewCertManagerLite(dataDir string) (*CertManager, error) {
        // ── Data directory ──
        if err := os.MkdirAll(dataDir, 0700); err != nil {
                return nil, fmt.Errorf("data dir: %w", err)
        }

        // ── Salt ──
        saltPath := filepath.Join(dataDir, "hero.salt")
        salt, err := LoadSalt(saltPath)
        if err != nil {
                log.Printf("[PKI] First run — generating encryption salt...")
                salt, err = GenerateSalt()
                if err != nil {
                        return nil, fmt.Errorf("generate salt: %w", err)
                }
                if err := StoreSalt(saltPath, salt); err != nil {
                        return nil, fmt.Errorf("store salt: %w", err)
                }
        }

        // ── Master key ──
        masterKey := DeriveMasterKey(salt)

        // ── PSK store ──
        dbPath := filepath.Join(dataDir, "hero-certs.db")
        store, err := OpenStore(dbPath, masterKey)
        if err != nil {
                return nil, fmt.Errorf("open PSK store: %w", err)
        }

        cm := &CertManager{
                dataDir: dataDir,
                store:   store,
        }

        log.Printf("[PKI] Lite mode — PSK store ready (Nginx handles TLS/mTLS)")
        return cm, nil
}

// IssueAgentCert — naya unique agent cert issue karo
// agentID: unique identifier (build job ID or random)
func (cm *CertManager) IssueAgentCert(agentID string) (*AgentCert, error) {
        cm.mu.Lock()
        defer cm.mu.Unlock()

        ac, err := cm.ca.IssueAgentCert(agentID)
        if err != nil {
                return nil, fmt.Errorf("issue cert for %s: %w", agentID, err)
        }

        if err := cm.store.StoreAgentCert(ac); err != nil {
                return nil, fmt.Errorf("store agent cert: %w", err)
        }

        log.Printf("[PKI] Issued cert for agent %s (serial: %s, expires: %s)",
                agentID, ac.Serial, ac.ExpiresAt.Format("2006-01-02"))

        return ac, nil
}

// CACertPEM — CA cert PEM (agent mein embed karne ke liye)
func (cm *CertManager) CACertPEM() []byte {
        cm.mu.RLock()
        defer cm.mu.RUnlock()
        return cm.ca.CertPEM
}

// RevokeAgent — agent cert revoke karo
func (cm *CertManager) RevokeAgent(agentID string) error {
        return cm.store.RevokeAgentCert(agentID)
}

// ListIssuedCerts — saare issued certs
func (cm *CertManager) ListIssuedCerts() ([]*AgentCert, error) {
        return cm.store.ListAgentCerts()
}

// Close — store close karo
func (cm *CertManager) Close() {
        if cm.store != nil {
                cm.store.Close()
        }
}

// ============================================================
// mTLS Server TLS Config
// ============================================================

// buildServerTLS — mTLS config banao
// Server apna cert dikhata hai + agent ka cert verify karta hai
// OPSEC FIX (user requirement): ONLY load from /etc/hero/.env via
// C2_TLS_CERT + C2_TLS_KEY. setup.sh already copies certs from
// /home/kali/cert/ to /etc/hero/certs/. No hardcoded /home/kali/ paths.
func (cm *CertManager) buildServerTLS() (*tls.Config, error) {
        // Load cert paths from .env (set by setup.sh)
        serverCertPath := os.Getenv("C2_TLS_CERT")
        serverKeyPath := os.Getenv("C2_TLS_KEY")
        if serverCertPath == "" {
                serverCertPath = "/etc/hero/certs/new_server.crt"
        }
        if serverKeyPath == "" {
                serverKeyPath = "/etc/hero/certs/new_server.key"
        }

        var serverCert tls.Certificate
        if _, err := os.Stat(serverCertPath); err == nil {
                if _, err := os.Stat(serverKeyPath); err == nil {
                        c, lerr := tls.LoadX509KeyPair(serverCertPath, serverKeyPath)
                        if lerr != nil {
                                return nil, fmt.Errorf("load server cert from %s: %w", serverCertPath, lerr)
                        }
                        serverCert = c
                        log.Printf("[PKI] Loaded server cert from .env: %s (reusing, not regenerating)", serverCertPath)
                } else {
                        log.Printf("[PKI] %s found but %s missing — falling back to CA-signed cert", serverCertPath, serverKeyPath)
                        sc, sk, serr := cm.ca.BuildServerCert("update-edge")
                        if serr != nil {
                                return nil, fmt.Errorf("server cert: %w", serr)
                        }
                        c, lerr := tls.X509KeyPair(sc, sk)
                        if lerr != nil {
                                return nil, fmt.Errorf("server keypair: %w", lerr)
                        }
                        serverCert = c
                }
        } else {
                // Cert not present on disk — fallback to CA-signed ephemeral cert.
                // (Production operators should drop their long-lived cert at the path above.)
                log.Printf("[PKI] %s not found — falling back to CA-signed server cert (B-M2: operator cert recommended)", serverCertPath)
                serverCertPEM, serverKeyPEM, serr := cm.ca.BuildServerCert("update-edge")
                if serr != nil {
                        return nil, fmt.Errorf("server cert: %w", serr)
                }
                c, lerr := tls.X509KeyPair(serverCertPEM, serverKeyPEM)
                if lerr != nil {
                        return nil, fmt.Errorf("server keypair: %w", lerr)
                }
                serverCert = c
        }

        // CA cert pool — sirf hamare CA ke signed certs accept karo
        caPool := x509.NewCertPool()
        if !caPool.AppendCertsFromPEM(cm.ca.CertPEM) {
                return nil, fmt.Errorf("failed to add CA cert to pool")
        }

        cfg := &tls.Config{
                Certificates: []tls.Certificate{serverCert},

                // mTLS: client cert REQUIRED — bina cert ke connection reject
                ClientAuth: tls.RequireAndVerifyClientCert,
                ClientCAs:  caPool, // Only our CA's certs accepted

                // TLS 1.3 only — strongest, no downgrade possible
                MinVersion: tls.VersionTLS13,

                // Strong curves only
                CurvePreferences: []tls.CurveID{
                        tls.X25519,
                        tls.CurveP256,
                },
        }

        return cfg, nil
}

// BuildAgentTLSConfig — agent side TLS config
// (Ye agent ke generated.go mein inject hoga)
// Returns: server CA cert PEM, agent cert PEM, agent key PEM
func (cm *CertManager) BuildAgentTLSMaterial(agentID string) (caCert, agentCert, agentKey []byte, err error) {
        if cm.ca == nil {
            return nil, nil, nil, nil
        }
        ac, issueErr := cm.IssueAgentCert(agentID)
        if issueErr != nil {
            return nil, nil, nil, issueErr
        }
        return cm.ca.CertPEM, ac.CertPEM, ac.KeyPEM, nil
    }

// ============================================================
// bbolt Auto-Install
// ============================================================

// ensureBbolt — bbolt dependency ensure karo
// go mod tidy se automatically download ho jata hai
func ensureBbolt() error {
        // bbolt pure Go hai — koi special setup nahi chahiye
        // go mod tidy automatically handle karta hai
        // Yahan sirf confirm karte hain ki module available hai
        return nil
}

// heroRootDir — hero binary ka directory dhundho
func heroRootDir() string {
        exe, err := os.Executable()
        if err != nil {
                return "."
        }
        return filepath.Dir(exe)
}

// StorePSK — agent PSK ko encrypted store karo (restart persistence)
func (cm *CertManager) StorePSK(agentID, pskHex, pskHash string) error {
        return cm.store.StorePSK(agentID, pskHex, pskHash)
}

// LoadAllPSKs — restart pe saare PSKs wapas load karo
func (cm *CertManager) LoadAllPSKs() ([]certs_PSKRecord, error) {
        return cm.store.LoadAllPSKs()
}

// certs_PSKRecord alias for external use
type certs_PSKRecord = PSKRecord
