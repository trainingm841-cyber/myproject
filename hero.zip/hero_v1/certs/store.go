package certs

// ============================================================
// Hero Cert Store — Pure stdlib, zero external dependencies
// ============================================================
// Storage: flat files in dataDir, AES-256-GCM encrypted
//
// Layout:
//   hero-data/
//   ├── hero.salt          — random salt for key derivation
//   ├── ca.cert.enc        — encrypted CA cert PEM
//   ├── ca.key.enc         — encrypted CA private key PEM
//   └── agents/
//       └── {agentID}.enc  — encrypted agent cert JSON
//
// Encryption: AES-256-GCM (same as before, no bbolt needed)
// ============================================================

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"time"
)

// Store — encrypted file-based cert store
type Store struct {
	dataDir string
	key     [32]byte // AES-256 master key (in memory only)
}

// agentRecord — what we store per agent
type agentRecord struct {
	AgentID   string    `json:"agent_id"`
	CertPEM   []byte    `json:"cert_pem"`
	KeyPEM    []byte    `json:"key_pem"`
	Serial    string    `json:"serial"`
	IssuedAt  time.Time `json:"issued_at"`
	ExpiresAt time.Time `json:"expires_at"`
}

// OpenStore — store open karo (directory create karo agar missing ho)
func OpenStore(dataDir string, masterKey [32]byte) (*Store, error) {
	// Agents subdirectory
	agentsDir := filepath.Join(dataDir, "agents")
	if err := os.MkdirAll(agentsDir, 0700); err != nil {
		return nil, fmt.Errorf("create agents dir: %w", err)
	}
	return &Store{dataDir: dataDir, key: masterKey}, nil
}

func (s *Store) Close() error { return nil } // no-op for file store

// ============================================================
// CA operations
// ============================================================

func (s *Store) StoreCA(ca *CABundle) error {
	certEnc, err := s.encrypt(ca.CertPEM)
	if err != nil {
		return fmt.Errorf("encrypt CA cert: %w", err)
	}
	keyEnc, err := s.encrypt(ca.KeyPEM)
	if err != nil {
		return fmt.Errorf("encrypt CA key: %w", err)
	}

	if err := os.WriteFile(filepath.Join(s.dataDir, "ca.cert.enc"), certEnc, 0600); err != nil {
		return fmt.Errorf("write CA cert: %w", err)
	}
	return os.WriteFile(filepath.Join(s.dataDir, "ca.key.enc"), keyEnc, 0600)
}

func (s *Store) LoadCA() (*CABundle, error) {
	certEnc, err := os.ReadFile(filepath.Join(s.dataDir, "ca.cert.enc"))
	if err != nil {
		return nil, fmt.Errorf("read CA cert: %w", err)
	}
	keyEnc, err := os.ReadFile(filepath.Join(s.dataDir, "ca.key.enc"))
	if err != nil {
		return nil, fmt.Errorf("read CA key: %w", err)
	}

	certPEM, err := s.decrypt(certEnc)
	if err != nil {
		return nil, fmt.Errorf("decrypt CA cert: %w", err)
	}
	keyPEM, err := s.decrypt(keyEnc)
	if err != nil {
		return nil, fmt.Errorf("decrypt CA key: %w", err)
	}

	return LoadCABundle(certPEM, keyPEM)
}

func (s *Store) HasCA() bool {
	_, err := os.Stat(filepath.Join(s.dataDir, "ca.cert.enc"))
	return err == nil
}

// ============================================================
// Agent cert operations
// ============================================================

func (s *Store) StoreAgentCert(ac *AgentCert) error {
	rec := agentRecord{
		AgentID:   ac.AgentID,
		CertPEM:   ac.CertPEM,
		KeyPEM:    ac.KeyPEM,
		Serial:    ac.Serial,
		IssuedAt:  ac.IssuedAt,
		ExpiresAt: ac.ExpiresAt,
	}
	data, err := json.Marshal(rec)
	if err != nil {
		return fmt.Errorf("marshal: %w", err)
	}
	enc, err := s.encrypt(data)
	if err != nil {
		return fmt.Errorf("encrypt: %w", err)
	}
	path := filepath.Join(s.dataDir, "agents", ac.AgentID+".enc")
	return os.WriteFile(path, enc, 0600)
}

func (s *Store) LoadAgentCert(agentID string) (*AgentCert, error) {
	path := filepath.Join(s.dataDir, "agents", agentID+".enc")
	enc, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("agent cert not found: %s", agentID)
	}
	data, err := s.decrypt(enc)
	if err != nil {
		return nil, fmt.Errorf("decrypt: %w", err)
	}
	var rec agentRecord
	if err := json.Unmarshal(data, &rec); err != nil {
		return nil, fmt.Errorf("unmarshal: %w", err)
	}
	return &AgentCert{
		AgentID:   rec.AgentID,
		CertPEM:   rec.CertPEM,
		KeyPEM:    rec.KeyPEM,
		Serial:    rec.Serial,
		IssuedAt:  rec.IssuedAt,
		ExpiresAt: rec.ExpiresAt,
	}, nil
}

func (s *Store) ListAgentCerts() ([]*AgentCert, error) {
	entries, err := os.ReadDir(filepath.Join(s.dataDir, "agents"))
	if err != nil {
		return nil, err
	}
	var result []*AgentCert
	for _, e := range entries {
		if e.IsDir() {
			continue
		}
		enc, err := os.ReadFile(filepath.Join(s.dataDir, "agents", e.Name()))
		if err != nil {
			continue
		}
		data, err := s.decrypt(enc)
		if err != nil {
			continue
		}
		var rec agentRecord
		if err := json.Unmarshal(data, &rec); err != nil {
			continue
		}
		result = append(result, &AgentCert{
			AgentID:   rec.AgentID,
			Serial:    rec.Serial,
			IssuedAt:  rec.IssuedAt,
			ExpiresAt: rec.ExpiresAt,
		})
	}
	return result, nil
}

func (s *Store) RevokeAgentCert(agentID string) error {
	return os.Remove(filepath.Join(s.dataDir, "agents", agentID+".enc"))
}

// ============================================================
// AES-256-GCM Encryption
// ============================================================

func (s *Store) encrypt(plaintext []byte) ([]byte, error) {
	block, err := aes.NewCipher(s.key[:])
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, err
	}
	return gcm.Seal(nonce, nonce, plaintext, nil), nil
}

func (s *Store) decrypt(ciphertext []byte) ([]byte, error) {
	block, err := aes.NewCipher(s.key[:])
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	ns := gcm.NonceSize()
	if len(ciphertext) < ns+gcm.Overhead() {
		return nil, fmt.Errorf("ciphertext too short")
	}
	return gcm.Open(nil, ciphertext[:ns], ciphertext[ns:], nil)
}

// ============================================================
// Master Key Derivation — pure stdlib
// ============================================================

func DeriveMasterKey(salt []byte) [32]byte {
	hostname, _ := os.Hostname()
	machineID, _ := os.ReadFile("/etc/machine-id")
	combined := append(salt, []byte(hostname)...)
	combined = append(combined, machineID...)
	return sha256.Sum256(combined)
}

func GenerateSalt() ([]byte, error) {
	salt := make([]byte, 32)
	if _, err := io.ReadFull(rand.Reader, salt); err != nil {
		return nil, err
	}
	return salt, nil
}

func StoreSalt(path string, salt []byte) error {
	return os.WriteFile(path, salt, 0600)
}

func LoadSalt(path string) ([]byte, error) {
	return os.ReadFile(path)
}

// ============================================================
// PSK Persistence — restart pe bhi PSK available rahe
// ============================================================

type PSKRecord struct {
	AgentID string `json:"agent_id"`
	PSKHex  string `json:"psk_hex"`
	PSKHash string `json:"psk_hash"`
}

// StorePSK — agent PSK encrypted save karo
func (s *Store) StorePSK(agentID, pskHex, pskHash string) error {
	rec := PSKRecord{AgentID: agentID, PSKHex: pskHex, PSKHash: pskHash}
	data, err := json.Marshal(rec)
	if err != nil {
		return err
	}
	enc, err := s.encrypt(data)
	if err != nil {
		return err
	}
	path := filepath.Join(s.dataDir, "agents", agentID+".psk.enc")
	return os.WriteFile(path, enc, 0600)
}

// LoadAllPSKs — server restart pe saare PSKs reload karo
func (s *Store) LoadAllPSKs() ([]PSKRecord, error) {
	entries, err := os.ReadDir(filepath.Join(s.dataDir, "agents"))
	if err != nil {
		return nil, err
	}
	var result []PSKRecord
	for _, e := range entries {
		if e.IsDir() || filepath.Ext(e.Name()) != ".enc" {
			continue
		}
		// Only .psk.enc files
		name := e.Name()
		if len(name) < 8 || name[len(name)-8:] != ".psk.enc" {
			continue
		}
		enc, err := os.ReadFile(filepath.Join(s.dataDir, "agents", name))
		if err != nil {
			continue
		}
		data, err := s.decrypt(enc)
		if err != nil {
			continue
		}
		var rec PSKRecord
		if err := json.Unmarshal(data, &rec); err != nil {
			continue
		}
		result = append(result, rec)
	}
	return result, nil
}
