// beacons/ — beacon loop implementations.
//
// https_beacon.rs: the single active beacon — HTTPS POST polling with
// configurable sleep/jitter/backoff, working hours, kill date and a
// runtime sleep override (operator `sleep` command).

pub mod https_beacon;
