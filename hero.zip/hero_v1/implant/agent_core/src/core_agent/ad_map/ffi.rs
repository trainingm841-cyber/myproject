//! ad_map/ffi.rs — raw Win32 FFI for AD/domain discovery (v8, Phase E)
//!
//! WHY hand-declared externs (framework convention, same as dispatcher.rs /
//! inline_network.rs):
//!   • Zero new crate features — no winapi feature-flag surprises on the
//!     windows-gnu toolchain.
//!   • WE own the signature — the netapi32 `resume_handle` parameter has a
//!     documented history of header-variance pain (PDWORD_PTR vs LPDWORD,
//!     the exact bug class fixed in the BOF arsenal). Declaring it as
//!     *mut c_void and passing NULL sidesteps every header variant: with
//!     MAX_PREFERRED_LENGTH the call is single-shot, so NULL is the
//!     documented optional value.
//!   • Everything is inline WinAPI — no child process, no cmd.exe, no
//!     nltest/net view — maximum stealth (MITRE T1018 / T1482 done via
//!     documented APIs only).
//!
//! Linked libraries (mingw-w64): netapi32 (NetServerEnum, DsGetDcNameA,
//! NetApiBufferFree), iphlpapi (GetIpNetTable, GetTcpTable), shell32
//! (IsUserAnAdmin).

#![allow(non_snake_case)]
#![allow(non_camel_case_types)]
#![allow(dead_code)]

// ============================================================
// netapi32 — server/domain enumeration
// ============================================================

/// MAX_PREFERRED_LENGTH — ask the API to allocate exactly what it needs
/// (single-shot response; makes resume_handle NULL legal).
pub const MAX_PREFERRED_LENGTH: u32 = 0xFFFF_FFFF;

/// SERVER_INFO_101 type flags (only the ones we classify on)
pub const SV_TYPE_WORKSTATION: u32 = 0x0000_0001;
pub const SV_TYPE_SERVER:      u32 = 0x0000_0002;
pub const SV_TYPE_DOMAIN_CTRL: u32 = 0x0000_0008;
pub const SV_TYPE_DOMAIN_BAKCTRL: u32 = 0x0000_0010;
pub const SV_TYPE_DOMAIN_ENUM: u32 = 0x8000_0000;

/// SERVER_INFO_101 (x64 layout: 40 bytes)
///   DWORD sv101_platform_id;        +4 pad → 8
///   LPWSTR sv101_name;              → 16
///   DWORD sv101_version_major;      → 20
///   DWORD sv101_version_minor;      → 24
///   DWORD sv101_type;       +4 pad  → 32
///   LPWSTR sv101_comment;           → 40
#[repr(C)]
pub struct SERVER_INFO_101 {
    pub sv101_platform_id: u32,
    pub sv101_name: *const u16,
    pub sv101_version_major: u32,
    pub sv101_version_minor: u32,
    pub sv101_type: u32,
    pub sv101_comment: *const u16,
}

/// DOMAIN_CONTROLLER_INFOA (x64 layout: 80 bytes)
#[repr(C)]
pub struct DOMAIN_CONTROLLER_INFOA {
    pub DomainControllerName: *const u8,
    pub DomainControllerAddress: *const u8,
    pub DomainControllerAddressType: u32,
    pub DomainGuid: [u8; 16],
    pub DomainName: *const u8,
    pub DnsForestName: *const u8,
    pub Flags: u32,
    pub DcSiteName: *const u8,
    pub ClientSiteName: *const u8,
}

#[cfg(target_os = "windows")]
#[link(name = "netapi32")]
extern "system" {
    /// Lists all servers of the given type visible in the (primary) domain.
    /// level=101 → SERVER_INFO_101 array. resume_handle=NULL is legal with
    /// MAX_PREFERRED_LENGTH (single-shot — same pattern as the BOF fixes).
    pub fn NetServerEnum(
        servername:    *const u16,
        level:         u32,
        bufptr:        *mut *mut u8,
        prefmaxlen:    u32,
        entriesread:   *mut u32,
        totalentries:  *mut u32,
        servertype:    u32,
        domain:        *const u16,
        resume_handle: *mut core::ffi::c_void,
    ) -> u32;

    pub fn NetApiBufferFree(buffer: *mut core::ffi::c_void) -> u32;

    /// Locates a DC for the primary (or given) domain. ANSI variant.
    /// Returns ERROR_SUCCESS(0) or ERROR_NO_SUCH_DOMAIN(1355) etc.
    pub fn DsGetDcNameA(
        computername: *const u8,
        domainname:   *const u8,
        domainguid:   *mut core::ffi::c_void,
        sitename:     *const u8,
        flags:        u32,
        info:         *mut *mut DOMAIN_CONTROLLER_INFOA,
    ) -> u32;
}

// ============================================================
// iphlpapi — local network evidence (ARP + TCP tables)
// ============================================================

pub const MIB_TCP_STATE_ESTAB: u32 = 5;

#[cfg(target_os = "windows")]
#[link(name = "iphlpapi")]
extern "system" {
    pub fn GetIpNetTable(
        IpNetTable: *mut core::ffi::c_void,
        pdwSize:    *mut u32,
        bOrder:     u32,
    ) -> u32;

    pub fn GetTcpTable(
        pTcpTable:   *mut core::ffi::c_void,
        pdwSize:     *mut u32,
        bOrder:      u32,
    ) -> u32;
}

// ============================================================
// shell32 — elevation check
// ============================================================

#[cfg(target_os = "windows")]
#[link(name = "shell32")]
extern "system" {
    pub fn IsUserAnAdmin() -> i32;
}

// ============================================================
// Helpers shared by both call sites
// ============================================================

/// NUL-terminated UTF-16 for LPCWSTR params.
pub fn to_wide(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(std::iter::once(0)).collect()
}

/// Read a NUL-terminated UTF-16 string from a raw pointer.
pub unsafe fn from_wide(p: *const u16) -> String {
    if p.is_null() {
        return String::new();
    }
    let mut len = 0usize;
    while *p.add(len) != 0 {
        len += 1;
    }
    String::from_utf16_lossy(std::slice::from_raw_parts(p, len))
}

/// Read a NUL-terminated ANSI string from a raw pointer.
pub unsafe fn from_ansi(p: *const u8) -> String {
    if p.is_null() {
        return String::new();
    }
    let mut len = 0usize;
    while *p.add(len) != 0 {
        len += 1;
    }
    String::from_utf8_lossy(std::slice::from_raw_parts(p, len)).into_owned()
}

/// DWORD network-order IPv4 → dotted quad.
pub fn u32_to_ip(v: u32) -> String {
    format!("{}.{}.{}.{}", v & 0xFF, (v >> 8) & 0xFF, (v >> 16) & 0xFF, (v >> 24) & 0xFF)
}

/// Network-byte-order u16 port → host order.
pub fn ntohs(v: u16) -> u16 {
    (v >> 8) | (v << 8)
}
