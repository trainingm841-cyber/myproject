// management/ — agent configuration, entry flow, runtime profiles, logging.

pub mod config;
pub mod profile;

// ── Logging ────────────────────────────────────────────────────────────────
//
/// Agent debug log — writes to `hero_agent_debug.log` next to the executable.
///
/// BUGFIX (Bug #8 — OPSEC): release builds used to write EVERYTHING to disk:
/// chain phases, config validation, session creation, TLS setup, HTTP requests,
/// responses, errors — a complete forensic timeline of the agent's behaviour.
/// The log file was a treasure trove for IR / blue teams.
///
/// FIX: debug_log() and write_log() are now DEBUG-BUILD ONLY. A `cargo build
/// --release` produces zero log files — the log file is never created, never
/// opened, never written. Verified: release binary contains no fs::OpenOptions
/// references in the logging path.
///
/// Dev builds (`cargo build`) still get the full unified log so operators can
/// diagnose connection issues during development.
pub fn debug_log(msg: &str) {
    #[cfg(debug_assertions)]
    write_log("hero_agent_debug.log", msg);
}

/// File logger — writes timestamped lines to a log file next to the exe.
/// Public so chain.rs can call it directly for unified logging.
///
/// Same OPSEC gate as debug_log (Bug #8): no-op in release builds.
pub fn write_log(filename: &str, msg: &str) {
    #[cfg(debug_assertions)]
    {
        use std::io::Write;
        let log_path = std::env::current_exe()
            .ok()
            .and_then(|p| {
                let dir = p.parent()?.to_path_buf();
                Some(dir.join(filename))
            });
        if let Some(path) = log_path {
            if let Ok(mut f) = std::fs::OpenOptions::new()
                .create(true)
                .append(true)
                .open(&path)
            {
                let timestamp = std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .map(|d| d.as_secs())
                    .unwrap_or(0);
                let _ = writeln!(f, "[{}] {}", timestamp, msg);
            }
        }
    }
    #[cfg(not(debug_assertions))]
    {
        // Release build: silent. The compiler elides the entire call body,
        // the log file is never opened. `filename` and `msg` are unused.
        let _ = (filename, msg);
    }
}
