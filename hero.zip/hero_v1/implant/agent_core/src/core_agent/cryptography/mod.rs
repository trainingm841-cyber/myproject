// cryptography/ — session cryptography.
//
// crypto.rs: AES-256-GCM authenticated encryption + HMAC-SHA256 key
// derivation (HKDF-style) for per-session traffic keys.

pub mod crypto;
