/* hero.c - phases 1-5 (locate, parse, decode, resolve, report) + ntdll_locate
 * Pure C99, zero imports beyond CRT. ntdll found via PEB walk (gs:[0x60]).
 *
 * BUILD COMPAT (GCC 14+): explicit #include <stdlib.h> for qsort().
 * Older GCC treated implicit-function-declaration as a warning; GCC 14
 * promotes it to an error (-Werror=implicit-function-declaration by
 * default). Same dense single-line style preserved — only the missing
 * header is added. Code behavior is unchanged.
 */
#include "hero_peb_walking.h"
#include <stdlib.h>   /* qsort(), size_t — required by GCC 14+ (was implicit) */
#include <string.h>   /* memcpy(), strcmp(), memset() — defensive */

/* ---- phase 1: PEB walk (x64) ---- */
typedef struct { void* flink; void* blink; } HsLE;
typedef struct { uint16_t len, maxLen; uint16_t* buf; } HsUS;
typedef struct { HsLE inLoad, inMem, inInit; void* dllBase; void* entry;
    uint32_t sizeOfImage, pad; HsUS full, base; } HsLdr;

#if defined(HS_SELFTEST)
void* hs_test_ldr=0; int hs_test_dbg=-1;
static void* hs_peb(void){return 0;}
static void* hs_ldr(void){return hs_test_ldr;}
int hs_peb_being_debugged(void){return hs_test_dbg;}
#elif defined(_WIN64) && defined(__GNUC__)
static void* hs_peb(void){void*p;__asm__ volatile("movq %%gs:0x60,%0":"=r"(p));return p;}
static void* hs_ldr(void){uint8_t*p=hs_peb();return p?*(void**)(p+0x18):0;}
int hs_peb_being_debugged(void){uint8_t*p=hs_peb();return p?(int)p[0x02]:-1;}
#elif defined(_WIN64) && defined(_MSC_VER)
#include <intrin.h>
static void* hs_peb(void){return(void*)__readgsqword(0x60);}
static void* hs_ldr(void){uint8_t*p=hs_peb();return p?*(void**)(p+0x18):0;}
int hs_peb_being_debugged(void){uint8_t*p=hs_peb();return p?(int)p[0x02]:-1;}
#else
static void* hs_peb(void){return 0;} static void* hs_ldr(void){return 0;}
int hs_peb_being_debugged(void){return -1;}
#endif

static int hs_wieq(const uint16_t* w, uint32_t n, const char* s){
    uint32_t i; if(!w||!n||!s) return 0;
    for(i=0;i<n;i++){char a,b; if(w[i]>127) return 0; a=(char)w[i];
        if(a>='A'&&a<='Z') a+=32; b=s[i]; if(b==0) return 0;
        if(b>='A'&&b<='Z') b+=32; if(a!=b) return 0;}
    return s[n]==0;
}

int hs_find_ntdll_modules(HsModule* out, int max){
    uint8_t* ldr=(uint8_t*)hs_ldr(); HsLE *head, *cur; int found=0, steps=0;
    if(!ldr) return -1;
    head=(HsLE*)(ldr+0x10); cur=head->flink;
    while(cur && cur!=head && steps<256){
        HsLdr* e=(HsLdr*)((uint8_t*)cur-offsetof(HsLdr,inLoad));
        steps++;
        if(hs_wieq(e->base.buf, e->base.len/2, "ntdll.dll")){
            if(out && found<max){HsModule* m=&out[found]; uint32_t i,n=e->base.len/2;
                m->base=(uint8_t*)e->dllBase; m->size=e->sizeOfImage;
                if(n>63) n=63; for(i=0;i<n;i++) m->baseName[i]=(e->base.buf[i]<=127)?(char)e->base.buf[i]:'?';
                m->baseName[n]=0;} found++;}
        cur=cur->flink;}
    return found;
}

/* ---- phase 2: PE export walk + RVA sort ---- */
int hs_parse_exports(const uint8_t* base, uint32_t isz, HsFn* out, int max, HsExportStats* st){
    uint32_t eLfanew, expRva, numF, numN, rvaF, rvaN, rvaO, i, k=0;
    const uint8_t *nt, *opt, *exp, *funcs, *names, *ords;
    if(st){st->totalExports=st->totalNames=st->syscallNames=0;}
    if(!base||isz<0x40) return -1;
    if(hs_rd16(base)!=0x5A4D) return -1;
    eLfanew=hs_rd32(base+0x3C); if(!eLfanew||(uint64_t)eLfanew+264>isz) return -1;
    nt=base+eLfanew; if(hs_rd32(nt)!=0x4550) return -1;
    if(hs_rd16(nt+4)!=0x8664) return -2;
    opt=nt+24; if(hs_rd16(opt)!=0x20B) return -2;
    expRva=hs_rd32(opt+112); if(!expRva) return 0;
    if((uint64_t)expRva+40>isz) return -3;
    exp=base+expRva; numF=hs_rd32(exp+0x14); numN=hs_rd32(exp+0x18);
    rvaF=hs_rd32(exp+0x1C); rvaN=hs_rd32(exp+0x20); rvaO=hs_rd32(exp+0x24);
    if(st){st->totalExports=numF; st->totalNames=numN;}
    if(numF>0x100000||numN>0x100000) return -3;
    if((uint64_t)rvaF+(uint64_t)numF*4>isz) return -3;
    if((uint64_t)rvaN+(uint64_t)numN*4>isz) return -3;
    if((uint64_t)rvaO+(uint64_t)numN*2>isz) return -3;
    funcs=base+rvaF; names=base+rvaN; ords=base+rvaO;
    for(i=0;i<numN;i++){
        uint32_t nameRva=hs_rd32(names+i*4), fnRva, nl=0; uint16_t ordIdx;
        const char* nm; if((uint64_t)nameRva+3>=isz) continue;
        nm=(const char*)(base+nameRva); if(!hs_name_is_syscall(nm)) continue;
        while(nl<HS_NAME_MAX-1 && (uint64_t)nameRva+nl<isz && nm[nl]) nl++;
        if(!nl) continue;
        ordIdx=hs_rd16(ords+(uint64_t)i*2); if((uint32_t)ordIdx>=numF) continue;
        fnRva=hs_rd32(funcs+(uint64_t)ordIdx*4); if(fnRva>=isz) continue;
        if(out && k<max){HsFn* f=&out[k]; uint32_t c=(nl>HS_NAME_MAX-1)?(HS_NAME_MAX-1):nl;
            memcpy(f->name,nm,c); f->name[c]=0; f->rva=fnRva; f->ordinal=(int)ordIdx;
            f->ssn=-1; f->status=0; f->source=0; f->hooksig=0;} k++;
        if(out && k>=max) break;
    }
    if(st) st->syscallNames=k; return k;
}
static int hs_cmp_rva(const void* a, const void* b){
    const HsFn* x=a,* y=b; if(x->rva!=y->rva) return x->rva<y->rva?-1:1;
    return strcmp(x->name,y->name);
}
void hs_sort_by_rva(HsFn* fns, int n){ if(fns&&n>1) qsort(fns,(size_t)n,sizeof(HsFn),hs_cmp_rva); }

/* ---- phase 3: stub decode + hook detection ---- */
enum { HS_SIG_JMP=1, HS_SIG_MOVRAX=2, HS_SIG_RIPREL=3, HS_SIG_SHORT=4, HS_SIG_RET=5, HS_SIG_INT2E=6, HS_SIG_INT3=7 };
const char* hs_hooksig_name(uint8_t s){
    switch(s){case 1:return"jmp rel32(E9)";case 2:return"mov rax,imm64(48B8)";case 3:return"jmp[rip+](FF25)";
    case 4:return"jmp short(EB)";case 5:return"ret(C3)";case 6:return"int2e(CD2E)";case 7:return"int3(CC)";default:return"?";}
}
int hs_stub_clean_ssn(const uint8_t* p, uint32_t avail, int32_t* out){
    int32_t s; if(!p||avail<HS_STUB_LEN) return 0;
    if(p[0]!=0x4C||p[1]!=0x8B||p[2]!=0xD1||p[3]!=0xB8) return 0;
    s=(int32_t)hs_rd32(p+4); if(s<0||s>=HS_SSN_MAX) return 0;
    if(out) *out=s; return 1;
}
static int hs_classify(const uint8_t* p, uint32_t av, int32_t* ssn, uint8_t* sig){
    if(av>=1&&p[0]==0xCC){*sig=7;return HS_STUB_HOOKED;}
    if(av>=1&&p[0]==0xE9){*sig=1;return HS_STUB_HOOKED;}
    if(av>=12&&p[0]==0x48&&p[1]==0xB8&&p[10]==0xFF&&(p[11]==0xE0||p[11]==0xD0)){*sig=2;return HS_STUB_HOOKED;}
    if(av>=2&&p[0]==0xFF&&p[1]==0x25){*sig=3;return HS_STUB_HOOKED;}
    if(av>=1&&p[0]==0xEB){*sig=4;return HS_STUB_HOOKED;}
    if(av>=1&&p[0]==0xC3){*sig=5;return HS_STUB_HOOKED;}
    if(av>=2&&p[0]==0xCD&&p[1]==0x2E){*sig=6;return HS_STUB_HOOKED;}
    if(hs_stub_clean_ssn(p,av,ssn)){*sig=0;return HS_STUB_CLEAN;}
    *sig=0; return HS_STUB_NOT_A_STUB;
}
static int hs_follow_thunk(const uint8_t* b, uint32_t isz, uint32_t rva0, int32_t* ssn, uint32_t* tgt){
    uint32_t cur=rva0; int hop;
    for(hop=0;hop<4;hop++){
        int64_t t; int32_t rel, s=-1;
        if((uint64_t)cur+5>(uint64_t)isz) return 0; if(b[cur]!=0xE9) return 0;
        rel=(int32_t)hs_rd32(b+cur+1); t=(int64_t)cur+5+(int64_t)rel;
        if(t<0||t+1>(int64_t)isz) return 0; cur=(uint32_t)t;
        if(hs_stub_clean_ssn(b+cur,isz-cur,&s)){if(ssn)*ssn=s; if(tgt)*tgt=cur; return 1;}
        if(b[cur]!=0xE9){if(tgt)*tgt=cur; return 2;}
    }
    if(tgt)*tgt=cur; return 2;
}
int hs_decode_stubs(HsFn* fns, int n, const uint8_t* base, uint32_t isz, HsStubStats* st){
    int i; HsStubStats s={0,0,0,0,0};
    for(i=0;i<n;i++){HsFn* f=&fns[i]; const uint8_t* p; uint32_t av; int32_t ssn=-1; uint8_t sig=0; int cls;
        f->thunkTarget=0;
        if(!base||(uint64_t)f->rva+HS_STUB_LEN>isz){f->status=HS_STUB_NOT_A_STUB;f->ssn=-1;f->hooksig=0;s.notStub++;continue;}
        p=base+f->rva; av=isz-f->rva; if(av>HS_STUB_LEN) av=HS_STUB_LEN;
        cls=hs_classify(p,av,&ssn,&sig);
        if(cls==HS_STUB_HOOKED&&sig==1){
            int32_t ts=-1; uint32_t tg=0; int tk=hs_follow_thunk(base,isz,f->rva,&ts,&tg);
            if(tk!=0){f->status=HS_STUB_THUNK;f->hooksig=sig;f->thunkTarget=tg;
                f->ssn=(tk==1)?ts:-1;s.thunk++;continue;}}
        f->status=(uint8_t)cls; f->hooksig=sig;
        if(cls==HS_STUB_CLEAN){f->ssn=ssn;f->source=HS_SRC_DIRECT;s.clean++;if((uint32_t)ssn>s.maxSsn)s.maxSsn=ssn;}
        else{f->ssn=-1; if(cls==HS_STUB_HOOKED) s.hooked++; else s.notStub++;}
    }
    if(st) *st=s; return (int)s.clean;
}

/* ---- phase 4: HERO resolution pipeline ---- */
static int hs_find_zw(const HsFn* fns, int n, const char* ntName){
    char twin[HS_NAME_MAX]; int i, j=2; twin[0]='Z'; twin[1]='w';
    while(ntName[j]&&j<HS_NAME_MAX-1){twin[j]=ntName[j]; j++;} twin[j]=0;
    for(i=0;i<n;i++) if(fns[i].status==HS_STUB_CLEAN&&fns[i].ssn>=0&&!strcmp(fns[i].name,twin)) return i;
    return -1;
}
int hs_resolve_all(HsFn* fns, int n, const uint8_t* base, uint32_t isz, HsResolveStats* st){
    HsResolveStats r={0}; int i, anchor=-1;
    if(st) memset(st,0,sizeof *st);
    if(!fns||n<=0) return 0;
    for(i=0;i<n;i++) if(fns[i].status==HS_STUB_CLEAN&&fns[i].ssn>=0&&hs_name_is_nt(fns[i].name)){anchor=i;break;}
    r.anchorIndex=anchor;
    if(anchor>=0){r.anchorRva=fns[anchor].rva; r.anchorSsn=fns[anchor].ssn;
        for(i=0;i<n;i++){long long d; int32_t p;
            if(i==anchor||fns[i].status!=HS_STUB_CLEAN||!hs_name_is_nt(fns[i].name)) continue;
            d=(long long)fns[i].rva-(long long)fns[anchor].rva;
            if(d%HS_STUB_LEN!=0){r.strideSkipped++;continue;}
            p=fns[anchor].ssn+(int32_t)(d/HS_STUB_LEN);
            if(p>=0&&p<HS_SSN_MAX&&p==fns[i].ssn) r.confirmations++; else r.mismatches++;}
        r.calibValid=(r.confirmations>=2&&r.mismatches==0)?1:0;}
    for(i=0;i<n;i++) if(fns[i].status==HS_STUB_THUNK&&fns[i].ssn>=0) fns[i].source=HS_SRC_THUNK;
    /* halo probe (local, wedge-immune) */
    for(i=0;i<n;i++){HsFn* f=&fns[i]; int d;
        if(f->ssn>=0||f->status!=HS_STUB_HOOKED||!base) continue;
        for(d=1;d<=32&&f->ssn<0;d++){
            unsigned long long up=(unsigned long long)f->rva+(unsigned long long)d*HS_STUB_LEN;
            unsigned long long dn; int32_t s2,t;
            if(up+HS_STUB_LEN<=isz&&hs_stub_clean_ssn(base+up,HS_STUB_LEN,&s2)){t=s2-d;if(t>=0&&t<HS_SSN_MAX){f->ssn=t;f->source=HS_SRC_HALO;break;}}
            if((uint64_t)f->rva<(uint64_t)d*HS_STUB_LEN) continue;
            dn=(unsigned long long)f->rva-(unsigned long long)d*HS_STUB_LEN; s2=-1;
            if(dn+HS_STUB_LEN<=isz&&hs_stub_clean_ssn(base+dn,HS_STUB_LEN,&s2)){t=s2+d;if(t>=0&&t<HS_SSN_MAX){f->ssn=t;f->source=HS_SRC_HALO;break;}}
        }
    }
    /* global calib fallback */
    if(r.calibValid) for(i=0;i<n;i++){long long d; int32_t p;
        if(fns[i].ssn>=0||fns[i].status!=HS_STUB_HOOKED||!hs_name_is_nt(fns[i].name)) continue;
        d=(long long)fns[i].rva-(long long)fns[anchor].rva; if(d%HS_STUB_LEN!=0) continue;
        p=fns[anchor].ssn+(int32_t)(d/HS_STUB_LEN);
        if(p>=0&&p<HS_SSN_MAX){fns[i].ssn=p;fns[i].source=HS_SRC_CALIB;}}
    /* zw twin */
    for(i=0;i<n;i++){int t; if(fns[i].ssn>=0||fns[i].status!=HS_STUB_HOOKED||!hs_name_is_nt(fns[i].name)) continue;
        t=hs_find_zw(fns,n,fns[i].name); if(t>=0){fns[i].ssn=fns[t].ssn;fns[i].source=HS_SRC_ZWTWIN;}}
    /* tally */
    for(i=0;i<n;i++){if(fns[i].status==HS_STUB_THUNK&&fns[i].ssn<0){r.thunkImpl++;continue;}
        if(fns[i].ssn>=0){switch(fns[i].source){case HS_SRC_DIRECT:r.resolvedDirect++;break;case HS_SRC_CALIB:r.resolvedCalib++;
            break;case HS_SRC_HALO:r.resolvedHalo++;break;case HS_SRC_ZWTWIN:r.resolvedZw++;break;case HS_SRC_THUNK:r.resolvedThunk++;break;default:break;}}
        else r.unresolved++;}
    if(st) *st=r; return r.unresolved;
}

