/* hero.h - HERO'S GATE v3.0 (clean C2-ready build)
 * SSN resolver + forged-stub direct syscall engine for x64 Win11 24H2.
 * Pure C99, zero imports beyond CRT. All SSNs resolved at runtime.
 *
 * Phases: 1=locate ntdll  2=parse exports  3=decode stubs
 *         4=resolve SSNs   5=report        6=HERO FORGE + execute
 *         7=kernel-side hook detection (timing + TEB + KUSD + ext-SSN)
 *
 * Build:  cl /O2 *.c           (MSVC x64)
 *         gcc -O2 *.c           (MinGW x64)
 *         gcc -O2 -DHS_SELFTEST selftest.c hero.c forge.c (offline test)
 */
#ifndef HERO_H
#define HERO_H
#include <stdint.h>
#include <stddef.h>
#include <string.h>

#define HS_VERSION  "3.0"
#define HS_STUB_LEN  0x20
#define HS_SSN_MAX   0x400
#define HS_MAX_FNS   1024
#define HS_NAME_MAX  96
#define HS_NAME_COUNT 10

/* ---- SSN source classification ---- */
enum {
    HS_SRC_NONE=0, HS_SRC_DIRECT, HS_SRC_CALIB, HS_SRC_HALO, HS_SRC_ZWTWIN, HS_SRC_THUNK
};
/* ---- stub classification ---- */
enum { HS_STUB_UNVISITED=0, HS_STUB_CLEAN, HS_STUB_HOOKED, HS_STUB_NOT_A_STUB, HS_STUB_THUNK };

typedef struct {
    char     name[HS_NAME_MAX];
    uint32_t rva;
    int      ordinal;
    int32_t  ssn;            /* -1 = unknown */
    uint8_t  status;
    uint8_t  source;
    uint8_t  hooksig;
    uint32_t thunkTarget;
} HsFn;

typedef struct { uint8_t* base; uint32_t size; char baseName[64]; } HsModule;
typedef struct { uint32_t totalExports, totalNames, syscallNames; } HsExportStats;
typedef struct { uint32_t clean, hooked, notStub, thunk, maxSsn; } HsStubStats;
typedef struct {
    int calibValid, confirmations, mismatches, anchorIndex;
    uint32_t anchorRva; int32_t anchorSsn;
    int resolvedDirect, resolvedCalib, resolvedHalo, resolvedZw, resolvedThunk;
    int thunkImpl, strideSkipped, unresolved;
} HsResolveStats;

/* ---- safe readers (unaligned-safe) ---- */
static inline uint16_t hs_rd16(const uint8_t* p){ uint16_t v; memcpy(&v,p,2); return v; }
static inline uint32_t hs_rd32(const uint8_t* p){ uint32_t v; memcpy(&v,p,4); return v; }
static inline int hs_is_upper(char c){ return c>='A'&&c<='Z'; }
static inline int hs_name_is_nt(const char* n){ return n[0]=='N'&&n[1]=='t'&&hs_is_upper(n[2]); }
static inline int hs_name_is_zw(const char* n){ return n[0]=='Z'&&n[1]=='w'&&hs_is_upper(n[2]); }
static inline int hs_name_is_syscall(const char* n){ return hs_name_is_nt(n)||hs_name_is_zw(n); }
static inline const char* hs_status_str(uint8_t s){
    switch(s){case HS_STUB_CLEAN:return"CLEAN";case HS_STUB_HOOKED:return"HOOKED";
    case HS_STUB_NOT_A_STUB:return"ANOMALY";case HS_STUB_THUNK:return"THUNK";default:return"?";}
}
static inline const char* hs_source_str(uint8_t s){
    switch(s){case HS_SRC_DIRECT:return"DIRECT";case HS_SRC_CALIB:return"HERO-CALIB";
    case HS_SRC_HALO:return"HALO";case HS_SRC_ZWTWIN:return"ZW-TWIN";case HS_SRC_THUNK:return"NATIVE-THUNK";
    default:return"-";}
}

/* ---- phase function declarations ---- */
int  hs_find_ntdll_modules(HsModule* out, int max);
int  hs_peb_being_debugged(void);
int  hs_parse_exports(const uint8_t* base, uint32_t sz, HsFn* out, int max, HsExportStats* st);
void hs_sort_by_rva(HsFn* fns, int n);
int  hs_decode_stubs(HsFn* fns, int n, const uint8_t* base, uint32_t sz, HsStubStats* st);
int  hs_stub_clean_ssn(const uint8_t* p, uint32_t avail, int32_t* ssnOut);
const char* hs_hooksig_name(uint8_t sig);
int  hs_resolve_all(HsFn* fns, int n, const uint8_t* base, uint32_t sz, HsResolveStats* st);


/* ---- forge + exec ---- */
int  hs_forge_name(int idx, char out[HS_NAME_MAX]);
int  hs_forge_enc(int idx, const uint8_t** encOut);
int  hs_forge_stub(uint8_t out[HS_STUB_LEN], int32_t ssn);
int  hs_plan_classify(const HsFn* f);
int  hs_plan_lookup(const HsFn* fns, int n, const char* name);
int  hs_bootstrap_ok(const HsFn* allocFn, const HsFn* protFn);

#define HS_EXEC_MAX_APIS 10
typedef struct {
    char    name[HS_NAME_MAX]; int32_t ssn; int forged;
    int vendorStatus, heroStatus, dualMatch; char note[64];
} HsExecApi;
typedef struct {
    HsExecApi api[HS_EXEC_MAX_APIS]; int apiCount;
    int requested, forgeable, minted, skippedImpl, unresolvedSkips;
    int bootstrapCalls, measurementCalls, operationalVendorCalls;
    uintptr_t forgePageVa; int alive, canaryStatus;
    int dualTested, dualMatch, lifecycleOk, delayOk;
    int abRan, abMode, abRwVerified, abRxVerified, abWriteFault, abCopyFreed;
    int abVictimStatus, abHeroStatus, abHeroDataMatch, abRestored, abProtRestored, abReverified;
    /* phase 7 */
    int p7Ran; uint32_t p7TebW32Callout; uint8_t p7KusdByte;
    uint32_t p7KusdSig; uint64_t p7Baseline, p7Worst, p7PerSsn[HS_NAME_COUNT];
    int p7Outliers, p7ExtProbed, p7ExtAlive, p7MaxSsn, p7Kmods, p7NonMs, p7Suspect;
    char p7NonMsNames[8][64];
    int bootstrapRefused, exitReason; char lastStage[48];
} HsExecStats;
int  hs_exec_run(HsFn* fns, int n, uint8_t* base, uint32_t sz, HsExecStats* xs);
#endif
