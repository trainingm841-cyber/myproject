#if defined(_WIN32)||defined(_WIN64)
  #define PLATFORM_WINDOWS 1
#elif defined(__APPLE__)&&defined(__MACH__)
  #define PLATFORM_MACOS 1
#elif defined(__linux__)
  #define PLATFORM_LINUX 1
#else
  #error "Unsupported platform"
#endif

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>
#include <stdlib.h>
#include <time.h>

#ifdef PLATFORM_WINDOWS
  #ifndef _WIN32_WINNT
  #define _WIN32_WINNT 0x0600
  #endif
  #ifndef WINVER
  #define WINVER 0x0600
  #endif
  #include <windows.h>
  #include <tlhelp32.h>
  #include <psapi.h>
  #include <iphlpapi.h>
  #include <setupapi.h>
  #include <devguid.h>
  #include <shlobj.h>
  #ifdef __cplusplus
  extern "C" {
  #endif
  typedef LONG(WINAPI*pNtQuerySystemInformation)(ULONG,PVOID,ULONG,PULONG);
  #ifdef __cplusplus
  }
  #endif
#endif

#if defined(__GNUC__)&&(defined(__i386__)||defined(__x86_64__))
  #include <cpuid.h>
  #include <x86intrin.h>
#elif defined(_MSC_VER)
  #include <intrin.h>
#endif

#ifdef PLATFORM_LINUX
  #include <unistd.h>
  #include <fcntl.h>
  #include <sys/utsname.h>
  #include <sys/sysinfo.h>
  #include <sys/statvfs.h>
  #include <dirent.h>
#endif

#ifdef PLATFORM_MACOS
  #include <unistd.h>
  #include <sys/sysctl.h>
#endif

typedef enum { OS_UNKNOWN=0,OS_WINDOWS,OS_LINUX,OS_MACOS } OsType;
#define HAS_CPUID 1

static int g_vmware_tools_running      = 0;
static int g_vbox_guest_additions_running = 0;
static int g_hypervisor_vendor_is_ms   = 0;
static char g_hypervisor_vendor[13]    = {0};
static int g_strong_guest_signal       = 0;
static int g_weak_host_or_guest_signals= 0;

static int file_read(const char*path,char*buf,int sz){
#ifdef PLATFORM_WINDOWS
    HANDLE h=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(h==INVALID_HANDLE_VALUE)return 0;
    DWORD got=0; BOOL ok=ReadFile(h,buf,sz-1,&got,NULL); CloseHandle(h);
    if(!ok)return 0; buf[got]=0; return 1;
#else
    int fd=open(path,O_RDONLY); if(fd<0)return 0;
    ssize_t n=read(fd,buf,sz-1); close(fd);
    if(n<=0)return 0; buf[n]=0; return 1;
#endif
}

static int file_contains(const char*path,const char*needle){
    char buf[4096];
    return file_read(path,buf,sizeof(buf))&&strstr(buf,needle)!=NULL;
}

static void lower_inplace(char*s){ for(;*s;s++)*s=(char)tolower((unsigned char)*s); }

static OsType detect_runtime_os(void){
#ifdef PLATFORM_WINDOWS
    return OS_WINDOWS;
#elif defined(PLATFORM_LINUX)
    return OS_LINUX;
#elif defined(PLATFORM_MACOS)
    return OS_MACOS;
#else
    return OS_UNKNOWN;
#endif
}

static void read_hypervisor_vendor(char*out,int out_sz){
    if(!out||out_sz<13)return;
    out[0]=0;
    int c[4]={0};
#ifdef __GNUC__
    __cpuid(0x40000000,c[0],c[1],c[2],c[3]);
#else
    __cpuid(c,0x40000000);
#endif
    memcpy(out+0,&c[1],4); memcpy(out+4,&c[2],4); memcpy(out+8,&c[3],4); out[12]=0;
}

static void preflight_scan(void){
    g_vmware_tools_running=g_vbox_guest_additions_running=0;
    g_hypervisor_vendor_is_ms=0; g_hypervisor_vendor[0]=0;
    g_strong_guest_signal=g_weak_host_or_guest_signals=0;

    int c[4]={0};
#ifdef __GNUC__
    __cpuid(1,c[0],c[1],c[2],c[3]);
#else
    __cpuid(c,1);
#endif
    if(c[2]&(1<<31)){
        read_hypervisor_vendor(g_hypervisor_vendor,sizeof(g_hypervisor_vendor));
        if(strcmp(g_hypervisor_vendor,"Microsoft Hv")==0)g_hypervisor_vendor_is_ms=1;
    }

#ifdef PLATFORM_WINDOWS
    HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
    if(snap!=INVALID_HANDLE_VALUE){
        PROCESSENTRY32W pe={0}; pe.dwSize=sizeof(pe);
        if(Process32FirstW(snap,&pe)){
            do {
                char name[260]={0};
                WideCharToMultiByte(CP_ACP,0,pe.szExeFile,-1,name,260,NULL,NULL);
                lower_inplace(name);
                if(!g_vmware_tools_running&&_stricmp(name,"vmtoolsd.exe")==0)
                    g_vmware_tools_running=1;
                if(!g_vbox_guest_additions_running&&
                   (_stricmp(name,"vboxservice.exe")==0||
                    _stricmp(name,"vboxtray.exe")==0||
                    _stricmp(name,"vboxcontrol.exe")==0))
                    g_vbox_guest_additions_running=1;
            } while(Process32NextW(snap,&pe));
        }
        CloseHandle(snap);
    }
#endif
}

static int check_cpuid_hypervisor_bit(void){
    int c[4]={0};
#ifdef __GNUC__
    __cpuid(1,c[0],c[1],c[2],c[3]);
#else
    __cpuid(c,1);
#endif
    if(!(c[2]&(1<<31)))return 0;

    char hv[13]={0};
    read_hypervisor_vendor(hv,sizeof(hv));

    static const char*strong[]={"VMwareVMware","VBoxVBoxVBox","KVMKVMKVM","XenVMMXenVMM","TCGTCGTCGTCG",NULL};
    for(int i=0;strong[i];i++){
        if(strstr(hv,strong[i])){ g_strong_guest_signal=1; return 3; }
    }
    if(strstr(hv,"PrllHypervisor")||strstr(hv,"Parallels")){ g_strong_guest_signal=1; return 3; }
    if(strcmp(hv,"Microsoft Hv")==0){
        g_hypervisor_vendor_is_ms=1;
        if(g_vmware_tools_running||g_vbox_guest_additions_running){ g_strong_guest_signal=1; return 3; }
        g_weak_host_or_guest_signals++; return 1;
    }
    g_weak_host_or_guest_signals++; return 1;
}

static int check_cpuid_vendor_string(void){
    int c[4]={0};
#ifdef __GNUC__
    __cpuid(0,c[0],c[1],c[2],c[3]);
#else
    __cpuid(c,0);
#endif
    char vendor[13]={0};
    memcpy(vendor+0,&c[1],4); memcpy(vendor+4,&c[3],4); memcpy(vendor+8,&c[2],4);

    int known=(strcmp(vendor,"GenuineIntel")==0||strcmp(vendor,"AuthenticAMD")==0);
    int c2[4]={0};
#ifdef __GNUC__
    __cpuid(1,c2[0],c2[1],c2[2],c2[3]);
#else
    __cpuid(c2,1);
#endif
    if(!(c2[2]&(1<<31)))return 0;

    char hv[13]={0};
    read_hypervisor_vendor(hv,sizeof(hv));

    static const char*strong[]={"VMwareVMware","VBoxVBoxVBox","KVMKVMKVM","XenVMMXenVMM","TCGTCGTCGTCG",NULL};
    for(int i=0;strong[i];i++){
        if(strstr(hv,strong[i])){ g_strong_guest_signal=1; return 3; }
    }
    if(strstr(hv,"PrllHypervisor")||strstr(hv,"Parallels")){ g_strong_guest_signal=1; return 3; }
    if(strcmp(hv,"Microsoft Hv")==0){
        g_hypervisor_vendor_is_ms=1;
        if(g_vmware_tools_running||g_vbox_guest_additions_running){ g_strong_guest_signal=1; return 3; }
        g_weak_host_or_guest_signals++; return 1;
    }
    g_weak_host_or_guest_signals++; return 1;
    (void)known;
}

static int check_timing(void){
    unsigned long long t1,t2;
    int info[4]; const int N=10;
    unsigned long long s[10];
    for(int i=0;i<N;i++){
        t1=__rdtsc();
#ifdef __GNUC__
        __cpuid(0,info[0],info[1],info[2],info[3]);
#else
        __cpuid(info,0);
#endif
        t2=__rdtsc(); s[i]=t2-t1;
    }
    for(int i=0;i<N-1;i++)
        for(int j=i+1;j<N;j++)
            if(s[i]>s[j]){unsigned long long t=s[i];s[i]=s[j];s[j]=t;}
    unsigned long long med=(s[N/2-1]+s[N/2])/2;
    if(med>5000)return 2;
    if(med>2000)return 1;
    return 0;
}

#ifdef PLATFORM_WINDOWS

static int check_registry(void){
    struct{const char*key;int strong;}T[]={
        {"SOFTWARE\\VMware, Inc.\\VMware Tools",1},
        {"SOFTWARE\\Oracle\\VirtualBox Guest Additions",1},
        {"HARDWARE\\ACPI\\DSDT\\VBOX__",1},
        {"HARDWARE\\ACPI\\DSDT\\VBOX",1},
        {"HARDWARE\\ACPI\\FADT\\VBOX",1},
        {"HARDWARE\\ACPI\\RSDT\\VBOX",1},
        {"SYSTEM\\CurrentControlSet\\Services\\VBoxGuest",0},
        {"SYSTEM\\CurrentControlSet\\Services\\VBoxMouse",0},
        {"SYSTEM\\CurrentControlSet\\Services\\VBoxSF",0},
        {"SYSTEM\\CurrentControlSet\\Services\\VBoxVideo",0},
        {"SYSTEM\\CurrentControlSet\\Services\\vmhgfs",0},
        {"SYSTEM\\CurrentControlSet\\Services\\vmci",0},
        {"SYSTEM\\CurrentControlSet\\Services\\vmxnet3",0},
        {"SYSTEM\\CurrentControlSet\\Services\\xennet",1},
        {"SYSTEM\\CurrentControlSet\\Services\\xenevtchn",1},
    };
    int score=0,weak=0; HKEY hk;
    for(int i=0;i<(int)(sizeof(T)/sizeof(T[0]));i++){
        if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,T[i].key,0,KEY_READ,&hk)==ERROR_SUCCESS){
            RegCloseKey(hk);
            int s=T[i].strong||(g_vmware_tools_running||g_vbox_guest_additions_running);
            if(s){ score+=3; g_strong_guest_signal=1; }
            else { weak+=1; g_weak_host_or_guest_signals++; }
            if(score>=4)break;
        }
    }
    if(weak>2)weak=2; score+=weak;

    char buf[512]={0}; DWORD sz=sizeof(buf);
    if(RegGetValueA(HKEY_LOCAL_MACHINE,"HARDWARE\\DESCRIPTION\\System",
                    "SystemBiosVersion",RRF_RT_REG_SZ,NULL,buf,&sz)==ERROR_SUCCESS){
        lower_inplace(buf);
        if(strstr(buf,"vbox")||strstr(buf,"virtualbox")){ score+=3; g_strong_guest_signal=1; }
        if(strstr(buf,"vmware")){ score+=3; g_strong_guest_signal=1; }
        if(strstr(buf,"qemu")){ score+=3; g_strong_guest_signal=1; }
    }
    return score>4?4:score;
}

static int check_processes(void){
    static const char*GT[]={
        "vmtoolsd.exe","vmwaretray.exe","vmwareuser.exe","vmwaremount.exe",
        "vboxservice.exe","vboxtray.exe","vboxcontrol.exe",
        "xenservice.exe","vgauthservice.exe","vgaurd.exe",
        "prl_tools_service.exe","prl_cc.exe","qemu-ga.exe","spice-vdagent.exe",NULL
    };
    static const char*AT[]={
        "wireshark.exe","procmon.exe","procmon64.exe","procexp.exe","procexp64.exe",
        "x64dbg.exe","x32dbg.exe","ollydbg.exe","ida.exe","ida64.exe",
        "idaq.exe","idaq64.exe","windbg.exe","cdb.exe","dbgview.exe",
        "fiddler.exe","httpdebugger.exe","charles.exe",
        "pestudio.exe","die.exe","dnspy.exe","de4dot.exe","ilspy.exe","dotpeek.exe",
        "processhacker.exe","autoruns.exe",
        "sandboxiedcomlaunch.exe","sandboxierpcss.exe","sbiectrl.exe",
        "sysmon.exe","sysmon64.exe","tcpdump.exe","dumpcap.exe","netmon.exe",
        "frida.exe","frida-server.exe","frida-trace.exe",NULL
    };
    HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
    if(snap==INVALID_HANDLE_VALUE)return 0;
    PROCESSENTRY32W pe={0}; pe.dwSize=sizeof(pe);
    int score=0;
    if(Process32FirstW(snap,&pe)){
        do {
            char name[260]={0};
            WideCharToMultiByte(CP_ACP,0,pe.szExeFile,-1,name,260,NULL,NULL);
            lower_inplace(name);
            int hit=0;
            for(int i=0;GT[i];i++){
                if(_stricmp(name,GT[i])==0){
                    g_strong_guest_signal=1; score+=3; hit=1;
                    if(_stricmp(name,"vmtoolsd.exe")==0)g_vmware_tools_running=1;
                    if(_stricmp(name,"vboxservice.exe")==0||
                       _stricmp(name,"vboxtray.exe")==0||
                       _stricmp(name,"vboxcontrol.exe")==0)g_vbox_guest_additions_running=1;
                    break;
                }
            }
            if(!hit)for(int i=0;AT[i];i++){
                if(_stricmp(name,AT[i])==0){ score+=1; break; }
            }
            if(score>=6)break;
        } while(Process32NextW(snap,&pe));
    }
    CloseHandle(snap);
    return score>6?6:score;
}

static int check_mac(void){
    static const unsigned char oui[12][3]={
        {0x00,0x05,0x69},{0x00,0x0C,0x29},{0x00,0x50,0x56},
        {0x00,0x1C,0x42},{0x00,0x15,0x5D},{0x08,0x00,0x27},
        {0x00,0x16,0x3E},{0x52,0x54,0x00},{0x00,0x24,0x9B},
        {0x00,0x21,0xF6},{0xF0,0x1F,0xAF},{0x00,0x03,0xFF},
    };
    static const char*vkw[]={
        "vmware","virtualbox","virtual","vmnet","host-only","hyper-v",
        "vethernet","tap-","tap-win","tunnel","pseudo","teredo",
        "isatap","loopback","wan miniport","ras","nvidia nforce",NULL
    };
    PIP_ADAPTER_INFO adp=NULL; ULONG bsz=0;
    if(GetAdaptersInfo(NULL,&bsz)!=ERROR_BUFFER_OVERFLOW)return 0;
    adp=(PIP_ADAPTER_INFO)malloc(bsz);
    if(!adp)return 0;
    if(GetAdaptersInfo(adp,&bsz)!=ERROR_SUCCESS){free(adp);return 0;}

    int score=0;
    for(PIP_ADAPTER_INFO p=adp;p;p=p->Next){
        char desc[256]={0};
        strncpy(desc,p->Description,sizeof(desc)-1);
        lower_inplace(desc);
        int virt=0;
        for(int k=0;vkw[k];k++) if(strstr(desc,vkw[k])){ virt=1; break; }
        if(virt){
            if(g_vmware_tools_running||g_vbox_guest_additions_running){
                g_weak_host_or_guest_signals++;
                if(score<1)score=1;
            }
            continue;
        }
        if(p->AddressLength>=3){
            for(int i=0;i<12;i++){
                if(memcmp(p->Address,oui[i],3)==0){ g_strong_guest_signal=1; score=3; break; }
            }
        }
        if(score>=3)break;
    }
    free(adp);
    return score;
}

static int check_disk_size(void){
    ULARGE_INTEGER fr,tot;
    if(!GetDiskFreeSpaceExA("C:\\",&fr,&tot,NULL))return 0;
    unsigned long long gb=tot.QuadPart/(1024ULL*1024ULL*1024ULL);
    if(gb<60)return 2;
    if(gb<100)return 1;
    return 0;
}

static int check_screen_resolution(void){
    int sx=GetSystemMetrics(SM_CXSCREEN),sy=GetSystemMetrics(SM_CYSCREEN);
    int score=(sx<=800&&sy<=600)?2:(sx<=1024&&sy<=768)?1:0;
    DISPLAY_DEVICEA dd={0}; dd.cb=sizeof(dd);
    for(DWORD i=0;EnumDisplayDevicesA(NULL,i,&dd,0);i++){
        char n[128]; strncpy(n,dd.DeviceString,sizeof(n)-1); n[127]=0;
        lower_inplace(n);
        if(strstr(n,"vmware")||strstr(n,"virtual")||strstr(n,"vbox")||strstr(n,"virtualbox")||strstr(n,"qemu"))
            { g_strong_guest_signal=1; score=(score>3?score:3); }
        else if(strstr(n,"microsoft basic display"))
            { g_weak_host_or_guest_signals++; score=(score>1?score:1); }
    }
    return score;
}

static int check_uptime(void){
    // OPSEC FIX (audit I-M4): GetTickCount() rolls over at ~49.7 days
    // (DWORD = 32-bit unsigned). On long-uptime real hosts that have been
    // running >50 days, this would wrap to a small number and trigger a
    // false-positive VM verdict. Use GetTickCount64() (ULONGLONG, Win Vista+)
    // which has a rollover window of ~584 million years — effectively never.
    ULONGLONG us64 = GetTickCount64() / 1000;
    int score = (us64 < 300) ? 2 : (us64 < 1800) ? 1 : 0;
    LASTINPUTINFO lii = {0}; lii.cbSize = sizeof(lii);
    if (GetLastInputInfo(&lii)) {
        // dwTime in LASTINPUTINFO is a DWORD (32-bit) — same rollover issue,
        // but we can compute the delta using GetTickCount64 and a static
        // wrap-detection: if 64-bit tick < 32-bit dwTime, the 32-bit field
        // has wrapped. Fall back to no idle check in that edge case.
        ULONGLONG now64 = GetTickCount64();
        if (now64 >= lii.dwTime) {
            ULONGLONG im64 = (now64 - lii.dwTime) / 1000;
            if (im64 > 600) score += 2; else if (im64 > 300) score += 1;
        }
        // else: LASTINPUTINFO dwTime has wrapped — skip idle check this cycle
    }
    return score > 3 ? 3 : score;
}

static int check_username_computername(void){
    char u[256]={0},c[256]={0};
    DWORD us=sizeof(u),cs=sizeof(c);
    GetUserNameA(u,&us); GetComputerNameA(c,&cs);
    lower_inplace(u); lower_inplace(c);
    // OPSEC FIX (audit I-M5):
    //   OLD: substring match (strstr) on "user", "test", "john", "desktop"
    //        matched legit usernames like "user1", "john_doe", "DesktopSupport".
    //        Real corp users with these substrings got false-positive VM flag.
    //   NEW: exact match only — username/computername must EQUAL one of the
    //        bad names. Sandbox defaults ("sandbox", "malware", "cuckoo",
    //        "REMnUX", "SIFT") match exactly; real corp usernames rarely do.
    //        "john" alone matched "john.smith" — now requires username == "john".
    //        This is the same approach used by modern malware like RedLine /
    //        Raccoon Stealer — exact match avoids the false-positive tax.
    static const char* bad_exact[] = {
        "sandbox","malware","malwaretest","sample","virus",
        "cuckoo","analyst","remnux","sift","maltest",
        "snapshot","vbox","vmware","qemu","sandboxie",
        NULL
    };
    int score = 0;
    for (int i = 0; bad_exact[i] && score == 0; i++) {
        if (strcmp(u, bad_exact[i]) == 0) score += 2;
    }
    for (int i = 0; bad_exact[i] && score < 4; i++) {
        if (strcmp(c, bad_exact[i]) == 0) score += 2;
    }
    return score > 4 ? 4 : score;
}

static int check_smbios(void){
    DWORD size=GetSystemFirmwareTable('RSMB',0,NULL,0);
    if(size==0||size>1024*1024)return 0;
    BYTE*buf=(BYTE*)malloc(size); if(!buf)return 0;
    DWORD got=GetSystemFirmwareTable('RSMB',0,buf,size);
    int score=0;
    if(got>0){
        char tmp[65536];
        DWORD cp=got<sizeof(tmp)-1?got:(DWORD)(sizeof(tmp)-1);
        memcpy(tmp,buf,cp); tmp[cp]=0; lower_inplace(tmp);
        if(strstr(tmp,"vbox")||strstr(tmp,"virtualbox")){ score+=3; g_strong_guest_signal=1; }
        if(strstr(tmp,"vmware")){ score+=3; g_strong_guest_signal=1; }
        if(strstr(tmp,"qemu")){ score+=3; g_strong_guest_signal=1; }
        if(strstr(tmp,"xen")){ score+=2; g_strong_guest_signal=1; }
        if(strstr(tmp,"innotek")){ score+=3; g_strong_guest_signal=1; }
        if(strstr(tmp,"hyper-v")){ score+=2; g_strong_guest_signal=1; }
        if(strstr(tmp,"parallels")){ score+=3; g_strong_guest_signal=1; }
    }
    free(buf);
    return score>4?4:score;
}

static int check_pci_devices(void){
    HDEVINFO hd=SetupDiGetClassDevsA(NULL,"PCI",NULL,DIGCF_PRESENT|DIGCF_ALLCLASSES);
    if(hd==INVALID_HANDLE_VALUE)return 0;
    SP_DEVINFO_DATA di; di.cbSize=sizeof(di);
    int score=0;
    for(DWORD i=0;SetupDiEnumDeviceInfo(hd,i,&di);i++){
        char buf[256]={0};
        if(SetupDiGetDeviceRegistryPropertyA(hd,&di,SPDRP_HARDWAREID,NULL,(PBYTE)buf,sizeof(buf),NULL)){
            lower_inplace(buf);
            if(strstr(buf,"ven_15ad")){ score+=3; g_strong_guest_signal=1; }
            else if(strstr(buf,"ven_80ee")){ score+=3; g_strong_guest_signal=1; }
            else if(strstr(buf,"ven_1234")){ score+=3; g_strong_guest_signal=1; }
            else if(strstr(buf,"ven_1af4")){ score+=2; g_strong_guest_signal=1; }
            else if(strstr(buf,"ven_1b36")){ score+=2; g_strong_guest_signal=1; }
            else if(strstr(buf,"ven_5853")){ score+=2; g_strong_guest_signal=1; }
            if(score>=4)break;
        }
    }
    SetupDiDestroyDeviceInfoList(hd);
    return score;
}

static int check_loaded_drivers(void){
    HMODULE ntdll=GetModuleHandleA("ntdll.dll"); if(!ntdll)return 0;
    pNtQuerySystemInformation NtQSI=(pNtQuerySystemInformation)GetProcAddress(ntdll,"NtQuerySystemInformation");
    if(!NtQSI)return 0;
    ULONG needed=0;
    if(NtQSI(11,NULL,0,&needed)!=0xC0000004L||needed==0)return 0;
    void*buf=malloc(needed); if(!buf)return 0;
    int score=0;
    if(NtQSI(11,buf,needed,&needed)>=0){
        ULONG cnt=*(ULONG*)buf;
        char*base=(char*)buf; ULONG off=sizeof(ULONG);
        for(ULONG i=0;i<cnt&&off+256<needed;i++){
            char name[256]={0}; memcpy(name,base+off,255); lower_inplace(name);
            if(strstr(name,"vbox")||strstr(name,"virtualbox"))
                { g_strong_guest_signal=1; score+=3; break; }
            if(strstr(name,"vmhgfs")||strstr(name,"vmrawdsk"))
                { g_strong_guest_signal=1; score+=3; break; }
            if(strstr(name,"vmci")||strstr(name,"vmmouse")||
               strstr(name,"vmxnet")||strstr(name,"vmusbmouse")){
                int s=g_vmware_tools_running?3:1;
                if(s==3)g_strong_guest_signal=1; else g_weak_host_or_guest_signals++;
                score+=s; break;
            }
            if(strstr(name,"xen")){ score+=2; break; }
            if(strstr(name,"cuckoo")){ g_strong_guest_signal=1; score+=3; break; }
            off+=256;
        }
    }
    free(buf);
    return score;
}

static int check_named_pipes(void){
    struct{const char*p;int s;}P[]={
        {"\\\\.\\VBoxMiniRdrDN",1},{"\\\\.\\VBoxGuest",1},
        {"\\\\.\\VBoxTrayIPC",1},{"\\\\.\\VBoxControl",1},
        {"\\\\.\\pipe\\VBoxTrayIPC",1},{"\\\\.\\HGFS",1},
        {"\\\\.\\pipe\\cuckoo",1},{"\\\\.\\cuckoo",1},
        {"\\\\.\\vmci",0},{"\\\\.\\pipe\\vmware-vmci",0},
        {"\\\\.\\pipe\\sysmon",0},{NULL,0}
    };
    int score=0,weak=0;
    for(int i=0;P[i].p;i++){
        HANDLE h=CreateFileA(P[i].p,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);
        if(h!=INVALID_HANDLE_VALUE){
            CloseHandle(h);
            int s=P[i].s||(g_vmware_tools_running||g_vbox_guest_additions_running);
            if(s){ score+=3; g_strong_guest_signal=1; }
            else { weak+=1; g_weak_host_or_guest_signals++; }
        }
        if(score>=4)break;
    }
    if(weak>2)weak=2; score+=weak;
    return score;
}

static int check_prefetch(void){
    char path[MAX_PATH]={0},pat[MAX_PATH+8];
    GetWindowsDirectoryA(path,MAX_PATH); strcat(path,"\\Prefetch");
    snprintf(pat,sizeof(pat),"%s\\*.pf",path);
    WIN32_FIND_DATAA fd; HANDLE h=FindFirstFileA(pat,&fd);
    if(h==INVALID_HANDLE_VALUE)return 1;
    int cnt=0; do{ cnt++; }while(FindNextFileA(h,&fd)); FindClose(h);
    if(cnt<10)return 2; if(cnt<30)return 1; return 0;
}

static int check_browser_history(void){
    int score=0; char path[MAX_PATH];
    if(SHGetFolderPathA(NULL,CSIDL_HISTORY,NULL,0,path)==S_OK){
        char pat[MAX_PATH+4]; snprintf(pat,sizeof(pat),"%s\\*.*",path);
        WIN32_FIND_DATAA fd; HANDLE h=FindFirstFileA(pat,&fd);
        if(h!=INVALID_HANDLE_VALUE){
            int cnt=0; do{ if(fd.cFileName[0]!='.')cnt++; }while(FindNextFileA(h,&fd));
            FindClose(h); if(cnt<3)score+=1;
        }
    }
    char chrome[MAX_PATH];
    if(SHGetFolderPathA(NULL,CSIDL_LOCAL_APPDATA,NULL,0,chrome)==S_OK){
        strcat(chrome,"\\Google\\Chrome\\User Data\\Default\\History");
        WIN32_FILE_ATTRIBUTE_DATA fad;
        if(GetFileAttributesExA(chrome,GetFileExInfoStandard,&fad)){
            ULARGE_INTEGER sz; sz.LowPart=fad.nFileSizeLow; sz.HighPart=fad.nFileSizeHigh;
            if(sz.QuadPart<1024)score+=1;
        }
    }
    return score;
}

static int check_hardware(void){
    int score=0;
    SYSTEM_INFO si; GetSystemInfo(&si);
    if(si.dwNumberOfProcessors<2)score+=2;
    else if(si.dwNumberOfProcessors<4)score+=1;
    MEMORYSTATUSEX mem={0}; mem.dwLength=sizeof(mem);
    if(GlobalMemoryStatusEx(&mem)){
        unsigned long long gb=mem.ullTotalPhys/(1024ULL*1024ULL*1024ULL);
        if(gb<2)score+=2; else if(gb<4)score+=1;
    }
    score+=check_smbios()+check_pci_devices()+check_loaded_drivers()
          +check_named_pipes()+check_prefetch()+check_browser_history();
    return score>4?4:score;
}

#else
static int check_registry(void){return 0;}
static int check_processes(void){return 0;}
static int check_mac(void){return 0;}
static int check_disk_size(void){return 0;}
static int check_screen_resolution(void){return 0;}
static int check_uptime(void){return 0;}
static int check_username_computername(void){return 0;}
static int check_hardware(void){return 0;}
#endif

#ifdef PLATFORM_LINUX
static int check_linux_cpuinfo(void){
    char buf[8192]; if(!file_read("/proc/cpuinfo",buf,sizeof(buf)))return 0;
    lower_inplace(buf); int s=0;
    if(strstr(buf,"vmware"))s+=2;
    if(strstr(buf,"vbox"))s+=2;
    if(strstr(buf,"virtualbox"))s+=3;
    if(strstr(buf,"qemu"))s+=3;
    if(strstr(buf,"xen"))s+=2;
    if(strstr(buf,"hypervisor"))s+=2;
    if(strstr(buf,"kvm"))s+=2;
    return s;
}

static int check_linux_dmi(void){
    static const char*P[]={
        "/sys/class/dmi/id/sys_vendor","/sys/class/dmi/id/product_name",
        "/sys/class/dmi/id/board_vendor","/sys/class/dmi/id/bios_vendor",NULL
    };
    int score=0; char buf[256];
    for(int i=0;P[i];i++){
        if(file_read(P[i],buf,sizeof(buf))){
            lower_inplace(buf);
            if(strstr(buf,"vmware")||strstr(buf,"virtualbox")||strstr(buf,"vbox"))score+=2;
            if(strstr(buf,"qemu"))score+=2;
            if(strstr(buf,"xen"))score+=2;
            if(strstr(buf,"innotek"))score+=2;
        }
    }
    if(file_contains("/proc/1/cgroup","docker"))score+=3;
    if(file_contains("/proc/1/cgroup","lxc"))score+=3;
    if(file_contains("/proc/1/environ","container"))score+=2;
    if(file_contains("/proc/1/sched","bash"))score+=1;
    return score>4?4:score;
}

static int check_linux_traced(void){
    char buf[256]; if(!file_read("/proc/self/status",buf,sizeof(buf)))return 0;
    char*p=strstr(buf,"TracerPid:"); if(!p)return 0;
    p+=10; while(*p==' '||*p=='\t')p++;
    return(*p!='0')?3:0;
}

static int check_linux_disksize(void){
    FILE*fp=fopen("/proc/partitions","r"); if(!fp)return 0;
    char line[256]; unsigned long long largest=0;
    while(fgets(line,sizeof(line),fp)){
        unsigned long long sz=0;
        if(sscanf(line,"%*d %*d %llu",&sz)==1&&sz>largest)largest=sz;
    }
    fclose(fp);
    unsigned long long gb=largest/(1024ULL*1024ULL);
    if(gb<60)return 2; if(gb<100)return 1; return 0;
}

static int check_linux_uptime(void){
    struct sysinfo si; if(sysinfo(&si)!=0)return 0;
    if(si.uptime<300)return 2; if(si.uptime<1800)return 1; return 0;
}

static int check_linux_hardware(void){
    long cpu=sysconf(_SC_NPROCESSORS_ONLN);
    unsigned long long ram=(unsigned long long)sysconf(_SC_PHYS_PAGES)*
                           (unsigned long long)sysconf(_SC_PAGE_SIZE)/(1024ULL*1024ULL);
    int s=0;
    if(cpu<2)s+=2;
    if(ram<2048)s+=2;
    return s;
}
#else
static int check_linux_cpuinfo(void){return 0;}
static int check_linux_dmi(void){return 0;}
static int check_linux_traced(void){return 0;}
static int check_linux_disksize(void){return 0;}
static int check_linux_uptime(void){return 0;}
static int check_linux_hardware(void){return 0;}
#endif

#ifdef PLATFORM_MACOS
static int sysctl_str(const char*name,char*out,size_t sz){
    size_t len=sz;
    if(sysctlbyname(name,out,&len,NULL,0)!=0)return 0;
    out[len<sz?len:sz-1]=0; return 1;
}

static int check_macos_sysctl(void){
    char buf[256]; int s=0;
    if(sysctl_str("kern.hv_vmm_present",buf,sizeof(buf))&&buf[0]=='1')s+=3;
    if(sysctl_str("hw.model",buf,sizeof(buf))){
        lower_inplace(buf);
        if(strstr(buf,"vmware")||strstr(buf,"virtualbox"))s+=3;
        if(strstr(buf,"qemu"))s+=3;
    }
    return s;
}

static int check_macos_iokit(void){
    FILE*fp=popen("ioreg -l 2>/dev/null","r"); if(!fp)return 0;
    char line[512]; int s=0;
    while(fgets(line,sizeof(line),fp)){
        lower_inplace(line);
        if(strstr(line,"vmware")||strstr(line,"virtualbox")){s+=3;break;}
        if(strstr(line,"qemu")){s+=3;break;}
    }
    pclose(fp); return s;
}

static int check_macos_disksize(void){
    struct statvfs s; if(statvfs("/",&s)!=0)return 0;
    unsigned long long gb=(unsigned long long)s.f_blocks*s.f_frsize/(1024ULL*1024ULL*1024ULL);
    if(gb<60)return 2; if(gb<100)return 1; return 0;
}

static int check_macos_uptime(void){
    struct timespec ts;
    if(clock_gettime(CLOCK_UPTIME_RAW,&ts)!=0)return 0;
    if(ts.tv_sec<300)return 2; if(ts.tv_sec<1800)return 1; return 0;
}

static int check_macos_hardware(void){
    int cpu=(int)sysconf(_SC_NPROCESSORS_ONLN);
    unsigned long long ram=(unsigned long long)sysconf(_SC_PHYS_PAGES)*
                           (unsigned long long)sysconf(_SC_PAGE_SIZE)/(1024ULL*1024ULL);
    int s=0;
    if(cpu<2)s+=2;
    if(ram<2048)s+=2;
    return s;
}
#else
static int check_macos_sysctl(void){return 0;}
static int check_macos_iokit(void){return 0;}
static int check_macos_disksize(void){return 0;}
static int check_macos_uptime(void){return 0;}
static int check_macos_hardware(void){return 0;}
#endif

int anti_vm_check(int mask){
    g_strong_guest_signal=0; g_weak_host_or_guest_signals=0;
    if(mask==0x0FFF)preflight_scan();

    int total=0; OsType os=detect_runtime_os();

#ifdef HAS_CPUID
    if(mask&0x0001)total+=check_cpuid_hypervisor_bit();
    if(mask&0x0002)total+=check_cpuid_vendor_string();
    if(mask&0x0004)total+=check_timing();
#endif

    if(os==OS_WINDOWS){
        if(mask&0x0010)total+=check_registry();
        if(mask&0x0020)total+=check_processes();
        if(mask&0x0040)total+=check_mac();
        if(mask&0x0080)total+=check_disk_size();
        if(mask&0x0100)total+=check_screen_resolution();
        if(mask&0x0200)total+=check_uptime();
        if(mask&0x0400)total+=check_username_computername();
        if(mask&0x0800)total+=check_hardware();
    } else if(os==OS_LINUX){
        if(mask&0x0010)total+=check_linux_cpuinfo();
        if(mask&0x0020)total+=check_linux_dmi();
        if(mask&0x0040)total+=check_linux_traced();
        if(mask&0x0080)total+=check_linux_disksize();
        if(mask&0x0100)total+=check_linux_uptime();
        if(mask&0x0200)total+=check_linux_hardware();
    } else if(os==OS_MACOS){
        if(mask&0x0010)total+=check_macos_sysctl();
        if(mask&0x0020)total+=check_macos_iokit();
        if(mask&0x0040)total+=check_macos_disksize();
        if(mask&0x0080)total+=check_macos_uptime();
        if(mask&0x0100)total+=check_macos_hardware();
    }

    if(g_strong_guest_signal)return 2;
    // OPSEC FIX (audit I-M3):
    //   OLD: line was `if(g_hypervisor_vendor_is_ms&&!g_vmware_tools_running&&!g_vbox_guest_additions_running)return 0;`
    //        This short-circuited ALL other VM detection signals just because
    //        the hypervisor vendor string was "Microsoft Hv". Even if uptime,
    //        MAC OUI, disk size, and other checks flagged the host as a
    //        sandbox with score >= 8, this early return 0 would override.
    //        Hyper-V-based sandboxes (Windows Sandbox, Cuckoo on Hyper-V)
    //        sailed through.
    //   NEW: drop the early return 0. "Microsoft Hv" alone is now treated
    //        as ONE weak signal (already counted via g_weak_host_or_guest_signals++).
    //        The normal scoring threshold (total >= 5 with weak signals, or
    //        total >= 8) decides. Real Hyper-V hosts still pass (low total
    //        score); sandboxes (high score from other signals) get caught.
    if((total>=5&&g_weak_host_or_guest_signals>=2)||total>=8)return 1;
    return 0;
}
