//! Direct syscalls — FFI to C implementation

#[cfg(all(target_os = "windows", feature = "cffi"))]
use std::os::raw::c_void;

#[cfg(all(target_os = "windows", feature = "cffi"))]
#[repr(C)]
pub struct SyscallNumbers {
    pub nt_allocate_virtual_memory: u32,
    pub nt_write_virtual_memory: u32,
    pub nt_read_virtual_memory: u32,
    pub nt_protect_virtual_memory: u32,
    pub nt_free_virtual_memory: u32,
    pub nt_create_thread_ex: u32,
    pub nt_create_section: u32,
    pub nt_map_view_of_section: u32,
    pub nt_unmap_view_of_section: u32,
    pub nt_close: u32,
    pub nt_query_information_process: u32,
}

#[cfg(all(target_os = "windows", feature = "cffi"))]
extern "C" {
    pub fn resolve_syscalls(nums: *mut SyscallNumbers) -> i32;
    pub fn sys_alloc_virtual_mem(
        process_handle: *mut c_void, base_addr: *mut *mut c_void,
        region_size: *mut usize, alloc_type: u32, protect: u32, syscall_num: u32,
    ) -> i32;
    pub fn sys_write_virtual_mem(
        process_handle: *mut c_void, base_addr: *mut c_void,
        buffer: *const c_void, size: usize, bytes_written: *mut usize, syscall_num: u32,
    ) -> i32;
    pub fn sys_protect_virtual_mem(
        process_handle: *mut c_void, base_addr: *mut *mut c_void,
        region_size: *mut usize, new_protect: u32, old_protect: *mut u32, syscall_num: u32,
    ) -> i32;
    pub fn sys_create_thread_ex(
        thread_handle: *mut *mut c_void, desired_access: u32,
        object_attributes: *mut c_void, process_handle: *mut c_void,
        start_routine: *mut c_void, argument: *mut c_void,
        create_flags: u32, zero_bits: usize, stack_size: usize,
        maximum_stack_size: usize, attribute_list: *mut c_void, syscall_num: u32,
    ) -> i32;
}

#[cfg(all(target_os = "windows", feature = "cffi"))]
pub fn get_syscall_numbers() -> Option<SyscallNumbers> {
    let mut nums = unsafe { std::mem::zeroed::<SyscallNumbers>() };
    let result = unsafe { resolve_syscalls(&mut nums) };
    if result == 0 { Some(nums) } else { None }
}

#[cfg(not(all(target_os = "windows", feature = "cffi")))]
pub fn get_syscall_numbers() -> Option<()> { None }
