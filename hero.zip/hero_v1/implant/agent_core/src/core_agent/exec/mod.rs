// exec/mod.rs — Module root
// Re-exports dispatcher (command engine) and sub-modules.

pub mod dispatcher;
pub mod inline_fs;
pub mod inline_network;
pub mod inline_persist;
pub mod bof_bridge;

// Re-exports for backward compatibility — other modules use exec::dispatch, exec::TaskResult
pub use dispatcher::{TaskResult, dispatch};
