// commu/ — communication transport layer.
//
// comms.rs: HTTP(S) transport with TLS CA pinning, session handshake,
// task polling (WireTask), result submission and base64 wire codec.

pub mod comms;
