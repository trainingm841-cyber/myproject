// Crate-level attributes — suppress warnings expected in C2 agent code
#![allow(non_snake_case)]
#![allow(non_camel_case_types)]
#![allow(dead_code)]
#![allow(unused_imports)]
#![allow(unused_variables)]
#![allow(clashing_extern_declarations)]

pub mod core_agent;

pub fn run() {
    core_agent::management::config::run();
}
