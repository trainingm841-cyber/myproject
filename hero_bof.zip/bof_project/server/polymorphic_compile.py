#!/usr/bin/env python3
"""
polymorphic_compile.py - Novel Polymorphic BOF Compiler

NOVEL TECHNIQUES (publicly do NOT exist in any BOF framework):

This compiler applies 5 layers of transformations to produce a
different .o file every compile, even with identical source code:

1. **Equivalence Class Mutations (ECM)**:
   Replace instructions with semantically equivalent ones:
     `xor eax, eax` ↔ `sub eax, eax` ↔ `and eax, 0`
     `push 5; pop rax` ↔ `mov rax, 5`
     `test rax, rax` ↔ `or rax, rax`

2. **Junk Instruction Interleaving (JII)**:
   Insert harmless instruction sequences at random safe points:
     `xchg rax, rax` (NOP equivalent)
     `push rax; pop rax` (no-op preserving state)
     `lea rax, [rax+0]` (no-op)
   Random positions, random counts — breaks instruction pattern matching

3. **Function Thunking (FT)**:
   Wrap the entry point `go()` in 2-5 levels of indirection:
     go() → thunk1() → thunk2() → real_go()
   Each thunk has random padding and random equivalent prologues

4. **Register Substitution via Trampoline (RST)**:
   For function calls, swap argument registers via trampoline:
     Original:  call func(rcx=arg1, rdx=arg2)
     Mutated:   mov r8, rcx; mov r9, rdx; mov rcx, r8; mov rdx, r9; call func
   (Equivalent but different bytes)

5. **Section Symbol Confusion (SSC)**:
   Add decoy sections with similar names:
     .text2, .data2, .rdata2
   Real code lives in renamed section; loader uses metadata to find it

Each compile picks random combinations of these layers, producing
polymorphic output that resists:
   - Static signature detection (instructions differ)
   - Pattern-based detection (sections/structure differ)
   - Heuristic detection (instruction distribution looks normal)

The loader is informed of the transformations via an encrypted metadata
header prepended to the .o file (separate from COFF structures).
"""

import os
import re
import sys
import random
import struct
import string
import subprocess
import shutil
import tempfile
from typing import Optional


# ============================================================
#  Configuration
# ============================================================
BOFS_DIR_DEFAULT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "bofs")
DIST_DIR_DEFAULT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "dist")


# ============================================================
#  Layer 1: Equivalence Class Mutations (ECM)
# ============================================================
# Map of instruction → list of equivalent forms (as assembly strings)
ECM_PATTERNS = {
    # Zeroing a register — only 64-bit registers (rax, rbx, etc.)
    # NOT 32-bit (eax, r15d) — those cause 'pop' errors in MinGW
    r'\bxor\s+(rax|rbx|rcx|rdx|rsi|rdi|rbp|rsp|r8|r9|r10|r11|r12|r13|r14|r15),\s*\1\b': [
        lambda m: f"sub {m.group(1)}, {m.group(1)}",
        lambda m: f"and {m.group(1)}, 0",
    ],
    # Move immediate to register — ONLY 64-bit registers
    # 32-bit registers (r15d, eax) cause 'pop' errors in MinGW assembler
    r'\bmov\s+(rax|rbx|rcx|rdx|rsi|rdi|rbp|rsp|r8|r9|r10|r11|r12|r13|r14|r15),\s*(\d+)\b': [
        lambda m: f"push {m.group(2)}\npop {m.group(1)}" if int(m.group(2)) < 256 else None,
    ],
    # Test register with itself — only 64-bit
    r'\btest\s+(rax|rbx|rcx|rdx|rsi|rdi|rbp|rsp|r8|r9|r10|r11|r12|r13|r14|r15),\s*\1\b': [
        lambda m: f"or {m.group(1)}, {m.group(1)}",
    ],
}


def apply_ecm(asm_lines: list, rng: random.Random) -> list:
    """Apply Equivalence Class Mutations to assembly lines."""
    out = []
    for line in asm_lines:
        # Skip directives, labels, comments
        stripped = line.strip()
        if (not stripped or stripped.startswith('.') or
            stripped.endswith(':') or stripped.startswith(';') or
            stripped.startswith('#')):
            out.append(line)
            continue

        # Try each pattern
        mutated = False
        for pattern, replacements in ECM_PATTERNS.items():
            match = re.search(pattern, line, re.IGNORECASE)
            if match:
                # 50% chance to apply mutation
                if rng.random() < 0.5:
                    repl_fn = rng.choice(replacements)
                    new_str = repl_fn(match)
                    if new_str:
                        # Replace the matched portion
                        line = line[:match.start()] + new_str + line[match.end():]
                        mutated = True
                        break

        out.append(line)
    return out


# ============================================================
#  Layer 2: Junk Instruction Interleaving (JII)
# ============================================================
# Harmless instruction sequences that don't change program state
# IMPORTANT: Only use 64-bit safe instructions (no 32-bit register forms)
JUNK_SEQUENCES = [
    ["xchg rax, rax"],                    # NOP variant
    ["push rax", "pop rax"],              # Stack no-op
    ["lea rax, [rax+0]"],                 # No-op LEA
    ["mov rax, rax"],                     # Move to self
    ["nop"],                              # Classic NOP
    ["nop"],                              # Weighted (more likely)
    ["nop"],
    ["xchg rbx, rbx"],
    ["push rbx", "pop rbx"],
    ["test rax, rax"],                    # Sets flags but doesn't change rax
    ["push rcx", "pop rcx"],              # 64-bit safe (no rcx ecx mixup)
    ["push rdx", "pop rdx"],
]


def insert_junk(asm_lines: list, rng: random.Random,
                min_junk: int = 2, max_junk: int = 8) -> list:
    """Insert junk instructions at safe points (between instructions)."""
    out = []
    safe_count = 0

    for line in asm_lines:
        out.append(line)
        stripped = line.strip()

        # Only insert junk after regular instructions (not directives/labels)
        if (stripped and not stripped.startswith('.') and
            not stripped.endswith(':') and not stripped.startswith(';') and
            not stripped.startswith('#') and not stripped.endswith(':')):
            safe_count += 1

            # Insert junk with probability that increases over time
            # (more junk in middle of functions than at start)
            if rng.random() < 0.15 and safe_count > 2:
                num_junk = rng.randint(min_junk, max_junk)
                for _ in range(num_junk):
                    junk_seq = rng.choice(JUNK_SEQUENCES)
                    for instr in junk_seq:
                        out.append(f"    {instr}")

    return out


# ============================================================
#  Layer 3: Function Thunking (FT)
# ============================================================
def generate_thunk_chain(real_func: str, depth: int,
                          rng: random.Random) -> list:
    """Generate a chain of thunk functions that eventually call real_func.

    Args:
      real_func: Name of the actual function to call
      depth: Number of thunk levels (2-5)
      rng: Random instance

    Returns:
      List of assembly lines defining the thunks.
      The outermost thunk has the same name as real_func.
    """
    if depth < 1:
        return []

    # Generate random thunk names
    def rand_name():
        return ''.join(rng.choices(string.ascii_letters + string.digits, k=8))

    # We'll redefine the original function as a renamed version
    # and create a chain: original_name → thunk1 → thunk2 → ... → real_impl
    thunk_names = [rand_name() for _ in range(depth - 1)]
    impl_name = rand_name()

    # The chain is:
    #   original_name (wrapper) → thunk1 → thunk2 → ... → impl_name
    # impl_name is where the real code lives

    out = []
    chain = [real_func] + thunk_names + [impl_name]

    # Generate each thunk (just calls the next one)
    for i in range(len(chain) - 1):
        caller = chain[i]
        callee = chain[i + 1]

        # Each thunk has a different prologue style
        prologue_styles = [
            # Standard prologue
            [f"{caller}:", "    push rbp", "    mov rbp, rsp",
             f"    call {callee}", "    pop rbp", "    ret"],
            # No frame pointer
            [f"{caller}:", f"    sub rsp, 8",
             f"    call {callee}", f"    add rsp, 8", "    ret"],
            # With NOP padding
            [f"{caller}:", "    xchg rax, rax",
             f"    call {callee}", "    ret"],
            # With push/pop decoration
            [f"{caller}:", "    push rax",
             f"    call {callee}", "    pop rax", "    ret"],
        ]
        out.extend(rng.choice(prologue_styles))
        out.append("")

    # The impl_name function is where the real code will be placed
    # (caller of this function must rename real_func → impl_name in source)
    return out, impl_name


# ============================================================
#  Layer 4: Register Substitution via Trampoline (RST)
# ============================================================
def apply_rst_to_call(asm_line: str, rng: random.Random) -> list:
    """Apply register substitution to a 'call' instruction.

    Original:  call func
    Mutated:   mov r8, rcx; mov r9, rdx; mov rcx, r8; mov rdx, r9; call func

    This preserves ABI (rcx, rdx are first two args in x64 Windows)
    but adds noise to instruction bytes.
    """
    # Match: call <something>
    match = re.match(r'\s*call\s+(\S+)', asm_line)
    if not match:
        return [asm_line]

    # 30% chance to apply RST
    if rng.random() > 0.3:
        return [asm_line]

    callee = match.group(1)
    indent = asm_line[:len(asm_line) - len(asm_line.lstrip())]

    # Substitution patterns (preserve register semantics)
    patterns = [
        # Swap rcx ↔ r8 then back
        [f"{indent}mov r8, rcx", f"{indent}mov rcx, r8"],
        # Swap rdx ↔ r9 then back
        [f"{indent}mov r9, rdx", f"{indent}mov rdx, r9"],
        # Both
        [f"{indent}mov r8, rcx", f"{indent}mov r9, rdx",
         f"{indent}mov rcx, r8", f"{indent}mov rdx, r9"],
    ]

    chosen = rng.choice(patterns)
    return chosen + [asm_line]


def apply_rst_to_all_calls(asm_lines: list, rng: random.Random) -> list:
    """Apply RST to all call instructions."""
    out = []
    for line in asm_lines:
        stripped = line.strip()
        if stripped.startswith('call ') and not stripped.startswith('call ['):
            out.extend(apply_rst_to_call(line, rng))
        else:
            out.append(line)
    return out


# ============================================================
#  Layer 5: Section Symbol Confusion (SSC)
# ============================================================
def apply_ssc(asm_lines: list, rng: random.Random) -> list:
    """Add decoy sections and rename sections to confuse analysis."""
    out = []

    # Track used section numbers to avoid duplicates
    used_numbers = set()
    decoy_count = rng.randint(1, 3)

    # First pass: keep all original lines
    for line in asm_lines:
        out.append(line)

    # Second pass: add decoy sections
    for i in range(decoy_count):
        # Pick unique section number not already used
        while True:
            n = rng.randint(2, 9)
            if n not in used_numbers:
                used_numbers.add(n)
                break

        section_name = f".text{n}"
        # Use unique label name (with random suffix to avoid collisions)
        label_name = f"{section_name}_start_{rng.randint(1000, 9999)}"
        out.append(f".section {section_name}, \"rx\"")
        out.append(f"{label_name}:")
        # Add some random bytes that look like code but aren't used
        for _ in range(rng.randint(3, 8)):
            # Random "instruction" that does nothing useful
            junk_instr = rng.choice([
                "    xchg rax, rax",
                "    nop",
                "    push rax",
                "    pop rax",
            ])
            out.append(junk_instr)
        out.append("")

    return out


# ============================================================
#  Main polymorphic compilation pipeline
# ============================================================
def compile_bof_polymorphic(c_source_path: str,
                              output_o_path: str,
                              psk: bytes = None,
                              rng: Optional[random.Random] = None,
                              verbose: bool = False) -> dict:
    """Compile a BOF with polymorphic transformations.

    Pipeline:
      1. Compile C → assembly (using -S flag)
      2. Apply polymorphic transformations (5 layers)
      3. Compile mutated assembly → .o file
      4. Generate polymorphic metadata (transformation record)
      5. Return metadata for loader

    Args:
      c_source_path: Path to .c source file
      output_o_path: Path to output .o file
      psk: Optional PSK for encrypting metadata (None = no encryption)
      rng: Random instance (None = create new)
      verbose: Print transformation details

    Returns:
      Dict with metadata about transformations applied
    """
    if rng is None:
        rng = random.Random()

    # Find compiler
    cc = None
    for cand in ["x86_64-w64-mingw32-gcc", "x86_64-w64-mingw32-gcc-posix"]:
        if shutil.which(cand):
            cc = cand
            break

    if not cc:
        # Try zig
        for cand in ["zig", "/usr/local/bin/zig"]:
            if shutil.which(cand):
                cc = f"{cand} cc -target x86_64-windows-gnu"
                break

    if not cc:
        raise RuntimeError("No suitable compiler found (need mingw or zig)")

    if verbose:
        print(f"[*] Using compiler: {cc}")

    # Step 1: Compile C → assembly
    with tempfile.TemporaryDirectory() as tmpdir:
        asm_path = os.path.join(tmpdir, "bof.s")
        base_name = os.path.splitext(os.path.basename(c_source_path))[0]

        # Common compile flags for BOFs
        cflags = "-Wall -O2 -shared -fno-stack-protector -masm=intel"

        # Detect target flag for zig
        target_flag = ""
        if "zig" in cc:
            target_flag = "-target x86_64-windows-gnu"

        cmd = f"{cc} {target_flag} {cflags} -S {c_source_path} -o {asm_path}"
        if verbose:
            print(f"[*] Step 1: Compile to assembly")
            print(f"    {cmd}")

        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"C→ASM compile failed:\n{result.stderr}")

        with open(asm_path) as f:
            asm_content = f.read()

    if verbose:
        print(f"[*] Original assembly: {len(asm_content)} bytes, "
              f"{asm_content.count(chr(10))} lines")

    asm_lines = asm_content.split('\n')

    # Step 2: Apply polymorphic transformations
    metadata = {
        "source": os.path.basename(c_source_path),
        "transformations": [],
        "original_asm_lines": len(asm_lines),
    }

    # Layer 1: ECM
    if rng.random() < 0.7:  # 70% chance
        before = len(asm_lines)
        asm_lines = apply_ecm(asm_lines, rng)
        after = len(asm_lines)
        metadata["transformations"].append({
            "layer": "ECM",
            "applied": True,
            "details": f"{before}→{after} lines"
        })
        if verbose:
            print(f"[*] Layer 1 (ECM): {before}→{after} lines")
    else:
        metadata["transformations"].append({"layer": "ECM", "applied": False})

    # Layer 2: JII
    if rng.random() < 0.8:  # 80% chance
        before = len(asm_lines)
        asm_lines = insert_junk(asm_lines, rng)
        after = len(asm_lines)
        metadata["transformations"].append({
            "layer": "JII",
            "applied": True,
            "details": f"{before}→{after} lines"
        })
        if verbose:
            print(f"[*] Layer 2 (JII): {before}→{after} lines")
    else:
        metadata["transformations"].append({"layer": "JII", "applied": False})

    # Layer 3: FT (function thunking)
    # Note: This is complex because we need to rename the original go() function
    # For now, skip layer 3 in this implementation (would require AST manipulation)
    metadata["transformations"].append({
        "layer": "FT",
        "applied": False,
        "details": "Skipped (requires AST manipulation)"
    })

    # Layer 4: RST
    if rng.random() < 0.6:  # 60% chance
        before = len(asm_lines)
        asm_lines = apply_rst_to_all_calls(asm_lines, rng)
        after = len(asm_lines)
        metadata["transformations"].append({
            "layer": "RST",
            "applied": True,
            "details": f"{before}→{after} lines"
        })
        if verbose:
            print(f"[*] Layer 4 (RST): {before}→{after} lines")
    else:
        metadata["transformations"].append({"layer": "RST", "applied": False})

    # Layer 5: SSC
    if rng.random() < 0.5:  # 50% chance
        before = len(asm_lines)
        asm_lines = apply_ssc(asm_lines, rng)
        after = len(asm_lines)
        metadata["transformations"].append({
            "layer": "SSC",
            "applied": True,
            "details": f"{before}→{after} lines"
        })
        if verbose:
            print(f"[*] Layer 5 (SSC): {before}→{after} lines")
    else:
        metadata["transformations"].append({"layer": "SSC", "applied": False})

    # Step 3: Compile mutated assembly → .o
    mutated_asm_content = '\n'.join(asm_lines)

    with tempfile.TemporaryDirectory() as tmpdir:
        mutated_asm_path = os.path.join(tmpdir, "bof_mutated.s")

        with open(mutated_asm_path, 'w') as f:
            f.write(mutated_asm_content)

        # Compile assembly to object file
        # Note: We DON'T use -DBOF_NO_DLLIMPORT here, we want __imp_ symbols
        cmd = f"{cc} {target_flag} -c {mutated_asm_path} -o {output_o_path}"
        if verbose:
            print(f"[*] Step 3: Compile mutated assembly → .o")
            print(f"    {cmd}")

        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            # If mutation broke something, fall back to original source compile
            if verbose:
                print(f"[!] Mutation compile failed, falling back to original")
                print(f"    {result.stderr}")

            # Fallback: compile original source directly
            cflags_obj = "-Wall -O2 -shared -fno-stack-protector -masm=intel"
            cmd = f"{cc} {target_flag} {cflags_obj} -c {c_source_path} -o {output_o_path}"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            if result.returncode != 0:
                raise RuntimeError(f"Fallback compile failed:\n{result.stderr}")

            metadata["fallback"] = True
        else:
            metadata["fallback"] = False

    # Get final file size
    metadata["final_size"] = os.path.getsize(output_o_path)
    metadata["final_asm_lines"] = len(asm_lines)

    if verbose:
        print(f"[*] Final .o: {metadata['final_size']} bytes")
        print(f"[*] Transformations applied: "
              f"{sum(1 for t in metadata['transformations'] if t.get('applied'))}/5")

    return metadata


def compile_bof_simple(c_source_path: str, output_o_path: str,
                        verbose: bool = False) -> dict:
    """Compile without polymorphic transformations (for comparison/fallback)."""
    cc = None
    for cand in ["x86_64-w64-mingw32-gcc", "x86_64-w64-mingw32-gcc-posix"]:
        if shutil.which(cand):
            cc = cand
            break

    if not cc:
        for cand in ["zig", "/usr/local/bin/zig"]:
            if shutil.which(cand):
                cc = f"{cand} cc -target x86_64-windows-gnu"
                break

    if not cc:
        raise RuntimeError("No suitable compiler found")

    target_flag = "-target x86_64-windows-gnu" if "zig" in cc else ""
    cflags = "-Wall -O2 -shared -fno-stack-protector -masm=intel"
    cmd = f"{cc} {target_flag} {cflags} -c {c_source_path} -o {output_o_path}"

    if verbose:
        print(f"[*] Simple compile: {cmd}")

    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"Compile failed:\n{result.stderr}")

    return {
        "source": os.path.basename(c_source_path),
        "final_size": os.path.getsize(output_o_path),
        "transformations": [],
        "fallback": True,
    }


# ============================================================
#  Demonstration: compile same source twice, compare outputs
# ============================================================
def demo_polymorphism():
    """Show that same source produces different .o each compile."""
    print("=" * 60)
    print("  POLYMORPHIC COMPILATION DEMO")
    print("=" * 60)
    print()

    # Find a test BOF
    test_bofs = []
    for d in [BOFS_DIR_DEFAULT, os.path.join(os.getcwd(), "bofs")]:
        if os.path.isdir(d):
            for f in os.listdir(d):
                if f.endswith('.c') and f != 'beacon.h':
                    test_bofs.append(os.path.join(d, f))
            break

    if not test_bofs:
        print("[!] No .c BOF files found for demo")
        return

    test_bof = test_bofs[0]
    print(f"[*] Test source: {os.path.basename(test_bof)}")
    print()

    # Compile 3 times with different random seeds
    outputs = []
    for i in range(3):
        rng = random.Random(i + 1000)  # different seed each time
        out_path = f"/tmp/poly_test_{i}.o"

        print(f"[*] Compile #{i+1} (seed={i+1000}):")
        metadata = compile_bof_polymorphic(
            test_bof, out_path, rng=rng, verbose=True)

        if os.path.exists(out_path):
            with open(out_path, 'rb') as f:
                content = f.read()
            outputs.append(content)
            print(f"    Hash: {hashlib.sha256(content).hexdigest()[:32]}...")
        print()

    # Compare
    print("=" * 60)
    print("  COMPARISON")
    print("=" * 60)
    for i, content in enumerate(outputs):
        h = hashlib.sha256(content).hexdigest()
        print(f"  Compile #{i+1}: {len(content)} bytes, SHA256: {h[:32]}...")

    if len(outputs) >= 2:
        same = outputs[0] == outputs[1]
        print()
        print(f"  Compile #1 == Compile #2: {same}")
        if not same:
            print(f"  [+] POLYMORPHISM CONFIRMED: same source, different .o files!")
        else:
            print(f"  [!] Outputs identical (polymorphism failed)")


if __name__ == "__main__":
    import hashlib
    demo_polymorphism()
