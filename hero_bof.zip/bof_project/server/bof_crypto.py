#!/usr/bin/env python3
"""
bof_crypto.py - HKDF + AES-256-GCM + HMAC-SHA256 Wire Encryption

Implements the crypto layer from user's spec:
  - PSK baked into agent at build time (32 bytes)
  - Per-session salt (32 bytes, fresh each checkin)
  - HKDF-Extract + HKDF-Expand → 4 keys (128 bytes)
  - Encrypt-then-MAC hybrid (GCM + HMAC)

Dependencies:
  pip install cryptography

Key Derivation:
  PRK = HKDF-Extract(salt, PSK)
  OKM = HKDF-Expand(PRK, info="newclientc2-v1-derivation", L=128)
  traffic_key = OKM[0:32]
  sleep_key   = OKM[32:64]
  task_key    = OKM[64:96]
  mac_key     = OKM[96:128]

Wire Format:
  [4B length BE][12B nonce][N bytes ciphertext+tag]

Inner format (after GCM decrypt):
  [32B HMAC-SHA256(mac_key, plaintext)][plaintext]

Decrypt flow:
  1. Read 4B length
  2. Read 12B nonce
  3. Read N bytes ciphertext+tag
  4. AES-GCM decrypt with traffic_key → inner
  5. Split: hmac_recv = inner[:32], plaintext = inner[32:]
  6. Compute hmac_calc = HMAC-SHA256(mac_key, plaintext)
  7. Constant-time compare hmac_recv == hmac_calc
  8. If match → plaintext, else → reject

Why double authentication (GCM + HMAC):
  - GCM nonce reuse is catastrophic; HMAC catches tampering independently
  - Different keys (derived from different HKDF blocks) — defense in depth
  - Forward secrecy: compromising one key doesn't break the other
"""

import os
import hmac
import hashlib
import struct
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


# ============================================================
#  Constants
# ============================================================
HKDF_INFO = b"newclientc2-v1-derivation"
KEY_LEN = 32   # 256-bit keys
NONCE_LEN = 12  # 96-bit GCM nonce
MAC_LEN = 32   # 256-bit HMAC-SHA256
TOTAL_OKM = 128  # 4 keys × 32 bytes


# ============================================================
#  HKDF (RFC 5869)
# ============================================================
def hkdf_extract(salt: bytes, ikm: bytes) -> bytes:
    """HKDF-Extract: PRK = HMAC-SHA256(salt, IKM)"""
    return hmac.new(salt, ikm, hashlib.sha256).digest()


def hkdf_expand(prk: bytes, info: bytes, length: int) -> bytes:
    """HKDF-Expand: T(1) || T(2) || ... until length bytes"""
    okm = b""
    t = b""
    counter = 1
    while len(okm) < length:
        t = hmac.new(prk, t + info + bytes([counter]), hashlib.sha256).digest()
        okm += t
        counter += 1
    return okm[:length]


def derive_keys(psk: bytes, salt: bytes) -> dict:
    """Derive 4 keys from PSK + salt via HKDF.

    Returns dict with:
      traffic_key (32B) - AES-256-GCM for wire
      sleep_key   (32B) - agent internal (unused server-side)
      task_key    (32B) - per-task BOF encryption
      mac_key     (32B) - HMAC-SHA256
    """
    if len(psk) != KEY_LEN:
        raise ValueError(f"PSK must be {KEY_LEN} bytes, got {len(psk)}")
    if len(salt) != KEY_LEN:
        raise ValueError(f"Salt must be {KEY_LEN} bytes, got {len(salt)}")

    prk = hkdf_extract(salt, psk)
    okm = hkdf_expand(prk, HKDF_INFO, TOTAL_OKM)

    return {
        "traffic_key": okm[0:32],
        "sleep_key":   okm[32:64],
        "task_key":    okm[64:96],
        "mac_key":     okm[96:128],
    }


# ============================================================
#  Encrypt-then-MAC Hybrid
# ============================================================
def encrypt_payload(plaintext: bytes, traffic_key: bytes, mac_key: bytes) -> bytes:
    """Encrypt plaintext using AES-256-GCM + HMAC.

    Returns wire format:
      [12B nonce][N bytes ciphertext + 16B GCM tag]

    Note: 4-byte length prefix is added by caller (network framing).
    """
    if len(traffic_key) != KEY_LEN:
        raise ValueError("traffic_key must be 32 bytes")
    if len(mac_key) != KEY_LEN:
        raise ValueError("mac_key must be 32 bytes")

    # Layer 4: HMAC layer (prepended to plaintext)
    mac = hmac.new(mac_key, plaintext, hashlib.sha256).digest()
    inner = mac + plaintext

    # Layer 1: AES-256-GCM
    nonce = os.urandom(NONCE_LEN)
    aesgcm = AESGCM(traffic_key)
    ciphertext = aesgcm.encrypt(nonce, inner, None)  # no AAD

    return nonce + ciphertext


def decrypt_payload(wire_bytes: bytes, traffic_key: bytes, mac_key: bytes) -> bytes:
    """Decrypt wire bytes using AES-256-GCM + HMAC.

    Args:
      wire_bytes: [12B nonce][N bytes ciphertext+tag]
      traffic_key: 32-byte AES key
      mac_key: 32-byte HMAC key

    Returns plaintext if MAC verifies, else raises ValueError.

    Note: caller strips 4-byte length prefix before calling this.
    """
    if len(wire_bytes) < NONCE_LEN + 16:  # nonce + minimum GCM tag
        raise ValueError("Wire bytes too short")

    if len(traffic_key) != KEY_LEN:
        raise ValueError("traffic_key must be 32 bytes")
    if len(mac_key) != KEY_LEN:
        raise ValueError("mac_key must be 32 bytes")

    # Extract nonce and ciphertext
    nonce = wire_bytes[:NONCE_LEN]
    ciphertext = wire_bytes[NONCE_LEN:]

    # Layer 1: AES-256-GCM decrypt (verifies GCM auth tag)
    try:
        aesgcm = AESGCM(traffic_key)
        inner = aesgcm.decrypt(nonce, ciphertext, None)
    except Exception as e:
        raise ValueError(f"GCM decryption failed: {e}")

    # Layer 4: HMAC verify
    if len(inner) < MAC_LEN:
        raise ValueError("Inner too short for HMAC")

    hmac_recv = inner[:MAC_LEN]
    plaintext = inner[MAC_LEN:]

    hmac_calc = hmac.new(mac_key, plaintext, hashlib.sha256).digest()

    # Constant-time comparison
    if not hmac.compare_digest(hmac_recv, hmac_calc):
        raise ValueError("HMAC verification failed — tampering detected")

    return plaintext


# ============================================================
#  Wire framing (length-prefixed)
# ============================================================
def pack_frame(encrypted_blob: bytes) -> bytes:
    """Add 4-byte big-endian length prefix."""
    return struct.pack(">I", len(encrypted_blob)) + encrypted_blob


def unpack_frame_from_stream(stream_bytes: bytes) -> tuple:
    """Extract one frame from stream.

    Returns (encrypted_blob, remaining_bytes).
    Raises ValueError if not enough data.
    """
    if len(stream_bytes) < 4:
        raise ValueError("Not enough data for length prefix")
    length = struct.unpack(">I", stream_bytes[:4])[0]
    if len(stream_bytes) < 4 + length:
        raise ValueError(f"Not enough data: need {4+length}, have {len(stream_bytes)}")
    return stream_bytes[4:4+length], stream_bytes[4+length:]


# ============================================================
#  Test / demo
# ============================================================
if __name__ == "__main__":
    # Demo: encrypt + decrypt round trip
    psk = os.urandom(32)
    salt = os.urandom(32)

    keys = derive_keys(psk, salt)
    print(f"PSK: {psk.hex()}")
    print(f"Salt: {salt.hex()}")
    print(f"traffic_key: {keys['traffic_key'].hex()}")
    print(f"mac_key:     {keys['mac_key'].hex()}")
    print(f"task_key:    {keys['task_key'].hex()}")
    print()

    plaintext = b'{"msg_type":"heartbeat","data":{"id":"WIN_OT_001"}}'
    print(f"Plaintext: {plaintext}")
    print(f"  Length: {len(plaintext)} bytes")

    encrypted = encrypt_payload(plaintext, keys["traffic_key"], keys["mac_key"])
    print(f"Encrypted: {encrypted.hex()}")
    print(f"  Length: {len(encrypted)} bytes (nonce + ciphertext)")

    decrypted = decrypt_payload(encrypted, keys["traffic_key"], keys["mac_key"])
    print(f"Decrypted: {decrypted}")
    print(f"  Match: {decrypted == plaintext}")

    # Tamper test
    print()
    print("Tamper test:")
    tampered = bytearray(encrypted)
    tampered[NONCE_LEN + 5] ^= 0xFF  # flip a bit in ciphertext
    try:
        decrypt_payload(bytes(tampered), keys["traffic_key"], keys["mac_key"])
        print("  [!] Tampering NOT detected (BAD!)")
    except ValueError as e:
        print(f"  [+] Tampering detected: {e}")

    # Frame packing test
    print()
    print("Frame test:")
    frame = pack_frame(encrypted)
    print(f"  Frame length: {len(frame)} (4 + {len(encrypted)})")
    blob, rest = unpack_frame_from_stream(frame)
    print(f"  Unpacked blob length: {len(blob)} (matches encrypted: {blob == encrypted})")
    print(f"  Remaining: {len(rest)}")
