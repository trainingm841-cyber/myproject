/*
 * beacon_api.c - Beacon API + Output Buffer + VEH + CRT fallbacks
 *
 * Contains:
 *   - Output buffer (g_output_buf, output_append, output_reset)
 *   - Beacon API implementations (BeaconPrintf, BeaconOutput, BeaconDataParse, etc.)
 *   - VEH handler for catching BOF crashes
 *   - CRT fallback functions (bof_memset, bof_memcpy, bof_memmove)
 *
 * This file provides the runtime support that BOFs call into.
 */

#include "agent.h"

/* ====== Output buffer ====== */
char*  g_output_buf   = NULL;
size_t g_output_len    = 0;
size_t g_output_cap    = 0;

/* ====== Argument buffer state (used by BOF) ====== */
ARG_STATE g_args = { NULL, 0, 0 };

/* ====== Exception tracking (set by VEH) ====== */
DWORD g_last_exception = 0;

/* ====== Output buffer management ====== */
void output_append(const char* str, size_t len) {
    if (!g_output_buf) {
        g_output_cap = 65536;
        g_output_buf = (char*)malloc(g_output_cap);
        if (!g_output_buf) return;
        g_output_len = 0;
    }
    /* Grow buffer if needed */
    while (g_output_len + len + 1 > g_output_cap) {
        size_t newcap = g_output_cap * 2;
        if (newcap > OUTPUTSZ) {
            /* Truncate output if exceeds cap */
            len = OUTPUTSZ - g_output_len - 1;
            if (len == 0) return;
            break;
        }
        char* p = (char*)realloc(g_output_buf, newcap);
        if (!p) return;
        g_output_buf = p;
        g_output_cap = newcap;
    }
    memcpy(g_output_buf + g_output_len, str, len);
    g_output_len += len;
    g_output_buf[g_output_len] = '\0';
}

void output_reset(void) {
    g_output_len = 0;
    g_last_exception = 0;
    if (g_output_buf) g_output_buf[0] = 0;
}

/* ====== Beacon API ====== */
void BeaconPrintf(int type, const char* fmt, ...) {
    char tmp[8192];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(tmp, sizeof(tmp), fmt, ap);
    va_end(ap);
    if (n < 0) return;
    if ((size_t)n >= sizeof(tmp)) n = sizeof(tmp) - 1;

    const char* prefix = "";
    if (type == 0x0d)      prefix = "[!] ";
    else if (type == 0x1e)  prefix = "[OEM] ";
    else if (type == 0x20)  prefix = "[UTF8] ";

    output_append(prefix, strlen(prefix));
    output_append(tmp, n);
    output_append("\n", 1);
}

void BeaconOutput(int type, const char* data, int len) {
    (void)type;
    output_append(data, len);
    output_append("\n", 1);
}

void BeaconDataParse(datatype* args, char* buf, int size) {
    (void)args;
    g_args.base   = buf;
    g_args.size   = size;
    g_args.cursor = 0;
}

int BeaconDataInt(datatype* args) {
    (void)args;
    if (g_args.cursor + 4 > g_args.size) return 0;
    int v;
    memcpy(&v, g_args.base + g_args.cursor, 4);
    g_args.cursor += 4;
    return v;
}

short BeaconDataShort(datatype* args) {
    (void)args;
    if (g_args.cursor + 2 > g_args.size) return 0;
    short v;
    memcpy(&v, g_args.base + g_args.cursor, 2);
    g_args.cursor += 2;
    return v;
}

char BeaconDataByte(datatype* args) {
    (void)args;
    if (g_args.cursor + 1 > g_args.size) return 0;
    char v = g_args.base[g_args.cursor];
    g_args.cursor += 1;
    return v;
}

char* BeaconDataExtract(datatype* args, int* size) {
    (void)args;
    if (g_args.cursor + 4 > g_args.size) {
        if (size) *size = 0;
        return "";
    }
    int slen;
    memcpy(&slen, g_args.base + g_args.cursor, 4);
    g_args.cursor += 4;
    if (slen < 0 || g_args.cursor + slen > g_args.size) {
        if (size) *size = 0;
        return "";
    }
    char* result = g_args.base + g_args.cursor;
    g_args.cursor += slen;
    if (size) *size = slen;
    return result;
}

/* Token operations - stubs (we don't support impersonation in this demo) */
BOOL BeaconIsAdmin(void)        { return FALSE; }
void BeaconGetSpawnTo(char* b, int l) { if (l>0) b[0]=0; }
BOOL BeaconUseToken(HANDLE t)   { (void)t; return FALSE; }
void BeaconRevertToken(void)    { /* no-op */ }

/* ====== VEH - catch BOF crashes (replaces MSVC __try/__except) ====== */
LONG WINAPI veh_handler(PEXCEPTION_POINTERS ep) {
    DWORD code = ep->ExceptionRecord->ExceptionCode;
    if (code == 0xC0000005 /* ACCESS_VIOLATION */ ||
        code == 0xC000001D /* ILLEGAL_INSTRUCTION */ ||
        code == 0xC0000409 /* STACK_BUFFER_OVERRUN */ ||
        code == 0x80000003 /* BREAKPOINT */) {
        g_last_exception = code;

        /* Print to STDERR immediately so we see it even if process dies */
        fprintf(stderr, "\n[X] ====== BOF CRASH DETECTED ======\n");
        fprintf(stderr, "[X] Exception code: 0x%08lX\n", (unsigned long)code);
        fprintf(stderr, "[X] Exception address: 0x%p\n", ep->ExceptionRecord->ExceptionAddress);
        if (code == 0xC0000005) {
            /* Access violation has additional info: read/write/execute + target address */
            fprintf(stderr, "[X] Access type: %lu (0=read, 1=write, 8=execute)\n",
                    ep->ExceptionRecord->ExceptionInformation[0]);
            fprintf(stderr, "[X] Target address: 0x%p\n",
                    (void*)ep->ExceptionRecord->ExceptionInformation[1]);
        }
        fprintf(stderr, "[X] RIP: 0x%p\n", (void*)ep->ContextRecord->Rip);
        fprintf(stderr, "[X] RSP: 0x%p\n", (void*)ep->ContextRecord->Rsp);
        fprintf(stderr, "[X] RCX: 0x%p  (first arg)\n", (void*)ep->ContextRecord->Rcx);
        fprintf(stderr, "[X] RDX: 0x%p  (second arg)\n", (void*)ep->ContextRecord->Rdx);
        fprintf(stderr, "[X] RAX: 0x%p\n", (void*)ep->ContextRecord->Rax);
        fprintf(stderr, "[X] R8:  0x%p\n", (void*)ep->ContextRecord->R8);
        fprintf(stderr, "[X] R9:  0x%p\n", (void*)ep->ContextRecord->R9);
        fprintf(stderr, "[X] ================================\n\n");
        fflush(stderr);

        /* Also append to output buffer (in case we survive) */
        char buf[512];
        snprintf(buf, sizeof(buf),
                 "[X] BOF raised exception 0x%08lX at 0x%p (RIP=0x%p)\n",
                 (unsigned long)code, ep->ExceptionRecord->ExceptionAddress,
                 (void*)ep->ContextRecord->Rip);
        output_append(buf, strlen(buf));

        /* Continue search - the BOF will likely fault again and terminate.
           We can't safely recover from a corrupted stack. */
        return EXCEPTION_CONTINUE_SEARCH;
    }
    return EXCEPTION_CONTINUE_SEARCH;
}

void veh_register(void) {
    AddVectoredExceptionHandler(0, veh_handler);
}

/* ====== CRT fallbacks ====== */
/* Used as last resort when msvcrt.dll/ntdll.dll don't have these.
 * We use volatile pointers to prevent compiler from turning these
 * back into memset/memcpy calls (would cause infinite recursion). */
void* bof_memset(void* dst, int val, size_t n) {
    volatile unsigned char* p = (volatile unsigned char*)dst;
    while (n--) *p++ = (unsigned char)val;
    return dst;
}

void* bof_memcpy(void* dst, const void* src, size_t n) {
    volatile unsigned char* d = (volatile unsigned char*)dst;
    volatile const unsigned char* s = (volatile const unsigned char*)src;
    while (n--) *d++ = *s++;
    return dst;
}

void* bof_memmove(void* dst, const void* src, size_t n) {
    volatile unsigned char* d = (volatile unsigned char*)dst;
    volatile const unsigned char* s = (volatile const unsigned char*)src;
    if (d < s) {
        while (n--) *d++ = *s++;
    } else {
        d += n; s += n;
        while (n--) *--d = *--s;
    }
    return dst;
}

/* ====== Symbol resolution (called by coff_loader.c) ====== */
/* Beacon API registry - plain names (no __imp_) */
typedef struct { const char* name; void* ptr; } SYM_ENTRY;
static const SYM_ENTRY g_beacon_funcs[] = {
    { "BeaconDataParse",     (void*)BeaconDataParse     },
    { "BeaconDataInt",       (void*)BeaconDataInt       },
    { "BeaconDataShort",     (void*)BeaconDataShort     },
    { "BeaconDataByte",      (void*)BeaconDataByte      },
    { "BeaconDataExtract",   (void*)BeaconDataExtract   },
    { "BeaconPrintf",        (void*)BeaconPrintf        },
    { "BeaconOutput",        (void*)BeaconOutput        },
    { "BeaconIsAdmin",       (void*)BeaconIsAdmin       },
    { "BeaconGetSpawnTo",    (void*)BeaconGetSpawnTo    },
    { "BeaconUseToken",      (void*)BeaconUseToken      },
    { "BeaconRevertToken",   (void*)BeaconRevertToken   },
};
static const size_t g_beacon_funcs_n = sizeof(g_beacon_funcs) / sizeof(g_beacon_funcs[0]);

static const char* g_default_dlls[] = {
    "kernel32.dll", "advapi32.dll", "user32.dll",
    "ntdll.dll",    "ws2_32.dll",   "crypt32.dll",
    NULL
};

/* Resolve Beacon API by name (internal use, exposed via resolve_dynamic below) */
void* resolve_dynamic(const char* plain) {
    /* 1. Beacon API first */
    for (size_t i = 0; i < g_beacon_funcs_n; i++) {
        if (_stricmp(g_beacon_funcs[i].name, plain) == 0)
            return g_beacon_funcs[i].ptr;
    }

    /* 2. CRT runtime functions (compiler-generated calls) */
    if (strcmp(plain, "memset")  == 0 ||
        strcmp(plain, "memcpy")  == 0 ||
        strcmp(plain, "memmove") == 0 ||
        strcmp(plain, "memcmp")  == 0 ||
        strcmp(plain, "strlen")  == 0 ||
        strcmp(plain, "strcpy")  == 0 ||
        strcmp(plain, "strcmp")  == 0) {
        HMODULE h = GetModuleHandleA("msvcrt.dll");
        if (!h) h = LoadLibraryA("msvcrt.dll");
        if (h) {
            void* p = (void*)GetProcAddress(h, plain);
            if (p) return p;
        }
        h = GetModuleHandleA("ntdll.dll");
        if (!h) h = LoadLibraryA("ntdll.dll");
        if (h) {
            void* p = (void*)GetProcAddress(h, plain);
            if (p) return p;
        }
        /* Fallbacks for memset/memcpy/memmove using our own impl */
        if (strcmp(plain, "memset")  == 0) return (void*)bof_memset;
        if (strcmp(plain, "memcpy")  == 0) return (void*)bof_memcpy;
        if (strcmp(plain, "memmove") == 0) return (void*)bof_memmove;
    }

    /* 3. LIB$FUNC syntax: e.g. ADVAPI32$GetUserNameA */
    const char* dollar = strchr(plain, '$');
    if (dollar && dollar != plain) {
        char dll_buf[64];
        size_t dlen = dollar - plain;
        if (dlen >= sizeof(dll_buf)) return NULL;
        memcpy(dll_buf, plain, dlen);
        dll_buf[dlen] = 0;
        _strlwr(dll_buf);
        if (!strstr(dll_buf, ".dll"))
            _snprintf(dll_buf + dlen, sizeof(dll_buf) - dlen, ".dll");
        const char* func = dollar + 1;
        HMODULE h = LoadLibraryA(dll_buf);
        if (!h) return NULL;
        return (void*)GetProcAddress(h, func);
    }

    /* 4. Default DLL list (for plain names without $ prefix) */
    for (int i = 0; g_default_dlls[i]; i++) {
        HMODULE h = GetModuleHandleA(g_default_dlls[i]);
        if (!h) h = LoadLibraryA(g_default_dlls[i]);
        if (!h) continue;
        void* p = (void*)GetProcAddress(h, plain);
        if (p) return p;
    }
    return NULL;
}
