/*
 * netusers.c - Local users enumeration
 */
#include <windows.h>
#include <lm.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI NET_API_STATUS WINAPI NETAPI32$NetUserEnum(LPCWSTR, DWORD, DWORD, LPBYTE*, DWORD, LPDWORD, LPDWORD, LPDWORD);
DECLSPEC_IMPORT WINBASEAPI NET_API_STATUS WINAPI NETAPI32$NetApiBufferFree(LPVOID);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    LPUSER_INFO_1 pBuf = NULL;
    DWORD entriesRead = 0, totalEntries = 0;
    DWORD resumeHandle = 0;

    NET_API_STATUS status = NETAPI32$NetUserEnum(NULL, 1, 0, (LPBYTE*)&pBuf, MAX_PREFERRED_LENGTH,
        &entriesRead, &totalEntries, &resumeHandle);

    if (status == NERR_Success || status == ERROR_MORE_DATA) {
        BeaconPrintf(CALLBACK_OUTPUT, "=== Local Users (%lu of %lu) ===", entriesRead, totalEntries);
        BeaconPrintf(CALLBACK_OUTPUT, "%-25s %-15s %s", "Username", "Comment", "Status");

        for (DWORD i = 0; i < entriesRead; i++) {
            char name[128] = {0};
            WideCharToMultiByte(CP_ACP, 0, pBuf[i].usri1_name, -1, name, sizeof(name), NULL, NULL);

            const char* statusStr = "Active";
            if (pBuf[i].usri1_flags & UF_ACCOUNTDISABLE) statusStr = "Disabled";
            if (pBuf[i].usri1_flags & UF_LOCKOUT) statusStr = "Locked";

            BeaconPrintf(CALLBACK_OUTPUT, "%-25s %-15s %s", name, "(none)", statusStr);
        }

        if (status == ERROR_MORE_DATA) {
            BeaconPrintf(CALLBACK_OUTPUT, "... (%lu more entries)", totalEntries - entriesRead);
        }

        NETAPI32$NetApiBufferFree(pBuf);
    } else {
        BeaconPrintf(CALLBACK_OUTPUT, "Failed to enumerate users (error %lu)", status);
    }
}
