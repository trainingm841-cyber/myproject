/*
 * beacon.h - BOF SDK Header (plain symbol mode)
 *
 * Compile BOFs with -DBOF_NO_DLLIMPORT=1 so symbol names are PLAIN
 * (no __imp_ prefix). Our agent.c loader handles both modes, but
 * plain is simpler and matches what most BOF loaders expect.
 */

#ifndef _BEACON_H_
#define _BEACON_H_

#include <stdint.h>
#include <stdio.h>
#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

/* In plain mode, DECLSPEC_IMPORT is empty - just declarations */
#ifdef BOF_NO_DLLIMPORT
    #ifdef DECLSPEC_IMPORT
        #undef DECLSPEC_IMPORT
    #endif
    #define DECLSPEC_IMPORT
#else
    #ifdef DECLSPEC_IMPORT
        #undef DECLSPEC_IMPORT
    #endif
    #define DECLSPEC_IMPORT __declspec(dllimport)
#endif

/* Beacon callback types */
#define CALLBACK_OUTPUT      0x0
#define CALLBACK_OUTPUT_OEM 0x1e
#define CALLBACK_ERROR       0x0d
#define CALLBACK_OUTPUT_UTF8 0x20

/* Argument types */
#define ARG_INT8    0
#define ARG_INT16   1
#define ARG_INT32   2
#define ARG_INT64   3
#define ARG_STR     4
#define ARG_WSTR    5
#define ARG_BINARY  6

typedef struct {
    char  original;
    char  buffer[256];
    int   length;
    int   size;
} datatype;

/* Beacon API - implemented by agent.c, called by BOF */
DECLSPEC_IMPORT void    BeaconDataParse(datatype* args, char* buffer, int size);
DECLSPEC_IMPORT int     BeaconDataInt(datatype* args);
DECLSPEC_IMPORT short   BeaconDataShort(datatype* args);
DECLSPEC_IMPORT char    BeaconDataByte(datatype* args);
DECLSPEC_IMPORT char*   BeaconDataExtract(datatype* args, int* size);
DECLSPEC_IMPORT void    BeaconPrintf(int type, const char* fmt, ...);
DECLSPEC_IMPORT void    BeaconOutput(int type, const char* data, int len);
DECLSPEC_IMPORT BOOL    BeaconIsAdmin(void);
DECLSPEC_IMPORT void    BeaconGetSpawnTo(char* buffer, int length);
DECLSPEC_IMPORT BOOL    BeaconUseToken(HANDLE token);
DECLSPEC_IMPORT void    BeaconRevertToken(void);

#ifdef __cplusplus
}
#endif

#endif /* _BEACON_H_ */
