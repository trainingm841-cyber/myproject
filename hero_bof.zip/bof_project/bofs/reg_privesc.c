/*
 * reg_privesc.c - Registry privilege escalation
 * Checks AlwaysInstallElevated, IFEO, App Paths
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegOpenKeyExA(HKEY, LPCSTR, DWORD, REGSAM, PHKEY);
DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegQueryValueExA(HKEY, LPCSTR, LPDWORD, LPDWORD, LPBYTE, LPDWORD);
DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegCloseKey(HKEY);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    HKEY hKey = NULL;
    DWORD val = 0, valLen = 0, type = 0;

    BeaconPrintf(CALLBACK_OUTPUT, "=== Registry Privesc Scan ===");

    /* AlwaysInstallElevated - HKLM */
    BeaconPrintf(CALLBACK_OUTPUT, "--- AlwaysInstallElevated ---");
    if (ADVAPI32$RegOpenKeyExA(HKEY_LOCAL_MACHINE,
        "SOFTWARE\\Policies\\Microsoft\\Windows\\Installer",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        valLen = sizeof(val);
        if (ADVAPI32$RegQueryValueExA(hKey, "AlwaysInstallElevated", NULL, &type, (LPBYTE)&val, &valLen) == ERROR_SUCCESS) {
            BeaconPrintf(CALLBACK_OUTPUT, "  HKLM AlwaysInstallElevated: %s", val ? "ENABLED" : "Disabled");
            if (val) BeaconPrintf(CALLBACK_OUTPUT, "  → MSI runs as SYSTEM!");
        }
        ADVAPI32$RegCloseKey(hKey);
    }

    /* AlwaysInstallElevated - HKCU */
    if (ADVAPI32$RegOpenKeyExA(HKEY_CURRENT_USER,
        "SOFTWARE\\Policies\\Microsoft\\Windows\\Installer",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        valLen = sizeof(val);
        if (ADVAPI32$RegQueryValueExA(hKey, "AlwaysInstallElevated", NULL, &type, (LPBYTE)&val, &valLen) == ERROR_SUCCESS) {
            BeaconPrintf(CALLBACK_OUTPUT, "  HKCU AlwaysInstallElevated: %s", val ? "ENABLED" : "Disabled");
            if (val) BeaconPrintf(CALLBACK_OUTPUT, "  → MSI runs as SYSTEM!");
        }
        ADVAPI32$RegCloseKey(hKey);
    }

    /* IFEO Debugger check */
    BeaconPrintf(CALLBACK_OUTPUT, "--- IFEO Debugger Entries ---");
    if (ADVAPI32$RegOpenKeyExA(HKEY_LOCAL_MACHINE,
        "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        BeaconPrintf(CALLBACK_OUTPUT, "  IFEO key accessible (check for Debugger entries)");
        ADVAPI32$RegCloseKey(hKey);
    }

    /* App Paths check */
    BeaconPrintf(CALLBACK_OUTPUT, "--- App Paths ---");
    if (ADVAPI32$RegOpenKeyExA(HKEY_LOCAL_MACHINE,
        "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        BeaconPrintf(CALLBACK_OUTPUT, "  App Paths key accessible (check for hijackable paths)");
        ADVAPI32$RegCloseKey(hKey);
    }
}
