/*
 * drives.c - All drives + network shares + UNC paths
 * Sandworm style drive enumeration
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI DWORD WINAPI KERNEL32$GetLogicalDriveStringsA(DWORD, LPSTR);
DECLSPEC_IMPORT WINBASEAPI UINT  WINAPI KERNEL32$GetDriveTypeA(LPCSTR);
DECLSPEC_IMPORT WINBASEAPI BOOL  WINAPI KERNEL32$GetDiskFreeSpaceExA(LPCSTR, PULARGE_INTEGER, PULARGE_INTEGER, PULARGE_INTEGER);
DECLSPEC_IMPORT WINBASEAPI BOOL  WINAPI KERNEL32$GetVolumeInformationA(LPCSTR, LPSTR, DWORD, LPDWORD, LPDWORD, LPDWORD, LPSTR, DWORD);

static int my_strlen(const char* s) {
    volatile int len = 0;
    while (s[len]) len++;
    return (int)len;
}

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    char driveStr[512] = {0};
    DWORD len = KERNEL32$GetLogicalDriveStringsA(sizeof(driveStr), driveStr);
    if (len == 0) {
        BeaconPrintf(CALLBACK_OUTPUT, "No drives found");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "=== Mounted Drives ===");

    char* ptr = driveStr;
    while (*ptr) {
        UINT type = KERNEL32$GetDriveTypeA(ptr);
        const char* typeStr = "Unknown";
        switch (type) {
            case 1: typeStr = "No Root"; break;
            case 2: typeStr = "Removable"; break;
            case 3: typeStr = "Fixed"; break;
            case 4: typeStr = "Remote"; break;
            case 5: typeStr = "CD-ROM"; break;
            case 6: typeStr = "RAM Disk"; break;
        }

        char fsName[32] = {0}, volName[128] = {0};
        DWORD serial = 0, maxComp = 0, fsFlags = 0;
        ULARGE_INTEGER freeBytes = {0}, totalBytes = {0}, availBytes = {0};

        KERNEL32$GetVolumeInformationA(ptr, volName, sizeof(volName), &serial, &maxComp, &fsFlags, fsName, sizeof(fsName));
        KERNEL32$GetDiskFreeSpaceExA(ptr, &availBytes, &totalBytes, &freeBytes);

        BeaconPrintf(CALLBACK_OUTPUT, "  %-4s  %-10s  FS:%-10s  Vol:%s  Size:%lluGB  Free:%lluGB",
            ptr, typeStr, fsName, volName,
            (unsigned long long)(totalBytes.QuadPart / 1073741824),
            (unsigned long long)(availBytes.QuadPart / 1073741824));

        ptr += my_strlen(ptr) + 1;
    }
}
