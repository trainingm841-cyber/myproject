/*
 * arp.c - ARP table with flags support
 * Flags: -a (all), -n (numeric), -v (verbose with type)
 */
#include <windows.h>
#include <iphlpapi.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI DWORD WINAPI IPHLPAPI$GetIpNetTable(PMIB_IPNETTABLE, PULONG, BOOL);

static int my_strcmp(const char* a, const char* b) { while(*a&&*b){if(*a!=*b)return *a-*b; a++;b++;} return *a-*b; }

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    /* Parse args for flags */
    int verbose = 0;
    if (args && args_len > 0) {
        datatype parser;
        BeaconDataParse(&parser, args, args_len);
        /* Try to extract first arg (flag) */
        int remaining = args_len;
        const char* p = args;
        while (remaining > 0 && *p == ' ') { p++; remaining--; }
        if (remaining >= 2 && p[0] == '-' && p[1] == 'v') {
            verbose = 1;
        }
    }

    DWORD dwSize = 0;
    DWORD ret = IPHLPAPI$GetIpNetTable(NULL, &dwSize, FALSE);
    if (ret != ERROR_INSUFFICIENT_BUFFER || dwSize == 0) {
        BeaconPrintf(CALLBACK_OUTPUT, "ARP table empty or error");
        return;
    }

    PMIB_IPNETTABLE pArpTable = (PMIB_IPNETTABLE)HeapAlloc(GetProcessHeap(), 0, dwSize);
    if (!pArpTable) return;

    ret = IPHLPAPI$GetIpNetTable(pArpTable, &dwSize, FALSE);
    if (ret == NO_ERROR) {
        BeaconPrintf(CALLBACK_OUTPUT, "=== ARP Table (%lu entries) ===", pArpTable->dwNumEntries);
        if (verbose) {
            BeaconPrintf(CALLBACK_OUTPUT, "%-16s %-18s %-8s %-12s", "IP", "MAC", "Type", "Index");
        } else {
            BeaconPrintf(CALLBACK_OUTPUT, "%-16s %-18s %s", "IP", "MAC", "Type");
        }

        for (DWORD i = 0; i < pArpTable->dwNumEntries; i++) {
            PMIB_IPNETROW row = &pArpTable->table[i];
            struct in_addr addr; addr.S_un.S_addr = row->dwAddr;

            char macStr[24];
            snprintf(macStr, sizeof(macStr), "%02X-%02X-%02X-%02X-%02X-%02X",
                row->bPhysAddr[0], row->bPhysAddr[1], row->bPhysAddr[2],
                row->bPhysAddr[3], row->bPhysAddr[4], row->bPhysAddr[5]);

            const char* type = "Other";
            if (row->dwType == 1) type = "Dynamic";
            else if (row->dwType == 2) type = "Static";
            else if (row->dwType == 3) type = "Invalid";

            if (verbose) {
                BeaconPrintf(CALLBACK_OUTPUT, "%-16s %-18s %-8s %-12lu",
                    inet_ntoa(addr), macStr, type, row->dwIndex);
            } else {
                BeaconPrintf(CALLBACK_OUTPUT, "%-16s %-18s %s", inet_ntoa(addr), macStr, type);
            }
        }
    }

    HeapFree(GetProcessHeap(), 0, pArpTable);
}
