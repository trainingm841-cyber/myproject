/*
 * svc_audit.c - Service vulnerability audit
 * Finds unquoted paths, weak permissions, interesting services
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI SC_HANDLE WINAPI ADVAPI32$OpenSCManagerA(LPCSTR, LPCSTR, DWORD);
DECLSPEC_IMPORT WINBASEAPI SC_HANDLE WINAPI ADVAPI32$OpenServiceA(SC_HANDLE, LPCSTR, DWORD);
DECLSPEC_IMPORT WINBASEAPI BOOL     WINAPI ADVAPI32$EnumServicesStatusExA(SC_HANDLE, DWORD, DWORD, DWORD, LPBYTE, DWORD, LPDWORD, LPDWORD, LPDWORD, LPCSTR);
DECLSPEC_IMPORT WINBASEAPI BOOL     WINAPI ADVAPI32$QueryServiceConfigA(SC_HANDLE, LPQUERY_SERVICE_CONFIGA, DWORD, LPDWORD);
DECLSPEC_IMPORT WINBASEAPI BOOL     WINAPI ADVAPI32$CloseServiceHandle(SC_HANDLE);

static char* my_strchr(const char* s, char c) {
    while (*s) {
        if (*s == c) return (char*)s;
        s++;
    }
    return NULL;
}

static char* my_strstr(const char* s, const char* find) {
    if (!*find) return (char*)s;
    for (; *s; s++) {
        const char* p = s;
        const char* q = find;
        while (*p && *q && *p == *q) { p++; q++; }
        if (!*q) return (char*)s;
    }
    return NULL;
}

static int my_stricmp(const char* a, const char* b) {
    while (*a && *b) {
        char ca = *a, cb = *b;
        if (ca >= 'a' && ca <= 'z') ca -= 32;
        if (cb >= 'a' && cb <= 'z') cb -= 32;
        if (ca != cb) return ca - cb;
        a++; b++;
    }
    return *a - *b;
}

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    SC_HANDLE hSCM = ADVAPI32$OpenSCManagerA(NULL, NULL, 0x0004);
    if (!hSCM) {
        BeaconPrintf(CALLBACK_OUTPUT, "Failed to open SCM");
        return;
    }

    DWORD bytesNeeded = 0;
    DWORD servicesReturned = 0;
    DWORD resumeHandle = 0;

    ADVAPI32$EnumServicesStatusExA(hSCM, 0, 0x30, 0x03,
        NULL, 0, &bytesNeeded, &servicesReturned, &resumeHandle, NULL);

    if (bytesNeeded == 0) {
        BeaconPrintf(CALLBACK_OUTPUT, "No services found");
        ADVAPI32$CloseServiceHandle(hSCM);
        return;
    }

    BYTE* pBuffer = (BYTE*)HeapAlloc(GetProcessHeap(), 0, bytesNeeded);
    if (!pBuffer) {
        ADVAPI32$CloseServiceHandle(hSCM);
        return;
    }

    if (ADVAPI32$EnumServicesStatusExA(hSCM, 0, 0x30, 0x03,
        pBuffer, bytesNeeded, &bytesNeeded, &servicesReturned, &resumeHandle, NULL)) {

        BeaconPrintf(CALLBACK_OUTPUT, "=== Services (%lu) ===", servicesReturned);

        ENUM_SERVICE_STATUS_PROCESSA* pServices = (ENUM_SERVICE_STATUS_PROCESSA*)pBuffer;
        int unquotedCount = 0;
        int sysCount = 0;

        for (DWORD i = 0; i < servicesReturned; i++) {
            SC_HANDLE hService = ADVAPI32$OpenServiceA(hSCM, pServices[i].lpServiceName, 0x0001);
            if (hService) {
                DWORD cfgLen = 0;
                ADVAPI32$QueryServiceConfigA(hService, NULL, 0, &cfgLen);

                if (cfgLen > 0) {
                    LPQUERY_SERVICE_CONFIGA pCfg = (LPQUERY_SERVICE_CONFIGA)HeapAlloc(GetProcessHeap(), 0, cfgLen);
                    if (pCfg) {
                        if (ADVAPI32$QueryServiceConfigA(hService, pCfg, cfgLen, &cfgLen)) {
                            const char* path = pCfg->lpBinaryPathName;
                            if (path[0] != '"' && my_strchr(path, ' ')) {
                                char* firstSpace = my_strchr(path, ' ');
                                if (firstSpace) {
                                    char* exePos = my_strstr(path, ".exe");
                                    if (exePos && exePos > firstSpace) {
                                        BeaconPrintf(CALLBACK_OUTPUT, "  [UNQUOTED] %-30s %s", pServices[i].lpServiceName, path);
                                        unquotedCount++;
                                    }
                                }
                            }

                            if (pCfg->dwServiceType & 0x10) {
                                if (my_stricmp(pCfg->lpServiceStartName, "LocalSystem") == 0) {
                                    sysCount++;
                                }
                            }
                        }
                        HeapFree(GetProcessHeap(), 0, pCfg);
                    }
                }
                ADVAPI32$CloseServiceHandle(hService);
            }
        }

        BeaconPrintf(CALLBACK_OUTPUT, "--- Summary ---");
        BeaconPrintf(CALLBACK_OUTPUT, "Total services : %lu", servicesReturned);
        BeaconPrintf(CALLBACK_OUTPUT, "Unquoted paths : %d", unquotedCount);
        BeaconPrintf(CALLBACK_OUTPUT, "SYSTEM services: %d", sysCount);
    }

    HeapFree(GetProcessHeap(), 0, pBuffer);
    ADVAPI32$CloseServiceHandle(hSCM);
}
