/*
 * shadow_creds.c - Shadow Credentials check
 * Checks if msDS-KeyCredentialLink can be abused
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI BOOL WINAPI ADVAPI32$OpenProcessToken(HANDLE, DWORD, PHANDLE);
DECLSPEC_IMPORT WINBASEAPI BOOL WINAPI ADVAPI32$GetTokenInformation(HANDLE, TOKEN_INFORMATION_CLASS, LPVOID, DWORD, PDWORD);
DECLSPEC_IMPORT WINBASEAPI BOOL WINAPI ADVAPI32$LookupAccountSidA(LPCSTR, PSID, LPSTR, LPDWORD, LPSTR, LPDWORD, PSID_NAME_USE);
DECLSPEC_IMPORT WINBASEAPI BOOL WINAPI KERNEL32$CloseHandle(HANDLE);
DECLSPEC_IMPORT WINBASEAPI HANDLE WINAPI KERNEL32$GetCurrentProcess(void);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    BeaconPrintf(CALLBACK_OUTPUT, "=== Shadow Credentials Check ===");

    /* Check current user context */
    HANDLE hToken = NULL;
    if (!ADVAPI32$OpenProcessToken(KERNEL32$GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
        BeaconPrintf(CALLBACK_OUTPUT, "Failed to open process token");
        return;
    }

    char tokenBuf[512] = {0};
    DWORD retLen = 0;
    if (ADVAPI32$GetTokenInformation(hToken, TokenUser, tokenBuf, sizeof(tokenBuf), &retLen)) {
        TOKEN_USER* tu = (TOKEN_USER*)tokenBuf;
        char name[128] = {0}, domain[128] = {0};
        DWORD nameLen = sizeof(name), domLen = sizeof(domain);
        SID_NAME_USE sidType;
        ADVAPI32$LookupAccountSidA(NULL, tu->User.Sid, name, &nameLen, domain, &domLen, &sidType);

        BeaconPrintf(CALLBACK_OUTPUT, "Current user: %s\\%s", domain, name);
    }

    /* Check for domain membership */
    BeaconPrintf(CALLBACK_OUTPUT, "");
    BeaconPrintf(CALLBACK_OUTPUT, "Shadow Credentials Requirements:");
    BeaconPrintf(CALLBACK_OUTPUT, "  1. Domain-joined machine (need AD)");
    BeaconPrintf(CALLBACK_OUTPUT, "  2. Write access to target's AD object");
    BeaconPrintf(CALLBACK_OUTPUT, "  3. PKINIT support (Windows 10+ DC)");
    BeaconPrintf(CALLBACK_OUTPUT, "");
    BeaconPrintf(CALLBACK_OUTPUT, "Attack Steps:");
    BeaconPrintf(CALLBACK_OUTPUT, "  Step 1: Generate RSA key pair");
    BeaconPrintf(CALLBACK_OUTPUT, "  Step 2: Create KeyCredential blob");
    BeaconPrintf(CALLBACK_OUTPUT, "  Step 3: LDAP write msDS-KeyCredentialLink");
    BeaconPrintf(CALLBACK_OUTPUT, "  Step 4: PKINIT → get TGT");
    BeaconPrintf(CALLBACK_OUTPUT, "  Step 5: UnPAC → NTLM hash");
    BeaconPrintf(CALLBACK_OUTPUT, "");
    BeaconPrintf(CALLBACK_OUTPUT, "Full exploitation requires LDAP + Crypto APIs");
    BeaconPrintf(CALLBACK_OUTPUT, "Run from domain-joined machine with GenericWrite");

    KERNEL32$CloseHandle(hToken);
}
