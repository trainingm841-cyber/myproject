/*
 * pipe_hunt.c - Named pipe enumeration
 * Finds privesc vectors and IPC channels
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI HANDLE WINAPI KERNEL32$CreateFileA(LPCSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI KERNEL32$CloseHandle(HANDLE);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    BeaconPrintf(CALLBACK_OUTPUT, "=== Named Pipes ===");

    /* Known interesting pipes for privesc */
    const char* knownPipes[] = {
        "\\\\.\\pipe\\spoolss",
        "\\\\.\\pipe\\epmapper",
        "\\\\.\\pipe\\lsass",
        "\\\\.\\pipe\\atsvc",
        "\\\\.\\pipe\\scerpc",
        "\\\\.\\pipe\\NETLOGON",
        "\\\\.\\pipe\\wkssvc",
        "\\\\.\\pipe\\srvsvc",
        "\\\\.\\pipe\\samr",
        "\\\\.\\pipe\\InitShutdown",
        NULL
    };

    BeaconPrintf(CALLBACK_OUTPUT, "--- Known System Pipes ---");
    for (int i = 0; knownPipes[i]; i++) {
        HANDLE hPipe = KERNEL32$CreateFileA(knownPipes[i], GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
        if (hPipe != INVALID_HANDLE_VALUE) {
            BeaconPrintf(CALLBACK_OUTPUT, "  [EXISTS] %s", knownPipes[i]);
            KERNEL32$CloseHandle(hPipe);
        }
    }

    BeaconPrintf(CALLBACK_OUTPUT, "--- Custom/Application Pipes ---");
    /* Check common app pipes */
    const char* appPipes[] = {
        "\\\\.\\pipe\\SQLLocal\\MSSQL$SQLEXPRESS",
        "\\\\.\\pipe\\sql\\query",
        "\\\\.\\pipe\\jenkins",
        "\\\\.\\pipe\\Chrome.4521.0",
        "\\\\.\\pipe\\MSSE-1504-server",
        NULL
    };

    for (int i = 0; appPipes[i]; i++) {
        HANDLE hPipe = KERNEL32$CreateFileA(appPipes[i], GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
        if (hPipe != INVALID_HANDLE_VALUE) {
            BeaconPrintf(CALLBACK_OUTPUT, "  [EXISTS] %s", appPipes[i]);
            KERNEL32$CloseHandle(hPipe);
        }
    }
}
