/*
 * task_scout.c - Scheduled tasks enumeration
 * Finds persistence and privesc opportunities
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegOpenKeyExA(HKEY, LPCSTR, DWORD, REGSAM, PHKEY);
DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegEnumKeyExA(HKEY, DWORD, LPSTR, LPDWORD, LPDWORD, LPSTR, LPDWORD, PFILETIME);
DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegQueryValueExA(HKEY, LPCSTR, LPDWORD, LPDWORD, LPBYTE, LPDWORD);
DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegCloseKey(HKEY);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    HKEY hKey = NULL;
    LONG ret = ADVAPI32$RegOpenKeyExA(HKEY_LOCAL_MACHINE,
        "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache\\Tasks",
        0, KEY_READ, &hKey);

    if (ret != ERROR_SUCCESS) {
        BeaconPrintf(CALLBACK_OUTPUT, "Failed to open scheduled tasks cache");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "=== Scheduled Tasks ===");

    int count = 0;
    DWORD index = 0;
    char subKeyName[256];
    DWORD subKeyLen;

    while (1) {
        subKeyLen = sizeof(subKeyName);
        ret = ADVAPI32$RegEnumKeyExA(hKey, index, subKeyName, &subKeyLen,
                                       NULL, NULL, NULL, NULL);
        if (ret != ERROR_SUCCESS) break;

        /* Try to read the task path from the subkey */
        HKEY hSubKey = NULL;
        ret = ADVAPI32$RegOpenKeyExA(hKey, subKeyName, 0, KEY_READ, &hSubKey);
        if (ret == ERROR_SUCCESS) {
            char path[512] = {0};
            DWORD pathLen = sizeof(path);
            DWORD type = 0;

            ret = ADVAPI32$RegQueryValueExA(hSubKey, "Path", NULL, &type, (LPBYTE)path, &pathLen);
            if (ret == ERROR_SUCCESS && pathLen > 0) {
                /* Try to extract readable task name from the binary path */
                BeaconPrintf(CALLBACK_OUTPUT, "  Task %d: %s", count, subKeyName);
            }
            ADVAPI32$RegCloseKey(hSubKey);
        }
        count++;
        index++;
    }

    ADVAPI32$RegCloseKey(hKey);
    BeaconPrintf(CALLBACK_OUTPUT, "Total: %d tasks found", count);
}
