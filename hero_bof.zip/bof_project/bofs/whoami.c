/*
 * whoami.c - Current user info (username, SID, groups)
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI BOOL  WINAPI ADVAPI32$GetUserNameA(LPSTR, LPDWORD);
DECLSPEC_IMPORT WINBASEAPI BOOL  WINAPI ADVAPI32$LookupAccountNameA(LPCSTR, LPCSTR, PSID, LPDWORD, LPSTR, LPDWORD, PSID_NAME_USE);
DECLSPEC_IMPORT WINBASEAPI BOOL  WINAPI ADVAPI32$ConvertSidToStringSidA(PSID, LPSTR*);
DECLSPEC_IMPORT WINBASEAPI BOOL  WINAPI KERNEL32$LocalFree(HLOCAL);

static int my_strlen(const char* s) { volatile int l=0; while(s[l])l++; return (int)l; }
static int my_strcmp(const char* a, const char* b) { while(*a&&*b){if(*a!=*b)return *a-*b; a++;b++;} return *a-*b; }

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    char username[256] = {0};
    DWORD ulen = sizeof(username);
    ADVAPI32$GetUserNameA(username, &ulen);

    /* Get SID */
    BYTE sidBuf[256] = {0};
    DWORD sidLen = sizeof(sidBuf);
    char domain[256] = {0};
    DWORD domLen = sizeof(domain);
    SID_NAME_USE sidType;

    ADVAPI32$LookupAccountNameA(NULL, username, (PSID)sidBuf, &sidLen, domain, &domLen, &sidType);

    LPSTR sidStr = NULL;
    ADVAPI32$ConvertSidToStringSidA((PSID)sidBuf, &sidStr);

    BeaconPrintf(CALLBACK_OUTPUT, "Username : %s\\%s", domain, username);
    if (sidStr) {
        BeaconPrintf(CALLBACK_OUTPUT, "SID      : %s", sidStr);
        KERNEL32$LocalFree(sidStr);
    }
}
