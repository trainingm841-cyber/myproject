/*
 * token_scan.c - Process token enumeration
 * Finds impersonation opportunities across processes
 */
#include <windows.h>
#include <stdio.h>
#include <tlhelp32.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI HANDLE WINAPI KERNEL32$CreateToolhelp32Snapshot(DWORD, DWORD);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI KERNEL32$Process32FirstW(HANDLE, LPPROCESSENTRY32W);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI KERNEL32$Process32NextW(HANDLE, LPPROCESSENTRY32W);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI KERNEL32$CloseHandle(HANDLE);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI ADVAPI32$OpenProcessToken(HANDLE, DWORD, PHANDLE);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI ADVAPI32$GetTokenInformation(HANDLE, TOKEN_INFORMATION_CLASS, LPVOID, DWORD, PDWORD);
DECLSPEC_IMPORT WINBASEAPI HANDLE WINAPI KERNEL32$OpenProcess(DWORD, BOOL, DWORD);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI ADVAPI32$LookupAccountSidA(LPCSTR, PSID, LPSTR, LPDWORD, LPSTR, LPDWORD, PSID_NAME_USE);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    HANDLE hSnap = KERNEL32$CreateToolhelp32Snapshot(0x00000002, 0);
    if (hSnap == INVALID_HANDLE_VALUE) {
        BeaconPrintf(CALLBACK_OUTPUT, "Failed to create process snapshot");
        return;
    }

    PROCESSENTRY32W pe;
    memset(&pe, 0, sizeof(pe));
    pe.dwSize = sizeof(PROCESSENTRY32W);

    BeaconPrintf(CALLBACK_OUTPUT, "=== Process Token Scan ===");
    BeaconPrintf(CALLBACK_OUTPUT, "%-8s %-30s %s", "PID", "Name", "User");

    if (KERNEL32$Process32FirstW(hSnap, &pe)) {
        do {
            HANDLE hProc = KERNEL32$OpenProcess(0x0400, FALSE, pe.th32ProcessID);
            if (hProc) {
                HANDLE hToken = NULL;
                if (ADVAPI32$OpenProcessToken(hProc, 0x0008, &hToken)) {
                    char userBuf[512] = {0};
                    DWORD retLen = 0;
                    if (ADVAPI32$GetTokenInformation(hToken, TokenUser, userBuf, sizeof(userBuf), &retLen)) {
                        TOKEN_USER* tu = (TOKEN_USER*)userBuf;
                        char name[128] = {0}, domain[128] = {0};
                        DWORD nameLen = sizeof(name), domLen = sizeof(domain);
                        SID_NAME_USE sidType;
                        ADVAPI32$LookupAccountSidA(NULL, tu->User.Sid, name, &nameLen, domain, &domLen, &sidType);

                        /* Convert wide name to narrow for output */
                        char exeName[256] = {0};
                        WideCharToMultiByte(CP_ACP, 0, pe.szExeFile, -1, exeName, sizeof(exeName), NULL, NULL);

                        BeaconPrintf(CALLBACK_OUTPUT, "%-8lu %-30s %s\\%s",
                            pe.th32ProcessID, exeName, domain, name);
                    }
                    KERNEL32$CloseHandle(hToken);
                }
                KERNEL32$CloseHandle(hProc);
            }
        } while (KERNEL32$Process32NextW(hSnap, &pe));
    }

    KERNEL32$CloseHandle(hSnap);
}
