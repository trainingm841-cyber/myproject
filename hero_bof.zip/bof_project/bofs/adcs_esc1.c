/*
 * adcs_esc1.c - ADCS ESC1 vulnerability check
 * Checks for vulnerable certificate templates
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegOpenKeyExA(HKEY, LPCSTR, DWORD, REGSAM, PHKEY);
DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegQueryValueExA(HKEY, LPCSTR, LPDWORD, LPDWORD, LPBYTE, LPDWORD);
DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegCloseKey(HKEY);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    BeaconPrintf(CALLBACK_OUTPUT, "=== ADCS ESC1 Check ===");

    /* Check if ADCS is installed */
    HKEY hKey = NULL;
    if (ADVAPI32$RegOpenKeyExA(HKEY_LOCAL_MACHINE,
        "SYSTEM\\CurrentControlSet\\Services\\CertSvc",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {

        BeaconPrintf(CALLBACK_OUTPUT, "ADCS Service: INSTALLED");

        /* Check for CA configuration */
        char caName[256] = {0};
        DWORD caLen = sizeof(caName);
        DWORD type = 0;
        if (ADVAPI32$RegQueryValueExA(hKey, "Active", NULL, &type, (LPBYTE)caName, &caLen) == ERROR_SUCCESS) {
            BeaconPrintf(CALLBACK_OUTPUT, "CA Active: %s", caName);
        }
        ADVAPI32$RegCloseKey(hKey);
    } else {
        BeaconPrintf(CALLBACK_OUTPUT, "ADCS Service: NOT INSTALLED");
        BeaconPrintf(CALLBACK_OUTPUT, "ESC1 not applicable on this host");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "");
    BeaconPrintf(CALLBACK_OUTPUT, "ESC1 Conditions to check (requires AD access):");
    BeaconPrintf(CALLBACK_OUTPUT, "  1. Template allows SAN (ENROLLEE_SUPPLIES_SUBJECT)");
    BeaconPrintf(CALLBACK_OUTPUT, "  2. Client Authentication EKU present");
    BeaconPrintf(CALLBACK_OUTPUT, "  3. Low-priv user can enroll");
    BeaconPrintf(CALLBACK_OUTPUT, "");
    BeaconPrintf(CALLBACK_OUTPUT, "Full ADCS ESC1 exploitation requires LDAP queries");
    BeaconPrintf(CALLBACK_OUTPUT, "Use from domain-joined machine with AD access");
}
