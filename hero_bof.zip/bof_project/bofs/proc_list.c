/*
 * proc_list.c - Process list enumeration
 */
#include <windows.h>
#include <stdio.h>
#include <tlhelp32.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI HANDLE WINAPI KERNEL32$CreateToolhelp32Snapshot(DWORD, DWORD);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI KERNEL32$Process32FirstW(HANDLE, LPPROCESSENTRY32W);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI KERNEL32$Process32NextW(HANDLE, LPPROCESSENTRY32W);
DECLSPEC_IMPORT WINBASEAPI BOOL   WINAPI KERNEL32$CloseHandle(HANDLE);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    HANDLE hSnap = KERNEL32$CreateToolhelp32Snapshot(0x00000002, 0);
    if (hSnap == INVALID_HANDLE_VALUE) {
        BeaconPrintf(CALLBACK_OUTPUT, "Failed to create process snapshot");
        return;
    }

    PROCESSENTRY32W pe;
    memset(&pe, 0, sizeof(pe));
    pe.dwSize = sizeof(PROCESSENTRY32W);

    BeaconPrintf(CALLBACK_OUTPUT, "=== Process List ===");
    BeaconPrintf(CALLBACK_OUTPUT, "%-8s %-8s %s", "PID", "PPID", "Name");

    int count = 0;
    if (KERNEL32$Process32FirstW(hSnap, &pe)) {
        do {
            char exeName[256] = {0};
            WideCharToMultiByte(CP_ACP, 0, pe.szExeFile, -1, exeName, sizeof(exeName), NULL, NULL);
            BeaconPrintf(CALLBACK_OUTPUT, "%-8lu %-8lu %s", pe.th32ProcessID, pe.th32ParentProcessID, exeName);
            count++;
        } while (KERNEL32$Process32NextW(hSnap, &pe));
    }

    BeaconPrintf(CALLBACK_OUTPUT, "Total: %d processes", count);
    KERNEL32$CloseHandle(hSnap);
}
