/*
 * netstat.c - Network connections (TCP/UDP)
 */
#include <windows.h>
#include <iphlpapi.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI DWORD WINAPI IPHLPAPI$GetExtendedTcpTable(PVOID, PDWORD, BOOL, ULONG, TCP_TABLE_CLASS, ULONG);
DECLSPEC_IMPORT WINBASEAPI DWORD WINAPI IPHLPAPI$GetExtendedUdpTable(PVOID, PDWORD, BOOL, ULONG, UDP_TABLE_CLASS, ULONG);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    DWORD tcpSize = 0;
    IPHLPAPI$GetExtendedTcpTable(NULL, &tcpSize, FALSE, 2, TCP_TABLE_OWNER_PID_ALL, 0);
    if (tcpSize > 0) {
        PMIB_TCPTABLE_OWNER_PID pTcp = (PMIB_TCPTABLE_OWNER_PID)HeapAlloc(GetProcessHeap(), 0, tcpSize);
        if (pTcp && IPHLPAPI$GetExtendedTcpTable(pTcp, &tcpSize, FALSE, 2, TCP_TABLE_OWNER_PID_ALL, 0) == NO_ERROR) {
            BeaconPrintf(CALLBACK_OUTPUT, "=== TCP Connections (%lu) ===", pTcp->dwNumEntries);
            BeaconPrintf(CALLBACK_OUTPUT, "%-6s %-22s %-22s %-8s", "Proto", "Local", "Remote", "PID");
            for (DWORD i = 0; i < pTcp->dwNumEntries; i++) {
                DWORD lAddr = pTcp->table[i].dwLocalAddr;
                DWORD lPort = ntohs((USHORT)(pTcp->table[i].dwLocalPort >> 8));
                DWORD rAddr = pTcp->table[i].dwRemoteAddr;
                DWORD rPort = ntohs((USHORT)(pTcp->table[i].dwRemotePort >> 8));

                struct in_addr la, ra;
                la.S_un.S_addr = lAddr; ra.S_un.S_addr = rAddr;

                BeaconPrintf(CALLBACK_OUTPUT, "TCP    %d.%d.%d.%d:%-5d     %d.%d.%d.%d:%-5d     %lu",
                    la.S_un.S_un_b.s_b1, la.S_un.S_un_b.s_b2, la.S_un.S_un_b.s_b3, la.S_un.S_un_b.s_b4, lPort,
                    ra.S_un.S_un_b.s_b1, ra.S_un.S_un_b.s_b2, ra.S_un.S_un_b.s_b3, ra.S_un.S_un_b.s_b4, rPort,
                    pTcp->table[i].dwOwningPid);
            }
            HeapFree(GetProcessHeap(), 0, pTcp);
        }
    }

    DWORD udpSize = 0;
    IPHLPAPI$GetExtendedUdpTable(NULL, &udpSize, FALSE, 2, UDP_TABLE_OWNER_PID, 0);
    if (udpSize > 0) {
        PMIB_UDPTABLE_OWNER_PID pUdp = (PMIB_UDPTABLE_OWNER_PID)HeapAlloc(GetProcessHeap(), 0, udpSize);
        if (pUdp && IPHLPAPI$GetExtendedUdpTable(pUdp, &udpSize, FALSE, 2, UDP_TABLE_OWNER_PID, 0) == NO_ERROR) {
            BeaconPrintf(CALLBACK_OUTPUT, "=== UDP Listeners (%lu) ===", pUdp->dwNumEntries);
            for (DWORD i = 0; i < pUdp->dwNumEntries; i++) {
                DWORD lAddr = pUdp->table[i].dwLocalAddr;
                DWORD lPort = ntohs((USHORT)(pUdp->table[i].dwLocalPort >> 8));
                struct in_addr la; la.S_un.S_addr = lAddr;
                BeaconPrintf(CALLBACK_OUTPUT, "UDP    %d.%d.%d.%d:%d    PID:%lu",
                    la.S_un.S_un_b.s_b1, la.S_un.S_un_b.s_b2, la.S_un.S_un_b.s_b3, la.S_un.S_un_b.s_b4, lPort,
                    pUdp->table[i].dwOwningPid);
            }
            HeapFree(GetProcessHeap(), 0, pUdp);
        }
    }
}
