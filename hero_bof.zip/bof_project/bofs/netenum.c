/*
 * netenum.c - Network enumeration (domain computers + shares)
 */
#include <windows.h>
#include <lm.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI NET_API_STATUS WINAPI NETAPI32$NetServerEnum(LPCWSTR, DWORD, LPBYTE*, DWORD, LPDWORD, LPDWORD, DWORD, LPCWSTR, LPDWORD);
DECLSPEC_IMPORT WINBASEAPI NET_API_STATUS WINAPI NETAPI32$NetShareEnum(LPCWSTR, DWORD, LPBYTE*, DWORD, LPDWORD, LPDWORD, LPDWORD);
DECLSPEC_IMPORT WINBASEAPI NET_API_STATUS WINAPI NETAPI32$NetApiBufferFree(LPVOID);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    /* Enumerate domain computers */
    LPSERVER_INFO_101 pBuf = NULL;
    DWORD entriesRead = 0, totalEntries = 0;
    DWORD resumeHandle = 0;

    NET_API_STATUS status = NETAPI32$NetServerEnum(NULL, 101, (LPBYTE*)&pBuf, MAX_PREFERRED_LENGTH,
        &entriesRead, &totalEntries, SV_TYPE_ALL, NULL, &resumeHandle);

    if (status == NERR_Success || status == ERROR_MORE_DATA) {
        BeaconPrintf(CALLBACK_OUTPUT, "=== Network Computers (%lu) ===", entriesRead);
        for (DWORD i = 0; i < entriesRead; i++) {
            char name[128] = {0};
            WideCharToMultiByte(CP_ACP, 0, pBuf[i].sv101_name, -1, name, sizeof(name), NULL, NULL);
            BeaconPrintf(CALLBACK_OUTPUT, "  %s", name);
        }
        NETAPI32$NetApiBufferFree(pBuf);
    } else {
        BeaconPrintf(CALLBACK_OUTPUT, "NetServerEnum failed (error %lu)", status);
    }

    /* Enumerate local shares */
    LPSHARE_INFO_1 pShare = NULL;
    entriesRead = 0; totalEntries = 0;

    status = NETAPI32$NetShareEnum(NULL, 1, (LPBYTE*)&pShare, MAX_PREFERRED_LENGTH,
        &entriesRead, &totalEntries, NULL);

    if (status == NERR_Success || status == ERROR_MORE_DATA) {
        BeaconPrintf(CALLBACK_OUTPUT, "=== Local Shares (%lu) ===", entriesRead);
        for (DWORD i = 0; i < entriesRead; i++) {
            char name[128] = {0}, remark[256] = {0};
            WideCharToMultiByte(CP_ACP, 0, pShare[i].shi1_netname, -1, name, sizeof(name), NULL, NULL);
            if (pShare[i].shi1_remark) {
                WideCharToMultiByte(CP_ACP, 0, pShare[i].shi1_remark, -1, remark, sizeof(remark), NULL, NULL);
            }
            BeaconPrintf(CALLBACK_OUTPUT, "  %-20s %-30s Type:%lu", name, remark[0] ? remark : "(none)", pShare[i].shi1_type);
        }
        NETAPI32$NetApiBufferFree(pShare);
    }
}
