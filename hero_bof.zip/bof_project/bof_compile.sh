#!/usr/bin/env bash
# ============================================================
#  bof_compile.sh - Compile all BOF .c files into .o (COFF AMD64)
#
#  Auto-finds all *.c in ./bofs/ and compiles each to dist/*.x64.o
#
#  Usage:
#    ./bof_compile.sh                # compile all BOFs
#    ./bof_compile.sh bof_whoami     # compile one specific BOF
#    ./bof_compile.sh --imp          # use __imp_ mode (CS-style)
# ============================================================

set -uo pipefail

# ---------- colors ----------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log()  { echo -e "${CYAN}[*]${NC} $*"; }
ok()   { echo -e "${GREEN}[+]${NC} $*"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"; }
err()  { echo -e "${RED}[X]${NC} $*" >&2; }

# ---------- args ----------
USE_IMP=0
SPECIFIC=""
for arg in "$@"; do
    case "$arg" in
        --imp) USE_IMP=1 ;;
        -h|--help)
            head -15 "$0" | tail -12
            exit 0
            ;;
        *)
            if [ -z "$SPECIFIC" ]; then SPECIFIC="$arg"; fi
            ;;
    esac
done

# ---------- locate compiler ----------
CC=""
CC_KIND=""

# 1) MinGW-w64 cross-compiler
for cand in x86_64-w64-mingw32-gcc x86_64-w64-mingw32-gcc-posix mingw-w64-x86_64-gcc; do
    if command -v "$cand" >/dev/null 2>&1; then
        CC="$cand"
        CC_KIND="mingw"
        break
    fi
done

# 2) Zig (portable)
if [ -z "$CC" ]; then
    for cand in zig /usr/local/bin/zig /opt/zig/zig "$HOME/zig/zig"; do
        if command -v "$cand" >/dev/null 2>&1; then
            if "$cand" cc --version >/dev/null 2>&1; then
                CC="$cand cc"
                CC_KIND="zig"
                break
            fi
        fi
    done
fi

# 3) Native Windows gcc (MSYS2)
if [ -z "$CC" ]; then
    if command -v gcc >/dev/null 2>&1; then
        if gcc -dumpmachine 2>/dev/null | grep -qi 'w64-mingw'; then
            CC="gcc"
            CC_KIND="native"
        fi
    fi
fi

if [ -z "$CC" ]; then
    err "No MinGW-w64 or Zig compiler found on PATH"
    cat <<EOM

Install one of:

  # MinGW-w64 cross-compiler (Linux/WSL)
    sudo apt install gcc-mingw-w64-x86-64

  # MSYS2 / Git Bash on Windows
    pacman -S mingw-w64-x86_64-gcc

  # OR Zig (single binary)
    https://ziglang.org/download/

EOM
    exit 1
fi

ok "Compiler: $CC  (mode: $CC_KIND)"

# Build target flag
case "$CC_KIND" in
    mingw)  TARGET_FLAG="" ;;
    zig)    TARGET_FLAG="-target x86_64-windows-gnu" ;;
    native) TARGET_FLAG="" ;;
esac

# ---------- paths ----------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BOFS_DIR="$SCRIPT_DIR/bofs"
DIST_DIR="$SCRIPT_DIR/dist"
mkdir -p "$DIST_DIR"

if [ ! -d "$BOFS_DIR" ]; then
    err "bofs/ directory not found at: $BOFS_DIR"
    exit 1
fi

# ---------- gather sources ----------
if [ -n "$SPECIFIC" ]; then
    if [[ "$SPECIFIC" == *.c ]]; then
        SOURCES=("$BOFS_DIR/$SPECIFIC")
    else
        SOURCES=("$BOFS_DIR/${SPECIFIC}.c")
    fi
    if [ ! -f "${SOURCES[0]}" ]; then
        err "Specified BOF not found: ${SOURCES[0]}"
        exit 1
    fi
else
    mapfile -t SOURCES < <(find "$BOFS_DIR" -maxdepth 1 -type f -name '*.c' | sort)
fi

if [ "${#SOURCES[@]}" -eq 0 ]; then
    warn "No *.c BOF sources found in $BOFS_DIR"
    exit 0
fi

log "Found ${#SOURCES[@]} BOF source file(s):"
for s in "${SOURCES[@]}"; do
    echo "    - $(basename "$s")"
done
echo

# ---------- compile flags ----------
# DEFAULT: use __declspec(dllimport) mode (generates __imp_ symbols + IAT slots)
#   - This is the CORRECT mode for BOFs - matches Cobalt Strike convention
#   - Calls are indirect: call [rip+disp] -> IAT slot -> function pointer
#   - Loader fills IAT slot with function address (no 2GB range issue)
#
# Use --plain flag for plain mode (no dllimport, direct calls)
#   - ONLY works for functions within 2GB of BOF code (rarely the case)
#   - Will cause "Rel32 out of range" errors for Windows DLL functions
if [ "$USE_IMP" -eq 1 ]; then
    # --imp flag means "use __imp_ mode" (the default, but explicit)
    DEFINES=""
    log "Compile mode: __imp_ (DEFAULT, Cobalt Strike style)"
else
    DEFINES=""
    log "Compile mode: __imp_ (DEFAULT, Cobalt Strike style)"
fi

CFLAGS="$TARGET_FLAG -Wall -O2 -shared -fno-stack-protector -masm=intel $DEFINES"

# ---------- compile loop ----------
TOTAL=${#SOURCES[@]}
SUCCESS=0
FAILED=0
FAILED_LIST=()

i=0
for src in "${SOURCES[@]}"; do
    i=$((i+1))
    name="$(basename "$src" .c)"
    out="$DIST_DIR/${name}.x64.o"

    echo -e "${CYAN}[$i/$TOTAL]${NC} Compiling $name.c ..."

    if $CC $CFLAGS -c "$src" -o "$out" 2> /tmp/bof_compile_$$.err; then
        if command -v file >/dev/null 2>&1; then
            ftype=$(file -b "$out" 2>/dev/null)
            # Match: "x86-64", "x86_64", "AMD64", "COFF object" (case-insensitive)
            # Old buggy pattern only matched 'x86_64' (underscore), but `file` outputs 'x86-64' (hyphen)
            if echo "$ftype" | grep -qiE 'x86.64|AMD64|COFF object'; then
                sz=$(stat -c%s "$out" 2>/dev/null || stat -f%z "$out" 2>/dev/null)
                ok "Built: ${name}.x64.o ($sz bytes)"
                SUCCESS=$((SUCCESS+1))
            else
                warn "Built but type looks off: $ftype"
                FAILED=$((FAILED+1))
                FAILED_LIST+=("$name (bad COFF type)")
            fi
        else
            sz=$(stat -c%s "$out" 2>/dev/null || stat -f%z "$out" 2>/dev/null)
            ok "Built: ${name}.x64.o ($sz bytes)"
            SUCCESS=$((SUCCESS+1))
        fi
    else
        err "Failed to compile $name.c"
        sed 's/^/      /' /tmp/bof_compile_$$.err | head -20
        FAILED=$((FAILED+1))
        FAILED_LIST+=("$name")
    fi
    rm -f /tmp/bof_compile_$$.err
done

# ---------- summary ----------
echo
echo "=============================================="
echo -e "  Total   : $TOTAL"
echo -e "  ${GREEN}Success : $SUCCESS${NC}"
if [ "$FAILED" -gt 0 ]; then
    echo -e "  ${RED}Failed  : $FAILED${NC}"
    for f in "${FAILED_LIST[@]}"; do
        echo "    - $f"
    done
else
    echo -e "  ${RED}Failed  : 0${NC}"
fi
echo "=============================================="
echo "  Output dir: $DIST_DIR"
ls -la "$DIST_DIR"/*.o 2>/dev/null | awk '{printf "    %8d  %s\n", $5, $9}'
echo "=============================================="

[ "$FAILED" -gt 0 ] && exit 1 || exit 0
